$(window).resize(function()){
	$("fla").append("<div>"+(window).width()+"</div>")
}