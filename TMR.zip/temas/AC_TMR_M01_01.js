(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"AC_TMR_M01_01_atlas_", frames: [[0,0,735,551]]}
];


// symbols:



(lib.Módulo1 = function() {
	this.initialize(ss["AC_TMR_M01_01_atlas_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.ventana3mod1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F3F3F3").s().p("EA5rAc+IndAAIhqAAMgmnAAAIngAAIh4AAIjbAAIkEAAIuTAAIpeAAI00AAIr1AAQggAAgbgIQhbgZAAh2MAAAgzDMCDVAAAIAABJIAABnIAADPIAAG5IAABFIAACvIAAAEIAAEGIAAC+IAAFvIAACCIAAGLIAAItIAACmIAAAAIAAA2IAABKQAACWiWABgEhBqgYcIAAg5IAAg6IAAgXQAAh2BbgZQAagHAhgBIL1AAIU0AAIXxAAIEEAAIFTAAIHgAAMAmnAAAIBqAAINHAAQAsAAAbALQBPAhAABrIAAAXIAAA6IAAA5g");
	this.shape.setTransform(380.475,216.85);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-39.8,31.5,840.5999999999999,370.7);


(lib.ventana1mod1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F3F3F3").s().p("EA5rAc+IndAAIhqAAMgmnAAAIngAAIh4AAIjbAAIkEAAIuTAAIpeAAI00AAIr1AAQggAAgbgIQhbgZAAh2MAAAgzDMCDVAAAIAABJIAABnIAADPIAAG5IAABFIAACvIAAAEIAAEGIAAC+IAAFvIAACCIAAGLIAAItIAACmIAAAAIAAA2IAABKQAACWiWABgEhBqgYcIAAg5IAAg6IAAgXQAAh2BbgZQAagHAhgBIL1AAIU0AAIXxAAIEEAAIFTAAIHgAAMAmnAAAIBqAAINHAAQAsAAAbALQBPAhAABrIAAAXIAAA6IAAA5g");
	this.shape.setTransform(380.475,216.85);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-39.8,31.5,840.5999999999999,370.7);


(lib.txtprimertextogde = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.text = new cjs.Text("También llamado Talent Management Review (TMR), es un proceso a través del cual los líderes de negocio aseguran contar con una oferta sostenible de talento adecuado, disponible en el lugar y el momento para satisfacer sus objetivos de negocio de corto y largo plazo.\n", "17px 'Arial'", "#333333");
	this.text.lineHeight = 19;
	this.text.lineWidth = 457;
	this.text.parent = this;
	this.text.setTransform(9,66);

	this.timeline.addTween(cjs.Tween.get(this.text).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(7,64,461.2,137);


(lib.txt_modulo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D73D45").s().p("AhABzQgfgQgQgdQgQgeAAgqQAAgiAQgeQAQgfAegQQAegQAjAAQA5AAAjAlQAlAlgBA3QABA4glAlQglAlg3AAQghAAgfgPgAgqg3QgSATAAAkQAAAlASAUQASATAYABQAagBASgTQARgUAAglQAAgkgRgTQgSgVgaABQgYgBgSAVg");
	this.shape.setTransform(157.9,33);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#D73D45").s().p("AggCsIAAlXIBBAAIAAFXg");
	this.shape_1.setTransform(136.6,28.275);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#D73D45").s().p("AhKB0QgUgLgJgUQgJgTAAgkIAAicIBCAAIAAByQAAA0ADAMQAEALAKAHQAJAHAPAAQAQAAANgJQAOgJAEgOQAFgOAAg0IAAhpIBCAAIAAD4Ig9AAIAAgmQgOAUgWAMQgVALgYAAQgaAAgTgLg");
	this.shape_2.setTransform(115.175,33.275);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#D73D45").s().p("AhZCMQgggjAAg9QAAg/AfggQAdgiAtAAQApAAAfAjIAAh8IBBAAIAAFXIg8AAIAAglQgQAWgUALQgVAKgUgBQgrAAgegigAglgPQgQARAAAlQAAAoALASQAQAZAcAAQAWABAQgUQAQgTAAgmQAAgrgQgSQgPgTgYAAQgWAAgQATg");
	this.shape_3.setTransform(85.35,28.55);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#D73D45").s().p("AhACiQgfgPgQgeQgRgeAAgrQAAghARgeQAQgeAegQQAdgQAkgBQA4ABAlAkQAjAlABA3QgBA4gjAlQglAmg3gBQgiAAgfgPgAgqgIQgSASAAAmQAAAkASAVQASATAYAAQAaAAARgTQASgUAAgmQAAglgSgSQgRgUgaAAQgYAAgSAUgAgghrIAghFIBJAAIhBBFg");
	this.shape_4.setTransform(56.7,28.25);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#D73D45").s().p("ABlCsIAAkOIhEEOIhCAAIhDkOIAAEOIhBAAIAAlXIBoAAIA9DqIA+jqIBoAAIAAFXg");
	this.shape_5.setTransform(22,28.275);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.txt_modulo, new cjs.Rectangle(0,0,174.7,57.6), null);


(lib.tituloestatica = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// TITULO
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgaAaQgLgKAAgQQAAgOALgLQAMgLAOAAQAPAAALALQALALAAAOQAAAQgLAKQgLALgPAAQgOAAgMgLg");
	this.shape.setTransform(-293.7,-228.975);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#D73D45").s().p("AgtAuQgTgTAAgbQAAgaATgTQATgTAaAAQAbAAATATQATATAAAaQAAAbgTATQgTATgbAAQgaAAgTgTg");
	this.shape_1.setTransform(-293.775,-229.1);

	this.text = new cjs.Text("¿En qué consiste Talent Management Review (TMR)?", "20px 'Arial'", "#333333");
	this.text.lineHeight = 22;
	this.text.parent = this;
	this.text.setTransform(-282.05,-240.55);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.tituloestatica, new cjs.Rectangle(-300.2,-242.5,501.9,26.30000000000001), null);


(lib.titulo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.text = new cjs.Text("¿En qué consiste el proceso Talent Management Review (TMR)?", "bold 25px 'Arial'", "#333333");
	this.text.textAlign = "center";
	this.text.lineHeight = 28;
	this.text.lineWidth = 186;
	this.text.parent = this;
	this.text.setTransform(94.9,-12);

	this.timeline.addTween(cjs.Tween.get(this.text).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-14,189.9,146.7);


(lib.Tema = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa_1
	this.text = new cjs.Text("Introducción a Talent Management Review", "36px 'Arial'", "#606060");
	this.text.lineHeight = 47;
	this.text.lineWidth = 356;
	this.text.parent = this;
	this.text.setTransform(2,2);

	this.timeline.addTween(cjs.Tween.get(this.text).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,360.1,91.7);


(lib.Telefono = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#4E5153").s().p("AgIBUQgFAAgFgEQgEgEAAgFIAAiPQAAgEADgDQAEgDADAAIAVgBQAFAAAEAEQAEAEAAAFIAACOQAAALgDABg");
	this.shape.setTransform(12.9875,22.0908,2.4722,2.4722);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#4E5153").s().p("AgGAHQgDgDAAgEQAAgDADgDQADgDADAAQAEAAADADQADADAAADQAAAEgDADQgDADgEAAQgDAAgDgDg");
	this.shape_1.setTransform(42.5917,41.3737,2.4722,2.4722);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#4E5153").s().p("AgHAHQgFAAAAgEIAAgEQAAgFAFAAIAPAAQAFAAAAAFIAAAEQAAAEgFAAg");
	this.shape_2.setTransform(42.7771,35.5023,2.4722,2.4722);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#4E5153").s().p("AgHAHQgFAAAAgEIAAgEQAAgFAFAAIAPAAQAFAAAAAFIAAAEQAAAEgFAAg");
	this.shape_3.setTransform(42.7771,30.1871,2.4722,2.4722);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#4E5153").s().p("AgHAHQgFAAAAgEIAAgEQAAgFAFAAIAPAAQAFAAAAAFIAAAEQAAAEgFAAg");
	this.shape_4.setTransform(42.7771,24.8719,2.4722,2.4722);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#4E5153").s().p("AgHAHQgFAAAAgFIAAgDQAAgFAFAAIAPAAQAFAAAAAFIAAADQAAAFgFAAg");
	this.shape_5.setTransform(42.7771,19.804,2.4722,2.4722);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#4E5153").s().p("AgHAHQgFAAAAgEIAAgEQAAgFAFAAIAQAAQAEAAAAAFIAAAEQAAAEgEAAg");
	this.shape_6.setTransform(34.8661,35.5023,2.4722,2.4722);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#4E5153").s().p("AgHAHQgFAAAAgEIAAgEQAAgFAFAAIAQAAQAEAAAAAFIAAAEQAAAEgEAAg");
	this.shape_7.setTransform(34.8661,30.1871,2.4722,2.4722);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#4E5153").s().p("AgHAHQgFAAAAgEIAAgEQAAgFAFAAIAQAAQAEAAAAAFIAAAEQAAAEgEAAg");
	this.shape_8.setTransform(34.8661,24.8719,2.4722,2.4722);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#4E5153").s().p("AgHAHQgFAAAAgFIAAgDQAAgFAFAAIAQAAQAEAAAAAFIAAADQAAAFgEAAg");
	this.shape_9.setTransform(34.8661,19.804,2.4722,2.4722);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#4E5153").s().p("AgHAHQgFAAAAgEIAAgEQAAgFAFAAIAPAAQAFAAAAAFIAAAEQAAAEgFAAg");
	this.shape_10.setTransform(26.9552,35.5023,2.4722,2.4722);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#4E5153").s().p("AgHAHQgFAAAAgEIAAgEQAAgFAFAAIAPAAQAFAAAAAFIAAAEQAAAEgFAAg");
	this.shape_11.setTransform(26.9552,30.1871,2.4722,2.4722);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#4E5153").s().p("AgHAHQgFAAAAgEIAAgEQAAgFAFAAIAPAAQAFAAAAAFIAAAEQAAAEgFAAg");
	this.shape_12.setTransform(26.9552,24.8719,2.4722,2.4722);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#4E5153").s().p("AgHAHQgFAAAAgFIAAgDQAAgFAFAAIAPAAQAFAAAAAFIAAADQAAAFgFAAg");
	this.shape_13.setTransform(26.9552,19.804,2.4722,2.4722);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#4E5153").s().p("AgmAPQgEgBgDgDQgCgCAAgEIAAgJQAAgKAJAAIBNAAQAJAAAAAKIAAAJQAAAEgCACQgDADgEABg");
	this.shape_14.setTransform(35.4224,13.3764,2.4722,2.4722);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#24272A").s().p("AhuBVIgBgFIAAhzIAAgWQgBgWACgEQACgFAHgBIAHAAIC5gBQAPgBAFAIQACAEAAAEIAACWQgBALgHADIgGACIjFAAIgBAAQgJAAgCgGg");
	this.shape_15.setTransform(27.8184,22.4526,2.4722,2.4722);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Telefono, new cjs.Rectangle(0,0,55.7,44.9), null);


(lib.tapageneralgris = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E6E6E6").s().p("AhKBUIAAinICVAAIAACng");
	this.shape.setTransform(7.45,8.425);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,14.9,16.9);


(lib.tapakakigeneral = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E3EFB9").s().p("AhKBUIAAinICVAAIAACng");
	this.shape.setTransform(7.45,8.425);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,14.9,16.9);


(lib.tapabca2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AwoG+IAAt8MAhRAAAIAAN8g");
	this.shape.setTransform(106.5,44.65);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,213,89.3);


(lib.tapabca = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AwoG+IAAt8MAhRAAAIAAN8g");
	this.shape.setTransform(106.5,44.65);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,213,89.3);


(lib.Silla_de_frente = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#3D4659").s().p("AAACHQgCgCgCgIQgDgLAIgrQADgNAEgrQAEgxgDgVQgDgVgHgTQgGgQgFgGQgDgDgDgIIgCgGIARAOQAQAQACAGQAEAQACAZQACAngHAqQgRBlACAGQAAABAAABQAAABABAAQAAABAAAAQgBAAAAAAIgBAAg");
	this.shape.setTransform(128.9633,115.8213,2.4722,2.4722);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#3D4659").s().p("AAACEQACgGgRhlQgHgqADgoQABgYAFgQQABgHAQgQIARgOQgCAMgGAGQgFAFgGAQQgHAUgDAUQgCAVAEAxQADApADAQQAJAogEANQgCAIgDACIAAAAQAAAAAAAAQAAAAAAgBQAAAAAAgBQAAAAAAgBg");
	this.shape_1.setTransform(21.9206,112.6122,2.4722,2.4722);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#B5B7B8").s().p("AgLCJQgKgDADgZIAIg9QAHg5ABgaQACgxgJgLQgKgKgKgPIgIgOIAbgDIAUAHQAXALADAPQAHAZgQCnQgFArgDADQgLAEgJAAIgKgBg");
	this.shape_2.setTransform(133.1354,115.2475,2.4722,2.4722);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#B5B7B8").s().p("AgICJIgKgDQgDgDgFgrQgQinAHgZQAEgPAWgLQAKgFAKgCIAbADQgMAXgQAQQgKALADAxQABAaAHA5IAIA9QADAZgKADIgKABIgKgBg");
	this.shape_3.setTransform(17.7154,112.6342,2.4722,2.4722);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#323436").s().p("AgIAZQhMAAhBgTIgxgRQgJgFABgFQABgFAHAEQAPAJApALQA8APBEACQBGADA0gMIBGgTQAdgIAAAHQAAAHgPAEQg1APgbAFQgpAIhHAAIgIAAg");
	this.shape_4.setTransform(77.02,80.8669,2.4722,2.4722);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#3D4659").s().p("AgRAeQhJgBg7gQQgegJgSgJIgBAAQgIgIAFgKQAEgKAHAHQAIAHA3AOQA+AOAuABQBHABA4gKQATgDAzgPQAlgKgQAcQhbAdhxAAIgMAAg");
	this.shape_5.setTransform(77.7453,80.9609,2.4722,2.4722);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#626666").s().p("AhICjQhjgGgUgMQgSgMAGhUQAMhmABguQACgsAPgPQAKgLAPAEQAOAEALAAQDCADBKAAQAhAAALAMQAGAIADAXQAEAnACBbQADBzgIAQQgIARgjACIhTABIgqABQgvAAg4gEg");
	this.shape_6.setTransform(76.7347,41.221,2.4722,2.4722);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#626666").s().p("AhcDUIhJgJQgmgDgcgYQgPgNgIgPIAAgBQgCgcAOg0QARg1ACgNQAEgRAGg/QAFg4ABgaQABgQANgPQAHgJAJgFIABgBIFlgJQAmAAAMBfQAGAzACBIIAMBWQAIA+gJAUQgJAVgMAFIgtAKQgdAHg1ACQggAChMAAQgvAAgngFg");
	this.shape_7.setTransform(74.0675,128.0541,2.4722,2.4722);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#717677").s().p("Ah7AgIDvhWIAIAPIj2BMIAAASg");
	this.shape_8.setTransform(36.0561,221.4405,2.4722,2.4722);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#3D4659").s().p("AiGBLIAAg+ID2hXQALAAgDABQgDAAAJAHIAJAIIgIAnIjtAvIgBAvg");
	this.shape_9.setTransform(37.1686,226.1995,2.4722,2.4722);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#231F20").s().p("AgCAdQgEgBgEgDQgDgDAAgEIAAgjQAAgEADgDQAEgEAEAAIAGAAQAEAAADAEQADADAAAEIAAAjQAAAEgDADQgDADgEABg");
	this.shape_10.setTransform(140.1344,242.8248,2.4722,2.4722);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#717677").s().p("AB/AjIkAhQIALgJID2BUIABAHIgBASg");
	this.shape_11.setTransform(111.0864,222.6766,2.4722,2.4722);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#3D4659").s().p("ABvBLIAAgvIjtgvIgIguQATgHgDgBIAIgBID1BXIAAA+g");
	this.shape_12.setTransform(109.7885,227.621,2.4722,2.4722);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#3D4659").s().p("AAgANIAAgIIgaAAIgwgRIBVADIAAAWg");
	this.shape_13.setTransform(99.6526,214.7657,2.4722,2.4722);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#3D4659").s().p("AgqANIAAgWIBVgDIgwARIgaAAIAAAIg");
	this.shape_14.setTransform(43.2872,214.5185,2.4722,2.4722);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#231F20").s().p("AgDAcQgEAAgDgDQgDgDAAgEIAAgjQAAgEADgDQADgDAEAAIAGAAQAFAAADADQADADAAAEIAAAjQAAAEgDADQgDADgFAAg");
	this.shape_15.setTransform(35.1291,224.3453,2.4722,2.4722);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#231F20").s().p("AgDAcQgDAAgEgDQgDgDAAgEIAAgjQAAgEADgDQAEgDADAAIAHAAQAEAAADADQADADAAAEIAAAjQAAAEgDADQgDADgEAAg");
	this.shape_16.setTransform(108.1198,224.3453,2.4722,2.4722);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#231F20").s().p("AgCAZQgFAAgDgCQgDgEAAgEIAAgdQAAgEADgDQADgEAFAAIAGAAQAEAAADAEQADADAAAEIAAAdQAAAEgDAEQgDACgEAAg");
	this.shape_17.setTransform(6.2047,243.4428,2.4722,2.4722);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#231F20").s().p("AgCAcQgFAAgDgDQgDgDAAgEIAAgjQAAgEADgDQADgDAFAAIAGAAQAEAAADADQADADAAAEIAAAjQAAAEgDADQgDADgEAAg");
	this.shape_18.setTransform(73.1386,255.9891,2.4722,2.4722);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#717677").s().p("AAAAbQgFAAAAgFIAAgrQAAgFAFAAIABAAQAFAAAAAFIAAArQAAAFgFAAg");
	this.shape_19.setTransform(112.1371,224.3453,2.4722,2.4722);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#717677").s().p("AAAAbQgFAAAAgFIAAgrQAAgFAFAAIABAAQAFAAAAAFIAAArQAAAFgFAAg");
	this.shape_20.setTransform(104.3498,224.3453,2.4722,2.4722);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#717677").s().p("AAAAbQgFAAAAgFIAAgrQAAgFAFAAIABAAQAFAAAAAFIAAArQAAAFgFAAg");
	this.shape_21.setTransform(39.2081,224.3453,2.4722,2.4722);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#717677").s().p("AAAAbQgFAAAAgFIAAgrQAAgFAFAAIABAAQAFAAAAAFIAAArQAAAFgFAAg");
	this.shape_22.setTransform(31.5444,224.3453,2.4722,2.4722);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#717677").s().p("AAAAbQgGAAAAgGIAAgpQAAgBAAAAQAAgBAAAAQAAgBABAAQAAgBABAAQAAgBABAAQAAgBABAAQAAAAABAAQAAAAABAAIABAAQAGAAAAAGIAAApQAAAGgGAAg");
	this.shape_23.setTransform(11.3963,243.381,2.4722,2.4722);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#717677").s().p("AAAAbQgGAAAAgGIAAgpQAAgGAGAAIABAAQABAAAAAAQABAAABAAQAAAAAAABQABAAAAABQABAAAAABQABAAAAABQAAAAAAABQAAAAAAABIAAApQAAAGgGAAg");
	this.shape_24.setTransform(1.7548,243.381,2.4722,2.4722);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#717677").s().p("AAAAbQgGAAAAgGIAAgpQAAgGAGAAIABAAQABAAAAAAQABAAAAAAQABAAAAABQABAAAAABQABAAAAABQABAAAAABQAAAAAAABQAAAAAAABIAAApQAAAGgGAAg");
	this.shape_25.setTransform(145.2642,243.381,2.4722,2.4722);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#717677").s().p("AAAAbQgGAAAAgGIAAgpQAAgBAAAAQAAgBAAAAQABgBAAAAQAAgBABAAQAAgBABAAQAAgBABAAQAAAAABAAQAAAAABAAIABAAQAGAAAAAGIAAApQAAAGgGAAg");
	this.shape_26.setTransform(135.4991,243.381,2.4722,2.4722);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#717677").s().p("AAAAhQgGAAAAgGIAAg1QAAgGAGAAIABAAQAGAAAAAGIAAA1QAAABAAAAQAAABAAAAQgBABAAAAQAAABgBAAQAAABgBAAQAAAAgBAAQAAABgBAAQAAAAgBAAg");
	this.shape_27.setTransform(77.774,256.2981,2.4722,2.4722);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#717677").s().p("AAAAhQgBAAAAAAQgBAAAAgBQgBAAAAAAQgBAAAAgBQgBAAAAgBQAAAAgBgBQAAAAAAgBQAAAAAAgBIAAg1QAAgGAGAAIABAAQAGAAAAAGIAAA1QAAAGgGAAg");
	this.shape_28.setTransform(68.0089,256.2981,2.4722,2.4722);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#717677").s().p("AgbADIgegJIBiAJIASAEg");
	this.shape_29.setTransform(95.8826,210.6866,2.4722,2.4722);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#717677").s().p("AgqAAIBhgEIgYAFIhVAEg");
	this.shape_30.setTransform(46.2538,210.9956,2.4722,2.4722);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#717677").s().p("AgGBMIgHiXIAbAAIgJCXg");
	this.shape_31.setTransform(73.2005,230.6494,2.4722,2.4722);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#717677").s().p("AgaA4IgFgEIAAhvIA/ABIAABvQgNAHgXAAQgPAAgHgEg");
	this.shape_32.setTransform(73.5713,196.9661,2.4722,2.4722);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Silla_de_frente, new cjs.Rectangle(0,0,147.1,264.5), null);


(lib.rh3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E16F74").s().p("Ah1AVIASgRIA1A0ICSiSIARARIijCkg");
	this.shape.setTransform(49.382,65.2351,0.4898,0.4898);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#E16F74").s().p("Ah1AUIASgRIA1A1ICSiSIARASIijCjg");
	this.shape_1.setTransform(49.382,48.5077,0.4898,0.4898);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#E16F74").s().p("Ah1AVIASgRIA1A0ICSiSIARARIijCkg");
	this.shape_2.setTransform(49.382,31.6088,0.4898,0.4898);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#B0B0B0").s().p("AhBBDIAAiFICDAAIAACFg");
	this.shape_3.setTransform(45.8365,33.5343,0.4898,0.4898);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#B0B0B0").s().p("AhBBDIAAiEICDAAIAACEg");
	this.shape_4.setTransform(45.8365,50.25,0.4898,0.4898);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#B0B0B0").s().p("AhBBDIAAiFICDAAIAACFg");
	this.shape_5.setTransform(45.8365,67.2351,0.4898,0.4898);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#B0B0B0").s().p("ABeAIIAAgPIARAAIAAAPgAA8AIIAAgPIARAAIAAAPgAAaAIIAAgPIARAAIAAAPgAgHAIIAAgPIAQAAIAAAPgAgqAIIAAgPIASAAIAAAPgAhMAIIAAgPIARAAIAAAPgAhuAIIAAgPIARAAIAAAPg");
	this.shape_6.setTransform(45.921,27.0841,0.4897,0.4897);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#B0B0B0").s().p("AgHAIIAAgPIAPAAIAAAPg");
	this.shape_7.setTransform(39.2484,27.0841,0.4897,0.4897);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#B0B0B0").s().p("AgHBvIAAgRIAPAAIAAARgAgHBNIAAgRIAPAAIAAARgAgHArIAAgRIAPAAIAAARgAgHAJIAAgRIAPAAIAAARgAgHgZIAAgRIAPAAIAAARgAgHg7IAAgRIAPAAIAAARgAgHhdIAAgRIAPAAIAAARg");
	this.shape_8.setTransform(39.2484,33.7566,0.4897,0.4897);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#B0B0B0").s().p("AgHAIIAAgPIAPAAIAAAPg");
	this.shape_9.setTransform(39.2484,40.4292,0.4897,0.4897);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#B0B0B0").s().p("ABeAIIAAgPIARAAIAAAPgAA8AIIAAgPIARAAIAAAPgAAaAIIAAgPIARAAIAAAPgAgHAIIAAgPIAQAAIAAAPgAgqAIIAAgPIASAAIAAAPgAhMAIIAAgPIARAAIAAAPgAhuAIIAAgPIARAAIAAAPg");
	this.shape_10.setTransform(45.921,40.4292,0.4897,0.4897);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#B0B0B0").s().p("AgHAIIAAgPIAPAAIAAAPg");
	this.shape_11.setTransform(52.6058,40.4292,0.4897,0.4897);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#B0B0B0").s().p("AgHBvIAAgRIAPAAIAAARgAgHBNIAAgRIAPAAIAAARgAgHArIAAgRIAPAAIAAARgAgHAJIAAgRIAPAAIAAARgAgHgZIAAgRIAPAAIAAARgAgHg7IAAgRIAPAAIAAARgAgHhdIAAgRIAPAAIAAARg");
	this.shape_12.setTransform(52.6058,33.7566,0.4897,0.4897);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#B0B0B0").s().p("AgHAIIAAgPIAPAAIAAAPg");
	this.shape_13.setTransform(52.6058,27.0841,0.4897,0.4897);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#B0B0B0").s().p("ABeAIIAAgPIARAAIAAAPgAA8AIIAAgPIARAAIAAAPgAAaAIIAAgPIARAAIAAAPgAgHAIIAAgPIAQAAIAAAPgAgqAIIAAgPIASAAIAAAPgAhMAIIAAgPIARAAIAAAPgAhuAIIAAgPIARAAIAAAPg");
	this.shape_14.setTransform(45.921,43.8328,0.4897,0.4897);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#B0B0B0").s().p("AgHAIIAAgPIAPAAIAAAPg");
	this.shape_15.setTransform(39.2484,43.8328,0.4897,0.4897);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#B0B0B0").s().p("AgHBvIAAgRIAPAAIAAARgAgHBNIAAgRIAPAAIAAARgAgHArIAAgRIAPAAIAAARgAgHAJIAAgQIAPAAIAAAQgAgHgZIAAgRIAPAAIAAARgAgHg7IAAgRIAPAAIAAARgAgHhdIAAgRIAPAAIAAARg");
	this.shape_16.setTransform(39.2484,50.5054,0.4897,0.4897);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#B0B0B0").s().p("AgHAIIAAgPIAPAAIAAAPg");
	this.shape_17.setTransform(39.2484,57.1903,0.4897,0.4897);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#B0B0B0").s().p("ABeAIIAAgPIARAAIAAAPgAA8AIIAAgPIARAAIAAAPgAAaAIIAAgPIARAAIAAAPgAgHAIIAAgPIAQAAIAAAPgAgqAIIAAgPIASAAIAAAPgAhMAIIAAgPIARAAIAAAPgAhuAIIAAgPIARAAIAAAPg");
	this.shape_18.setTransform(45.921,57.1903,0.4897,0.4897);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#B0B0B0").s().p("AgHAIIAAgPIAPAAIAAAPg");
	this.shape_19.setTransform(52.6058,57.1903,0.4897,0.4897);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#B0B0B0").s().p("AgHBvIAAgRIAPAAIAAARgAgHBNIAAgRIAPAAIAAARgAgHArIAAgRIAPAAIAAARgAgHAJIAAgQIAPAAIAAAQgAgHgZIAAgRIAPAAIAAARgAgHg7IAAgRIAPAAIAAARgAgHhdIAAgRIAPAAIAAARg");
	this.shape_20.setTransform(52.6058,50.5054,0.4897,0.4897);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#B0B0B0").s().p("AgHAIIAAgPIAPAAIAAAPg");
	this.shape_21.setTransform(52.6058,43.8328,0.4897,0.4897);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#B0B0B0").s().p("ABeAIIAAgPIARAAIAAAPgAA8AIIAAgPIARAAIAAAPgAAaAIIAAgPIARAAIAAAPgAgHAIIAAgPIAQAAIAAAPgAgqAIIAAgPIASAAIAAAPgAhMAIIAAgPIARAAIAAAPgAhuAIIAAgPIARAAIAAAPg");
	this.shape_22.setTransform(45.921,60.5816,0.4897,0.4897);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#B0B0B0").s().p("AgHAIIAAgPIAPAAIAAAPg");
	this.shape_23.setTransform(39.2484,60.5816,0.4897,0.4897);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#B0B0B0").s().p("AgHBvIAAgRIAPAAIAAARgAgHBNIAAgRIAPAAIAAARgAgHAqIAAgRIAPAAIAAARgAgHAIIAAgQIAPAAIAAAQgAgHgYIAAgSIAPAAIAAASgAgHg7IAAgRIAPAAIAAARgAgHhdIAAgRIAPAAIAAARg");
	this.shape_24.setTransform(39.2484,67.2665,0.4897,0.4897);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#B0B0B0").s().p("AgHAIIAAgPIAPAAIAAAPg");
	this.shape_25.setTransform(39.2484,73.9391,0.4897,0.4897);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#B0B0B0").s().p("ABeAIIAAgPIARAAIAAAPgAA8AIIAAgPIARAAIAAAPgAAaAIIAAgPIARAAIAAAPgAgHAIIAAgPIAQAAIAAAPgAgqAIIAAgPIASAAIAAAPgAhMAIIAAgPIARAAIAAAPgAhuAIIAAgPIARAAIAAAPg");
	this.shape_26.setTransform(45.921,73.9391,0.4897,0.4897);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#B0B0B0").s().p("AgHAIIAAgPIAPAAIAAAPg");
	this.shape_27.setTransform(52.6058,73.9391,0.4897,0.4897);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#B0B0B0").s().p("AgHBvIAAgRIAPAAIAAARgAgHBNIAAgRIAPAAIAAARgAgHAqIAAgRIAPAAIAAARgAgHAIIAAgQIAPAAIAAAQgAgHgYIAAgSIAPAAIAAASgAgHg7IAAgRIAPAAIAAARgAgHhdIAAgRIAPAAIAAARg");
	this.shape_28.setTransform(52.6058,67.2665,0.4897,0.4897);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#B0B0B0").s().p("AgHAIIAAgPIAPAAIAAAPg");
	this.shape_29.setTransform(52.6058,60.5816,0.4897,0.4897);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#B0B0B0").s().p("ABuEiIhKlWIAGgCQAhgNATgdQAUgdAAgjQAAgvgigiQghghgvAAQguAAgiAhQghAiAAAvQAAAjATAcQAUAdAgANIAGADIhJFWIgPAAIBHlNQgigQgVggQgUgfAAgmQAAg2AmglQAmgmA0AAQA1AAAmAmQAmAlAAA2QAAAmgVAgQgUAfgjAQIBIFNg");
	this.shape_30.setTransform(64.7747,-0.8297,0.4898,0.4898);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#F0A693").s().p("ACLBtIAAgTIkXAAIAAATIhqAAIAAjaIHtAAIAADag");
	this.shape_31.setTransform(64.683,8.5893,0.4898,0.4898);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#EBE5EE").s().p("AgNADIgBgGIAdAAIAAAGg");
	this.shape_32.setTransform(70.7692,13.4142,0.4898,0.4898);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#EBE5EE").s().p("AgPADIAAgGIAfAAIgCAGg");
	this.shape_33.setTransform(58.5355,13.4142,0.4898,0.4898);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FEE69D").s().p("AncAjIAAhFIO5AAIAABFg");
	this.shape_34.setTransform(58.6264,10.012,0.4899,0.4899);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#B0B0B0").s().p("AkgARIAAghIJBAAIAAAhg");
	this.shape_35.setTransform(73.6405,72.5702,0.4898,0.4898);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#B0B0B0").s().p("AkgARIAAghIJBAAIAAAhg");
	this.shape_36.setTransform(73.6405,68.8475,0.4898,0.4898);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#B0B0B0").s().p("AkgARIAAghIJBAAIAAAhg");
	this.shape_37.setTransform(73.6405,65.1249,0.4898,0.4898);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#B0B0B0").s().p("AkgARIAAghIJBAAIAAAhg");
	this.shape_38.setTransform(73.6405,61.4267,0.4898,0.4898);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#B0B0B0").s().p("AkgARIAAghIJBAAIAAAhg");
	this.shape_39.setTransform(73.6405,57.6918,0.4898,0.4898);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#B0B0B0").s().p("AkgAQIAAgfIJBAAIAAAfg");
	this.shape_40.setTransform(73.6405,53.9692,0.4898,0.4898);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#B0B0B0").s().p("AkgARIAAghIJBAAIAAAhg");
	this.shape_41.setTransform(73.6405,50.2343,0.4898,0.4898);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#B0B0B0").s().p("AkgARIAAghIJBAAIAAAhg");
	this.shape_42.setTransform(73.6405,46.5116,0.4898,0.4898);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#B0B0B0").s().p("AkgARIAAghIJBAAIAAAhg");
	this.shape_43.setTransform(73.6405,42.789,0.4898,0.4898);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#B0B0B0").s().p("AkgARIAAghIJBAAIAAAhg");
	this.shape_44.setTransform(73.6405,39.0663,0.4898,0.4898);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#B0B0B0").s().p("AkgARIAAghIJBAAIAAAhg");
	this.shape_45.setTransform(73.6405,35.3437,0.4898,0.4898);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#B0B0B0").s().p("AiCARIAAghIEFAAIAAAhg");
	this.shape_46.setTransform(65.889,28.6331,0.4898,0.4898);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#FFFFFF").s().p("ApWL2IAA3rIO5AAIAAD0ID0AAIAAT3g");
	this.shape_47.setTransform(64.8359,45.4952,0.4898,0.4898);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#E6E7E8").s().p("ApWKdIAA05IO5AAID0D0IAARFg");
	this.shape_48.setTransform(64.8359,41.1481,0.4898,0.4898);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#FFFFFF").s().p("ApSLxIAA3hISlAAIAAXhg");
	this.shape_49.setTransform(64.6516,45.1957,0.4899,0.4899);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#7F8487").s().p("ApzM4QgKABgHgIQgHgHAAgKIAA4/QAAgKAHgHQAHgIAKABITnAAQAJgBAIAIQAHAHAAAKIAAY/QAAAKgHAHQgIAIgJgBg");
	this.shape_50.setTransform(64.6026,45.4039,0.4899,0.4899);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(32.7,-15,63.89999999999999,100.8);


(lib.respuestadecheckboxes = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#52941B").s().p("AgeBrQgHgBgFgDIgFgEIgxg4QgJgKgCgHQgDgHACgGQABgFACgDIACgEQAJgGAIABQAHABAGADIAFADIAkArIB1iMQAGgJAGgCQAFgCACABIADABQADAEAAAFQgBAFgCADIgCAEIh2C4QgJAHgHAAIgBAAg");
	this.shape.setTransform(11.0131,10.7067);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,22,21.4);


(lib.Postits = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CFCE79").s().p("AhGBeIAAi7ICNAAIAAC7g");
	this.shape.setTransform(66.35,9.425);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CFCE79").s().p("AhGBeIAAi7ICNAAIAAC7g");
	this.shape_1.setTransform(46.55,9.425);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#CFCE79").s().p("AhGBeIAAi7ICNAAIAAC7g");
	this.shape_2.setTransform(26.9,9.425);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#CFCE79").s().p("AhGBeIAAi7ICNAAIAAC7g");
	this.shape_3.setTransform(7.1,9.425);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Postits, new cjs.Rectangle(0,0,73.5,18.9), null);


(lib.Postit = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CFCE79").s().p("AhGBeIAAi7ICNAAIAAC7g");
	this.shape.setTransform(7.1,8.425);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Postit, new cjs.Rectangle(0,-1,14.2,18.9), null);


(lib.Pisarron_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#454748").s().p("AgIABQgBgEADgEQACgEAEAAQACgBAEAEQADADAAAFQABAEgDAEQgCADgEABIgBAAQgHAAgBgLg");
	this.shape.setTransform(176.0459,374.2708,2.4722,2.4722);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#040D1C").s().p("AgHAOQgGgBgBgIIAAgTIARAAIAAACIAFABQAFACABAEQAEANgJAEQgEACgFABIgCAAIgFgBg");
	this.shape_1.setTransform(177.7764,373.6716,2.4722,2.4722);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#454748").s().p("AAAAMQgEgBgCgDQgDgEABgEQABgFADgDQADgEACABQAEAAACAEQADAEgBAEQgBALgIAAIAAAAg");
	this.shape_2.setTransform(210.7799,374.2708,2.4722,2.4722);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#040D1C").s().p("AAAAPQgEgBgEgCQgJgEAEgNQACgEAFgCIAEgBIAAgCIARAAIAAATQgBAIgGABIgFABIgDAAg");
	this.shape_3.setTransform(209.0765,373.6716,2.4722,2.4722);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#454748").s().p("AgIABQgBgEADgEQACgEAEAAQACgBAEAEQADADAAAFQABAEgDAEQgCADgEABIgBAAQgHAAgBgLg");
	this.shape_4.setTransform(-90.5103,374.2708,2.4722,2.4722);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#040D1C").s().p("AgHAOQgGgBgBgIIAAgTIARAAIAAACIAFABQAFACABAEQAEANgJAEQgEACgFABIgCAAIgFgBg");
	this.shape_5.setTransform(-88.7772,373.6716,2.4722,2.4722);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#454748").s().p("AAAAMQgEgBgCgDQgCgEAAgEQABgFADgDQADgEACABQAEAAACAEQADAEgBAEQAAAFgDADQgDADgDAAIAAAAg");
	this.shape_6.setTransform(-55.7166,374.2701,2.4722,2.4722);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#040D1C").s().p("AgIAMQgJgEAEgNQACgEAFgCIAEgBIAAgCIARAAIAAATQgBAIgGABIgGABQgFAAgFgDg");
	this.shape_7.setTransform(-57.4797,373.6995,2.4722,2.4722);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgLCbIAAk0IAXAAIAAE0g");
	this.shape_8.setTransform(210.9035,331.1297,2.4722,2.4722);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AhOAMIAAgBQAAgKAHgFQAHgHAJAAICGAAIAAAXg");
	this.shape_9.setTransform(194.2163,367.0379,2.4722,2.4722);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AhOAMIAAgXICLAAQAIAAAFAFQAFAFAAAGIAAAHg");
	this.shape_10.setTransform(-73.1433,367.0379,2.4722,2.4722);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgLCbIAAk0IAXAAIAAE0g");
	this.shape_11.setTransform(-89.645,331.1297,2.4722,2.4722);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("rgba(204,204,204,0.498)").s().p("EgjuAXuQgxAAghgiQgjgjAAgxMAAAgrwQAAgwAjgjQAhgiAxAAMBHbAAAQAyAAAiAiQAjAjAAAwMAAAArwQAAAxgjAjQgiAigyAAg");
	this.shape_12.setTransform(29.25,133.575);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("EglGAZeQgwAAgigjQgjghAAgyMAAAgvOQAAgyAjgiQAigjAwAAMBKNAAAQAxAAAiAjQAiAiAAAyMAAAAvOQAAAygiAhQgiAjgxAAg");
	this.shape_13.setTransform(28.175,132.575);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Pisarron_2, new cjs.Rectangle(-221,-30.4,498.4,407.9), null);


(lib.Pisarron_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#454748").s().p("AgIABQgBgEADgEQACgEAEAAQACgBAEAEQADADAAAFQABAEgDAEQgCADgEABIgBAAQgHAAgBgLg");
	this.shape.setTransform(176.0459,374.2708,2.4722,2.4722);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#040D1C").s().p("AgHAOQgGgBgBgIIAAgTIARAAIAAACIAFABQAFACABAEQAEANgJAEQgEACgFABIgCAAIgFgBg");
	this.shape_1.setTransform(177.7764,373.6716,2.4722,2.4722);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#454748").s().p("AAAAMQgEgBgCgDQgDgEABgEQABgFADgDQADgEACABQAEAAACAEQADAEgBAEQgBALgIAAIAAAAg");
	this.shape_2.setTransform(210.7799,374.2708,2.4722,2.4722);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#040D1C").s().p("AAAAPQgEgBgEgCQgJgEAEgNQACgEAFgCIAEgBIAAgCIARAAIAAATQgBAIgGABIgFABIgDAAg");
	this.shape_3.setTransform(209.0765,373.6716,2.4722,2.4722);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#454748").s().p("AgIABQgBgEADgEQACgEAEAAQACgBAEAEQADADAAAFQABAEgDAEQgCADgEABIgBAAQgHAAgBgLg");
	this.shape_4.setTransform(14.4897,374.2708,2.4722,2.4722);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#040D1C").s().p("AgHAOQgGgBgBgIIAAgTIARAAIAAACIAFABQAFACABAEQAEANgJAEQgEACgFABIgCAAIgFgBg");
	this.shape_5.setTransform(16.2228,373.6716,2.4722,2.4722);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#454748").s().p("AAAAMQgEgBgCgDQgCgEAAgEQABgFADgDQADgEACABQAEAAACAEQADAEgBAEQAAAFgDADQgDADgDAAIAAAAg");
	this.shape_6.setTransform(49.2834,374.2701,2.4722,2.4722);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#040D1C").s().p("AgIAMQgJgEAEgNQACgEAFgCIAEgBIAAgCIARAAIAAATQgBAIgGABIgGABQgFAAgFgDg");
	this.shape_7.setTransform(47.5203,373.6995,2.4722,2.4722);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgLCbIAAk0IAXAAIAAE0g");
	this.shape_8.setTransform(210.9035,331.1297,2.4722,2.4722);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AhOAMIAAgBQAAgKAHgFQAHgHAJAAICGAAIAAAXg");
	this.shape_9.setTransform(194.2163,367.0379,2.4722,2.4722);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AhOAMIAAgXICLAAQAIAAAFAFQAFAFAAAGIAAAHg");
	this.shape_10.setTransform(31.8567,367.0379,2.4722,2.4722);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgLCbIAAk0IAXAAIAAE0g");
	this.shape_11.setTransform(15.355,331.1297,2.4722,2.4722);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#D992BF").s().p("AgYAhIAAhBIAxAAIAABBg");
	this.shape_12.setTransform(170.663,155.8497,2.4722,2.4722);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#CFCE79").s().p("AgYAhIAAhBIAxAAIAABBg");
	this.shape_13.setTransform(152.678,155.8497,2.4722,2.4722);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#CF93C1").s().p("AgYAhIAAhBIAxAAIAABBg");
	this.shape_14.setTransform(135.4964,155.8497,2.4722,2.4722);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AhDBEIAAiHICHAAIAACHg");
	this.shape_15.setTransform(182.035,185.3921,2.4722,2.4722);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AhDBEIAAiHICHAAIAACHg");
	this.shape_16.setTransform(145.3851,185.3921,2.4722,2.4722);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AiqBuIAAjbIFVAAIAADbg");
	this.shape_17.setTransform(83.21,175.6888,2.4722,2.4722);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#717576").s().p("Al8ItQgUAAgNgPQgOgNAAgVIAAv4QAAgUAOgNQANgOAUgBIL4AAQAUABAOAOQAOANAAAUIAAP4QAAAVgOANQgOAPgUAAg");
	this.shape_18.setTransform(113.7473,147.8184,2.4722,2.4722);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AmbJWQgUAAgOgOQgOgOAAgUIAAxLQAAgUAOgOQAOgOAUAAIM3AAQAVAAANAOQAOAOAAAUIAARLQAAAUgOAOQgNAOgVAAg");
	this.shape_19.setTransform(113.6855,147.7566,2.4722,2.4722);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Pisarron_1, new cjs.Rectangle(0,0,227.4,377.5), null);


(lib.PINTURAS = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = getMCSymbolPrototype(lib.PINTURAS, new cjs.Rectangle(0,0,0,0), null);


(lib.Pantallaamedias = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#A5A9A9").s().p("AhPAPIAAgdICfAAIAAAdg");
	this.shape.setTransform(24.3669,142.7414,1.3956,1.3956);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#B6E0DA").s().p("AnDHgIAAu/INrAAQAMAAAIAIQAIAIAAAMIAAOIQAAALgIAIQgIAIgMAAg");
	this.shape_1.setTransform(63.0254,70.3439,1.3956,1.3956);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AnWH3IAAvtIORAAQAMAAAIAIQAIAIAAALIAAO3QAAAMgIAHQgIAIgMAAg");
	this.shape_2.setTransform(65.6771,70.2044,1.3956,1.3956);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AhNIGIAAwLICbAAIAAQLg");
	this.shape_3.setTransform(24.3669,212.4175,1.3956,1.3956);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Pantallaamedias, new cjs.Rectangle(0,0,131.4,284.7), null);


(lib.numerodetema = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.text = new cjs.Text("Tema", "50px 'Arial'", "#FFFFFF");
	this.text.textAlign = "center";
	this.text.lineHeight = 75;
	this.text.parent = this;
	this.text.setTransform(69.0774,21.15,0.5935,0.5935);

	this.text_1 = new cjs.Text("1.1", "50px 'Arial'", "#FFFFFF");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 75;
	this.text_1.parent = this;
	this.text_1.setTransform(67.9296,51.65,1.0935,1.0935);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#793A26").s().p("Ag7HKQiJgUhphiIgRgQQhthmgbiMQgaiBAyh/QAyh/BshOQB0hTCVAAIAQAAQC8AACFCFQCGCGAAC8IAAAPQAACQhPByQhKBqh5A1QhZAmhdAAQghAAgigFg");
	this.shape.setTransform(69.7908,69.6505,1.5036,1.5036);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.text_1},{t:this.text}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,139.6,139.3);


(lib.Mueble1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#C4B49B").s().p("AlBAQIAAgfIKDAAIAAAfg");
	this.shape.setTransform(44.9264,186.1658,1.3956,1.3956);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#C4B49B").s().p("AlBAQIAAgfIKDAAIAAAfg");
	this.shape_1.setTransform(44.9264,130.3063,1.3956,1.3956);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#C4B49B").s().p("AlBAgIAAg/IKDAAIAAA/g");
	this.shape_2.setTransform(44.9264,72.1789,1.3956,1.3956);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#515055").s().p("AkuCMIJYkgIAFAJIpZEgg");
	this.shape_3.setTransform(49.2877,100.3006,1.3956,1.3956);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#515055").s().p("AkxiOIAFgJIJdEmIgDAJg");
	this.shape_4.setTransform(47.4734,102.4638,1.3956,1.3956);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#515055").s().p("AgSHdIAAu5IAkAAIAAO5g");
	this.shape_5.setTransform(6.0236,140.7036,1.3956,1.3956);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#5E050F").s().p("AkoDIIAAmPIJRAAIAAGPg");
	this.shape_6.setTransform(48.3456,157.0672,1.3956,1.3956);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#D77A54").s().p("AhOjCIA6gOIBjGSIg6APg");
	this.shape_7.setTransform(62.0226,36.6257,1.3956,1.3956);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FAB16A").s().p("AhAiyIAngJIBaFtIgnAKg");
	this.shape_8.setTransform(52.5325,38.8935,1.3956,1.3956);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#684D4C").s().p("AgkjiIAlgDIAjHIIglADg");
	this.shape_9.setTransform(40.4255,32.0899,1.3956,1.3956);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#984439").s().p("AgXDQIAAmeIAvAAIAAGeg");
	this.shape_10.setTransform(32.2263,35.1603,1.3956,1.3956);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#D68E79").s().p("AgXDiIAAnDIAvAAIAAHDg");
	this.shape_11.setTransform(24.5155,32.5086,1.3956,1.3956);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#D77A54").s().p("AgyCjIAAlEIBlAAIAAFEg");
	this.shape_12.setTransform(12.1992,41.1614,1.3956,1.3956);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#E62F33").s().p("AgwAmQgEgwAIgfIARACQAVADARgCQAdgBAGgCIADAaQADAdgCAYQgdAEgYAAQgYAAgVgEg");
	this.shape_13.setTransform(82.5551,41.8507,1.3956,1.3956);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#2A1213").s().p("AghCaQgMgEgBgVIAAgXQACgGACgHQADgPgFgZQgGgZACgtIAEgvQAAgGAIgNIANgYQAIgOgCgZIgEAAIAAgHIArAAIAAAHIgEAAIAAAOQABAQAFAJIANAYQAIANAAAGQAJBOgIAnQgFAZACAPQACAHACAGIABAXQgCAVgMAEg");
	this.shape_14.setTransform(82.5623,45.1738,1.3956,1.3956);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#E62F33").s().p("AgXAKIAAgQIABgBQACgBAGAAIAgAAIADAAQAAAAABAAQAAABAAAAQABAAAAAAQAAABAAAAIAAAQg");
	this.shape_15.setTransform(82.5905,21.9543,1.3956,1.3956);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Mueble1, new cjs.Rectangle(0,0,91.6,207.3), null);


(lib.Mueble2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AguBCQgEAAgDgDQgXgRAAgdIAAhGQAAgFADgDQAEgEAFAAICBAAQAGAAADAEQAEAFgBAFIAAACIAAA3QACAPgEARQgIAcgYAAg");
	this.shape.setTransform(266.8416,101.2929,2.4722,2.4722);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#509B5C").s().p("AgLAXIgBgKQABgLAEgHQAGgMAFgGIAFASQAFAOgCAHQgCAHgGABg");
	this.shape_1.setTransform(260.5596,79.5379,2.4722,2.4722);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#A0C5A7").s().p("AgIAWQgBgNABgJQAAgHADgHIADgHIAGALQADAFABADQABAGABASg");
	this.shape_2.setTransform(264.3332,79.5379,2.4722,2.4722);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#A0C5A7").s().p("AgIAWQgCgNABgJQABgHADgHIADgHIAFALQAEAFABADIACAYg");
	this.shape_3.setTransform(275.1489,79.5379,2.4722,2.4722);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#509B5C").s().p("AgLAQQgBgFAEgQIAFgSIALASQAGALgCARIgPABQgGAAgCgIg");
	this.shape_4.setTransform(270.9092,79.2906,2.4722,2.4722);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#A0C5A7").s().p("AgIAWQgCgNABgJQABgHADgHIADgHIAGALIAEAIQABAGABASg");
	this.shape_5.setTransform(258.4618,79.5379,2.4722,2.4722);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#509B5C").s().p("AgJAKQACgIAJgMIAJgNIABAGQABAGgBAKQgBAOgJAKIgOAAQAAgCADgLg");
	this.shape_6.setTransform(279.8878,79.3524,2.4722,2.4722);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#509B5C").s().p("AgBAXQgIgKgCgOQgBgJABgHIABgFIAJAMQAJANACAHQAEALgBACg");
	this.shape_7.setTransform(253.5944,79.167,2.4722,2.4722);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#ADAAD4").s().p("AgJAKQACgIAJgNIAJgMIABAGQACAGgCAKQgBAOgJAKIgOAAQAAgCADgLg");
	this.shape_8.setTransform(276.4576,79.1052,2.4722,2.4722);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#ADAAD4").s().p("AgBAXQgIgKgCgOQgBgJABgHIABgFIAJAMQAJANACAHQADALAAACg");
	this.shape_9.setTransform(256.666,79.167,2.4722,2.4722);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#C4B49B").s().p("AtkAJIAAgRIbJAAIAAARg");
	this.shape_10.setTransform(214.8775,123.2334,2.4722,2.4722);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#C4B49B").s().p("AtkAJIAAgRIbJAAIAAARg");
	this.shape_11.setTransform(214.8775,65.1375,2.4722,2.4722);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#C4B49B").s().p("AtkATIAAglIbJAAIAAAlg");
	this.shape_12.setTransform(214.8775,4.693,2.4722,2.4722);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#515055").s().p("AgKEYIAAovIAVAAIAAIvg");
	this.shape_13.setTransform(426.2478,75.9532,2.4722,2.4722);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#515055").s().p("AgKEYIAAovIAVAAIAAIvg");
	this.shape_14.setTransform(320.8099,75.9532,2.4722,2.4722);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#515055").s().p("AgKEYIAAovIAVAAIAAIvg");
	this.shape_15.setTransform(217.1024,75.9532,2.4722,2.4722);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#DED0BE").s().p("AjPB2IAAjqIGfAAIAADqg");
	this.shape_16.setTransform(164.8161,93.8146,2.4722,2.4722);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#DED0BE").s().p("AjPB2IAAjqIGfAAIAADqg");
	this.shape_17.setTransform(271.1811,35.7187,2.4722,2.4722);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#5E050F").s().p("AjSBvIAAjdIGlAAIAADdg");
	this.shape_18.setTransform(373.8379,94.9889,2.4722,2.4722);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#D77A54").s().p("AgoBlIAzjQIAeAHIgzDQg");
	this.shape_19.setTransform(365.3089,38.4999,2.4722,2.4722);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FAB16A").s().p("AggBcIAui9IATAGIguC9g");
	this.shape_20.setTransform(374.0233,40.663,2.4722,2.4722);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#684D4C").s().p("AgSB2IASjsIATABIgSDsg");
	this.shape_21.setTransform(385.1481,34.4208,2.4722,2.4722);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#984439").s().p("AgMBrIAAjWIAZAAIAADWg");
	this.shape_22.setTransform(392.6882,37.202,2.4722,2.4722);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#D68E79").s().p("AgLB1IAAjqIAXAAIAADqg");
	this.shape_23.setTransform(399.7956,34.7298,2.4722,2.4722);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#D77A54").s().p("AgZBUIAAinIAzAAIAACng");
	this.shape_24.setTransform(411.044,42.7026,2.4722,2.4722);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Mueble2, new cjs.Rectangle(0,0,429.8,145.3), null);


(lib.Mueble_4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhbCCQgIAAgHgEQgugjAAg5IAAiLQAAgKAHgHQAIgHAJAAIEBAAQALAAAHAIQAHAJgCALIAABxQADAkgHAcQgOA2gyAAg");
	this.shape.setTransform(250.3443,195.8735,1.1724,1.1724);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#509B5C").s().p("AgXAtQgBgIAAgMQABgWAIgOQAIgPAHgLIAHgJIALAjIAFAUQADANgCAKQgEAOgNABg");
	this.shape_1.setTransform(244.5184,175.4451,1.1724,1.1724);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#A0C5A7").s().p("AgRArQgDgaACgTQACgNAFgPIAGgMIAMAUQAHAKABAHQADAMABAkg");
	this.shape_2.setTransform(248.073,175.5037,1.1724,1.1724);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#A0C5A7").s().p("AgRArQgDgaACgTQACgNAFgPIAGgMIAMAUQAHAKABAHQADAMABAkg");
	this.shape_3.setTransform(258.1554,175.5037,1.1724,1.1724);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#509B5C").s().p("AgXAgQgCgKACgMIAGgVIAKgjIAHAJQAIAMAIAOQAMAYgEAgIgfACQgNgBgDgOg");
	this.shape_4.setTransform(254.1805,175.2692,1.1724,1.1724);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#A0C5A7").s().p("AgRArQgDgaACgTQACgNAGgPIAFgMIAMAUQAHAKABAHQADAMABAkg");
	this.shape_5.setTransform(242.5095,175.5037,1.1724,1.1724);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#509B5C").s().p("AgTATQAEgOASgaIASgZIADALQACAOgCASQgDAdgSAUIgbABQgCgGAHgWg");
	this.shape_6.setTransform(262.6111,175.2692,1.1724,1.1724);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#509B5C").s().p("AgDAuQgRgUgDgdQgCgSACgOIACgKIATAYQASAaAEAOQAGAXgBAEg");
	this.shape_7.setTransform(237.9627,175.1227,1.1724,1.1724);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#ADAAD4").s().p("AgTATQAEgOASgaIASgZIADALQACAOgCATQgDAdgSASIgbABQgCgEAHgXg");
	this.shape_8.setTransform(259.3871,175.0347,1.1724,1.1724);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#ADAAD4").s().p("AgCAuQgSgUgDgdQgCgSACgOIADgKIASAYQASAaAEAOQAHAXgCAEg");
	this.shape_9.setTransform(240.8492,175.1227,1.1724,1.1724);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#C4B49B").s().p("A63ATIAAglMA1vAAAIAAAlg");
	this.shape_10.setTransform(201.6409,216.4485,1.1724,1.1724);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#C4B49B").s().p("A63ATIAAglMA1vAAAIAAAlg");
	this.shape_11.setTransform(201.6409,161.9336,1.1724,1.1724);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#C4B49B").s().p("A63AlIAAhKMA1vAAAIAABKg");
	this.shape_12.setTransform(201.6409,105.2791,1.1724,1.1724);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#515055").p("AmlCoINLlP");
	this.shape_13.setTransform(57.0299,132.7124,1.1724,1.1724);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#515055").p("AmpirINSFW");
	this.shape_14.setTransform(54.9197,134.8227,1.1724,1.1724);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#515055").s().p("AgVIqIAAxTIAqAAIAARTg");
	this.shape_15.setTransform(399.8876,172.1331,1.1724,1.1724);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#515055").s().p("AgUIqIAAxTIAqAAIAARTg");
	this.shape_16.setTransform(300.9987,172.1331,1.1724,1.1724);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#515055").s().p("AgVIqIAAxTIAqAAIAARTg");
	this.shape_17.setTransform(203.7512,172.1331,1.1724,1.1724);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#515055").s().p("AgVIqIAAxTIAqAAIAARTg");
	this.shape_18.setTransform(105.6244,172.1331,1.1724,1.1724);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#515055").s().p("AgUIqIAAxTIAqAAIAARTg");
	this.shape_19.setTransform(5.8563,172.1331,1.1724,1.1724);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#5E050F").s().p("AmaDoIAAnPIM1AAIAAHPg");
	this.shape_20.setTransform(54.9197,188.048,1.1724,1.1724);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#DED0BE").s().p("AmaDoIAAnPIM1AAIAAHPg");
	this.shape_21.setTransform(154.6878,188.8686,1.1724,1.1724);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#DED0BE").s().p("AmaDoIAAnPIM1AAIAAHPg");
	this.shape_22.setTransform(254.4559,134.383,1.1724,1.1724);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#5E050F").s().p("AmhDcIAAm3INDAAIAAG3g");
	this.shape_23.setTransform(350.7656,189.9531,1.1724,1.1724);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#D77A54").s().p("AhQDIIBmmdIA7APIhmGdg");
	this.shape_24.setTransform(342.7642,136.9916,1.1724,1.1724);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FAB16A").s().p("AhCC3IBdl3IAnAKIhbF3g");
	this.shape_25.setTransform(350.9414,138.9553,1.1724,1.1724);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#684D4C").s().p("AgkDpIAjnUIAmADIgjHUg");
	this.shape_26.setTransform(361.4048,133.0934,1.1724,1.1724);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#984439").s().p("AgXDVIAAmpIAwAAIAAGpg");
	this.shape_27.setTransform(368.4096,135.7606,1.1724,1.1724);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#D68E79").s().p("AgXDoIAAnPIAvAAIAAHPg");
	this.shape_28.setTransform(375.0921,133.4452,1.1724,1.1724);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#D77A54").s().p("AgzCnIAAlNIBnAAIAAFNg");
	this.shape_29.setTransform(385.6727,140.9483,1.1724,1.1724);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#D77A54").s().p("AhbjhIBEgRIBzHUIhEARg");
	this.shape_30.setTransform(60.547,70.5479,1.1724,1.1724);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FAB16A").s().p("AhKjPIAtgLIBoGpIgtAMg");
	this.shape_31.setTransform(51.256,72.8047,1.1724,1.1724);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#684D4C").s().p("AgpkHIArgDIAoISIgrADg");
	this.shape_32.setTransform(39.4152,66.1515,1.1724,1.1724);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#984439").s().p("AgbDxIAAnhIA3AAIAAHhg");
	this.shape_33.setTransform(31.4431,69.1703,1.1724,1.1724);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#D68E79").s().p("AgbEHIAAoNIA3AAIAAINg");
	this.shape_34.setTransform(23.8814,66.5618,1.1724,1.1724);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#D77A54").s().p("Ag6C9IAAl5IB1AAIAAF5g");
	this.shape_35.setTransform(11.9233,75.0028,1.1724,1.1724);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#BC916B").s().p("Ag0AEIAAAAQAAgIAJABIBXAAQAEAAACACQADABAAAEIAAAAg");
	this.shape_36.setTransform(261.4608,75.0322,1.1724,1.1724);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#BC916B").s().p("Ag0AEIAAAAQAAgIAJABIBXAAQAEAAACACQADABAAAEIAAAAg");
	this.shape_37.setTransform(241.9996,75.0322,1.1724,1.1724);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#573311").s().p("AAcAqIg4AAIgEgBIgIgMQgFgKgDgRIgEgWQgBgGAAgHIABgHIBogBIACAFQABAIgCAKQgDAZgLAaQgEAJgGAAIgBAAg");
	this.shape_38.setTransform(261.5331,80.2838,1.1724,1.1724);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#573311").s().p("AgcAqIgEgBIgHgMQgGgKgDgRIgEgWQgBgGAAgHIABgHIBpgBIABAFQABAIgCAKQgBAMgFAQQgEAOgEAJQgFAKgGgBIgnAAIgRAAg");
	this.shape_39.setTransform(242.0132,80.2931,1.1724,1.1724);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#D1D0BE").s().p("AgrBHQgHAAgDgHIgOgtIgJgxIAAgoICZAAIAAAoIgJAxIgOAtQgDAHgHAAg");
	this.shape_40.setTransform(261.4022,78.432,1.1724,1.1724);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#D1D0BE").s().p("AgrBHQgHAAgDgHIgQg2IgHgsIAAgkICZAAIAAAkIgJA1IgPAtQgCAHgIAAg");
	this.shape_41.setTransform(242.0289,78.432,1.1724,1.1724);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#D1D0BE").s().p("AhUAiIAAhCICpAAIAABCg");
	this.shape_42.setTransform(251.7302,48.4195,1.1724,1.1724);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#585B5C").s().p("AAVARIAAgLIgoAAIAAALIgcAAIAAgLIgVAAIAAgWICJAAIAAAWIgUAAIAAALg");
	this.shape_43.setTransform(251.7302,54.252,1.1724,1.1724);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#D77A54").s().p("AkjA4IAAhvIJHAAIAABvg");
	this.shape_44.setTransform(250.6164,93.5262,1.1724,1.1724);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#573311").s().p("AjxC4IAAlvIHjAAIAAFvg");
	this.shape_45.setTransform(250.8216,65.536,1.1724,1.1724);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#585B5C").s().p("AgSATQgIgIAAgLQAAgKAIgIQAIgIAKAAQALAAAIAIQAIAIAAAKQAAALgIAIQgIAIgLAAQgLAAgHgIg");
	this.shape_46.setTransform(250.9681,31.8599,1.1724,1.1724);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#D1D0BE").s().p("AgfAgQgNgNAAgTQAAgSANgNQANgNASAAQATAAANANQANANAAASQAAATgNANQgNANgTAAQgSAAgNgNg");
	this.shape_47.setTransform(250.8509,31.684,1.1724,1.1724);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#D77A54").s().p("AkjCDIAAkFIJHAAIAAEFg");
	this.shape_48.setTransform(250.6164,29.1634,1.1724,1.1724);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#D1D0BE").s().p("ADlA9IAAgxQAAgVgOgQQgOgQgUAAIljAAQgWAAgQAQQgQAQAAAVIAAAxIgTAAIAAgxQAAgdAVgWQAWgVAeAAIFjAAQAcAAAUAVQATAWAAAdIAAAxg");
	this.shape_49.setTransform(250.3233,7.1816,1.1724,1.1724);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#573311").s().p("AjOAYIAAgvIGdAAIAAAvg");
	this.shape_50.setTransform(250.5285,11.7832,1.1724,1.1724);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#E62F33").s().p("Ag3AtQgGg4AKglIAUADQAYADAUgCQAigCAGgCIAEAeQADAjgCAbQgiAFgdAAQgbAAgXgEg");
	this.shape_51.setTransform(80.5231,75.663,1.1724,1.1724);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#2A1213").s().p("AgmCzQgOgEgCgZIAAgcQADgGACgJQADgRgGgdQgJgqAJheQABgGAJgQIAQgbQAFgLABgSIABgQIgGAAIAAgJIAzAAIAAAJIgGAAIABAQQABASAFALIAQAbQAIAQACAGQAIBegIAqQgGAdAEARQABAJADAGIAAAcQgDAZgNAEg");
	this.shape_52.setTransform(80.5358,78.9303,1.1724,1.1724);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#E62F33").s().p("AgaALIAAgSIABgBQACgCAGAAIAmAAIADABQABAAAAAAQABABAAAAQABAAAAABQAAAAAAABIAAARg");
	this.shape_53.setTransform(80.5798,56.2597,1.1724,1.1724);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Mueble_4, new cjs.Rectangle(0,0,403.3,237.1), null);


(lib.Mesa_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#C4B49B").s().p("AH+EpIjGooIpvAAIjGIoIghAAIBgooIAAgpIN9AAIAAApIBgIog");
	this.shape.setTransform(149.8201,87.062,2.4722,2.4722);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#DED0BE").s().p("ApuAcIAAg3ITdAAIAAA3g");
	this.shape_1.setTransform(153.961,6.8402,2.4722,2.4722);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Mesa_1, new cjs.Rectangle(0,0,307.9,160.4), null);


(lib.mc4r_etro = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.t5 = new cjs.Text("¿Estás seguro que las recomendaciones que elegiste son las mejores? ¿Son todas?\n\nLa elección no es fácil, ¿verdad?\n\nConozcamos a continuación, el proceso para mapear el talento y hacer LA MEJOR elección al seleccionar sucesores.", "9px 'Arial'");
	this.t5.name = "t5";
	this.t5.textAlign = "center";
	this.t5.lineHeight = 12;
	this.t5.lineWidth = 216;
	this.t5.parent = this;
	this.t5.setTransform(254.95,53.7,1.9497,1.9497);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,255,0.498)").s().p("EglRAWVQgxAAghgjQgigjgBgxMAAAgo8QABgxAigiQAhgjAxAAMBKhAAAQAxAAAjAjQAiAiAAAxMAAAAo8QAAAxgiAjQgjAjgxAAg");
	this.shape.setTransform(250.25,142.875);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("EglRAWVQgxAAghgjQgigjgBgxMAAAgo8QABgxAigiQAhgjAxAAMBKhAAAQAxAAAjAjQAiAiAAAxMAAAAo8QAAAxgiAjQgjAjgxAAg");
	this.shape_1.setTransform(250.25,142.875);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape},{t:this.t5}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.mc4r_etro, new cjs.Rectangle(0,0,500.5,285.8), null);


(lib.mc_numMod01 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AALDGIAAkcQgoAng5ASIAAhEQAegKAjgbQAigbANgkIA9AAIAAGLg");
	this.shape.setTransform(23.9,32.075);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#D73D45").s().p("AghEHQhPgMg8g4IgKgJQg+g7gQhQQgPhKAchJQAdhIA+gtQBDgwBVAAIAJAAQBsAABNBNQBMBMAABsIAAAIQAABTgtBBQgqA9hGAfQgzAWg1AAQgSAAgUgDg");
	this.shape_1.setTransform(26.6164,32.5226);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.mc_numMod01, new cjs.Rectangle(0,0,53.3,65.5), null);


(lib.Maseta1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#4A9868").s().p("AhFBfQgDhcAKheQAVi+A+gWIgVBtQgOB2AgApQAiAoANAnQAGAUgBALIhFDlg");
	this.shape.setTransform(67.0663,42.4358,1.3956,1.3956);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#109773").s().p("Ai2AjQA5iLBvglQBuglBIASQAkAIAOAQQgvAFg1ANQhrAagcAqQghAvgLBYQgGAtABAjIiXACQAGg+AdhGg");
	this.shape_1.setTransform(98.0812,67.7578,1.3956,1.3956);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#149848").s().p("AiwEHQAShUAdhgQA7i+Azg7QAzg8BOgYQAngMAcAAQg/Adg+B2IgxBxIgmEJg");
	this.shape_2.setTransform(90.3006,54.6125,1.3956,1.3956);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#149848").s().p("AAkEHIgmkJQgSg2gfg7Qg+h2g/gdIBDAMQBOAYAzA8QAzA7A6C+QAdBgATBUg");
	this.shape_3.setTransform(44.4896,54.6125,1.3956,1.3956);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#109773").s().p("ABEClQABgjgHgtQgLhYghgvQgcgqhrgaIhlgSIAMgJQAQgKAXgFQBIgSBuAlQBvAlA5CLQAdBGAHA+g");
	this.shape_4.setTransform(30.4986,67.7578,1.3956,1.3956);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#D77A54").s().p("AkekpII9AAIhKJNImHAGg");
	this.shape_5.setTransform(64.8656,132.6274,1.3956,1.3956);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Maseta1, new cjs.Rectangle(0,0,128.6,174.3), null);


(lib.mascaratapar = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EgvWACqIAAlTMBetAAAIAAFTg");
	this.shape.setTransform(303.075,17);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,606.2,34);


(lib.lapizmueve = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#010101").s().p("Ah8CUIgEgCIgCgEQAAgBAAAAQAAgBABAAQAAgBAAAAQABAAAAgBIAEgBID0AAQABAAAAAAQABAAAAAAQABAAAAABQABAAAAAAQAAABABAAQAAAAAAABQAAAAAAABQAAAAAAABQAAABAAAAQAAABAAABQAAAAAAAAQgBABAAAAQAAABgBAAQAAAAgBAAQAAABgBAAQAAAAgBAAgAh4B/IgBgCIAQgwIABgBIABAAIAcAXIABACIgBABIgsAZIAAAAIgBAAgAhiBEIAYgnIAggrIAsAkQgSAWgRASQgSATgPANgAAGAMIgmgfIgBgDIAAgDIBUhpIgGgEIhBBSIgHgGIBFhZIAOALIABgCIADgBIBDgCQABAAABAAQAAAAABAAQAAABAAAAQABABAAAAIgBAEIh2CSIgDACIgDgBg");
	this.shape.setTransform(21.9083,22.525);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(8.8,7.8,26.2,29.499999999999996);


(lib.interrogamover = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#990000").s().p("AgnDZIAAhSIBRAAIAABSgAgnBqIAAgUQAAgjAMgYQAMgYAjgcQAkgdAHgJQALgOAAgSQAAgYgTgRQgUgRggAAQgfAAgVARQgVATgIAkIhLgJQADg1AqgkQApglBDAAQBGAAAqAmQAqAkAAAxQAAAcgPAYQgQAZgyAoQgaAWgGANQgHAOABAhg");
	this.shape.setTransform(15.425,21.7);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,30.9,43.4);


(lib.info01ss = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.text = new cjs.Text("“La gestión del talento es un proceso continuo y requiere del compromiso de todos los participantes”.", "16px 'Arial'");
	this.text.textAlign = "center";
	this.text.lineHeight = 16;
	this.text.lineWidth = 153;
	this.text.parent = this;
	this.text.setTransform(-219.65,-8.85);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E3EFB9").s().p("AskJWQhkAAAAhkIAArPIAAg/IAAgnIAAgwIAAiFIAAhDIAYAAQAZgaAzAAIFbAAIAWAAIAAAAIAVAAIAqAAIAYAAICwAAIHLAAIDIAAIF2AAIAAAMQALAFAJAJIAYAAIAABDIAAA8IAABJIAAMKIAAAYIAABDQAABDgsAWIAAALg");
	this.shape.setTransform(-219.925,33.15);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.text}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.info01ss, new cjs.Rectangle(-310.4,-26.6,180.99999999999997,145.1), null);


(lib.globodialogo5cambio = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AirHUMglZAAAQg8gCgngnQgNgNgJgOQgTgggBgoIAA49QABgoATggQAJgOANgNQAngnA8gCMBQKAAAQA7ACAoAnQAoAoABA7IAAY9QgBA7goAoQgoAng7ACMgkpAAAICMOjIgDALg");
	this.shape.setTransform(19.45,88.825);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.globodialogo5cambio, new cjs.Rectangle(-251.1,-52.1,541.2,281.90000000000003), null);


(lib.globodialogo3cambio = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("ADYHUMg1kAAAQg7gCgognQgogogBg7IAA49QABg7AogoQAognA7gCMBkZAAAQA7ACAoAnQAoAoABA7IAAY9QgBA7goAoQgoAng7ACMgorAAAICMOjIgEALg");
	this.shape.setTransform(14.3,42.225);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.globodialogo3cambio, new cjs.Rectangle(-321,-98.7,670.7,281.9), null);


(lib.globodialogo2c = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AmuJVMgpcAAAQg8gBgngoQgogngCg8IAA8/QACg8AognQAngoA8gBMBgVAAAQA8ABAoAoQAnAnACA8IAAc/QgCA8gnAnQgoAog8ABMgwwAAAICLOjIgDALg");
	this.shape.setTransform(45.35,81.075);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.globodialogo2c, new cjs.Rectangle(-277,-72.8,644.8,307.8), null);


(lib.globodialogo2bcambio = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("ABXHUMgpbAAAQg8gCgognQgogogBg7IAA49QABg7AogoQAognA8gCMBQJAAAQA8ACAoAnQAnAoACA7IAAY9QgCA7gnAoQgoAng8ACMggkAAAICLOjIgDALg");
	this.shape.setTransform(-92,115.075);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.globodialogo2bcambio, new cjs.Rectangle(-362.6,-25.9,541.2,282), null);


(lib.globodialogo2b = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AHbJVMgpaAAAQg9gBgngoQgogngCg8IAA8/QACg8AognQAngoA9gBMBEAAAAQA7ABApAoQAnAnABA8IAAc/QgBA8gnAnQgpAog7ABI0cAAICMOjIgEALg");
	this.shape.setTransform(-130.85,128.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.globodialogo2b, new cjs.Rectangle(-362.6,-25.9,463.5,307.9), null);


(lib.globodialogo2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AHcJVI2fAAMAAAghXMAxEAAAQA8ABAoAoQAnAnABA8IAAc/QgBA8gnAnQgoAog8ABI0cAAICLOjIgCALgEgiAAJVQg8gBgngoQgogngCg8IAA8/QACg8AognQAngoA8gBIS8AAMAAAAhXg");
	this.shape.setTransform(-45.3,81.075);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.globodialogo2, new cjs.Rectangle(-277,-72.8,463.5,307.8), null);


(lib.globodialogo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AHcJVI2fAAMAAAghXMAxEAAAQA8ABAoAoIAGAGQAhAmABA3IAAc/QgBA8gnAnQgoAog8ABI0cAAICLOjIgCALgEgiAAJVQg8gBgngoQgogngCg8IAA8/QACg3AigmIAGgGQAngoA8gBIS8AAMAAAAhXg");
	this.shape.setTransform(179.95,128.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.globodialogo, new cjs.Rectangle(-51.8,-25.9,463.5,307.9), null);


(lib.Fondo_oficina_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// flash0.ai
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#B5B7B8").s().p("EgzFAF7IAAr1MBmLAAAIAAL1g");
	this.shape.setTransform(482.2721,414.2581,1.3986,1.4454);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#E3EFB9").s().p("EhHQAisMAAAhFXMBgnAAAIAAI6IFRAAIAAo6MAopAAAMAAABFXgAeo5xIlRAAIAAo6IFRAAIAAI6gEAZXgirg");
	this.shape_1.setTransform(480.775,222);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Fondo_oficina_1, new cjs.Rectangle(24.7,0,915,469.1), null);


(lib.flechainstrucciones = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D73D45").s().p("ABFBsIhLhNIgYA4QgEAHgHAAQgIgBgCgHIg6i1QgCgHAEgFQAFgEAHACIC1A6QAHACABAIQAAAHgHAEIg3AYIBMBLQADADAAAFQAAAEgDAEIgXAXQgDADgFAAQgFAAgDgDg");
	this.shape.setTransform(8.1455,9.1455,0.7838,0.7838);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.5,0.5,17.4,17.4);


(lib.Group_17 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#6379B7").ss(0.5).p("AgDhBIAHCD");
	this.shape.setTransform(0.65,6.6);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_17, new cjs.Rectangle(-0.7,-1,2.8,15.2), null);


(lib.Group_16 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#6379B7").ss(0.5).p("AgDg/QAEA/ADBA");
	this.shape.setTransform(0.6256,6.3942);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_16, new cjs.Rectangle(-0.7,-1,2.7,14.8), null);


(lib.Group_15 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#6379B7").ss(0.5).p("AgDg7IAHB3");
	this.shape.setTransform(0.65,5.975);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_15, new cjs.Rectangle(-0.7,-1,2.8,14), null);


(lib.Group_14 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#6379B7").ss(0.5).p("AgDg9QAEA9ADA+");
	this.shape.setTransform(0.6257,6.1683);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_14, new cjs.Rectangle(-0.7,-1,2.7,14.4), null);


(lib.Group_13 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#6379B7").ss(0.5).p("AgDg8QAEA8ADA9");
	this.shape.setTransform(0.6257,6.119);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_13, new cjs.Rectangle(-0.7,-0.9,2.7,14.1), null);


(lib.Group_12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#6379B7").ss(0.5).p("AgDg5QAEA5ADA7");
	this.shape.setTransform(0.6257,5.8936);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_12, new cjs.Rectangle(-0.7,-0.9,2.7,13.700000000000001), null);


(lib.Group_11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#6379B7").ss(0.5).p("AAEhBIgHCD");
	this.shape.setTransform(0.65,6.6);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_11, new cjs.Rectangle(-0.7,-1,2.8,15.2), null);


(lib.Group_10 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#6379B7").ss(0.5).p("AAEg/QgEA/gDBA");
	this.shape.setTransform(0.6244,6.3942);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_10, new cjs.Rectangle(-0.7,-1,2.7,14.8), null);


(lib.Group_9 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#6379B7").ss(0.5).p("AAEg7IgHB3");
	this.shape.setTransform(0.65,5.975);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_9, new cjs.Rectangle(-0.7,-1,2.8,14), null);


(lib.Group_8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#6379B7").ss(0.5).p("AAEg9QgEA9gDA+");
	this.shape.setTransform(0.6243,6.1683);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_8, new cjs.Rectangle(-0.7,-1,2.7,14.4), null);


(lib.Group_7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#6379B7").ss(0.5).p("AAEg8QgEA8gDA9");
	this.shape.setTransform(0.6243,6.119);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_7, new cjs.Rectangle(-0.7,-0.9,2.7,14.1), null);


(lib.Group_6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#6379B7").ss(0.5).p("AAEg5QgEA5gDA7");
	this.shape.setTransform(0.6243,5.8936);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_6, new cjs.Rectangle(-0.7,-0.9,2.7,13.700000000000001), null);


(lib.Group_5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#6379B7").ss(0.5).p("AAQgwIgfBh");
	this.shape.setTransform(1.8,5.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_5, new cjs.Rectangle(-0.7,-0.9,5.1000000000000005,11.9), null);


(lib.Group_4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#6379B7").ss(0.5).p("AgLAlIAXhJ");
	this.shape.setTransform(1.375,3.775);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_4, new cjs.Rectangle(-0.8,-0.9,4.4,9.4), null);


(lib.Group_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#6379B7").ss(0.5).p("AgXgxQAVANALAiQAHAUAGAk");
	this.shape.setTransform(2.5934,5.2156);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_3, new cjs.Rectangle(-0.8,-0.8,6.6,12.5), null);


(lib.Group_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#6379B7").ss(0.5).p("AAYgxQggAVgNBS");
	this.shape.setTransform(2.435,5.2122);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_2, new cjs.Rectangle(-0.7,-0.8,6.6000000000000005,12.5), null);


(lib.Group_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#6379B7").ss(0.5).p("AgIgbIARA3");
	this.shape.setTransform(1.175,2.8);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_1, new cjs.Rectangle(-0.7,-0.9,3.8,7.5), null);


(lib.Group = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#6379B7").ss(0.5).p("AARAvIghhd");
	this.shape.setTransform(1.875,4.75);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group, new cjs.Rectangle(-0.8,-0.9,5.3999999999999995,11.3), null);


(lib.ClipGroup_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhGAeQgCgIAAgHQABgRANgPQAQgTAbgEQAXgFAYAJQAdAMAJAWQAHAUgJAWIiCADQgFgEgDgJg");
	mask.setTransform(7.2863,4.2638);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#C8885F").s().p("AhGAeQgCgIAAgHQABgRANgPQAQgTAbgEQAXgFAYAJQAdAMAJAWQAHAUgJAWIiCADQgFgEgDgJg");
	this.shape.setTransform(7.2863,4.2638);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_1, new cjs.Rectangle(0,0,14.6,8.6), null);


(lib.ClipGroup = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("ABKCdIAAgCIARgwQAIgbAAgWQABgfgJgWQgKgWgWgVQgIgIgjgVQgbgRgKgSIgFAEIgYAaQgRASgFAHQgQAWgEAfQgDAcAFAfQADATAGARIAJAYIAFAIQAAABAAABQAAABAAAAQgBABAAAAQAAAAgBgBIAAgBIgBAAIgCgFIgRgZQgJgOgCgNIgKhTQgHgmAHgaQAHgaAVgYQAOgPAHgEQBCgkBAAjQAXANAPAtQAHAVAAARQABALgEARQgFAZABAHQAAALAEAXQADARgFAPQgEANgIAPIgWAuIAAAAIgBAAg");
	mask.setTransform(11.4216,15.7059);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CC8D61").s().p("ABKCdIAAgCIARgwQAIgbAAgWQABgfgJgWQgKgWgWgVQgIgIgjgVQgbgRgKgSIgFAEIgYAaQgRASgFAHQgQAWgEAfQgDAcAFAfQADATAGARIAJAYIAFAIQAAABAAABQAAABAAAAQgBABAAAAQAAAAgBgBIAAgBIgBAAIgCgFIgRgZQgJgOgCgNIgDgrIgHgoQgHgmAHgaQAHgaAVgYQAOgPAHgEQBCgkBAAjQAXANAPAtQAHAVAAARQABALgEARQgFAZABAHQAAALAEAXQADARgFAPQgEANgIAPIgWAuIAAAAIgBAAg");
	this.shape.setTransform(11.4216,15.7059);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FBEC3F").s().p("ABKCdIAAgCIARgwQAIgbAAgWQABgfgJgWQgKgWgWgVQgIgIgjgVQgbgRgKgSIgFAEIgYAaQgRASgFAHQgQAWgEAfQgDAcAFAfQADATAGARIAJAYIAFAIQAAABAAABQAAABAAAAQgBABAAAAQAAAAgBgBIAAgBIgBAAIgCgFIgRgZQgJgOgCgNIgKhTQgHgmAHgaQAHgaAVgYQAOgPAHgEQBCgkBAAjQAXANAPAtQAHAVAAARQABALgEARQgFAZABAHQAAALAEAXQADARgFAPQgEANgIAPIgWAuIAAAAIgBAAg");
	this.shape_1.setTransform(11.4216,15.7059);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup, new cjs.Rectangle(0,0,22.9,31.4), null);


(lib.Path = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AAxFTQh4gBhphqQiFiEgeiDQA0haBWhXQBUhTBXgvQCFAeCCCDQBqBpABB4QABByhZBZQhYBYhwAAIgDAAg");
	this.shape.setTransform(33.9756,33.8756);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Path, new cjs.Rectangle(0,0,68,67.8), null);


(lib.imgmod1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EgBBAiNQm9AAmXisQmJimkvkvQkvkvimmJQismWAAm+QAAm8CsmXQCmmJEvkvQEvkvGJimQGXisG9AAICCAAQG+AAGXCsQGJCmEuEvQEwEvCmGJQCsGXAAG8QAAG+isGWQimGJkwEvQkuEvmJCmQmXCsm+AAg");
	mask.setTransform(386.95,218.9);

	// Capa_3
	this.instance = new lib.Módulo1();
	this.instance.parent = this;
	this.instance.setTransform(69,-11);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.imgmod1, new cjs.Rectangle(161.5,0,451,437.8), null);


(lib.e3buttons3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(66,66,66,0.008)").s().p("A1DISIAAwjMAqHAAAIAAQjg");
	this.shape.setTransform(134.8,52.975);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.e3buttons3, new cjs.Rectangle(0,0,269.6,106), null);


(lib.e3buttons2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(66,66,66,0.008)").s().p("A1LIpIAAxSMAqXAAAIAARSg");
	this.shape.setTransform(135.6,55.35);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.e3buttons2, new cjs.Rectangle(0,0,271.2,110.7), null);


(lib.e3buttons = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(66,66,66,0.008)").s().p("A1DJCIAAyDMAqHAAAIAASDg");
	this.shape.setTransform(134.8,57.775);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.e3buttons, new cjs.Rectangle(0,0,269.6,115.6), null);


(lib.e2buttons2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(66,66,66,0.008)").s().p("A2LIhIAAxCMAsXAAAIAARCg");
	this.shape.setTransform(142,54.55);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.e2buttons2, new cjs.Rectangle(0,0,284,109.1), null);


(lib.e2buttons = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(66,66,66,0.008)").s().p("A17IyIAAxjMAr3AAAIAARjg");
	this.shape.setTransform(140.4,56.175);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.e2buttons, new cjs.Rectangle(0,0,280.8,112.4), null);


(lib.e1Buttos = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(69,69,69,0.008)").s().p("A2SIZIAAwyMAslAAAIAAQyg");
	this.shape.setTransform(142.725,53.75);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.e1Buttos, new cjs.Rectangle(0,0,285.5,107.5), null);


(lib.e1buttons4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(69,69,69,0.008)").s().p("A17JBIAAyCMAr3AAAIAASCg");
	this.shape.setTransform(140.4,57.75);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.e1buttons4, new cjs.Rectangle(0,0,280.8,115.5), null);


(lib.e1buttons3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(69,69,69,0.008)").s().p("A2TIpIAAxSMAsnAAAIAARSg");
	this.shape.setTransform(142.8,55.35);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.e1buttons3, new cjs.Rectangle(0,0,285.6,110.7), null);


(lib.e1buttons2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(69,69,69,0.008)").s().p("A17JBIAAyCMAr3AAAIAASCg");
	this.shape.setTransform(140.4,57.75);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.e1buttons2, new cjs.Rectangle(0,0,280.8,115.5), null);


(lib.Cuadros_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AmzG3IAAttINmAAIAANtg");
	this.shape.setTransform(63.2981,63.5399,1.3956,1.3956);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#C4B49B").s().p("AnJHKIAAuTIOTAAIAAOTg");
	this.shape_1.setTransform(63.9262,63.9237,1.3956,1.3956);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Cuadros_1, new cjs.Rectangle(0,0,127.9,127.9), null);


(lib.Cuadro_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#684D4C").s().p("AguBCQgDAAgEgCQgXgRAAgeIAAhFQAAgGADgDQAEgEAFAAICBAAQAGAAADAFQAEAEgBAFIAAACIAAA3QACAPgEARQgIAcgYAAg");
	this.shape.setTransform(54.2287,60.6973,2.4722,2.4722);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#509B5C").s().p("AgLAXIgBgKQABgLAEgHQAGgMAFgGIAFASQAFAPgCAGQgCAHgGABg");
	this.shape_1.setTransform(47.9807,38.8805,2.4722,2.4722);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#A0C5A7").s().p("AgIAWQgCgNABgKQABgGADgIIADgGIAFAKQAEAFABAEIACAYg");
	this.shape_2.setTransform(51.7821,39.0041,2.4722,2.4722);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#A0C5A7").s().p("AgIAWQgCgNABgKQABgGADgIIADgGIAGAKIAEAJIACAYg");
	this.shape_3.setTransform(62.536,39.0041,2.4722,2.4722);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#509B5C").s().p("AgLAQQgBgFAEgQIAFgSIADAFQAEAFAEAIQAGALgCARIgPABQgGgBgCgHg");
	this.shape_4.setTransform(58.3203,38.7568,2.4722,2.4722);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#A0C5A7").s().p("AgIAWQgBgNABgKQAAgGADgIIADgGIAGAKIAEAJQABAGABASg");
	this.shape_5.setTransform(45.8983,39.0041,2.4722,2.4722);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#509B5C").s().p("AgJAKQACgIAJgMIAJgNIABAGQABAHgBAKQgBANgJAKIgOAAQAAgCADgLg");
	this.shape_6.setTransform(67.2749,38.695,2.4722,2.4722);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#509B5C").s().p("AgBAXQgIgKgCgOQgBgJABgIIABgEIAJALQAJAOACAGQAEAMgBADg");
	this.shape_7.setTransform(40.9815,38.5714,2.4722,2.4722);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#ADAAD4").s().p("AgJAKQACgIAJgNIAJgMIACAGQABAGgCAKQgBAOgJAKIgOAAQAAgCADgLg");
	this.shape_8.setTransform(63.8633,38.4478,2.4722,2.4722);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#ADAAD4").s().p("AgBAXQgIgKgCgOQgBgJABgIIABgEIAJALQAJAOACAGQAEAMgBADg");
	this.shape_9.setTransform(44.0717,38.5714,2.4722,2.4722);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AjPDQIAAmfIGfAAIAAGfg");
	this.shape_10.setTransform(54.7363,54.8259,2.4722,2.4722);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#C4B49B").s().p("Ai8DfQgOAAgJgKQgKgKAAgOIAAl5QAAgOAKgJQAJgLAOAAIF5AAQAOAAAKALQAKAJAAAOIAAF5QAAAOgKAKQgKAKgOAAg");
	this.shape_11.setTransform(54.9835,55.0114,2.4722,2.4722);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Cuadro_2, new cjs.Rectangle(0,0,110,110), null);


(lib.Computadora_por_atras = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#A5A8A2").s().p("AhMDsIAAg4IAAmfICZAAIAAGfIAAA4g");
	this.shape.setTransform(55.725,60.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("ABpGIIAAmfIiaAAIAAGfIm4AAQgQAAgNgMQgLgLABgQIAArBQgBgQALgLQANgMAQAAIPTAAQAQAAALAMQANALAAAQIAALBQAAAQgNALQgLAMgQAAg");
	this.shape_1.setTransform(52.95,39.225);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Computadora_por_atras, new cjs.Rectangle(0,0,105.9,84), null);


(lib.CirculoRojo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D73D45").s().p("AoZIYQjejdAAk7QAAk6DejfQDfjeE6AAQE7AADdDeQDgDfAAE6QAAE7jgDdQjdDgk7AAQk6AAjfjgg");
	this.shape.setTransform(0.025,0);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-75.9,-76,151.9,152);


(lib.circulo2instrucciones = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#ACAFA1").p("AB9AAQAAAzgkAlQglAlg0AAQgzAAgkglQglglAAgzQAAgzAlglQAkgkAzAAQA0AAAlAkQAkAlAAAzg");
	this.shape.setTransform(14,14);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.5,0.5,27,27);


(lib.circulo1instrucciones = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#B9BDAD").s().p("Ag/BAQgagbgBglQABglAagaQAbgbAkAAQAlAAAbAbQAbAagBAlQABAlgbAbQgbAbglgBQgkABgbgbg");
	this.shape.setTransform(104.5759,9.0501,0.895,0.895);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(96.5,1,16.200000000000003,16.2);


(lib.circulo_blanco = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AmrGsQixixAAj7QAAj6CxixQCxixD6AAQD7AACxCxQCxCxAAD6QAAD7ixCxQixCxj7AAQj6AAixixg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-60.5,-60.5,121,121);


(lib.CERRO = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AjCBWIAAisIGEAAIAACsg");
	mask.setTransform(19.45,8.65);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#485150").s().p("AjABXIgChiQA+gbApghQAZgUAVAIQALAEARAKQAKACAIgJQAJgKAEABIAWAJQAOAHAHAAQAFAAAOgIQAOgIALACQAUADBJBFIAABig");
	this.shape.setTransform(19.45,8.6477);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.CERRO, new cjs.Rectangle(0,0,38.9,17.3), null);


(lib.Cafetera = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#BC916B").s().p("AgaACIAAAAQAAgDAFAAIArAAQAFAAAAADIAAAAg");
	this.shape.setTransform(48.1094,80.043,2.4722,2.4722);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#BC916B").s().p("AgaACIAAAAQAAgDAFAAIArAAQAFAAAAADIAAAAg");
	this.shape_1.setTransform(27.3432,80.043,2.4722,2.4722);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#573311").s().p("AAiA0IhGAAQgEAAgBgBIgJgPQgFgJgLg0IABgaICCAAIABAGQACAJgCANQgDAjgPAdQgFALgHAAIgCAAg");
	this.shape_2.setTransform(48.2125,85.683);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#573311").s().p("AAOAVIgcAAIgCgBIgEgGQgCgDgEgVIAAgKIA0AAIABACIAAAJQgCAOgGALQgCAFgDAAIAAAAg");
	this.shape_3.setTransform(27.4359,85.6728,2.4722,2.4722);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#D1D0BE").s().p("AgVAeQgEAAgBgDIgHgTIgFgUIAAgRIBNAAIAAARIgFAUIgHATQgBADgEAAg");
	this.shape_4.setTransform(48.0476,85.6054,2.4722,2.4722);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#D1D0BE").s().p("AgVAkQgEAAgBgEIgHgWIgFgZIAAgUIBMAAIABAUIgEAZIgIAWQgBAEgEAAg");
	this.shape_5.setTransform(27.405,83.6276,2.4722,2.4722);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#D1D0BE").s().p("AgqARIAAghIBVAAIAAAhg");
	this.shape_6.setTransform(37.7881,51.6749,2.4722,2.4722);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#585B5C").s().p("AALAJIAAgGIgUAAIAAAGIgOAAIAAgGIgLAAIAAgLIBFAAIAAALIgKAAIAAAGg");
	this.shape_7.setTransform(37.7263,57.9171,2.4722,2.4722);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#573311").s().p("Ah5BdIAAi5IDzAAIAAC5g");
	this.shape_8.setTransform(36.7374,69.9071,2.4722,2.4722);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#585B5C").s().p("AgJAKQgEgFAAgFQAAgFAEgEQAEgEAFAAQAFAAAFAEQAEAEAAAFQAAAFgEAFQgFAEgFAAQgFAAgEgEg");
	this.shape_9.setTransform(36.9229,34.0607,2.4722,2.4722);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#D1D0BE").s().p("AgPAQQgHgHAAgJQAAgIAHgIQAGgGAJAAQAJAAAHAGQAHAIAAAIQAAAJgHAHQgHAHgJAAQgJAAgGgHg");
	this.shape_10.setTransform(36.7992,33.8752,2.4722,2.4722);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#D77A54").s().p("AiTBCIAAiDIEnAAIAACDg");
	this.shape_11.setTransform(36.4902,31.1559,2.4722,2.4722);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#D1D0BE").s().p("AB0AfIAAgZQAAgKgHgIQgHgIgKAAIizAAQgLAAgJAIQgIAIAAAKIAAAZIgKAAIAAgZQAAgOALgLQALgLAQAAICzAAQAOAAAKALQAKALAAAOIAAAZg");
	this.shape_12.setTransform(36.243,7.6703,2.4722,2.4722);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#573311").s().p("AhoAMIAAgXIDRAAIAAAXg");
	this.shape_13.setTransform(36.4902,12.6146,2.4722,2.4722);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#D77A54").s().p("AlsBGIAAiMILZAAIAACMg");
	this.shape_14.setTransform(36.525,100.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Cafetera, new cjs.Rectangle(0,0,73.1,107.6), null);


(lib.bullet = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#990000").s().p("AgoApQgSgRABgYQgBgXASgRQARgRAXAAQAYAAARARQASARAAAXQAAAYgSARQgRARgYAAQgXAAgRgRg");
	this.shape.setTransform(5.8272,5.8643,0.5897,0.5897);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(2.4,2.4,6.9,6.9);


(lib.btn_Validar = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.text = new cjs.Text("Compartir recomendaciones", "16px 'Arial'", "#FFFFFF");
	this.text.lineHeight = 20;
	this.text.lineWidth = 228;
	this.text.parent = this;
	this.text.setTransform(9,7.55);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#999999").s().p("Aw8CRQgoAAgdgdQgdgdAAgoIAAhdQAAgpAdgcQAdgdAoAAMAh5AAAQApAAAcAdQAdAcABApIAABdQgBAogdAdQgcAdgpAAg");
	this.shape.setTransform(110.75,17.075);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#D73D45").s().p("Aw8CRQgoAAgdgdQgdgdAAgoIAAhdQAAgpAdgcQAdgdAoAAMAh5AAAQApAAAcAdQAdAcABApIAABdQgBAogdAdQgcAdgpAAg");
	this.shape_1.setTransform(110.75,17.075);

	this.text_1 = new cjs.Text("Compartir recomendaciones", "16px 'Arial'", "#FFFFFF");
	this.text_1.lineHeight = 20;
	this.text_1.lineWidth = 228;
	this.text_1.parent = this;
	this.text_1.setTransform(9,7.55);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.text}]}).to({state:[{t:this.shape_1},{t:this.text}]},1).to({state:[{t:this.shape_1},{t:this.text_1},{t:this.text}]},1).to({state:[{t:this.shape_1}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-7.6,2.6,246.4,29);


(lib.brazo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhCBfQBIgoABgFIABg9QADhAALgbQAJgVAOAAQAHgBAFAEIAGAIQAGAKgCAQQgBAVgLBBQgLBEgEAGQgJAOhXAkg");
	mask.setTransform(6.7411,12.9222);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D6D8D8").s().p("AhCBhQBIgnABgFQgHghgDghQgIhFAOgaQANgVAWAEQALACAIAGIAGAHQAGALgCAQQgBAVgLBBQgLBEgEAFQgJAOhXAlg");
	this.shape.setTransform(6.7411,12.6686);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.brazo, new cjs.Rectangle(0,0.5,13.5,24.9), null);


(lib.brazo_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("AgiBVQgHgDgVhpQADgUANgPQAOgSAKgGQAFgDABAAIAHAqQACAOABAiQABAdABABQACADAwgjIARATQgTASgVARQgkAdgQAAIgFgBg");
	mask_1.setTransform(9.175,9.8847);

	// Layer_3
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#881A1E").s().p("AgrAGIBVgUIACAJIhVATg");
	this.shape_1.setTransform(4.425,1.45);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#881A1E").s().p("AgiBVQgHgDgVhpQADgUANgPQAOgSAKgGQAFgDABAAIAHAqQACAOABAiQABAdABABQACADAwgjIARATQgTASgVARQgkAdgQAAIgFgBg");
	this.shape_2.setTransform(9.175,9.8847);

	var maskedShapeInstanceList = [this.shape_1,this.shape_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1}]}).wait(1));

	// Layer_1
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#881A1E").s().p("AgiBVQgHgDgVhpQADgUANgPQAOgSAKgGQAFgDABAAIAHAqQACAOABAiQABAdABABQACADAwgjIARATQgTASgVARQgkAdgQAAIgFgBg");
	this.shape_3.setTransform(9.175,9.8847);

	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(1));

}).prototype = getMCSymbolPrototype(lib.brazo_1, new cjs.Rectangle(2.9,1.3,12.6,17.2), null);


(lib.botondialogose2d2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF0000").s().p("A2CIXIAAwtMAsGAAAIAAQtg");
	this.shape.setTransform(140.15,66.45);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(3).to({_off:false},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,0,282.3,120);


(lib.botondialogose2d1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF0000").s().p("A2CIXIAAwtMAsGAAAIAAQtg");
	this.shape.setTransform(140.15,66.45);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(3).to({_off:false},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,0,282.3,120);


(lib.botondialogose1d3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0066CC").s().p("A2CIXIAAwtMAsGAAAIAAQtg");
	this.shape.setTransform(140.15,46.45);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(3).to({_off:false},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-7,282.3,107);


(lib.botondialogose1d2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF0000").s().p("A2CIXIAAwtMAsGAAAIAAQtg");
	this.shape.setTransform(140.15,66.45);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(3).to({_off:false},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,0,282.3,120);


(lib.botondialogos = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF0000").s().p("A2CIXIAAwtMAsGAAAIAAQtg");
	this.shape.setTransform(140.15,66.45);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(3).to({_off:false},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,0,282.3,120);


(lib.AS_LG_153ss = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(2,0,0,4).p("ABKhhQAcAeAAAoQAAAVgMAVQgJATgQARQgJAIgDAIQgEAHAAAPIAAATQAAAJgGAGQgGAHgJAAIg3AAQgJAAgGgHQgHgGAAgJIAAgTQAAgPgDgHQgDgIgIgIQgRgRgKgTQgLgVAAgVQAAgpAcgdQAcgdApgCIAKAAQAoACAcAdg");
	this.shape.setTransform(16.3314,37.2681,1.1113,1.1113);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AitAjQgRAAgNgKQgNgLAAgOQAAgOANgJQANgLARAAIFbAAQARAAANALQAMAJAAAOQAAAOgMALQgNAKgRAAg");
	this.shape_1.setTransform(15.7774,59.2439,0.2769,0.3563);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AitAjQgRAAgNgKQgNgLAAgOQAAgOANgJQANgLARAAIFbAAQARAAANALQAMAJAAAOQAAAOgMALQgNAKgRAAg");
	this.shape_2.setTransform(15.7774,55.7169,0.2769,0.3563);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("rgba(0,0,0,0.067)").s().p("AjRBWIA7gGQA7gFAAgBQgBgBABhvQAUgtAAgCIANgSQAOgQAAgBQgBgCAUg9IgXhKQAEgDDoDkIAWAVQgHAfgMAeQgaA9gwAwQgvAvg+AaQg4AYg/ACg");
	this.shape_3.setTransform(29.2875,50.3356);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).to({state:[]},1).wait(6));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.5,21.8,49.8,54.400000000000006);


(lib.tema_entrada_titulo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_99 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(99).call(this.frame_99).wait(1));

	// destape TITULO
	this.instance = new lib.mascaratapar("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(-0.65,-226.55,1,1,0,0,0,303.1,17);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(87).to({_off:false},0).to({alpha:0},12,cjs.Ease.get(1)).wait(1));

	// TITULO
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgaAaQgLgKAAgQQAAgOALgLQAMgLAOAAQAPAAALALQALALAAAOQAAAQgLAKQgLALgPAAQgOAAgMgLg");
	this.shape.setTransform(-293.7,-228.975);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#D73D45").s().p("AgtAuQgTgTAAgbQAAgaATgTQATgTAaAAQAbAAATATQATATAAAaQAAAbgTATQgTATgbAAQgaAAgTgTg");
	this.shape_1.setTransform(-293.775,-229.1);

	this.text = new cjs.Text("¿En qué consiste Talent Management Review (TMR)?", "20px 'Arial'", "#333333");
	this.text.lineHeight = 22;
	this.text.parent = this;
	this.text.setTransform(-282.05,-240.55);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text},{t:this.shape_1},{t:this.shape}]},87).wait(13));

	// txt tit
	this.instance_1 = new lib.titulo("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(153.15,32.8,1,1,0,0,0,94.9,73.4);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(15).to({_off:false},0).wait(51).to({startPosition:0},0).to({regX:95,regY:73.6,scaleX:0.0421,scaleY:0.0421,x:153.2},15,cjs.Ease.get(1)).to({_off:true},1).wait(18));

	// circulo bco
	this.instance_2 = new lib.circulo_blanco("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(150.7,20.1,0.2397,0.2397,0,0,0,1.2,0.4);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(5).to({_off:false},0).to({regX:0,regY:0,scaleX:2,scaleY:2,x:149.3,alpha:1},10,cjs.Ease.get(1)).wait(62).to({startPosition:0},0).to({scaleX:11.1008,scaleY:11.1008,x:180.3,y:0},10,cjs.Ease.get(1)).to({_off:true},1).wait(12));

	// circulo rojo
	this.instance_3 = new lib.CirculoRojo("synched",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(150.4,0,0.0329,0.0329);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({scaleX:2,scaleY:2,y:20},9,cjs.Ease.get(1)).wait(63).to({startPosition:0},0).to({regX:0.1,regY:-0.2,scaleX:9.8803,scaleY:9.8788,x:200.95,y:-22.2},11,cjs.Ease.get(1)).to({_off:true},5).wait(12));

	// Layer 6
	this.instance_4 = new lib.numerodetema("synched",0);
	this.instance_4.parent = this;
	this.instance_4.setTransform(98.1,-13.6,1,1,0,0,0,69.8,69.7);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(15).to({_off:false},0).to({x:-40.1,y:-113.6},9,cjs.Ease.get(1)).wait(41).to({startPosition:0},0).to({x:98.1,y:-13.6},12,cjs.Ease.get(1)).to({_off:true},1).wait(22));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-550.4,-771,1501.3,1501.6);


(lib.personajes4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#9D3728").s().p("AAAArIgChZIABgBIABBLQABADACACIAAAPg");
	this.shape.setTransform(-100.4507,22.283,0.807,0.807);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#9D3728").s().p("AgDgLQAAgBABAAQAAgBAAgBQAAAAABgBQAAAAAAgBQACgBADAAIAAARIgBAAIgFgBIABASIAAABg");
	this.shape_1.setTransform(-100.5112,17.0928,0.807,0.807);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#E2BB90").s().p("AgUBCIgCAAIgBgCIAAgQIADABIAaAAQAFAAAAgFIAAhWQAAgGgFAAIgKAAQAJgDAIAAQgJgBABgNIAOAAQAFAAAAAGIAAB3QAAAGgFAAg");
	this.shape_2.setTransform(-98.2717,20.9918,0.807,0.807);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#9D3728").s().p("AgSAJIAAgQIAcAAQgBAMAKAAQgJAAgKAEg");
	this.shape_3.setTransform(-98.7054,16.3513,0.807,0.807);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#9D3728").s().p("AAAAnIgChLIAFgGIAABVQgCgBgBgDg");
	this.shape_4.setTransform(-100.4305,21.4154,0.807,0.807);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#9D3728").s().p("AgDgWQgBgMAGgKIACBZQgIgRABgyg");
	this.shape_5.setTransform(-100.7936,22.162,0.807,0.807);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#9D3728").s().p("AgCgJIAEABIABABIAAAKIgEAGg");
	this.shape_6.setTransform(-100.4708,17.6829,0.807,0.807);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#9D3728").s().p("Ag3B/QgPAAgMgMQgLgLAAgQIAAivQAAgQALgMQALgLAQABIBvAAQAQgBALALQALAMAAAQIAAACQgCAAgDABQAAABgBAAQAAABAAAAQgBABAAAAQAAABAAABIACAdQgGAKAAANQAAAxAJARIAAABQABAEABABIAAArQAAAQgLALQgLAMgQAAg");
	this.shape_7.setTransform(-107.8351,22.6058,0.807,0.807);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#E2BB90").s().p("Ag4BTQgNgEgHgJIABAAIAoAAQAGAAAAgFIAAh4QAAgGgGAAIgOAAQAAgFAEgJQAHgSAPAKQAGADAUAWQARAQAVAAQAfAOAEAoQACAVgEARIgJAEQgLAGgHAHQgJAJgjAHQgSAEgPAAQgPAAgLgEg");
	this.shape_8.setTransform(-93.8868,20.6358,0.807,0.807);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#E2BB90").s().p("AgOAxIgDgBIAAhVQAIgIAKgDIALAAQAGAAAAAFIAABXQAAAFgGAAg");
	this.shape_9.setTransform(-98.7962,21.0119,0.807,0.807);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#3F3231").s().p("AkGDBIgTgFQgDABgGgQQgLgigOhZQgGgpASgiQANgaAZgTQgDgkANggQASgtAygXQgaAigGAeQAAAAAAAAQAAABAAAAQAAABABAAQAAAAAAAAQABABABAAQAAAAABAAQAAAAABgBQAAAAAAgBQAegiA2gaQBYgpB8gCQguAGghATQgDACABAEQACADAEgBQA2gGAyAFQBPAIAzAgQgPgCgUAAQAAAAgBABQAAAAAAAAQgBAAAAABQAAAAAAABQAAAAAAAAQAAABAAAAQAAAAABABQAAAAAAAAQAnAQAcAbQAtArAAA8QgPgUgMgLQAAAAAAAAQAAgBgBAAQAAAAAAAAQgBAAAAABQgBAAAAAAQAAAAAAABQAAAAAAAAQAAABAAAAQAQAugMAwQgCgNgPgPQgDBKgUBfQgVgBgPAYIgKAXQACghgCgpQgEhQgVggQg3hTiWACQgwACgzAJIgqAJQgHARgLAUQgXAqgWAZQgFAUgFCLQgDgngUgNg");
	this.shape_10.setTransform(-97.1912,-87.8776,0.807,0.807);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#3F3231").s().p("ABGAtIgCgBQgMgCgKgHQgNgLAAgQIAAgEQgNgKgNABIAAAAIgDAAIAAAAQgMgBgNAKIAAAEQAAAQgNALQgKAHgNACIgBABIhuAAIgDgCQgSgHgIgMQgGgJAAgIIAAgIIggADIgFgVIAogGQAIgPAZgDIABgBIBnAAQAPAAAMAIQAJAFAEAIQAOgGAOACQAPgCAPAGQAMgVAcAAIBmAAIACABQAZADAIAPIAdAEIgCAOIgZAGIAAAIQABAIgHAJQgIAMgRAHIgEACgAAxgVIAAAhIACAIQAEAIAKAGIB3AAQANgFAAgRIAAggQgEgKgLAAIh4AAQgNADAAAGgAi6gVIAAAhIACAIQAEAIAKAGIB3AAQANgFAAgRIAAggQgEgKgLAAIh4AAQgNADAAAGg");
	this.shape_11.setTransform(-99.0383,-72.7456,0.807,0.807);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#A9B3BC").s().p("AhRATICGhOIAeA7QgDAXgsAVQgVAKgVAGg");
	this.shape_12.setTransform(-91.1092,-37.7404,0.807,0.807);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#A9B3BC").s().p("AgdAsQg0gegDgXIAeg7ICLBgIhAApQgYgKgagPg");
	this.shape_13.setTransform(-104.6069,-38.4667,0.807,0.807);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#3F3231").s().p("AAzABQgRgPgVAGQgOAGgRACQgjAGgKgKIAJgEQAPgEAcgFIAigBQAkAGAFAfQgFgKgIgIg");
	this.shape_14.setTransform(-89.0714,-77.3861,0.807,0.807);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#3F3231").s().p("AgXgRQATgDAQAEQAtAHAHAFQgKALgigHIgggHQgVgHgRAPQgJAJgEAJQAEgfAkgFg");
	this.shape_15.setTransform(-108.6219,-77.2062,0.807,0.807);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#E9AF91").s().p("AAigBIgQgDIgHgBIgHAAIggAEQgQAEgOAFQALgJARgEQAPgGASgBIASABIAQAFQASAIAEAMQgJgKgQgFg");
	this.shape_16.setTransform(-108.2184,-74.6825,0.807,0.807);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#E9AF91").s().p("AgqALIgRgLIgDgBIADgBQASgKAYgFIAVgDQAbAAASAMQAJAGADAFIABABIgBABQgIAGgVAFIgUAFIgJAAQgXAAgWgKgAg2AAQAcAVAlgEQAhgGANgIQgRgTgkAAQgfABgbAPg");
	this.shape_17.setTransform(-108.1377,-73.8957,0.807,0.807);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#3F3231").s().p("AgMAMQgFgFAAgHQAAgGAFgFQAFgFAHAAQAHAAAGAFQAFAFAAAGQAAAHgFAFQgGAFgHAAQgHAAgFgFg");
	this.shape_18.setTransform(-89.0311,-73.8957,0.807,0.807);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#3F3231").s().p("AgLAMQgGgFAAgHQAAgGAGgFQAEgFAHAAQAHAAAGAFQAFAFAAAGQAAAHgFAFQgGAFgHAAQgHAAgEgFg");
	this.shape_19.setTransform(-107.8552,-73.8957,0.807,0.807);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AAEATQgagBgVgKIgPgJIAXgKQAZgJAOACIAYADQAZAGAGAPQghANgSAAIgEAAg");
	this.shape_20.setTransform(-108.1175,-73.9042,0.807,0.807);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#E9AF91").s().p("AgkgGIARgFIASgBQARABAPAGQARAEALAJQgOgFgRgEIgegEIgIAAIgIABIgPADQgPAFgKAKQAEgMASgIg");
	this.shape_21.setTransform(-88.8495,-74.6825,0.807,0.807);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#E9AF91").s().p("AgLAVQgkgHgNgJIgBgBIABgBIAMgLQARgMAcAAQAGAAAPADQAYAFASAKIADABIgCABQgHAGgLAFQgVAKgXAAIgKAAgAg3ADQANAIAgAGQAkAEAdgVQgRgJgWgFIgTgCQglAAgPATg");
	this.shape_22.setTransform(-88.9302,-73.8957,0.807,0.807);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AgmANIgUgHQAGgPAZgGQANgDALAAQAXgDAoAUQgGAEgKAFQgVAKgaABIgDABQgLAAgVgHg");
	this.shape_23.setTransform(-88.9706,-73.9064,0.807,0.807);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#E6A680").s().p("AgnANIADgDQAHAGALgGQADgIAIgBIAHAAQAaADAHgJQAEgFgCgFIAEgCQADAIgFAIQgJAJgcgBIgBAAQgCgBgDAAQgGABgCAFIAAABIgBAAQgFAFgIAAQgHAAgEgFg");
	this.shape_24.setTransform(-96.128,-64.1103,0.807,0.807);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#E6A680").s().p("AAQANIgBgBQgDgFgFgBIgFABIgBAAQgcACgJgKQgDgFAAgFIABgGIAEACIAAAEQAAADACADQAHAJAZgDIAIAAQAIABADAIQAKAHAIgHIADADQgEAFgHAAQgIAAgFgFg");
	this.shape_25.setTransform(-100.6121,-64.1103,0.807,0.807);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#E7A37F").s().p("AhDAAIgTgLIBWAEIBXgEQgFAGgOAFQgcAMgoAAQgoAAgbgMg");
	this.shape_26.setTransform(-98.3725,-56.5374,0.807,0.807);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#E39F7B").s().p("AhWACIA8gLIAFAEQAJAEAMAAQAVAAAHgIQAWAGAlAFQgbAHghAAIgbAAIgVABQggAAghgIg");
	this.shape_27.setTransform(-98.3725,-57.671,0.807,0.807);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#E2BB90").s().p("AgqFEQgdgLglgaQhKgzgphHQgDgEAAgEIgBguIgCgBQgMAAgHgLIAAAAQgEgGgHgmIgJg3QgEgWAAgPQAAgRAFgCQAFgCAKAIQAEADACAHIAFgBQgJgnAAgsQAAhjA0gZIABgBIA2gpQBDgpBAAAIAOAAQBBgCBGAqQAiAVAXAVIAAABQA0AZAABjQAAAsgIAnIgCAJIAGgHQAFgGAHgFQAJgGAEACIABAAQAKAFgIAsIgJA8QgJAogCAEIgBAAQgHALgMAAIgCABIgFA3QgBAFgCADQgWAgggAgQg2A3g8AfIgDABQgPAFgUABIgNABQgYAAgTgIg");
	this.shape_28.setTransform(-98.5858,-72.9869,0.807,0.807);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#D7AE86").s().p("AgVB8Qi0gHAtgsQAngnAThIIAMhBIBWgSQBVgMABAeQACAhAnBjQAUAyATArQg8ADg5AAIhGgBg");
	this.shape_29.setTransform(-97.9488,-46.306,0.807,0.807);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FFFFFF").s().p("AgHABQgBgCADgDQACgDADAAQAHgBABAIQABACgDADQgCADgDAAQgHAAgBgHg");
	this.shape_30.setTransform(-86.6907,23.2674,0.807,0.807);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#626568").s().p("AgogEIgGgzIARgCQAVgDAYgKQgEAQAPA5QAOA2AGAEIg6AKQgTgVgKg2g");
	this.shape_31.setTransform(-86.731,20.6286,0.807,0.807);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#A9B3BC").s().p("AjJAaIgCgqIGEhYQgDAMAPAbQAMAVgJADIgKACQAJAQACAoQgXA0h2ARQiTALhCAIQgmgfgKgwg");
	this.shape_32.setTransform(-72.6173,17.5417,0.807,0.807);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#D6D8D8").s().p("Ai4I1QiAgfgBgOQgDgnAPhmIAQh1QADhFAHgnQACgNgGgSQhCi+goiqQg8j/AzgcQA/gkCsgYQBWgMBJgFICfARQCtAYA/AkQAyAcg7D/QgoCnhCDBQgGASACANQAHAnADBFIAQB1QAPBmgDAnQgBANiHAgQiDAeg2ADQg2gDh7geg");
	this.shape_33.setTransform(-97.3536,6.1221,0.807,0.807);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#000007").s().p("ACxPMIhWgMIgLn2QgNoAgHgxQgFgxgUjNIgSjDQhOIsAAAUIgeHeIgeHOIkNAAIASr1IATnPIBFrPQBHAwEWgOQCLgHB9gRIAiDtQAGA3AKB7QAMCTAAAxQAAAugPJuIgPJlIgPAKQgTAMgdAQQgTALgsAAQgZAAghgEg");
	this.shape_34.setTransform(-99.1796,125.7952,0.807,0.807);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#554436").s().p("AA7BcIiZgvQhZAFgLgJQgHgGgBgnIAAgnIAQgnIDKgJIAWAxIAuAZQAzAaAYALQAbAMAKAOQAIALgBAQQgCASgGABg");
	this.shape_35.setTransform(-73.083,209.4148,0.807,0.807);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#554436").s().p("AhbBpQgUgSgKgbQgJgaAhgzIAjgvIANg1ICtAAIAAB+QAAAfgFAIQgNAYgsAXQgjASAEADIhnACQgIgDgLgKg");
	this.shape_36.setTransform(-122.4868,212.0982,0.807,0.807);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#FFFFFF").s().p("AgIABQgBgDADgDQACgDAEAAQAIgBABAJQABADgDADQgCADgEAAQgIAAgBgIg");
	this.shape_37.setTransform(-141.6499,64.5879,0.807,0.807);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#626568").s().p("AhHAcIgEhDQAFAFBAACQBBADARgJQgHAuAGAaQgZAEggACIgTAAQgvAAgXgMg");
	this.shape_38.setTransform(-138.9463,64.2691,0.807,0.807);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#A9B3BC").s().p("AipJnQgJh2AYj2QAXjyAahFQACj2A+i2QATg6AWgsIATggICZB9IjJROQgNAIgYAGQgUAEgWAAQgdAAgggIg");
	this.shape_39.setTransform(-130.7546,14.4103,0.807,0.807);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#EFAB83").s().p("AgxGjQgeg1gOhUQgHgvAMg3IANguIABgCIgCg2QgCgVAAgaQgDhmAJipIAPjTIBMAIQAxAFAcAFIgFAcQgiClgkCQQgJAkgDBAQgDBJAPADIAHAGIgCABQAOAPALAlQAMAkgDARQgBAFAGAsQAFAigMARQgLARgUgmQgYgtgDgBQgNgHAIA6QAFAiAJAvQAEAogXAvQgDAIgGAAQgLAAgTghg");
	this.shape_40.setTransform(-136.1776,60.9562,0.807,0.807);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#A9B3BC").s().p("AkxE9IgCglIG3g8IhongICZh9IATAhQAXArATA6QA+C2ACD1QAHBZgfApQgcAlhJAOQguAIiGAEQicAHhlAKQgngagKgrg");
	this.shape_41.setTransform(-79.8393,-4.7527,0.807,0.807);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#A9B1BA").s().p("Ag8ANIBig3IAXAqQgDARgfAPQgQAHgPAEg");
	this.shape_42.setTransform(48.1211,-36.9191,1.0844,1.0844);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#A9B1BA").s().p("AgVAgQgmgWgCgQIAVgrIBmBFIgvAeQgRgHgTgLg");
	this.shape_43.setTransform(34.8378,-37.651,1.0844,1.0844);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#3F3231").s().p("ACqCUIAAhIQAAgTgSgtQgVgzgVgGQgRgGgkATQgnAVgPAAIgFAAQgPAAgngVQgkgTgRAGQgVAGgUAzQgSAtAAATIgBBIQgCAEgGgMQgDgGgHgDQgKhwAchDQArhqB+AHIABAAQB+gHArBqQAbBDgIBwQgIADgDAGQgFAJgCAAIgBgBg");
	this.shape_44.setTransform(40.2053,-84.7965,1.0844,1.0844);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#231F20").s().p("AA2ABQgSgRgWAIQgPAFgSADQglAGgKgLIAJgEQAQgEAdgFIAkgBQAnAGAEAhQgEgLgJgIg");
	this.shape_45.setTransform(49.3952,-75.5491,1.0844,1.0844);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#231F20").s().p("AgXgSQATgDARADQAvAIAHAFQgKALgkgGIgigIQgWgIgSARQgJAJgEAKQAEggAngGg");
	this.shape_46.setTransform(30.6901,-75.6242,1.0844,1.0844);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#957667").s().p("AgbgGIANgEIANgCQAOACAKAEQAMAFAJAJQgOgHgIgBIgYgFIgFAAIgGABIgMADQgLAFgIAJQAEgMANgHg");
	this.shape_47.setTransform(49.5307,-73.2991,1.0844,1.0844);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#957667").s().p("AAZgBIgLgDIgGgBIgGAAIgWAFQgJAAgPAIQAKgJAMgFQAKgEAOgCIAOACQAHABAEADQAOAGADANQgHgJgMgFg");
	this.shape_48.setTransform(30.8799,-73.2991,1.0844,1.0844);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#AB9083").s().p("AgdAKIACgDQAGAFAIgFQACgFAGgBQAEgBABABQATACAGgHQADgDgCgFIAEgBQACAHgEAEQgGAIgWgCIAAAAQgBAAAAAAQAAAAgBAAQAAAAgBAAQgBAAAAAAQgEABgCAEIgBABQgEADgFAAQgFAAgEgDg");
	this.shape_49.setTransform(42.7355,-61.317,1.0844,1.0844);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#AB9083").s().p("AAMAKIgBAAIAAgBQgCgEgEgBIgEAAIAAAAQgVACgHgIQgCgDAAgEQAAgBAAgBQAAAAAAgBQAAAAAAAAQAAgBABAAIADABIgBADQAAADACACQAFAHATgCIAGAAQAGABACAFQAIAFAGgFIACADQgEADgEAAQgGAAgEgDg");
	this.shape_50.setTransform(38.2264,-61.317,1.0844,1.0844);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#997B6D").s().p("AgyAAIgPgNIBBADIBCgDQgFAHgKAGQgVAOgeAAQgdAAgVgOg");
	this.shape_51.setTransform(40.4764,-54.6753,1.0844,1.0844);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#957667").s().p("AhBACIAtgIIAFADQAHADAIAAQAQAAAFgGIAtAIQgVAEgYABIgVAAIgPAAQgZAAgZgFg");
	this.shape_52.setTransform(40.4764,-56.3493,1.0844,1.0844);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#957667").s().p("AgIAUQgbgHgKgIIgBgBIABgBIAJgLQAOgMAUAAIAQADQASAFANAKIACABIgBABQgTAVgcAAgAgpADQAKAIAYAFQAaADAXgUQgNgIgRgEIgOgDQgcAAgLATg");
	this.shape_53.setTransform(49.4494,-72.2689,1.0844,1.0844);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#3F3231").s().p("AgMANQgFgFgBgIQABgGAFgGQAGgGAGABQAHgBAGAGQAGAGgBAGQABAIgGAFQgGAFgHABQgGgBgGgFg");
	this.shape_54.setTransform(49.4223,-72.3231,1.0844,1.0844);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#FFFFFF").s().p("AgcANIgQgIQAFgOAUgGQAJgCAIAAQARgEAdAUQgDAEgIAFQgPAKgUAAIgDABQgJAAgOgGg");
	this.shape_55.setTransform(49.4223,-72.3106,1.0844,1.0844);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#957667").s().p("AACAUQgRAAgQgKIgNgKIgCgBIACgBQAWgQAZgBQAVAAANALQAHAGADAFIAAABIgBABQgKAIgbAHgAgpAAQAIAGAKAFQAPAIARgCQAYgGAJgIQgKgTgdAAQgXACgVAOg");
	this.shape_56.setTransform(30.8257,-72.296,1.0844,1.0844);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#3F3231").s().p("AgMANQgFgFgBgIQABgGAFgGQAFgGAHABQAHgBAGAGQAGAGgBAGQABAIgGAFQgGAFgHABQgHgBgFgFg");
	this.shape_57.setTransform(30.8799,-72.3231,1.0844,1.0844);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#FFFFFF").s().p("AADASQgUAAgPgKIgMgJIARgKQAUgIAKACIASACQASAGAFAOQgZAOgNAAIgDgBg");
	this.shape_58.setTransform(30.8799,-72.3039,1.0844,1.0844);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#815F4F").s().p("AgfD0QgWgJgcgTQg3gngfg1IgCgGIgBgjIgCAAQgKAAgEgIIAAgBIAAAAQgEgHgEgZIgHgqQgDgRAAgKQAAgNAEgCQAEgBAHAGQAEACABAFIADgBQgGgdAAghQAAhKAngTIAAAAIApgfQAygfAwAAIAFAAIAAAAIAFAAIAAAAQAxgCA1AfQAaAQAQARIABAAQAnATAABKQAAAhgGAdIgCAHIAFgFQADgEAGgEQAGgFAEACIAAAAQAIAEgGAgIgHAtQgFAdgDAEIgBABQgFAHgJABIgCAAIgEAqQAAACgCAEQgRAXgXAZQgpApgsAXIgDABQgTAFgSAAQgQAAgPgFg");
	this.shape_59.setTransform(40.2502,-70.2965,1.0844,1.0844);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#957667").s().p("AgPBOQh9gDAighQAdgdAIgoIACgjIBAgNQBAgJABAWQABAZAaA6IAaA2Qg2AEgxAAIgbgBg");
	this.shape_60.setTransform(41.2299,-45.0368,1.0844,1.0844);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#BBCACB").s().p("AgFEUQgSgMgQgqQgUiTgYh6QgPhQAFg2QAGg8AfgKQAEgBAZgTQAUgPAHAIQANAPAPAqQAPAnALAvQAIA5AOCEIATDBQACAYgTAEQgbADgSADIgOABQgPAAgJgGg");
	this.shape_61.setTransform(75.5147,-1.1384,1.0844,1.0844);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#BBCACB").s().p("AjeBvQgwgEgKgaQgNguAdgrQAfgtA4gHIDlgcQCygVAhgCQARA2ADAbQAHAygXAIQgJADiMAXQiQAZgtAMQhQAVg0AAIgTgBg");
	this.shape_62.setTransform(30.195,19.9453,1.0844,1.0844);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f().s("#BBCACB").p("AAHhBQgHACgWgDQgOgCgMANQgPAQAGAmQAGAjASASQAjAlAlgxQAOgTAFgUQAFgVgJgHg");
	this.shape_63.setTransform(58.3427,15.7161,1.0844,1.0844);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#FFFFFF").s().p("AghA0QgSgSgGgjQgGgmAPgQQAMgNAOACQAWADAHgCIAvAmQAJAHgFAVQgFAUgOATQgVAcgUAAQgQAAgPgQg");
	this.shape_64.setTransform(58.3427,15.7161,1.0844,1.0844);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#957667").s().p("AhKA9QgNgjgCgPQgBgJAIgcIAJgaIBPgSQAxgFAWAjQALARABATQAJAog3AWIg3AOg");
	this.shape_65.setTransform(65.7375,14.3368,1.0844,1.0844);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#957667").s().p("AgZBFIgQgHQgQgPgGgkQgFgiAJgQQAIgNAZgLQAWgKAIABQAFABAXAAQAUABgGAIQgBADgLAHIgLAHQgCAFAGACQAHACANgFQARgGgBAEIgFAMQABAGgSAGQgSAGAAADQAAACAVABQAVABAAAGQAAAHgYAHIgYAJIAZACQAYACgFAIQgGAKgRALQgQAMgQAEIgIABQgKAAgNgEg");
	this.shape_66.setTransform(63.0425,14.0798,1.0844,1.0844);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#957667").s().p("AgqA6Qg3gWAJgoQABgTALgRQAWgjAxAFIBPASIAJAaQAIAcgBAJQgDAPgMAjIg+ALQgcgDgbgLg");
	this.shape_67.setTransform(19.0647,14.3368,1.0844,1.0844);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#957667").s().p("AgNAIIADglQAVgQADAnQABASgDAXg");
	this.shape_68.setTransform(26.2172,6.7153,1.0844,1.0844);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#957667").s().p("AgFBIQgQgEgQgMQgRgLgGgKQgFgIAYgCIAZgCIgYgJQgYgHAAgHQAAgGAVgBQAVgBAAgCQAAgDgSgGQgSgGABgGIgFgMQgBgEARAGQANAFAHgCQAGgCgCgFIgLgHQgLgHgBgDQgGgIAUgBIAbgBQAJgBAWAKQAZALAIANQAJAQgFAiQgGAkgQAPQgUALgRAAIgKgBg");
	this.shape_69.setTransform(21.7597,14.0914,1.0844,1.0844);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f().s("#BBCACB").p("AgIhEQAIACAWgCQAPgCANAOQAQASgFAmQgFAlgRASQglAkgng0QgQgUgGgUQgGgWAJgIg");
	this.shape_70.setTransform(25.7992,15.4337,1.0844,1.0844);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#FFFFFF").s().p("AglAnQgQgUgGgUQgGgWAJgIIAwglQAIACAWgCQAPgCANAOQAQASgFAmQgFAlgRASQgPAPgQAAQgVAAgYgfg");
	this.shape_71.setTransform(25.7992,15.4501,1.0844,1.0844);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#AFBCBC").s().p("ABIBbQgtgMiQgZQiMgXgJgDQgXgIAHgyQADgZAQg4QAiACCxAVIDlAcQA5AHAfAtQAdArgOAuQgJAagwAEIgTABQgzAAhRgVg");
	this.shape_72.setTransform(54.432,19.9453,1.0844,1.0844);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#BBCACB").s().p("AggEZQgigDgLgDQgTgEACgYIATjBQAOiEAIg5QALgvAPgnQAPgqANgPQAHgIAUAPQAZATAEABQAfAKAGA8QAFA2gPBQQgYB6gUCTQgQAqgSAMQgJAGgPAAIgOgBg");
	this.shape_73.setTransform(9.2875,-1.1384,1.0844,1.0844);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#747888").s().p("AAAAAIAAAAIABABIgBAAg");
	this.shape_74.setTransform(46.9012,39.0668,1.0844,1.0844);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#747888").s().p("AAAAAIAAAAIABABIgBAAg");
	this.shape_75.setTransform(43.2957,45.4644,1.0844,1.0844);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#747888").s().p("AgIgOIAQAZIgBAAIACACIgCACg");
	this.shape_76.setTransform(42.4011,44.1903,1.0844,1.0844);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#747888").s().p("AAAAAIAAAAIABABIAAAAg");
	this.shape_77.setTransform(39.7174,39.0668,1.0844,1.0844);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#747888").s().p("AgNAZIAAAAIgBgCIAdgxIgcA1g");
	this.shape_78.setTransform(41.3439,36.4643,1.0844,1.0844);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#747888").s().p("AgKgSIAUAfIAAABIABACIgCADg");
	this.shape_79.setTransform(45.7626,37.4945,1.0844,1.0844);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#747888").s().p("AgfABIAfg3IAAAAIAAAAIAMATIAUAlIggA2g");
	this.shape_80.setTransform(43.2686,39.3107,1.0844,1.0844);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#747888").s().p("AAAAAIAAgBIABABIgBACg");
	this.shape_81.setTransform(43.1873,20.8497,1.0844,1.0844);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#747888").s().p("AAAABIAAgBIABAAIgBABg");
	this.shape_82.setTransform(43.2686,20.9581,1.0844,1.0844);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#747888").s().p("AgIgPIAQAZIgBAAIACADIgCADg");
	this.shape_83.setTransform(42.4011,31.6119,1.0844,1.0844);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#747888").s().p("AgOAZIAAgBIgBgCIAegxIABABIgdA2g");
	this.shape_84.setTransform(41.4252,23.913,1.0844,1.0844);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#747888").s().p("AgKAUIABgBIgCgCIAXgkIgWAng");
	this.shape_85.setTransform(44.5156,30.8528,1.0844,1.0844);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#747888").s().p("AgOgaIAcAuIAAAAIABACIgCAGg");
	this.shape_86.setTransform(45.2476,24.1841,1.0844,1.0844);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#747888").s().p("AgeACIAeg2IAAABIABgDIACAEIAcA2IgfAyg");
	this.shape_87.setTransform(43.2686,26.7865,1.0844,1.0844);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#747888").s().p("AAAAAIAAAAIABAAIgBABg");
	this.shape_88.setTransform(43.2415,8.5423,1.0844,1.0844);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#747888").s().p("AAAAAIAAAAIABABIgBAAg");
	this.shape_89.setTransform(46.9012,14.2351,1.0844,1.0844);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#747888").s().p("AAAAAIAAAAIABABIgBAAg");
	this.shape_90.setTransform(43.2957,20.6328,1.0844,1.0844);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#747888").s().p("AgIgOIAQAZIgBABIACACIgBAAIgBgBIgBACg");
	this.shape_91.setTransform(42.4011,19.2774,1.0844,1.0844);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#747888").s().p("AAAAAIAAAAIABABIAAAAg");
	this.shape_92.setTransform(39.7174,14.2351,1.0844,1.0844);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#747888").s().p("AgOAaIAAgBIgBgBIAfgzIAAAAIgdA3g");
	this.shape_93.setTransform(41.4252,11.5514,1.0844,1.0844);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#747888").s().p("AgMgVIAXAlIAAAAIABACIgCAEg");
	this.shape_94.setTransform(45.5729,12.4189,1.0844,1.0844);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#747888").s().p("AgeABIAeg3IAAABIAAgBIAfA5IgfA0g");
	this.shape_95.setTransform(43.2686,14.5062,1.0844,1.0844);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#747888").s().p("AgIgOIAQAYIgBABIACACIgBACIgBAAIAAAAg");
	this.shape_96.setTransform(42.4011,6.8616,1.0844,1.0844);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#747888").s().p("AgNAZIAAgBIgBgCIAdgwIgcA1g");
	this.shape_97.setTransform(41.3439,-0.8373,1.0844,1.0844);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#747888").s().p("AgKAUIABgBIgCgCIAXgkIgWAng");
	this.shape_98.setTransform(44.5156,6.1567,1.0844,1.0844);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#747888").s().p("AgKgSIAUAfIAAAAIABADIgCADg");
	this.shape_99.setTransform(45.7626,0.1928,1.0844,1.0844);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#747888").s().p("AgfABIAfg3IAAAAIAMATIAUAmIggA0g");
	this.shape_100.setTransform(43.2686,1.982,1.0844,1.0844);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#747888").s().p("AAAAAIAAgBIABABIgBACg");
	this.shape_101.setTransform(43.1873,-16.452,1.0844,1.0844);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("#747888").s().p("AAAABIAAgBIABAAIgBABg");
	this.shape_102.setTransform(43.2686,-16.3435,1.0844,1.0844);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("#747888").s().p("AAAAAIAAAAIABABIgBAAg");
	this.shape_103.setTransform(43.2957,-4.4699,1.0844,1.0844);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f("#747888").s().p("AgIgPIAQAZIgBABIACACIgCADg");
	this.shape_104.setTransform(42.4011,-5.744,1.0844,1.0844);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f("#747888").s().p("AAAAAIAAAAIABABIAAAAg");
	this.shape_105.setTransform(39.7174,-10.8676,1.0844,1.0844);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f("#747888").s().p("AgOAZIAAgBIgBgCIAegxIABACIgdA1g");
	this.shape_106.setTransform(41.4252,-13.4158,1.0844,1.0844);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f("#747888").s().p("AgOgbIAcAvIAAAAIABACIgCAGg");
	this.shape_107.setTransform(45.2476,-13.1176,1.0844,1.0844);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f("#747888").s().p("AgeABIAeg1IAAAAIABgCIACADIAcA3IgfAyg");
	this.shape_108.setTransform(43.2686,-10.5152,1.0844,1.0844);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f("#747888").s().p("AAAAAIAAAAIABABIgBAAg");
	this.shape_109.setTransform(43.2957,-16.696,1.0844,1.0844);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f("#747888").s().p("AAHANIgBACIgOgdIAQAZIgBAAIACADIgBABg");
	this.shape_110.setTransform(42.4011,-18.0514,1.0844,1.0844);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f("#747888").s().p("AAAAAIAAgBIABABIAAABg");
	this.shape_111.setTransform(39.7174,-23.0936,1.0844,1.0844);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.f("#747888").s().p("AgNAZIAAgBIgBgCIAdgvIgcA0g");
	this.shape_112.setTransform(41.3439,-25.6961,1.0844,1.0844);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.f("#747888").s().p("AgKAUIABgBIgCgCIAXglIgWApg");
	this.shape_113.setTransform(44.5156,-18.702,1.0844,1.0844);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.f("#747888").s().p("AgKgSIAUAfIAAAAIABADIgCADg");
	this.shape_114.setTransform(45.7626,-24.6388,1.0844,1.0844);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.f("#747888").s().p("AgfAAIAfg2IAAAAIAMATIAUAmIggA0g");
	this.shape_115.setTransform(43.2686,-22.8496,1.0844,1.0844);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.f("#747888").s().p("AgIgOIAQAZIgBAAIACACIgCACg");
	this.shape_116.setTransform(42.4011,-30.5756,1.0844,1.0844);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.f("#747888").s().p("AAAAAIAAAAIABABIAAAAg");
	this.shape_117.setTransform(39.7174,-35.6992,1.0844,1.0844);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.f("#747888").s().p("AgFALIAAgBIgBgCIALgTIACAAIgMAXg");
	this.shape_118.setTransform(40.4764,-36.7293,1.0844,1.0844);

	this.shape_119 = new cjs.Shape();
	this.shape_119.graphics.f("#747888").s().p("AgHgNIABAAIANAVIABACIgCAEg");
	this.shape_119.setTransform(46.0337,-36.7022,1.0844,1.0844);

	this.shape_120 = new cjs.Shape();
	this.shape_120.graphics.f("#747888").s().p("AgfgMIAOgZIAOgBIAAgDIAUADIAPAcIggA0g");
	this.shape_120.setTransform(43.2686,-33.9914,1.0844,1.0844);

	this.shape_121 = new cjs.Shape();
	this.shape_121.graphics.f("#747888").s().p("AAAAAIAAAAIABABIgBAAg");
	this.shape_121.setTransform(54.0579,39.0668,1.0844,1.0844);

	this.shape_122 = new cjs.Shape();
	this.shape_122.graphics.f("#747888").s().p("AgIgOIAQAZIAAAAIABACIgCACg");
	this.shape_122.setTransform(49.5578,44.1903,1.0844,1.0844);

	this.shape_123 = new cjs.Shape();
	this.shape_123.graphics.f("#747888").s().p("AgOAZIABAAIgCgCIAegxIgcA1g");
	this.shape_123.setTransform(48.5006,36.4643,1.0844,1.0844);

	this.shape_124 = new cjs.Shape();
	this.shape_124.graphics.f("#747888").s().p("AgKgSIAUAfIAAABIABACIgCADg");
	this.shape_124.setTransform(52.9193,37.4945,1.0844,1.0844);

	this.shape_125 = new cjs.Shape();
	this.shape_125.graphics.f("#747888").s().p("AgfABIAfg3IAAAAIAAAAIAMATIAUAlIggA2g");
	this.shape_125.setTransform(50.4253,39.3107,1.0844,1.0844);

	this.shape_126 = new cjs.Shape();
	this.shape_126.graphics.f("#747888").s().p("AAAAAIABgBIAAABIgBACg");
	this.shape_126.setTransform(50.344,20.8497,1.0844,1.0844);

	this.shape_127 = new cjs.Shape();
	this.shape_127.graphics.f("#747888").s().p("AAAABIAAgBIABAAIgBABg");
	this.shape_127.setTransform(50.4253,20.9581,1.0844,1.0844);

	this.shape_128 = new cjs.Shape();
	this.shape_128.graphics.f("#747888").s().p("AgIgPIAQAZIAAAAIABADIgCADg");
	this.shape_128.setTransform(49.5578,31.6119,1.0844,1.0844);

	this.shape_129 = new cjs.Shape();
	this.shape_129.graphics.f("#747888").s().p("AgOAZIAAgBIgBgCIAegxIABABIgdA2g");
	this.shape_129.setTransform(48.5819,23.913,1.0844,1.0844);

	this.shape_130 = new cjs.Shape();
	this.shape_130.graphics.f("#747888").s().p("AgKAUIABgBIgCgCIAXgkIgWAng");
	this.shape_130.setTransform(51.6723,30.8528,1.0844,1.0844);

	this.shape_131 = new cjs.Shape();
	this.shape_131.graphics.f("#747888").s().p("AgOgaIAcAuIAAAAIABACIgDAGg");
	this.shape_131.setTransform(52.4043,24.1841,1.0844,1.0844);

	this.shape_132 = new cjs.Shape();
	this.shape_132.graphics.f("#747888").s().p("AgeACIAeg2IAAABIABgDIACAEIAcA2IgfAyg");
	this.shape_132.setTransform(50.4253,26.7865,1.0844,1.0844);

	this.shape_133 = new cjs.Shape();
	this.shape_133.graphics.f("#747888").s().p("AAAAAIAAAAIAAAAIAAABg");
	this.shape_133.setTransform(50.3982,8.5423,1.0844,1.0844);

	this.shape_134 = new cjs.Shape();
	this.shape_134.graphics.f("#747888").s().p("AAAAAIAAAAIABABIgBAAg");
	this.shape_134.setTransform(54.0579,14.2351,1.0844,1.0844);

	this.shape_135 = new cjs.Shape();
	this.shape_135.graphics.f("#747888").s().p("AAAAAIAAAAIABABIgBAAg");
	this.shape_135.setTransform(50.4795,20.6328,1.0844,1.0844);

	this.shape_136 = new cjs.Shape();
	this.shape_136.graphics.f("#747888").s().p("AgIgOIAQAZIAAABIABACIgBAAIAAgBIgCACg");
	this.shape_136.setTransform(49.5578,19.2774,1.0844,1.0844);

	this.shape_137 = new cjs.Shape();
	this.shape_137.graphics.f("#747888").s().p("AgOAaIAAgBIgBgBIAfgzIAAAAIgdA3g");
	this.shape_137.setTransform(48.5819,11.5514,1.0844,1.0844);

	this.shape_138 = new cjs.Shape();
	this.shape_138.graphics.f("#747888").s().p("AgLgVIAWAlIAAAAIABACIgCAEg");
	this.shape_138.setTransform(52.7296,12.4189,1.0844,1.0844);

	this.shape_139 = new cjs.Shape();
	this.shape_139.graphics.f("#747888").s().p("AgfABIAfg3IAAABIAAgBIAfA5IgfA0g");
	this.shape_139.setTransform(50.4524,14.5062,1.0844,1.0844);

	this.shape_140 = new cjs.Shape();
	this.shape_140.graphics.f("#747888").s().p("AgIgOIAQAYIAAABIABACIgBACIgBAAg");
	this.shape_140.setTransform(49.5578,6.8616,1.0844,1.0844);

	this.shape_141 = new cjs.Shape();
	this.shape_141.graphics.f("#747888").s().p("AgOAZIABgBIgCgCIAegwIgcA1g");
	this.shape_141.setTransform(48.5006,-0.8373,1.0844,1.0844);

	this.shape_142 = new cjs.Shape();
	this.shape_142.graphics.f("#747888").s().p("AgKAUIABgBIgCgCIAXgkIgWAng");
	this.shape_142.setTransform(51.6723,6.1567,1.0844,1.0844);

	this.shape_143 = new cjs.Shape();
	this.shape_143.graphics.f("#747888").s().p("AgKgSIAUAfIAAAAIABADIgCADg");
	this.shape_143.setTransform(52.9193,0.1928,1.0844,1.0844);

	this.shape_144 = new cjs.Shape();
	this.shape_144.graphics.f("#747888").s().p("AgfABIAfg3IAAAAIAMATIAUAmIggA0g");
	this.shape_144.setTransform(50.4253,1.982,1.0844,1.0844);

	this.shape_145 = new cjs.Shape();
	this.shape_145.graphics.f("#747888").s().p("AAAAAIABgBIAAABIgBACg");
	this.shape_145.setTransform(50.344,-16.452,1.0844,1.0844);

	this.shape_146 = new cjs.Shape();
	this.shape_146.graphics.f("#747888").s().p("AgIgPIAQAZIAAABIABACIgCADg");
	this.shape_146.setTransform(49.5578,-5.744,1.0844,1.0844);

	this.shape_147 = new cjs.Shape();
	this.shape_147.graphics.f("#747888").s().p("AgOAZIAAgBIgBgCIAegxIABACIgdA1g");
	this.shape_147.setTransform(48.5819,-13.4158,1.0844,1.0844);

	this.shape_148 = new cjs.Shape();
	this.shape_148.graphics.f("#747888").s().p("AgOgbIAcAvIAAAAIABACIgDAGg");
	this.shape_148.setTransform(52.4043,-13.1176,1.0844,1.0844);

	this.shape_149 = new cjs.Shape();
	this.shape_149.graphics.f("#747888").s().p("AgeABIAeg1IAAAAIABgCIACADIAcA3IgfAyg");
	this.shape_149.setTransform(50.4253,-10.5152,1.0844,1.0844);

	this.shape_150 = new cjs.Shape();
	this.shape_150.graphics.f("#747888").s().p("AAIANIgCACIgOgdIAQAZIAAAAIABADIgBABg");
	this.shape_150.setTransform(49.5578,-18.0514,1.0844,1.0844);

	this.shape_151 = new cjs.Shape();
	this.shape_151.graphics.f("#747888").s().p("AgOAZIABgBIgCgCIAegvIgcA0g");
	this.shape_151.setTransform(48.5006,-25.6961,1.0844,1.0844);

	this.shape_152 = new cjs.Shape();
	this.shape_152.graphics.f("#747888").s().p("AgKAUIABgBIgCgCIAXglIgWApg");
	this.shape_152.setTransform(51.6723,-18.702,1.0844,1.0844);

	this.shape_153 = new cjs.Shape();
	this.shape_153.graphics.f("#747888").s().p("AgKgSIAUAfIAAAAIABADIgCADg");
	this.shape_153.setTransform(52.9193,-24.6388,1.0844,1.0844);

	this.shape_154 = new cjs.Shape();
	this.shape_154.graphics.f("#747888").s().p("AgfAAIAfg2IAAAAIAMATIAUAmIggA0g");
	this.shape_154.setTransform(50.4253,-22.8496,1.0844,1.0844);

	this.shape_155 = new cjs.Shape();
	this.shape_155.graphics.f("#747888").s().p("AgIgOIAQAZIABACIgCACg");
	this.shape_155.setTransform(49.5578,-30.5756,1.0844,1.0844);

	this.shape_156 = new cjs.Shape();
	this.shape_156.graphics.f("#747888").s().p("AgFAKIABgBIgCgCIALgRIACAAIgLAVg");
	this.shape_156.setTransform(47.5518,-36.6209,1.0844,1.0844);

	this.shape_157 = new cjs.Shape();
	this.shape_157.graphics.f("#747888").s().p("AgFgIIAEABIAFAKIABACIgCAEg");
	this.shape_157.setTransform(53.4886,-36.1329,1.0844,1.0844);

	this.shape_158 = new cjs.Shape();
	this.shape_158.graphics.f("#747888").s().p("AgfgPIAMgXIAqAHIAJASIggA0g");
	this.shape_158.setTransform(50.4253,-33.6118,1.0844,1.0844);

	this.shape_159 = new cjs.Shape();
	this.shape_159.graphics.f("#747888").s().p("AAAAAIAAAAIABABIgBAAg");
	this.shape_159.setTransform(61.2146,39.0668,1.0844,1.0844);

	this.shape_160 = new cjs.Shape();
	this.shape_160.graphics.f("#747888").s().p("AgKAUIABgBIgCgCIAXgkIgVAng");
	this.shape_160.setTransform(58.829,43.4584,1.0844,1.0844);

	this.shape_161 = new cjs.Shape();
	this.shape_161.graphics.f("#747888").s().p("AgKgSIAUAfIAAABIABACIgCADg");
	this.shape_161.setTransform(60.076,37.4945,1.0844,1.0844);

	this.shape_162 = new cjs.Shape();
	this.shape_162.graphics.f("#747888").s().p("AgIgOIAQAZIAAAAIABACIgCACg");
	this.shape_162.setTransform(56.7146,44.1903,1.0844,1.0844);

	this.shape_163 = new cjs.Shape();
	this.shape_163.graphics.f("#747888").s().p("AgOAZIABAAIgCgCIAfgxIgdA1g");
	this.shape_163.setTransform(55.6573,36.4643,1.0844,1.0844);

	this.shape_164 = new cjs.Shape();
	this.shape_164.graphics.f("#747888").s().p("AAAABIAAgBIABAAIgBABg");
	this.shape_164.setTransform(57.6091,45.7626,1.0844,1.0844);

	this.shape_165 = new cjs.Shape();
	this.shape_165.graphics.f("#747888").s().p("AgfABIAfg3IAAAAIAAAAIAMATIAUAlIggA2g");
	this.shape_165.setTransform(57.582,39.3107,1.0844,1.0844);

	this.shape_166 = new cjs.Shape();
	this.shape_166.graphics.f("#747888").s().p("AAAAAIAAgBIABABIgBACg");
	this.shape_166.setTransform(57.5278,20.8497,1.0844,1.0844);

	this.shape_167 = new cjs.Shape();
	this.shape_167.graphics.f("#747888").s().p("AgKAUIABgBIgCgCIAXgkIgVAng");
	this.shape_167.setTransform(58.829,30.8528,1.0844,1.0844);

	this.shape_168 = new cjs.Shape();
	this.shape_168.graphics.f("#747888").s().p("AgPgaIAeAuIAAAAIABACIgEAGg");
	this.shape_168.setTransform(59.561,24.1841,1.0844,1.0844);

	this.shape_169 = new cjs.Shape();
	this.shape_169.graphics.f("#747888").s().p("AgIgPIAQAZIAAAAIABADIgCADg");
	this.shape_169.setTransform(56.7146,31.6119,1.0844,1.0844);

	this.shape_170 = new cjs.Shape();
	this.shape_170.graphics.f("#747888").s().p("AgOAZIAAgBIgBgCIAegxIABABIgdA2g");
	this.shape_170.setTransform(55.7386,23.913,1.0844,1.0844);

	this.shape_171 = new cjs.Shape();
	this.shape_171.graphics.f("#747888").s().p("AgeACIAeg2IAAABIABgDIACAEIAcA2IgfAyg");
	this.shape_171.setTransform(57.582,26.7865,1.0844,1.0844);

	this.shape_172 = new cjs.Shape();
	this.shape_172.graphics.f("#747888").s().p("AAAAAIAAAAIABABIgBAAg");
	this.shape_172.setTransform(57.6363,20.6328,1.0844,1.0844);

	this.shape_173 = new cjs.Shape();
	this.shape_173.graphics.f("#747888").s().p("AgKAUIABgBIgCgCIAXgkIgVAng");
	this.shape_173.setTransform(58.829,18.6268,1.0844,1.0844);

	this.shape_174 = new cjs.Shape();
	this.shape_174.graphics.f("#747888").s().p("AgLgVIAWAlIAAAAIABACIgCAEg");
	this.shape_174.setTransform(59.9134,12.4189,1.0844,1.0844);

	this.shape_175 = new cjs.Shape();
	this.shape_175.graphics.f("#747888").s().p("AgIgOIAQAZIAAABIABACIAAAAIgBgBIgCACg");
	this.shape_175.setTransform(56.7146,19.2774,1.0844,1.0844);

	this.shape_176 = new cjs.Shape();
	this.shape_176.graphics.f("#747888").s().p("AgOAaIAAgBIgBgBIAfgzIAAAAIgdA3g");
	this.shape_176.setTransform(55.7386,11.5514,1.0844,1.0844);

	this.shape_177 = new cjs.Shape();
	this.shape_177.graphics.f("#747888").s().p("AgeABIAeg3IAAABIAAgBIAJAOIAXArIggA0g");
	this.shape_177.setTransform(57.6091,14.5062,1.0844,1.0844);

	this.shape_178 = new cjs.Shape();
	this.shape_178.graphics.f("#747888").s().p("AgKAUIABgBIgCgCIAXgkIgVAng");
	this.shape_178.setTransform(58.829,6.1567,1.0844,1.0844);

	this.shape_179 = new cjs.Shape();
	this.shape_179.graphics.f("#747888").s().p("AgKgSIAUAfIAAAAIABADIgCADg");
	this.shape_179.setTransform(60.076,0.1928,1.0844,1.0844);

	this.shape_180 = new cjs.Shape();
	this.shape_180.graphics.f("#747888").s().p("AgIgOIAQAYIAAABIABACIgBACIgBAAg");
	this.shape_180.setTransform(56.7146,6.8616,1.0844,1.0844);

	this.shape_181 = new cjs.Shape();
	this.shape_181.graphics.f("#747888").s().p("AgOAZIABgBIgCgCIAfgwIgdA1g");
	this.shape_181.setTransform(55.6573,-0.8373,1.0844,1.0844);

	this.shape_182 = new cjs.Shape();
	this.shape_182.graphics.f("#747888").s().p("AgfABIAfg3IAAAAIAMATIAUAmIggA0g");
	this.shape_182.setTransform(57.582,1.982,1.0844,1.0844);

	this.shape_183 = new cjs.Shape();
	this.shape_183.graphics.f("#747888").s().p("AAAAAIAAAAIABAAIgBABg");
	this.shape_183.setTransform(57.6363,8.4068,1.0844,1.0844);

	this.shape_184 = new cjs.Shape();
	this.shape_184.graphics.f("#747888").s().p("AAAAAIAAgBIABABIgBACg");
	this.shape_184.setTransform(57.5278,-16.452,1.0844,1.0844);

	this.shape_185 = new cjs.Shape();
	this.shape_185.graphics.f("#747888").s().p("AgKAUIABgBIgCgCIAXgkIgVAng");
	this.shape_185.setTransform(58.829,-6.476,1.0844,1.0844);

	this.shape_186 = new cjs.Shape();
	this.shape_186.graphics.f("#747888").s().p("AgPgbIAeAvIAAAAIABACIgEAGg");
	this.shape_186.setTransform(59.561,-13.1176,1.0844,1.0844);

	this.shape_187 = new cjs.Shape();
	this.shape_187.graphics.f("#747888").s().p("AgIgPIAQAZIAAABIABACIgCADg");
	this.shape_187.setTransform(56.7146,-5.744,1.0844,1.0844);

	this.shape_188 = new cjs.Shape();
	this.shape_188.graphics.f("#747888").s().p("AgOAZIAAgBIgBgCIAegxIABACIgdA1g");
	this.shape_188.setTransform(55.7386,-13.4158,1.0844,1.0844);

	this.shape_189 = new cjs.Shape();
	this.shape_189.graphics.f("#747888").s().p("AAAABIAAAAIAAAAIAAgCIABABIgBABg");
	this.shape_189.setTransform(57.6091,-4.1717,1.0844,1.0844);

	this.shape_190 = new cjs.Shape();
	this.shape_190.graphics.f("#747888").s().p("AgeABIAeg1IAAAAIABgCIACADIAcA3IgfAyg");
	this.shape_190.setTransform(57.582,-10.5152,1.0844,1.0844);

	this.shape_191 = new cjs.Shape();
	this.shape_191.graphics.f("#747888").s().p("AgKAUIABgBIgCgCIAXglIgVApg");
	this.shape_191.setTransform(58.829,-18.702,1.0844,1.0844);

	this.shape_192 = new cjs.Shape();
	this.shape_192.graphics.f("#747888").s().p("AgKgSIAUAfIAAAAIABADIgCADg");
	this.shape_192.setTransform(60.076,-24.6388,1.0844,1.0844);

	this.shape_193 = new cjs.Shape();
	this.shape_193.graphics.f("#747888").s().p("AAIANIgCACIgOgdIAQAZIAAAAIABADIAAABg");
	this.shape_193.setTransform(56.7146,-18.0514,1.0844,1.0844);

	this.shape_194 = new cjs.Shape();
	this.shape_194.graphics.f("#747888").s().p("AgOAZIABgBIgCgCIAfgvIgdA0g");
	this.shape_194.setTransform(55.6573,-25.6961,1.0844,1.0844);

	this.shape_195 = new cjs.Shape();
	this.shape_195.graphics.f("#747888").s().p("AgfAAIAfg2IAAAAIAMATIAUAmIggA0g");
	this.shape_195.setTransform(57.582,-22.8496,1.0844,1.0844);

	this.shape_196 = new cjs.Shape();
	this.shape_196.graphics.f("#747888").s().p("AgKAUIABgBIgCgCIAXgkIgVAng");
	this.shape_196.setTransform(58.829,-31.3076,1.0844,1.0844);

	this.shape_197 = new cjs.Shape();
	this.shape_197.graphics.f("#747888").s().p("AgBgBIADABIgCACg");
	this.shape_197.setTransform(61.052,-35.3739,1.0844,1.0844);

	this.shape_198 = new cjs.Shape();
	this.shape_198.graphics.f("#747888").s().p("AgIgOIAQAZIABACIgCACg");
	this.shape_198.setTransform(56.7146,-30.5756,1.0844,1.0844);

	this.shape_199 = new cjs.Shape();
	this.shape_199.graphics.f("#747888").s().p("AgCAFIAAgBIgBgCIAEgHIADAAIgGALg");
	this.shape_199.setTransform(54.4374,-36.0787,1.0844,1.0844);

	this.shape_200 = new cjs.Shape();
	this.shape_200.graphics.f("#747888").s().p("AgfgUIAHgNIA2ALIACAEIggA0g");
	this.shape_200.setTransform(57.582,-33.0697,1.0844,1.0844);

	this.shape_201 = new cjs.Shape();
	this.shape_201.graphics.f("#747888").s().p("AAAABIAAABIAAgBIAAgBIABAAIgBACg");
	this.shape_201.setTransform(57.6091,-29.0033,1.0844,1.0844);

	this.shape_202 = new cjs.Shape();
	this.shape_202.graphics.f("#747888").s().p("AgHgOIAOAZIAAAAIABACIgBACg");
	this.shape_202.setTransform(63.8984,44.1903,1.0844,1.0844);

	this.shape_203 = new cjs.Shape();
	this.shape_203.graphics.f("#747888").s().p("AgNAZIAAAAIgBgCIAdgxIgbA1g");
	this.shape_203.setTransform(62.814,36.4643,1.0844,1.0844);

	this.shape_204 = new cjs.Shape();
	this.shape_204.graphics.f("#747888").s().p("AgIAQIABgBIgCgBIASgdIAAAAIgQAfg");
	this.shape_204.setTransform(65.7418,43.865,1.0844,1.0844);

	this.shape_205 = new cjs.Shape();
	this.shape_205.graphics.f("#747888").s().p("AAAABIAAgBIABAAIgBABg");
	this.shape_205.setTransform(64.7659,45.7626,1.0844,1.0844);

	this.shape_206 = new cjs.Shape();
	this.shape_206.graphics.f("#747888").s().p("AgYABIAcg1IACgCIAMASQAFAiACAcIgTAeg");
	this.shape_206.setTransform(64.061,39.3107,1.0844,1.0844);

	this.shape_207 = new cjs.Shape();
	this.shape_207.graphics.f("#747888").s().p("AgHgPIAOAZIAAAAIABADIgBADg");
	this.shape_207.setTransform(63.8984,31.6119,1.0844,1.0844);

	this.shape_208 = new cjs.Shape();
	this.shape_208.graphics.f("#747888").s().p("AgNAXIAAgBIgBgCIAcgtIABADIgbAwg");
	this.shape_208.setTransform(62.7598,24.1298,1.0844,1.0844);

	this.shape_209 = new cjs.Shape();
	this.shape_209.graphics.f("#747888").s().p("AgCAHIABgBIgCgDIAGgJIABADIgFAKg");
	this.shape_209.setTransform(65.1183,32.3167,1.0844,1.0844);

	this.shape_210 = new cjs.Shape();
	this.shape_210.graphics.f("#747888").s().p("AgSgBIAbgxQAEAVABAdQAAAJAFAgIgHAKg");
	this.shape_210.setTransform(63.4375,27.1389,1.0844,1.0844);

	this.shape_211 = new cjs.Shape();
	this.shape_211.graphics.f("#747888").s().p("AAAAAIAAAAIABAAIgBABg");
	this.shape_211.setTransform(64.7116,8.5423,1.0844,1.0844);

	this.shape_212 = new cjs.Shape();
	this.shape_212.graphics.f("#747888").s().p("AgOAaIAAgBIgBgBIAfgzIAAAAIgdA3g");
	this.shape_212.setTransform(62.8954,11.5514,1.0844,1.0844);

	this.shape_213 = new cjs.Shape();
	this.shape_213.graphics.f("#747888").s().p("AgSARIAeg3IAAABIABgBIAGAKIgZBDg");
	this.shape_213.setTransform(63.4104,12.7713,1.0844,1.0844);

	this.shape_214 = new cjs.Shape();
	this.shape_214.graphics.f("#957667").s().p("AgHgOIAOAYIAAABIABACIgBACIAAAAg");
	this.shape_214.setTransform(63.8984,6.8616,1.0844,1.0844);

	this.shape_215 = new cjs.Shape();
	this.shape_215.graphics.f("#747888").s().p("AgNAZIAAgBIgBgCIAdgwIgbA1g");
	this.shape_215.setTransform(62.814,-0.8373,1.0844,1.0844);

	this.shape_216 = new cjs.Shape();
	this.shape_216.graphics.f("#747888").s().p("AgKAUIABgBIgCgCIAXgkIgVAng");
	this.shape_216.setTransform(66.0129,6.1567,1.0844,1.0844);

	this.shape_217 = new cjs.Shape();
	this.shape_217.graphics.f("#747888").s().p("AgKgSIAUAfIAAAAIABACIgCADIAAABg");
	this.shape_217.setTransform(67.2328,0.1928,1.0844,1.0844);

	this.shape_218 = new cjs.Shape();
	this.shape_218.graphics.f("#747888").s().p("AgfABIAdg1IACgCIAgA5IggA0g");
	this.shape_218.setTransform(64.793,1.982,1.0844,1.0844);

	this.shape_219 = new cjs.Shape();
	this.shape_219.graphics.f("#747888").s().p("AAAAAIAAAAIABAAIgBABg");
	this.shape_219.setTransform(64.793,8.4068,1.0844,1.0844);

	this.shape_220 = new cjs.Shape();
	this.shape_220.graphics.f("#747888").s().p("AAAAAIAAgBIABABIgBACg");
	this.shape_220.setTransform(64.7116,-16.452,1.0844,1.0844);

	this.shape_221 = new cjs.Shape();
	this.shape_221.graphics.f("#747888").s().p("AgHgPIAOAZIAAABIABACIgBADg");
	this.shape_221.setTransform(63.8984,-5.744,1.0844,1.0844);

	this.shape_222 = new cjs.Shape();
	this.shape_222.graphics.f("#747888").s().p("AgOAZIAAgBIgBgCIAfgxIAAACIgdA1g");
	this.shape_222.setTransform(62.8954,-13.4158,1.0844,1.0844);

	this.shape_223 = new cjs.Shape();
	this.shape_223.graphics.f("#747888").s().p("AgKAUIABgBIgCgCIAXgkIgVAng");
	this.shape_223.setTransform(66.0129,-6.476,1.0844,1.0844);

	this.shape_224 = new cjs.Shape();
	this.shape_224.graphics.f("#747888").s().p("AgOgbIAcAvIAAAAIABACIgCAGg");
	this.shape_224.setTransform(66.7448,-13.1176,1.0844,1.0844);

	this.shape_225 = new cjs.Shape();
	this.shape_225.graphics.f("#747888").s().p("AgeABIAeg1IAAAAIAAgCIADADIAcA3IgfAyg");
	this.shape_225.setTransform(64.7659,-10.5152,1.0844,1.0844);

	this.shape_226 = new cjs.Shape();
	this.shape_226.graphics.f("#747888").s().p("AAAABIAAgCIABABIgBABg");
	this.shape_226.setTransform(64.7659,-4.1717,1.0844,1.0844);

	this.shape_227 = new cjs.Shape();
	this.shape_227.graphics.f("#747888").s().p("AAHANIgBACIgNgdIAOAZIAAAAIABADIAAABg");
	this.shape_227.setTransform(63.8984,-18.0514,1.0844,1.0844);

	this.shape_228 = new cjs.Shape();
	this.shape_228.graphics.f("#747888").s().p("AgNAZIAAgBIgBgCIAdgvIgbA0g");
	this.shape_228.setTransform(62.814,-25.6961,1.0844,1.0844);

	this.shape_229 = new cjs.Shape();
	this.shape_229.graphics.f("#747888").s().p("AgKAUIABgBIgCgCIAXglIgVApg");
	this.shape_229.setTransform(66.0129,-18.702,1.0844,1.0844);

	this.shape_230 = new cjs.Shape();
	this.shape_230.graphics.f("#747888").s().p("AgKgSIAUAfIAAAAIABADIgCADg");
	this.shape_230.setTransform(67.2328,-24.6388,1.0844,1.0844);

	this.shape_231 = new cjs.Shape();
	this.shape_231.graphics.f("#747888").s().p("AgfAAIAdg0IACgCIAgA5IggA0g");
	this.shape_231.setTransform(64.793,-22.8496,1.0844,1.0844);

	this.shape_232 = new cjs.Shape();
	this.shape_232.graphics.f("#747888").s().p("AgHgOIAOAZIABACIgBACg");
	this.shape_232.setTransform(63.8984,-30.5756,1.0844,1.0844);

	this.shape_233 = new cjs.Shape();
	this.shape_233.graphics.f("#747888").s().p("AgKAUIABgBIgCgCIAXgkIgVAng");
	this.shape_233.setTransform(66.0129,-31.3076,1.0844,1.0844);

	this.shape_234 = new cjs.Shape();
	this.shape_234.graphics.f("#747888").s().p("AAAABIAAgBIABAAIgBACg");
	this.shape_234.setTransform(64.7659,-29.0033,1.0844,1.0844);

	this.shape_235 = new cjs.Shape();
	this.shape_235.graphics.f("#747888").s().p("AgbgaIAAgBQAZAFAeAJIgCAEIgYAlg");
	this.shape_235.setTransform(64.4406,-32.4462,1.0844,1.0844);

	this.shape_236 = new cjs.Shape();
	this.shape_236.graphics.f("#747888").s().p("AAAAAIAAAAIAAAAIAAABg");
	this.shape_236.setTransform(71.8684,8.5423,1.0844,1.0844);

	this.shape_237 = new cjs.Shape();
	this.shape_237.graphics.f("#747888").s().p("AAAAAIAAgBIABABIgBACg");
	this.shape_237.setTransform(71.8684,-16.452,1.0844,1.0844);

	this.shape_238 = new cjs.Shape();
	this.shape_238.graphics.f("#747888").s().p("AgOAZIAAgBIgBgCIAfgxIAAACIgcA1g");
	this.shape_238.setTransform(70.0521,-13.4158,1.0844,1.0844);

	this.shape_239 = new cjs.Shape();
	this.shape_239.graphics.f("#747888").s().p("AgWAHIAcg1IABAAIABgCIAPAXQgIAdgPAtg");
	this.shape_239.setTransform(71.1093,-11.1387,1.0844,1.0844);

	this.shape_240 = new cjs.Shape();
	this.shape_240.graphics.f("#747888").s().p("AAHANIgBACIgOgdIARAbIgBACg");
	this.shape_240.setTransform(71.0822,-18.0514,1.0844,1.0844);

	this.shape_241 = new cjs.Shape();
	this.shape_241.graphics.f("#747888").s().p("AgOAZIABgBIgBgCIAdgvIgcA0g");
	this.shape_241.setTransform(69.9707,-25.6961,1.0844,1.0844);

	this.shape_242 = new cjs.Shape();
	this.shape_242.graphics.f("#747888").s().p("AgIgOIARAbIgCACg");
	this.shape_242.setTransform(71.0822,-30.5756,1.0844,1.0844);

	this.shape_243 = new cjs.Shape();
	this.shape_243.graphics.f("#747888").s().p("AACAUIACgDIgVglQAQAFAUAJIgQAbg");
	this.shape_243.setTransform(71.5431,-31.0907,1.0844,1.0844);

	this.shape_244 = new cjs.Shape();
	this.shape_244.graphics.f("#BBCACB").s().p("AgfAKIAfg2IAAABIAAgBIAgA4IgMAXIgiAJg");
	this.shape_244.setTransform(61.1875,44.5156,1.0844,1.0844);

	this.shape_245 = new cjs.Shape();
	this.shape_245.graphics.f("#BBCACB").s().p("AAAAAIAAgBIABABIgBACg");
	this.shape_245.setTransform(61.1062,27.2745,1.0844,1.0844);

	this.shape_246 = new cjs.Shape();
	this.shape_246.graphics.f("#BBCACB").s().p("AgfAAIAeg1IABACIABgCIAfA3IggA0g");
	this.shape_246.setTransform(61.1875,33.1028,1.0844,1.0844);

	this.shape_247 = new cjs.Shape();
	this.shape_247.graphics.f("#BBCACB").s().p("AAAACIAAgBIABgCIABABIgCACg");
	this.shape_247.setTransform(61.1875,39.4463,1.0844,1.0844);

	this.shape_248 = new cjs.Shape();
	this.shape_248.graphics.f("#BBCACB").s().p("AAAABIgBACIAAgBIACgEIABACIgBADg");
	this.shape_248.setTransform(61.1604,26.9492,1.0844,1.0844);

	this.shape_249 = new cjs.Shape();
	this.shape_249.graphics.f("#BBCACB").s().p("AgcAGIgBgEIAdg2IABABIAAgBIAOAVQgCAFAGAHQAHAKAEAQIgdAug");
	this.shape_249.setTransform(61.0249,20.6057,1.0844,1.0844);

	this.shape_250 = new cjs.Shape();
	this.shape_250.graphics.f("#BBCACB").s().p("AgDgGQgGgHABgFIAEAFIANAcIgCAEQgEgQgGgJg");
	this.shape_250.setTransform(63.5647,19.2232,1.0844,1.0844);

	this.shape_251 = new cjs.Shape();
	this.shape_251.graphics.f("#BBCACB").s().p("AAAACIAAAAIAAgBIABgCIABABIgCACg");
	this.shape_251.setTransform(61.1875,14.6418,1.0844,1.0844);

	this.shape_252 = new cjs.Shape();
	this.shape_252.graphics.f("#BBCACB").s().p("AgfABIAfg2IAAAAIAAAAIAgA4IggAzg");
	this.shape_252.setTransform(61.1875,8.2441,1.0844,1.0844);

	this.shape_253 = new cjs.Shape();
	this.shape_253.graphics.f("#BBCACB").s().p("AAAAAIAAgBIABABIgBACg");
	this.shape_253.setTransform(61.1062,-10.0272,1.0844,1.0844);

	this.shape_254 = new cjs.Shape();
	this.shape_254.graphics.f("#BBCACB").s().p("AAAACIAAAAIAAgBIABgCIABABIgCACg");
	this.shape_254.setTransform(61.1875,2.1446,1.0844,1.0844);

	this.shape_255 = new cjs.Shape();
	this.shape_255.graphics.f("#BBCACB").s().p("AgUAWIgLgWIAeg1IABADIABgCIAQAYIAPAeIgCADIgeAxg");
	this.shape_255.setTransform(61.1875,-4.253,1.0844,1.0844);

	this.shape_256 = new cjs.Shape();
	this.shape_256.graphics.f("#BBCACB").s().p("AgdAGIgCgEIAfg2IAAAAIAgA2IggAzg");
	this.shape_256.setTransform(61.1604,-16.7231,1.0844,1.0844);

	this.shape_257 = new cjs.Shape();
	this.shape_257.graphics.f("#BBCACB").s().p("AAAABIgBACIAAgBIACgEIABACIgBADg");
	this.shape_257.setTransform(61.1604,-10.3796,1.0844,1.0844);

	this.shape_258 = new cjs.Shape();
	this.shape_258.graphics.f("#BBCACB").s().p("AAAACIAAAAIAAgBIABgCIABABIgCACg");
	this.shape_258.setTransform(61.1875,-22.687,1.0844,1.0844);

	this.shape_259 = new cjs.Shape();
	this.shape_259.graphics.f("#BBCACB").s().p("AgUAXIgLgXIAfg2IAAABIAAgBIAgA4IgCAEIgeAwg");
	this.shape_259.setTransform(61.1875,-29.166,1.0844,1.0844);

	this.shape_260 = new cjs.Shape();
	this.shape_260.graphics.f("#BBCACB").s().p("AAAABIAAABIAAgBIABgCIABABIgCACg");
	this.shape_260.setTransform(61.1875,-35.2926,1.0844,1.0844);

	this.shape_261 = new cjs.Shape();
	this.shape_261.graphics.f("#BBCACB").s().p("AgJAIIARgfQACAZgBAPQAAACgKAFg");
	this.shape_261.setTransform(65.9078,44.7596,1.0844,1.0844);

	this.shape_262 = new cjs.Shape();
	this.shape_262.graphics.f("#BBCACB").s().p("AgEgEIAFgLIAEAfg");
	this.shape_262.setTransform(65.4436,33.5908,1.0844,1.0844);

	this.shape_263 = new cjs.Shape();
	this.shape_263.graphics.f("#BBCACB").s().p("AgOAUIAdgzIgXA+g");
	this.shape_263.setTransform(66.4737,6.1296,1.0844,1.0844);

	this.shape_264 = new cjs.Shape();
	this.shape_264.graphics.f("#BBCACB").s().p("AAAAAIAAgBIABABIgBACg");
	this.shape_264.setTransform(68.29,-10.0272,1.0844,1.0844);

	this.shape_265 = new cjs.Shape();
	this.shape_265.graphics.f("#BBCACB").s().p("AgQAWIgLgWIAdg1IABADIABgCIAQAYIAIAQIgVA9IgEAFg");
	this.shape_265.setTransform(67.9376,-4.253,1.0844,1.0844);

	this.shape_266 = new cjs.Shape();
	this.shape_266.graphics.f("#BBCACB").s().p("AAAABIAAgBIAAgBIABABIgBACg");
	this.shape_266.setTransform(68.3713,2.1446,1.0844,1.0844);

	this.shape_267 = new cjs.Shape();
	this.shape_267.graphics.f("#BBCACB").s().p("AAAABIgBACIAAgBIABgEIACACIgCADg");
	this.shape_267.setTransform(68.3713,-10.3796,1.0844,1.0844);

	this.shape_268 = new cjs.Shape();
	this.shape_268.graphics.f("#BBCACB").s().p("AgfACIAfg2IAgA2IggAzg");
	this.shape_268.setTransform(68.3171,-16.7231,1.0844,1.0844);

	this.shape_269 = new cjs.Shape();
	this.shape_269.graphics.f("#BBCACB").s().p("AAAABIAAgCIABABIgBACg");
	this.shape_269.setTransform(68.3713,-22.687,1.0844,1.0844);

	this.shape_270 = new cjs.Shape();
	this.shape_270.graphics.f("#BBCACB").s().p("AgUARIgLgVIAZgsIAPAFIAIAKIAPAfIgCACIgeAxg");
	this.shape_270.setTransform(68.3442,-28.5967,1.0844,1.0844);

	this.shape_271 = new cjs.Shape();
	this.shape_271.graphics.f("#BBCACB").s().p("AAAAAIAAAAIABABIAAAAg");
	this.shape_271.setTransform(36.1119,45.4644,1.0844,1.0844);

	this.shape_272 = new cjs.Shape();
	this.shape_272.graphics.f("#BBCACB").s().p("AgfgCIAfg3IAAAAIAAAAIAgA5IggA6g");
	this.shape_272.setTransform(39.6903,46.0066,1.0844,1.0844);

	this.shape_273 = new cjs.Shape();
	this.shape_273.graphics.f("#BBCACB").s().p("AAAAAIAAgBIABABIgBACg");
	this.shape_273.setTransform(39.636,27.2745,1.0844,1.0844);

	this.shape_274 = new cjs.Shape();
	this.shape_274.graphics.f("#BBCACB").s().p("AgKgSIAUAfIgBABIACACIgCADg");
	this.shape_274.setTransform(38.5788,37.4945,1.0844,1.0844);

	this.shape_275 = new cjs.Shape();
	this.shape_275.graphics.f("#BBCACB").s().p("AgKATIgBgCIAXgkIgWAng");
	this.shape_275.setTransform(37.3589,30.8528,1.0844,1.0844);

	this.shape_276 = new cjs.Shape();
	this.shape_276.graphics.f("#BBCACB").s().p("AgfAAIAeg1IABACIABgCIAfA3IggA0g");
	this.shape_276.setTransform(39.6903,33.1028,1.0844,1.0844);

	this.shape_277 = new cjs.Shape();
	this.shape_277.graphics.f("#BBCACB").s().p("AAAACIAAgBIABgCIAAABIgBACg");
	this.shape_277.setTransform(39.6903,39.4463,1.0844,1.0844);

	this.shape_278 = new cjs.Shape();
	this.shape_278.graphics.f("#BBCACB").s().p("AgPgaIAeAuIgBAAIACACIgEAGg");
	this.shape_278.setTransform(38.0908,24.1841,1.0844,1.0844);

	this.shape_279 = new cjs.Shape();
	this.shape_279.graphics.f("#BBCACB").s().p("AAAABIgBACIAAgBIACgEIABACIgBADg");
	this.shape_279.setTransform(39.6903,26.9492,1.0844,1.0844);

	this.shape_280 = new cjs.Shape();
	this.shape_280.graphics.f("#BBCACB").s().p("AgfACIAfg2IAAABIAAgBIAgA2IggAzg");
	this.shape_280.setTransform(39.636,20.6057,1.0844,1.0844);

	this.shape_281 = new cjs.Shape();
	this.shape_281.graphics.f("#BBCACB").s().p("AgMgVIAYAlIgBAAIACACIgDAEg");
	this.shape_281.setTransform(38.4161,12.4189,1.0844,1.0844);

	this.shape_282 = new cjs.Shape();
	this.shape_282.graphics.f("#BBCACB").s().p("AgKATIgBgCIAXgkIgWAng");
	this.shape_282.setTransform(37.3589,6.1567,1.0844,1.0844);

	this.shape_283 = new cjs.Shape();
	this.shape_283.graphics.f("#BBCACB").s().p("AgXAQIgIgPIAfg2IAAAAIAAAAIAgA4IggAzg");
	this.shape_283.setTransform(39.6631,8.2441,1.0844,1.0844);

	this.shape_284 = new cjs.Shape();
	this.shape_284.graphics.f("#BBCACB").s().p("AAAACIAAAAIgBgBIACgCIABABIgCACg");
	this.shape_284.setTransform(39.6903,14.6418,1.0844,1.0844);

	this.shape_285 = new cjs.Shape();
	this.shape_285.graphics.f("#BBCACB").s().p("AAAAAIAAgBIABABIgBACg");
	this.shape_285.setTransform(39.636,-10.0272,1.0844,1.0844);

	this.shape_286 = new cjs.Shape();
	this.shape_286.graphics.f("#BBCACB").s().p("AgKgSIAUAfIgBAAIACADIgCADg");
	this.shape_286.setTransform(38.5788,0.1928,1.0844,1.0844);

	this.shape_287 = new cjs.Shape();
	this.shape_287.graphics.f("#BBCACB").s().p("AgKATIgBgCIAXgkIgWAng");
	this.shape_287.setTransform(37.3589,-6.476,1.0844,1.0844);

	this.shape_288 = new cjs.Shape();
	this.shape_288.graphics.f("#BBCACB").s().p("AAAACIAAAAIAAgBIABgCIAAABIgBACg");
	this.shape_288.setTransform(39.6903,2.1446,1.0844,1.0844);

	this.shape_289 = new cjs.Shape();
	this.shape_289.graphics.f("#BBCACB").s().p("AgUAWIgLgWIAeg1IABADIABgCIAfA2IgBADIgfAxg");
	this.shape_289.setTransform(39.6903,-4.253,1.0844,1.0844);

	this.shape_290 = new cjs.Shape();
	this.shape_290.graphics.f("#BBCACB").s().p("AgPgbIAeAvIgBAAIACACIgEAGg");
	this.shape_290.setTransform(38.0908,-13.1176,1.0844,1.0844);

	this.shape_291 = new cjs.Shape();
	this.shape_291.graphics.f("#BBCACB").s().p("AgKATIgBgCIAXglIgWApg");
	this.shape_291.setTransform(37.3589,-18.702,1.0844,1.0844);

	this.shape_292 = new cjs.Shape();
	this.shape_292.graphics.f("#BBCACB").s().p("AAAABIgBACIAAgBIACgEIABACIgBADg");
	this.shape_292.setTransform(39.6903,-10.3796,1.0844,1.0844);

	this.shape_293 = new cjs.Shape();
	this.shape_293.graphics.f("#BBCACB").s().p("AgfACIAfg2IAAAAIAgA2IggAzg");
	this.shape_293.setTransform(39.636,-16.7231,1.0844,1.0844);

	this.shape_294 = new cjs.Shape();
	this.shape_294.graphics.f("#BBCACB").s().p("AgKgSIAUAfIgBAAIACADIgCADg");
	this.shape_294.setTransform(38.6059,-24.6388,1.0844,1.0844);

	this.shape_295 = new cjs.Shape();
	this.shape_295.graphics.f("#BBCACB").s().p("AgKATIgBgCIAXgkIgWAng");
	this.shape_295.setTransform(37.3589,-31.3076,1.0844,1.0844);

	this.shape_296 = new cjs.Shape();
	this.shape_296.graphics.f("#BBCACB").s().p("AAAACIAAAAIAAgBIABgCIAAABIgBACg");
	this.shape_296.setTransform(39.6903,-22.687,1.0844,1.0844);

	this.shape_297 = new cjs.Shape();
	this.shape_297.graphics.f("#BBCACB").s().p("AgfAAIAfg2IAAABIAAgBIAgA4IgBAEIgfAwg");
	this.shape_297.setTransform(39.6903,-29.166,1.0844,1.0844);

	this.shape_298 = new cjs.Shape();
	this.shape_298.graphics.f("#BBCACB").s().p("AgGgLIACAAIAKARIAAAAIABADIgCADg");
	this.shape_298.setTransform(38.9854,-36.5125,1.0844,1.0844);

	this.shape_299 = new cjs.Shape();
	this.shape_299.graphics.f("#BBCACB").s().p("AgLgHIAXgCIgMATg");
	this.shape_299.setTransform(39.7174,-36.9462,1.0844,1.0844);

	this.shape_300 = new cjs.Shape();
	this.shape_300.graphics.f("#BBCACB").s().p("AAAACIAAAAIAAgBIABgCIAAABIgBACg");
	this.shape_300.setTransform(39.6903,-35.3197,1.0844,1.0844);

	this.shape_301 = new cjs.Shape();
	this.shape_301.graphics.f("#BBCACB").s().p("AgfgBIAfg3IAAABIAAgBIAgA4IgfA4IgCABg");
	this.shape_301.setTransform(46.847,45.8711,1.0844,1.0844);

	this.shape_302 = new cjs.Shape();
	this.shape_302.graphics.f("#BBCACB").s().p("AgBAAIADgBIgCADg");
	this.shape_302.setTransform(46.8199,52.1603,1.0844,1.0844);

	this.shape_303 = new cjs.Shape();
	this.shape_303.graphics.f("#BBCACB").s().p("AAAAAIAAgBIABABIgBACg");
	this.shape_303.setTransform(46.7928,27.2745,1.0844,1.0844);

	this.shape_304 = new cjs.Shape();
	this.shape_304.graphics.f("#BBCACB").s().p("AgfAAIAeg1IABACIABgCIAfA3IggA0g");
	this.shape_304.setTransform(46.847,33.1028,1.0844,1.0844);

	this.shape_305 = new cjs.Shape();
	this.shape_305.graphics.f("#BBCACB").s().p("AAAACIAAgBIABgCIAAABIgBACg");
	this.shape_305.setTransform(46.847,39.4463,1.0844,1.0844);

	this.shape_306 = new cjs.Shape();
	this.shape_306.graphics.f("#BBCACB").s().p("AAAAAIAAAAIABAAIgBABg");
	this.shape_306.setTransform(46.7928,14.94,1.0844,1.0844);

	this.shape_307 = new cjs.Shape();
	this.shape_307.graphics.f("#BBCACB").s().p("AAAABIgBACIAAgBIACgEIABACIgBADg");
	this.shape_307.setTransform(46.847,26.9492,1.0844,1.0844);

	this.shape_308 = new cjs.Shape();
	this.shape_308.graphics.f("#BBCACB").s().p("AgfACIAfg2IAAABIABgBIAfA2IggAzg");
	this.shape_308.setTransform(46.7928,20.6057,1.0844,1.0844);

	this.shape_309 = new cjs.Shape();
	this.shape_309.graphics.f("#BBCACB").s().p("AgXAQIgIgPIAfg2IAAAAIAAAAIAgA4IggAzg");
	this.shape_309.setTransform(46.847,8.2441,1.0844,1.0844);

	this.shape_310 = new cjs.Shape();
	this.shape_310.graphics.f("#BBCACB").s().p("AAAACIAAAAIgBgBIACgCIABABIgCACg");
	this.shape_310.setTransform(46.847,14.6418,1.0844,1.0844);

	this.shape_311 = new cjs.Shape();
	this.shape_311.graphics.f("#BBCACB").s().p("AAAAAIAAgBIABABIgBACg");
	this.shape_311.setTransform(46.7928,-10.0272,1.0844,1.0844);

	this.shape_312 = new cjs.Shape();
	this.shape_312.graphics.f("#BBCACB").s().p("AgfAAIAeg1IABADIABgCIAfA2IgBADIgfAxg");
	this.shape_312.setTransform(46.847,-4.253,1.0844,1.0844);

	this.shape_313 = new cjs.Shape();
	this.shape_313.graphics.f("#BBCACB").s().p("AAAACIAAAAIAAgBIABgCIAAABIgBACg");
	this.shape_313.setTransform(46.847,2.1446,1.0844,1.0844);

	this.shape_314 = new cjs.Shape();
	this.shape_314.graphics.f("#BBCACB").s().p("AgfACIAfg2IAAAAIAgA2IggAzg");
	this.shape_314.setTransform(46.7928,-16.7231,1.0844,1.0844);

	this.shape_315 = new cjs.Shape();
	this.shape_315.graphics.f("#BBCACB").s().p("AAAABIgBACIAAgBIACgEIABACIgBADg");
	this.shape_315.setTransform(46.847,-10.3796,1.0844,1.0844);

	this.shape_316 = new cjs.Shape();
	this.shape_316.graphics.f("#BBCACB").s().p("AgfAAIAfg2IAAABIAAgBIAgA4IgBAEIgfAwg");
	this.shape_316.setTransform(46.847,-29.166,1.0844,1.0844);

	this.shape_317 = new cjs.Shape();
	this.shape_317.graphics.f("#BBCACB").s().p("AAAACIAAAAIAAgBIABgCIAAABIgBACg");
	this.shape_317.setTransform(46.847,-35.3197,1.0844,1.0844);

	this.shape_318 = new cjs.Shape();
	this.shape_318.graphics.f("#BBCACB").s().p("AgMgKIAZAEIgMARg");
	this.shape_318.setTransform(46.6843,-37.0275,1.0844,1.0844);

	this.shape_319 = new cjs.Shape();
	this.shape_319.graphics.f("#BBCACB").s().p("AgfAEIAfg2IAAAAIAAAAIAgA4IgXAqIgQADg");
	this.shape_319.setTransform(54.0037,45.2476,1.0844,1.0844);

	this.shape_320 = new cjs.Shape();
	this.shape_320.graphics.f("#BBCACB").s().p("AAAAAIAAgBIABABIgBACg");
	this.shape_320.setTransform(53.9495,27.2745,1.0844,1.0844);

	this.shape_321 = new cjs.Shape();
	this.shape_321.graphics.f("#BBCACB").s().p("AgfAAIAeg1IABACIABgCIAfA3IggA0g");
	this.shape_321.setTransform(54.0037,33.1028,1.0844,1.0844);

	this.shape_322 = new cjs.Shape();
	this.shape_322.graphics.f("#BBCACB").s().p("AAAACIAAgBIABgCIAAABIgBACg");
	this.shape_322.setTransform(54.0037,39.4463,1.0844,1.0844);

	this.shape_323 = new cjs.Shape();
	this.shape_323.graphics.f("#BBCACB").s().p("AAAABIgBACIAAgBIACgEIABACIgBADg");
	this.shape_323.setTransform(54.0037,26.9492,1.0844,1.0844);

	this.shape_324 = new cjs.Shape();
	this.shape_324.graphics.f("#BBCACB").s().p("AgfACIAfg2IAAABIABgBIAfA2IggAzg");
	this.shape_324.setTransform(53.9495,20.6057,1.0844,1.0844);

	this.shape_325 = new cjs.Shape();
	this.shape_325.graphics.f("#BBCACB").s().p("AAAACIAAAAIgBgBIABgCIACABIgCACg");
	this.shape_325.setTransform(54.0308,14.6418,1.0844,1.0844);

	this.shape_326 = new cjs.Shape();
	this.shape_326.graphics.f("#BBCACB").s().p("AgXAQIgIgPIAfg2IAAAAIAAAAIAgA4IggAzg");
	this.shape_326.setTransform(54.0037,8.2441,1.0844,1.0844);

	this.shape_327 = new cjs.Shape();
	this.shape_327.graphics.f("#BBCACB").s().p("AAAAAIAAgBIABABIgBACg");
	this.shape_327.setTransform(53.9495,-10.0272,1.0844,1.0844);

	this.shape_328 = new cjs.Shape();
	this.shape_328.graphics.f("#BBCACB").s().p("AgfAAIAeg1IABADIABgCIAfA2IgBADIgfAxg");
	this.shape_328.setTransform(54.0037,-4.253,1.0844,1.0844);

	this.shape_329 = new cjs.Shape();
	this.shape_329.graphics.f("#BBCACB").s().p("AAAABIgBACIAAgBIACgEIABACIgBADg");
	this.shape_329.setTransform(54.0037,-10.3796,1.0844,1.0844);

	this.shape_330 = new cjs.Shape();
	this.shape_330.graphics.f("#BBCACB").s().p("AgfACIAfg2IAAAAIAgA2IggAzg");
	this.shape_330.setTransform(53.9495,-16.7231,1.0844,1.0844);

	this.shape_331 = new cjs.Shape();
	this.shape_331.graphics.f("#BBCACB").s().p("AgfAAIAfg2IAAABIAAgBIAgA4IgBAEIgfAwg");
	this.shape_331.setTransform(54.0037,-29.166,1.0844,1.0844);

	this.shape_332 = new cjs.Shape();
	this.shape_332.graphics.f("#BBCACB").s().p("AgFgEIALACIgGAHg");
	this.shape_332.setTransform(53.9224,-36.4311,1.0844,1.0844);

	this.shape_333 = new cjs.Shape();
	this.shape_333.graphics.f("#BBCACB").s().p("AAAACIAAAAIAAgBIABgCIAAABIgBACg");
	this.shape_333.setTransform(54.0037,-35.3197,1.0844,1.0844);

	this.shape_334 = new cjs.Shape();
	this.shape_334.graphics.f("#BBCACB").s().p("AAAAAIAAAAIABABIAAAAg");
	this.shape_334.setTransform(28.9552,45.4644,1.0844,1.0844);

	this.shape_335 = new cjs.Shape();
	this.shape_335.graphics.f("#BBCACB").s().p("AgIgOIAQAZIgBAAIACACIgCACg");
	this.shape_335.setTransform(35.2444,44.1903,1.0844,1.0844);

	this.shape_336 = new cjs.Shape();
	this.shape_336.graphics.f("#BBCACB").s().p("AgGAyIgZgwIAfg2IAAABIAAgBIAgA4IgbAxg");
	this.shape_336.setTransform(32.5335,45.4373,1.0844,1.0844);

	this.shape_337 = new cjs.Shape();
	this.shape_337.graphics.f("#BBCACB").s().p("AAAAAIAAgBIABABIgBACg");
	this.shape_337.setTransform(32.4793,27.2745,1.0844,1.0844);

	this.shape_338 = new cjs.Shape();
	this.shape_338.graphics.f("#BBCACB").s().p("AgOAZIAAAAIgBgCIAfgxIgdA1g");
	this.shape_338.setTransform(34.1872,36.4643,1.0844,1.0844);

	this.shape_339 = new cjs.Shape();
	this.shape_339.graphics.f("#BBCACB").s().p("AgIgPIAQAZIgBAAIACADIgCADg");
	this.shape_339.setTransform(35.2444,31.6119,1.0844,1.0844);

	this.shape_340 = new cjs.Shape();
	this.shape_340.graphics.f("#BBCACB").s().p("AgKgSIAUAfIAAABIABACIgCADg");
	this.shape_340.setTransform(31.4221,37.4945,1.0844,1.0844);

	this.shape_341 = new cjs.Shape();
	this.shape_341.graphics.f("#BBCACB").s().p("AgKATIgBgCIAXgkIgWAng");
	this.shape_341.setTransform(30.2022,30.8528,1.0844,1.0844);

	this.shape_342 = new cjs.Shape();
	this.shape_342.graphics.f("#BBCACB").s().p("AAAACIAAgBIABgCIAAABIgBACg");
	this.shape_342.setTransform(32.5335,39.4463,1.0844,1.0844);

	this.shape_343 = new cjs.Shape();
	this.shape_343.graphics.f("#BBCACB").s().p("AgfAAIAeg1IABACIABgCIAfA3IggA0g");
	this.shape_343.setTransform(32.5335,33.1028,1.0844,1.0844);

	this.shape_344 = new cjs.Shape();
	this.shape_344.graphics.f("#BBCACB").s().p("AAAAAIAAgBIABABIgBACg");
	this.shape_344.setTransform(36.0306,20.8497,1.0844,1.0844);

	this.shape_345 = new cjs.Shape();
	this.shape_345.graphics.f("#BBCACB").s().p("AgOAZIAAgBIgBgCIAegxIABABIgdA2g");
	this.shape_345.setTransform(34.2685,23.913,1.0844,1.0844);

	this.shape_346 = new cjs.Shape();
	this.shape_346.graphics.f("#BBCACB").s().p("AgIgOIAQAZIgBABIACACIgBAAIgBgBIgBACg");
	this.shape_346.setTransform(35.2444,19.2774,1.0844,1.0844);

	this.shape_347 = new cjs.Shape();
	this.shape_347.graphics.f("#BBCACB").s().p("AgPgaIAdAuIAAAAIABACIgDAGg");
	this.shape_347.setTransform(30.9341,24.1841,1.0844,1.0844);

	this.shape_348 = new cjs.Shape();
	this.shape_348.graphics.f("#BBCACB").s().p("AgfACIAfg2IAAABIAAgBIAgA2IggAzg");
	this.shape_348.setTransform(32.4793,20.6057,1.0844,1.0844);

	this.shape_349 = new cjs.Shape();
	this.shape_349.graphics.f("#BBCACB").s().p("AAAABIgBACIAAgBIACgEIABACIgBADg");
	this.shape_349.setTransform(32.5335,26.9492,1.0844,1.0844);

	this.shape_350 = new cjs.Shape();
	this.shape_350.graphics.f("#BBCACB").s().p("AgOAaIAAgBIgBgBIAfgzIAAAAIgdA3g");
	this.shape_350.setTransform(34.2685,11.5514,1.0844,1.0844);

	this.shape_351 = new cjs.Shape();
	this.shape_351.graphics.f("#BBCACB").s().p("AgIgOIAQAYIgBABIACACIgBACIgBAAIAAAAg");
	this.shape_351.setTransform(35.2444,6.8616,1.0844,1.0844);

	this.shape_352 = new cjs.Shape();
	this.shape_352.graphics.f("#BBCACB").s().p("AgLgVIAWAlIAAAAIABACIgCAEg");
	this.shape_352.setTransform(31.2594,12.4189,1.0844,1.0844);

	this.shape_353 = new cjs.Shape();
	this.shape_353.graphics.f("#BBCACB").s().p("AgKATIgBgCIAXgkIgWAng");
	this.shape_353.setTransform(30.2022,6.1567,1.0844,1.0844);

	this.shape_354 = new cjs.Shape();
	this.shape_354.graphics.f("#BBCACB").s().p("AgXAQIgIgPIAfg2IAAAAIAAAAIAgA4IggAzg");
	this.shape_354.setTransform(32.5064,8.2441,1.0844,1.0844);

	this.shape_355 = new cjs.Shape();
	this.shape_355.graphics.f("#BBCACB").s().p("AAAACIAAAAIgBgBIACgCIABABIgCACg");
	this.shape_355.setTransform(32.5335,14.6418,1.0844,1.0844);

	this.shape_356 = new cjs.Shape();
	this.shape_356.graphics.f("#BBCACB").s().p("AAAAAIAAgBIABABIgBACg");
	this.shape_356.setTransform(32.4793,-10.0272,1.0844,1.0844);

	this.shape_357 = new cjs.Shape();
	this.shape_357.graphics.f("#BBCACB").s().p("AgOAZIAAgBIgBgCIAfgwIgdA1g");
	this.shape_357.setTransform(34.1872,-0.8373,1.0844,1.0844);

	this.shape_358 = new cjs.Shape();
	this.shape_358.graphics.f("#BBCACB").s().p("AgIgPIAQAZIgBABIACACIgCADg");
	this.shape_358.setTransform(35.2444,-5.744,1.0844,1.0844);

	this.shape_359 = new cjs.Shape();
	this.shape_359.graphics.f("#BBCACB").s().p("AgKgSIAUAfIAAAAIABADIgCADg");
	this.shape_359.setTransform(31.4221,0.1928,1.0844,1.0844);

	this.shape_360 = new cjs.Shape();
	this.shape_360.graphics.f("#BBCACB").s().p("AgKATIgBgCIAXgkIgWAng");
	this.shape_360.setTransform(30.2022,-6.476,1.0844,1.0844);

	this.shape_361 = new cjs.Shape();
	this.shape_361.graphics.f("#BBCACB").s().p("AgUAWIgLgWIAeg1IABADIABgCIAfA2IgBADIgfAxg");
	this.shape_361.setTransform(32.5335,-4.253,1.0844,1.0844);

	this.shape_362 = new cjs.Shape();
	this.shape_362.graphics.f("#BBCACB").s().p("AAAACIAAAAIAAgBIABgCIAAABIgBACg");
	this.shape_362.setTransform(32.5335,2.1446,1.0844,1.0844);

	this.shape_363 = new cjs.Shape();
	this.shape_363.graphics.f("#BBCACB").s().p("AAAAAIAAgBIABABIgBACg");
	this.shape_363.setTransform(36.0306,-16.452,1.0844,1.0844);

	this.shape_364 = new cjs.Shape();
	this.shape_364.graphics.f("#BBCACB").s().p("AgOAZIAAgBIgBgCIAegxIABACIgdA1g");
	this.shape_364.setTransform(34.2685,-13.4158,1.0844,1.0844);

	this.shape_365 = new cjs.Shape();
	this.shape_365.graphics.f("#BBCACB").s().p("AAHANIgBACIgOgdIAQAZIgBAAIACADIgBABg");
	this.shape_365.setTransform(35.2444,-18.0514,1.0844,1.0844);

	this.shape_366 = new cjs.Shape();
	this.shape_366.graphics.f("#BBCACB").s().p("AgPgbIAdAvIAAAAIABACIgDAGg");
	this.shape_366.setTransform(30.9341,-13.1176,1.0844,1.0844);

	this.shape_367 = new cjs.Shape();
	this.shape_367.graphics.f("#BBCACB").s().p("AgKATIgBgCIAXglIgWApg");
	this.shape_367.setTransform(30.2022,-18.702,1.0844,1.0844);

	this.shape_368 = new cjs.Shape();
	this.shape_368.graphics.f("#BBCACB").s().p("AAAABIgBACIAAgBIACgEIABACIgBADg");
	this.shape_368.setTransform(32.5335,-10.3796,1.0844,1.0844);

	this.shape_369 = new cjs.Shape();
	this.shape_369.graphics.f("#BBCACB").s().p("AgfACIAfg2IAAAAIAgA2IggAzg");
	this.shape_369.setTransform(32.4793,-16.7231,1.0844,1.0844);

	this.shape_370 = new cjs.Shape();
	this.shape_370.graphics.f("#BBCACB").s().p("AgOAZIAAgBIgBgCIAfgvIgdA0g");
	this.shape_370.setTransform(34.1872,-25.6961,1.0844,1.0844);

	this.shape_371 = new cjs.Shape();
	this.shape_371.graphics.f("#BBCACB").s().p("AgIgOIAQAZIgBAAIACACIgCACg");
	this.shape_371.setTransform(35.2444,-30.5756,1.0844,1.0844);

	this.shape_372 = new cjs.Shape();
	this.shape_372.graphics.f("#BBCACB").s().p("AgKgSIAUAfIAAAAIABADIgCADg");
	this.shape_372.setTransform(31.4221,-24.6388,1.0844,1.0844);

	this.shape_373 = new cjs.Shape();
	this.shape_373.graphics.f("#BBCACB").s().p("AgKATIgBgCIAXgkIgWAng");
	this.shape_373.setTransform(30.2022,-31.3076,1.0844,1.0844);

	this.shape_374 = new cjs.Shape();
	this.shape_374.graphics.f("#BBCACB").s().p("AgUAXIgLgXIAfg2IAAABIAAgBIAgA4IgBAEIgfAwg");
	this.shape_374.setTransform(32.5335,-29.166,1.0844,1.0844);

	this.shape_375 = new cjs.Shape();
	this.shape_375.graphics.f("#BBCACB").s().p("AAAACIAAAAIAAgBIABgCIAAABIgBACg");
	this.shape_375.setTransform(32.5335,-22.687,1.0844,1.0844);

	this.shape_376 = new cjs.Shape();
	this.shape_376.graphics.f("#BBCACB").s().p("AgEAHIAAAAIgBgCIAHgNIAEAAIgJARg");
	this.shape_376.setTransform(33.1028,-36.3769,1.0844,1.0844);

	this.shape_377 = new cjs.Shape();
	this.shape_377.graphics.f("#BBCACB").s().p("AgFgHIADgBIAGALIAAAAIABACIgCAEg");
	this.shape_377.setTransform(32.0185,-36.1329,1.0844,1.0844);

	this.shape_378 = new cjs.Shape();
	this.shape_378.graphics.f("#BBCACB").s().p("AgHgEIAPgCIgIANg");
	this.shape_378.setTransform(32.5335,-36.5667,1.0844,1.0844);

	this.shape_379 = new cjs.Shape();
	this.shape_379.graphics.f("#BBCACB").s().p("AAAACIAAAAIAAgBIABgCIAAABIgBACg");
	this.shape_379.setTransform(32.5335,-35.3197,1.0844,1.0844);

	this.shape_380 = new cjs.Shape();
	this.shape_380.graphics.f("#BBCACB").s().p("AAAAAIAAAAIABABIgBAAg");
	this.shape_380.setTransform(21.7985,45.4644,1.0844,1.0844);

	this.shape_381 = new cjs.Shape();
	this.shape_381.graphics.f("#BBCACB").s().p("AgIgOIAQAZIgBAAIACACIgCACg");
	this.shape_381.setTransform(28.0877,44.1903,1.0844,1.0844);

	this.shape_382 = new cjs.Shape();
	this.shape_382.graphics.f("#BBCACB").s().p("AgPAnIgQgfIAfg2IAgA4IgUAlg");
	this.shape_382.setTransform(25.3768,44.7596,1.0844,1.0844);

	this.shape_383 = new cjs.Shape();
	this.shape_383.graphics.f("#BBCACB").s().p("AAAAAIAAgBIABABIgBACg");
	this.shape_383.setTransform(25.3226,27.2745,1.0844,1.0844);

	this.shape_384 = new cjs.Shape();
	this.shape_384.graphics.f("#BBCACB").s().p("AAAAAIAAAAIABABIgBAAg");
	this.shape_384.setTransform(25.3768,39.0668,1.0844,1.0844);

	this.shape_385 = new cjs.Shape();
	this.shape_385.graphics.f("#BBCACB").s().p("AgOAZIAAAAIgBgCIAegxIgcA1g");
	this.shape_385.setTransform(27.0305,36.4643,1.0844,1.0844);

	this.shape_386 = new cjs.Shape();
	this.shape_386.graphics.f("#BBCACB").s().p("AgIgPIAQAZIgBAAIACADIgCADg");
	this.shape_386.setTransform(28.0877,31.6119,1.0844,1.0844);

	this.shape_387 = new cjs.Shape();
	this.shape_387.graphics.f("#BBCACB").s().p("AgKgSIAUAfIAAABIABACIgCADg");
	this.shape_387.setTransform(24.2383,37.4945,1.0844,1.0844);

	this.shape_388 = new cjs.Shape();
	this.shape_388.graphics.f("#BBCACB").s().p("AgKAUIAAgBIgBgCIAXgkIgWAng");
	this.shape_388.setTransform(23.0455,30.8528,1.0844,1.0844);

	this.shape_389 = new cjs.Shape();
	this.shape_389.graphics.f("#BBCACB").s().p("AAAABIAAgCIABABIgBACg");
	this.shape_389.setTransform(25.3768,39.4463,1.0844,1.0844);

	this.shape_390 = new cjs.Shape();
	this.shape_390.graphics.f("#BBCACB").s().p("AgfAAIAeg1IABACIABgCIAfA3IggA0g");
	this.shape_390.setTransform(25.3768,33.1028,1.0844,1.0844);

	this.shape_391 = new cjs.Shape();
	this.shape_391.graphics.f("#BBCACB").s().p("AAAAAIAAAAIABABIgBAAg");
	this.shape_391.setTransform(21.7985,20.6328,1.0844,1.0844);

	this.shape_392 = new cjs.Shape();
	this.shape_392.graphics.f("#BBCACB").s().p("AAAAAIAAgBIABABIgBACg");
	this.shape_392.setTransform(28.8739,20.8497,1.0844,1.0844);

	this.shape_393 = new cjs.Shape();
	this.shape_393.graphics.f("#BBCACB").s().p("AgPAZIABgBIgBgCIAegxIABABIgdA2g");
	this.shape_393.setTransform(27.1118,23.913,1.0844,1.0844);

	this.shape_394 = new cjs.Shape();
	this.shape_394.graphics.f("#BBCACB").s().p("AgIgOIAQAZIgBABIACACIgBAAIgBgBIgBACg");
	this.shape_394.setTransform(28.0877,19.2774,1.0844,1.0844);

	this.shape_395 = new cjs.Shape();
	this.shape_395.graphics.f("#BBCACB").s().p("AgOgaIAdAuIgBAAIABACIgCAGg");
	this.shape_395.setTransform(23.7503,24.1841,1.0844,1.0844);

	this.shape_396 = new cjs.Shape();
	this.shape_396.graphics.f("#BBCACB").s().p("AgKAUIAAgBIgBgCIAXgkIgWAng");
	this.shape_396.setTransform(23.0455,18.6268,1.0844,1.0844);

	this.shape_397 = new cjs.Shape();
	this.shape_397.graphics.f("#BBCACB").s().p("AAAABIgBACIAAgBIABgEIACACIgBADg");
	this.shape_397.setTransform(25.3768,26.9492,1.0844,1.0844);

	this.shape_398 = new cjs.Shape();
	this.shape_398.graphics.f("#BBCACB").s().p("AgfACIAfg2IAAABIAAgBIAgA2IggAzg");
	this.shape_398.setTransform(25.3226,20.6057,1.0844,1.0844);

	this.shape_399 = new cjs.Shape();
	this.shape_399.graphics.f("#BBCACB").s().p("AAAAAIAAAAIABAAIgBAAg");
	this.shape_399.setTransform(28.8739,8.5152,1.0844,1.0844);

	this.shape_400 = new cjs.Shape();
	this.shape_400.graphics.f("#BBCACB").s().p("AAAAAIAAAAIABABIgBAAg");
	this.shape_400.setTransform(25.3768,14.2351,1.0844,1.0844);

	this.shape_401 = new cjs.Shape();
	this.shape_401.graphics.f("#BBCACB").s().p("AgPAaIABgBIgBgBIAfgzIAAAAIgdA3g");
	this.shape_401.setTransform(27.1118,11.5514,1.0844,1.0844);

	this.shape_402 = new cjs.Shape();
	this.shape_402.graphics.f("#BBCACB").s().p("AgIgOIAQAYIgBABIACACIgBACIgBAAIAAAAg");
	this.shape_402.setTransform(28.0877,6.8616,1.0844,1.0844);

	this.shape_403 = new cjs.Shape();
	this.shape_403.graphics.f("#BBCACB").s().p("AgLgVIAXAlIgBAAIABACIgCAEg");
	this.shape_403.setTransform(24.0756,12.4189,1.0844,1.0844);

	this.shape_404 = new cjs.Shape();
	this.shape_404.graphics.f("#BBCACB").s().p("AgKAUIAAgBIgBgCIAXgkIgWAng");
	this.shape_404.setTransform(23.0455,6.1567,1.0844,1.0844);

	this.shape_405 = new cjs.Shape();
	this.shape_405.graphics.f("#BBCACB").s().p("AgXAQIgIgPIAfg2IAgA4IggAzg");
	this.shape_405.setTransform(25.3497,8.2441,1.0844,1.0844);

	this.shape_406 = new cjs.Shape();
	this.shape_406.graphics.f("#BBCACB").s().p("AAAACIAAAAIgBgBIABgCIACABIgCACg");
	this.shape_406.setTransform(25.3768,14.6418,1.0844,1.0844);

	this.shape_407 = new cjs.Shape();
	this.shape_407.graphics.f("#BBCACB").s().p("AAAAAIAAgBIABABIgBACg");
	this.shape_407.setTransform(25.3226,-10.0272,1.0844,1.0844);

	this.shape_408 = new cjs.Shape();
	this.shape_408.graphics.f("#BBCACB").s().p("AAAAAIAAAAIABABIgBAAg");
	this.shape_408.setTransform(21.7985,-4.4699,1.0844,1.0844);

	this.shape_409 = new cjs.Shape();
	this.shape_409.graphics.f("#BBCACB").s().p("AgOAZIAAgBIgBgCIAegwIgcA1g");
	this.shape_409.setTransform(27.0305,-0.8373,1.0844,1.0844);

	this.shape_410 = new cjs.Shape();
	this.shape_410.graphics.f("#BBCACB").s().p("AgIgPIAQAZIgBABIACACIgCADg");
	this.shape_410.setTransform(28.0877,-5.744,1.0844,1.0844);

	this.shape_411 = new cjs.Shape();
	this.shape_411.graphics.f("#BBCACB").s().p("AgKgSIAUAfIAAAAIABADIgCADg");
	this.shape_411.setTransform(24.2383,0.1928,1.0844,1.0844);

	this.shape_412 = new cjs.Shape();
	this.shape_412.graphics.f("#BBCACB").s().p("AgKAUIAAgBIgBgCIAXgkIgWAng");
	this.shape_412.setTransform(23.0455,-6.476,1.0844,1.0844);

	this.shape_413 = new cjs.Shape();
	this.shape_413.graphics.f("#BBCACB").s().p("AAAABIAAgCIABABIgBACg");
	this.shape_413.setTransform(25.3768,2.1446,1.0844,1.0844);

	this.shape_414 = new cjs.Shape();
	this.shape_414.graphics.f("#BBCACB").s().p("AgUAWIgLgWIAeg1IABADIABgCIAfA2IgBADIgfAxg");
	this.shape_414.setTransform(25.3768,-4.253,1.0844,1.0844);

	this.shape_415 = new cjs.Shape();
	this.shape_415.graphics.f("#BBCACB").s().p("AAAAAIAAgBIABABIgBACg");
	this.shape_415.setTransform(28.8739,-16.452,1.0844,1.0844);

	this.shape_416 = new cjs.Shape();
	this.shape_416.graphics.f("#BBCACB").s().p("AAAAAIAAAAIABABIgBAAg");
	this.shape_416.setTransform(25.3768,-10.8676,1.0844,1.0844);

	this.shape_417 = new cjs.Shape();
	this.shape_417.graphics.f("#BBCACB").s().p("AgPAZIABgBIgBgCIAegxIABACIgdA1g");
	this.shape_417.setTransform(27.1118,-13.4158,1.0844,1.0844);

	this.shape_418 = new cjs.Shape();
	this.shape_418.graphics.f("#BBCACB").s().p("AAHANIgBACIgOgdIAQAZIgBAAIACADIgBABg");
	this.shape_418.setTransform(28.0877,-18.0514,1.0844,1.0844);

	this.shape_419 = new cjs.Shape();
	this.shape_419.graphics.f("#BBCACB").s().p("AgOgbIAdAvIgBAAIABACIgCAGg");
	this.shape_419.setTransform(23.7503,-13.1176,1.0844,1.0844);

	this.shape_420 = new cjs.Shape();
	this.shape_420.graphics.f("#BBCACB").s().p("AgKAUIAAgBIgBgCIAXglIgWApg");
	this.shape_420.setTransform(23.0455,-18.702,1.0844,1.0844);

	this.shape_421 = new cjs.Shape();
	this.shape_421.graphics.f("#BBCACB").s().p("AgfACIAfg2IAgA2IggAzg");
	this.shape_421.setTransform(25.3226,-16.7231,1.0844,1.0844);

	this.shape_422 = new cjs.Shape();
	this.shape_422.graphics.f("#BBCACB").s().p("AAAABIgBACIAAgBIABgEIACACIgBADg");
	this.shape_422.setTransform(25.3768,-10.3796,1.0844,1.0844);

	this.shape_423 = new cjs.Shape();
	this.shape_423.graphics.f("#BBCACB").s().p("AgOAZIABgBIgBgCIAdgvIgcA0g");
	this.shape_423.setTransform(27.0034,-25.6961,1.0844,1.0844);

	this.shape_424 = new cjs.Shape();
	this.shape_424.graphics.f("#BBCACB").s().p("AgIgOIAQAZIgBAAIACACIgCACg");
	this.shape_424.setTransform(28.0877,-30.5756,1.0844,1.0844);

	this.shape_425 = new cjs.Shape();
	this.shape_425.graphics.f("#BBCACB").s().p("AgKgSIAUAfIAAAAIABADIgCADg");
	this.shape_425.setTransform(24.2383,-24.6388,1.0844,1.0844);

	this.shape_426 = new cjs.Shape();
	this.shape_426.graphics.f("#BBCACB").s().p("AgKAUIAAgBIgBgCIAXgkIgWAng");
	this.shape_426.setTransform(23.0455,-31.3076,1.0844,1.0844);

	this.shape_427 = new cjs.Shape();
	this.shape_427.graphics.f("#BBCACB").s().p("AgUAXIgLgXIAfg2IAgA4IggA0g");
	this.shape_427.setTransform(25.3768,-29.166,1.0844,1.0844);

	this.shape_428 = new cjs.Shape();
	this.shape_428.graphics.f("#BBCACB").s().p("AAAABIAAgCIABABIgBACg");
	this.shape_428.setTransform(25.3768,-22.687,1.0844,1.0844);

	this.shape_429 = new cjs.Shape();
	this.shape_429.graphics.f("#BBCACB").s().p("AgBACIAAAAIgBgCIACgDIADAAIgDAHg");
	this.shape_429.setTransform(25.675,-35.8347,1.0844,1.0844);

	this.shape_430 = new cjs.Shape();
	this.shape_430.graphics.f("#BBCACB").s().p("AgCgDIADAAIABACIAAAAIABACIgBAEg");
	this.shape_430.setTransform(25.0786,-35.6721,1.0844,1.0844);

	this.shape_431 = new cjs.Shape();
	this.shape_431.graphics.f("#BBCACB").s().p("AAAABIAAgCIABABIgBACg");
	this.shape_431.setTransform(25.3768,-35.3197,1.0844,1.0844);

	this.shape_432 = new cjs.Shape();
	this.shape_432.graphics.f("#BBCACB").s().p("AgBAAIADgBIgCADg");
	this.shape_432.setTransform(25.3497,-36.0245,1.0844,1.0844);

	this.shape_433 = new cjs.Shape();
	this.shape_433.graphics.f("#BBCACB").s().p("AgHgOIAPAZIAAAAIABACIgCACg");
	this.shape_433.setTransform(20.9039,44.1903,1.0844,1.0844);

	this.shape_434 = new cjs.Shape();
	this.shape_434.graphics.f("#BBCACB").s().p("AgSAZQgCgVAFgmIADgEIAgA4IgLAVQgagJgBgFg");
	this.shape_434.setTransform(19.5297,43.9192,1.0844,1.0844);

	this.shape_435 = new cjs.Shape();
	this.shape_435.graphics.f("#BBCACB").s().p("AAAAAIAAgBIABABIgBACg");
	this.shape_435.setTransform(18.1388,27.2745,1.0844,1.0844);

	this.shape_436 = new cjs.Shape();
	this.shape_436.graphics.f("#BBCACB").s().p("AAAAAIAAAAIABABIgBAAg");
	this.shape_436.setTransform(18.2201,39.0668,1.0844,1.0844);

	this.shape_437 = new cjs.Shape();
	this.shape_437.graphics.f("#BBCACB").s().p("AgOAZIABAAIgBgCIAdgxIgcA1g");
	this.shape_437.setTransform(19.8737,36.4643,1.0844,1.0844);

	this.shape_438 = new cjs.Shape();
	this.shape_438.graphics.f("#BBCACB").s().p("AgHgPIAPAZIAAAAIABADIgCADg");
	this.shape_438.setTransform(20.9039,31.6119,1.0844,1.0844);

	this.shape_439 = new cjs.Shape();
	this.shape_439.graphics.f("#BBCACB").s().p("AAAACIAAgFIABACIgBABIABABIgBADg");
	this.shape_439.setTransform(18.0846,39.121,1.0844,1.0844);

	this.shape_440 = new cjs.Shape();
	this.shape_440.graphics.f("#BBCACB").s().p("AgQArIANhXIAFAHIAPAfIgBADIgeAwg");
	this.shape_440.setTransform(19.8195,34.0245,1.0844,1.0844);

	this.shape_441 = new cjs.Shape();
	this.shape_441.graphics.f("#BBCACB").s().p("AAAABIAAgCIABABIgBACg");
	this.shape_441.setTransform(18.2201,39.4463,1.0844,1.0844);

	this.shape_442 = new cjs.Shape();
	this.shape_442.graphics.f("#BBCACB").s().p("AAAAAIAAgBIABABIgBACg");
	this.shape_442.setTransform(21.7171,20.8497,1.0844,1.0844);

	this.shape_443 = new cjs.Shape();
	this.shape_443.graphics.f("#BBCACB").s().p("AgHAIIAPgXIAAABIgPAeg");
	this.shape_443.setTransform(20.7683,22.6389,1.0844,1.0844);

	this.shape_444 = new cjs.Shape();
	this.shape_444.graphics.f("#BBCACB").s().p("AgFgIIAAgCIALARIgBABIABACIAAAAIgBgBIgBACg");
	this.shape_444.setTransform(21.1479,19.7111,1.0844,1.0844);

	this.shape_445 = new cjs.Shape();
	this.shape_445.graphics.f("#BBCACB").s().p("AgCgVIAKAUIgPAXIAFgrg");
	this.shape_445.setTransform(20.7683,21.1208,1.0844,1.0844);

	this.shape_446 = new cjs.Shape();
	this.shape_446.graphics.f("#BBCACB").s().p("AAAABIgBACIAAgBIABgEIACACIgCADg");
	this.shape_446.setTransform(18.2201,26.9492,1.0844,1.0844);

	this.shape_447 = new cjs.Shape();
	this.shape_447.graphics.f("#BBCACB").s().p("AgMASIAZgnIAAAAIgXAsg");
	this.shape_447.setTransform(20.2804,10.955,1.0844,1.0844);

	this.shape_448 = new cjs.Shape();
	this.shape_448.graphics.f("#BBCACB").s().p("AgHgOIAPAYIAAABIABACIgBACIAAAAIgBAAg");
	this.shape_448.setTransform(20.9039,6.8616,1.0844,1.0844);

	this.shape_449 = new cjs.Shape();
	this.shape_449.graphics.f("#BBCACB").s().p("AgXgUIAQgcIAfA4IgYApg");
	this.shape_449.setTransform(19.0063,7.6748,1.0844,1.0844);

	this.shape_450 = new cjs.Shape();
	this.shape_450.graphics.f("#BBCACB").s().p("AAAACIAAAAIgBgBIABgCIABABIgBACg");
	this.shape_450.setTransform(18.193,14.6418,1.0844,1.0844);

	this.shape_451 = new cjs.Shape();
	this.shape_451.graphics.f("#BBCACB").s().p("AAAAAIAAgBIABABIgBACg");
	this.shape_451.setTransform(18.1388,-10.0272,1.0844,1.0844);

	this.shape_452 = new cjs.Shape();
	this.shape_452.graphics.f("#BBCACB").s().p("AgOAZIABgBIgBgCIAdgwIgcA1g");
	this.shape_452.setTransform(19.8737,-0.8373,1.0844,1.0844);

	this.shape_453 = new cjs.Shape();
	this.shape_453.graphics.f("#BBCACB").s().p("AgHgPIAPAZIAAABIABACIgCADg");
	this.shape_453.setTransform(20.9039,-5.744,1.0844,1.0844);

	this.shape_454 = new cjs.Shape();
	this.shape_454.graphics.f("#BBCACB").s().p("AgKgSIAUAfIAAAAIABADIgCADg");
	this.shape_454.setTransform(17.0815,0.1928,1.0844,1.0844);

	this.shape_455 = new cjs.Shape();
	this.shape_455.graphics.f("#BBCACB").s().p("AgLASIAXglIgWAng");
	this.shape_455.setTransform(15.8617,-6.476,1.0844,1.0844);

	this.shape_456 = new cjs.Shape();
	this.shape_456.graphics.f("#BBCACB").s().p("AgUAWIgLgWIAeg1IABADIAAgCIARAYIAPAeIgBADIgfAxg");
	this.shape_456.setTransform(18.193,-4.253,1.0844,1.0844);

	this.shape_457 = new cjs.Shape();
	this.shape_457.graphics.f("#BBCACB").s().p("AAAABIAAgCIABABIgBACg");
	this.shape_457.setTransform(18.2201,2.1446,1.0844,1.0844);

	this.shape_458 = new cjs.Shape();
	this.shape_458.graphics.f("#BBCACB").s().p("AAAAAIAAgBIABABIgBACg");
	this.shape_458.setTransform(21.7171,-16.452,1.0844,1.0844);

	this.shape_459 = new cjs.Shape();
	this.shape_459.graphics.f("#BBCACB").s().p("AAAAAIAAAAIABABIgBAAg");
	this.shape_459.setTransform(18.2201,-10.8676,1.0844,1.0844);

	this.shape_460 = new cjs.Shape();
	this.shape_460.graphics.f("#BBCACB").s().p("AgPAZIABgBIgBgCIAfgxIAAACIgdA1g");
	this.shape_460.setTransform(19.928,-13.4158,1.0844,1.0844);

	this.shape_461 = new cjs.Shape();
	this.shape_461.graphics.f("#BBCACB").s().p("AAIANIgBACIgOgdIAPAZIAAAAIABADIAAABg");
	this.shape_461.setTransform(20.9039,-18.0514,1.0844,1.0844);

	this.shape_462 = new cjs.Shape();
	this.shape_462.graphics.f("#BBCACB").s().p("AgOgbIAdAvIgBAAIABACIgCAGg");
	this.shape_462.setTransform(16.5936,-13.1176,1.0844,1.0844);

	this.shape_463 = new cjs.Shape();
	this.shape_463.graphics.f("#BBCACB").s().p("AgLARIAXglIgWApg");
	this.shape_463.setTransform(15.8617,-18.702,1.0844,1.0844);

	this.shape_464 = new cjs.Shape();
	this.shape_464.graphics.f("#BBCACB").s().p("AAAABIgBACIAAgBIABgEIACACIgCADg");
	this.shape_464.setTransform(18.2201,-10.3796,1.0844,1.0844);

	this.shape_465 = new cjs.Shape();
	this.shape_465.graphics.f("#BBCACB").s().p("AgfACIAfg2IAgA2IggAzg");
	this.shape_465.setTransform(18.1659,-16.7231,1.0844,1.0844);

	this.shape_466 = new cjs.Shape();
	this.shape_466.graphics.f("#BBCACB").s().p("AAAAAIAAgBIABABIgBABg");
	this.shape_466.setTransform(18.2201,-23.0936,1.0844,1.0844);

	this.shape_467 = new cjs.Shape();
	this.shape_467.graphics.f("#BBCACB").s().p("AgOAZIABgBIgBgCIAdgvIgcA0g");
	this.shape_467.setTransform(19.8466,-25.6961,1.0844,1.0844);

	this.shape_468 = new cjs.Shape();
	this.shape_468.graphics.f("#BBCACB").s().p("AgHgOIAPAZIAAAAIABACIgCACg");
	this.shape_468.setTransform(20.9039,-30.5756,1.0844,1.0844);

	this.shape_469 = new cjs.Shape();
	this.shape_469.graphics.f("#BBCACB").s().p("AgKgSIAUAfIAAAAIABADIgCADg");
	this.shape_469.setTransform(17.0815,-24.6388,1.0844,1.0844);

	this.shape_470 = new cjs.Shape();
	this.shape_470.graphics.f("#BBCACB").s().p("AgLARIAXgkIgWAng");
	this.shape_470.setTransform(15.8617,-31.3076,1.0844,1.0844);

	this.shape_471 = new cjs.Shape();
	this.shape_471.graphics.f("#BBCACB").s().p("AAAABIAAgCIABABIgBACg");
	this.shape_471.setTransform(18.2201,-22.687,1.0844,1.0844);

	this.shape_472 = new cjs.Shape();
	this.shape_472.graphics.f("#BBCACB").s().p("AgUAVIgLgVIAdgzIADgBIAQAXIAPAeIgBADIgfAxg");
	this.shape_472.setTransform(18.193,-29.0304,1.0844,1.0844);

	this.shape_473 = new cjs.Shape();
	this.shape_473.graphics.f("#747888").s().p("AgfABIAfg3IAAAAIAAAAIAgA4IggA2g");
	this.shape_473.setTransform(36.1119,39.3107,1.0844,1.0844);

	this.shape_474 = new cjs.Shape();
	this.shape_474.graphics.f("#747888").s().p("AAAABIAAgBIABAAIgBABg");
	this.shape_474.setTransform(36.1119,20.9581,1.0844,1.0844);

	this.shape_475 = new cjs.Shape();
	this.shape_475.graphics.f("#747888").s().p("AgeACIAeg2IAAABIABgDIACAEIAcA2IgfAyg");
	this.shape_475.setTransform(36.1119,26.7865,1.0844,1.0844);

	this.shape_476 = new cjs.Shape();
	this.shape_476.graphics.f("#747888").s().p("AgeABIAeg3IAAABIAAgBIAJAOIAWArIgfA0g");
	this.shape_476.setTransform(36.1119,14.5062,1.0844,1.0844);

	this.shape_477 = new cjs.Shape();
	this.shape_477.graphics.f("#747888").s().p("AgfABIAfg3IAAAAIAgA5IggA0g");
	this.shape_477.setTransform(36.1119,1.982,1.0844,1.0844);

	this.shape_478 = new cjs.Shape();
	this.shape_478.graphics.f("#747888").s().p("AAAABIAAgBIABAAIgBABg");
	this.shape_478.setTransform(36.1119,-16.3435,1.0844,1.0844);

	this.shape_479 = new cjs.Shape();
	this.shape_479.graphics.f("#747888").s().p("AgeABIAeg1IAAAAIABgCIACADIAcA3IgfAyg");
	this.shape_479.setTransform(36.1119,-10.5152,1.0844,1.0844);

	this.shape_480 = new cjs.Shape();
	this.shape_480.graphics.f("#747888").s().p("AgfAAIAfg2IAAAAIAMATIAUAmIggA0g");
	this.shape_480.setTransform(36.1119,-22.8496,1.0844,1.0844);

	this.shape_481 = new cjs.Shape();
	this.shape_481.graphics.f("#747888").s().p("AgfgPIAKgSIAogFIANAZIggA0g");
	this.shape_481.setTransform(36.1119,-33.6118,1.0844,1.0844);

	this.shape_482 = new cjs.Shape();
	this.shape_482.graphics.f("#747888").s().p("AgfABIAfg3IAAAAIAAAAIAgA4IggA2g");
	this.shape_482.setTransform(28.9552,39.3107,1.0844,1.0844);

	this.shape_483 = new cjs.Shape();
	this.shape_483.graphics.f("#747888").s().p("AAAABIAAgBIABAAIgBABg");
	this.shape_483.setTransform(28.9552,20.9581,1.0844,1.0844);

	this.shape_484 = new cjs.Shape();
	this.shape_484.graphics.f("#747888").s().p("AgeACIAeg2IAAABIABgDIACAEIAcA2IgfAyg");
	this.shape_484.setTransform(28.9552,26.7865,1.0844,1.0844);

	this.shape_485 = new cjs.Shape();
	this.shape_485.graphics.f("#747888").s().p("AgeABIAeg3IAAABIAAgBIAJAOIAWArIgfA0g");
	this.shape_485.setTransform(28.9552,14.5062,1.0844,1.0844);

	this.shape_486 = new cjs.Shape();
	this.shape_486.graphics.f("#747888").s().p("AgfABIAfg3IAAAAIAgA5IggA0g");
	this.shape_486.setTransform(28.9552,1.982,1.0844,1.0844);

	this.shape_487 = new cjs.Shape();
	this.shape_487.graphics.f("#747888").s().p("AAAABIAAgBIABAAIgBABg");
	this.shape_487.setTransform(28.9552,-16.3435,1.0844,1.0844);

	this.shape_488 = new cjs.Shape();
	this.shape_488.graphics.f("#747888").s().p("AgeABIAeg1IAAAAIABgCIACADIAcA3IgfAyg");
	this.shape_488.setTransform(28.9552,-10.5152,1.0844,1.0844);

	this.shape_489 = new cjs.Shape();
	this.shape_489.graphics.f("#747888").s().p("AgfAAIAdg0IACgCIAAAAIAgA5IggA0g");
	this.shape_489.setTransform(28.9552,-22.8496,1.0844,1.0844);

	this.shape_490 = new cjs.Shape();
	this.shape_490.graphics.f("#747888").s().p("AgfgTIAFgIIAxgHIAJARIggA0g");
	this.shape_490.setTransform(28.9552,-33.2323,1.0844,1.0844);

	this.shape_491 = new cjs.Shape();
	this.shape_491.graphics.f("#747888").s().p("AAAABIABgBIAAAAIgBABg");
	this.shape_491.setTransform(21.7714,45.7626,1.0844,1.0844);

	this.shape_492 = new cjs.Shape();
	this.shape_492.graphics.f("#747888").s().p("AgfABIAfg3IAgA4IggA2g");
	this.shape_492.setTransform(21.7985,39.3107,1.0844,1.0844);

	this.shape_493 = new cjs.Shape();
	this.shape_493.graphics.f("#747888").s().p("AAAABIABgBIAAAAIgBABg");
	this.shape_493.setTransform(21.7443,20.9581,1.0844,1.0844);

	this.shape_494 = new cjs.Shape();
	this.shape_494.graphics.f("#747888").s().p("AgUAdIgFgIIAEgqIAQgfIABABIABgDIACAEIAbA2IgeAyg");
	this.shape_494.setTransform(22.3135,26.7865,1.0844,1.0844);

	this.shape_495 = new cjs.Shape();
	this.shape_495.graphics.f("#747888").s().p("AAAAAIAAAAIAAAAIAAABg");
	this.shape_495.setTransform(21.7171,8.5423,1.0844,1.0844);

	this.shape_496 = new cjs.Shape();
	this.shape_496.graphics.f("#747888").s().p("AgOAlQABgGgEgMIgKgcIAYgtIAAABIABgBIAIAOIAWArIgeA0g");
	this.shape_496.setTransform(22.1238,14.5062,1.0844,1.0844);

	this.shape_497 = new cjs.Shape();
	this.shape_497.graphics.f("#747888").s().p("AgfABIAfg3IAgA5IggA0g");
	this.shape_497.setTransform(21.7985,1.982,1.0844,1.0844);

	this.shape_498 = new cjs.Shape();
	this.shape_498.graphics.f("#747888").s().p("AgeABIAeg1IAAAAIAAgCIADADIAcA3IgfAyg");
	this.shape_498.setTransform(21.7985,-10.5152,1.0844,1.0844);

	this.shape_499 = new cjs.Shape();
	this.shape_499.graphics.f("#747888").s().p("AgfAAIAdg0IACgCIAgA5IggA0g");
	this.shape_499.setTransform(21.7985,-22.8496,1.0844,1.0844);

	this.shape_500 = new cjs.Shape();
	this.shape_500.graphics.f("#747888").s().p("AgegSQAUgFAkgHIAFAJIggA0g");
	this.shape_500.setTransform(21.934,-32.7715,1.0844,1.0844);

	this.shape_501 = new cjs.Shape();
	this.shape_501.graphics.f("#747888").s().p("AAAgCIABACIgBADg");
	this.shape_501.setTransform(17.949,39.6632,1.0844,1.0844);

	this.shape_502 = new cjs.Shape();
	this.shape_502.graphics.f("#747888").s().p("AgTgfIAHgLIAgA5IgRAcg");
	this.shape_502.setTransform(15.943,0.6265,1.0844,1.0844);

	this.shape_503 = new cjs.Shape();
	this.shape_503.graphics.f("#747888").s().p("AAAAAIAAgBIABABIgBACg");
	this.shape_503.setTransform(14.5604,-16.4249,1.0844,1.0844);

	this.shape_504 = new cjs.Shape();
	this.shape_504.graphics.f("#747888").s().p("AgWAQIgHgdIAcgrIABACIAAgCIACADIAcA2IgeA0IAAACIAAACg");
	this.shape_504.setTransform(14.696,-10.2441,1.0844,1.0844);

	this.shape_505 = new cjs.Shape();
	this.shape_505.graphics.f("#747888").s().p("AgFgHIAEgHIAHAdg");
	this.shape_505.setTransform(11.6056,-10.1085,1.0844,1.0844);

	this.shape_506 = new cjs.Shape();
	this.shape_506.graphics.f("#747888").s().p("AAAA3IAAACIggg9IAgg0IAhA5IghA1IACADIgBAAg");
	this.shape_506.setTransform(14.5333,-22.6328,1.0844,1.0844);

	this.shape_507 = new cjs.Shape();
	this.shape_507.graphics.f("#747888").s().p("AgYgLQATgHAegIIgGALIgXAlIACACIgCADg");
	this.shape_507.setTransform(15.0755,-31.7684,1.0844,1.0844);

	this.shape_508 = new cjs.Shape();
	this.shape_508.graphics.f("#D6D8D8").s().p("AgIgLIACgCIAPAcg");
	this.shape_508.setTransform(19.0605,40.9373,1.0844,1.0844);

	this.shape_509 = new cjs.Shape();
	this.shape_509.graphics.f("#D6D8D8").s().p("AgHgLIABgCIAOAcg");
	this.shape_509.setTransform(33.401,-33.8287,1.0844,1.0844);

	this.shape_510 = new cjs.Shape();
	this.shape_510.graphics.f("#D6D8D8").s().p("AgHgKIABgEIAOAdg");
	this.shape_510.setTransform(54.8712,-21.2231,1.0844,1.0844);

	this.shape_511 = new cjs.Shape();
	this.shape_511.graphics.f("#D6D8D8").s().p("AgHgJIACgEIANAag");
	this.shape_511.setTransform(54.9254,-8.8886,1.0844,1.0844);

	this.shape_512 = new cjs.Shape();
	this.shape_512.graphics.f("#D6D8D8").s().p("AgHgKIABgDIAOAcg");
	this.shape_512.setTransform(54.8712,3.6356,1.0844,1.0844);

	this.shape_513 = new cjs.Shape();
	this.shape_513.graphics.f("#D6D8D8").s().p("AgHgLIABgCIAOAcg");
	this.shape_513.setTransform(47.7145,40.9373,1.0844,1.0844);

	this.shape_514 = new cjs.Shape();
	this.shape_514.graphics.f("#D6D8D8").s().p("AgHgLIABgCIAOAcg");
	this.shape_514.setTransform(47.7145,-33.8287,1.0844,1.0844);

	this.shape_515 = new cjs.Shape();
	this.shape_515.graphics.f("#D6D8D8").s().p("AgHgLIABgCIAOAcg");
	this.shape_515.setTransform(40.5577,-33.8287,1.0844,1.0844);

	this.shape_516 = new cjs.Shape();
	this.shape_516.graphics.f("#D6D8D8").s().p("AgIgLIADgCIANAcg");
	this.shape_516.setTransform(26.2172,40.9373,1.0844,1.0844);

	this.shape_517 = new cjs.Shape();
	this.shape_517.graphics.f("#D6D8D8").s().p("AgHgLIABgCIAOAcg");
	this.shape_517.setTransform(54.8712,-33.8287,1.0844,1.0844);

	this.shape_518 = new cjs.Shape();
	this.shape_518.graphics.f("#D6D8D8").s().p("AgHgLIABgCIAOAcg");
	this.shape_518.setTransform(40.5577,40.9373,1.0844,1.0844);

	this.shape_519 = new cjs.Shape();
	this.shape_519.graphics.f("#D6D8D8").s().p("AgHgLIABgCIAOAcg");
	this.shape_519.setTransform(33.401,40.9373,1.0844,1.0844);

	this.shape_520 = new cjs.Shape();
	this.shape_520.graphics.f("#D6D8D8").s().p("AgRA8IAgg8Ighg2IAPgcIAIAFQAhARgoCPg");
	this.shape_520.setTransform(73.9675,-22.9039,1.0844,1.0844);

	this.shape_521 = new cjs.Shape();
	this.shape_521.graphics.f("#D6D8D8").s().p("AgOAIIALgVIABABIABgDIAPAfg");
	this.shape_521.setTransform(22.0424,47.3349,1.0844,1.0844);

	this.shape_522 = new cjs.Shape();
	this.shape_522.graphics.f("#D6D8D8").s().p("AgHgJIACgEIANAag");
	this.shape_522.setTransform(40.612,-8.8886,1.0844,1.0844);

	this.shape_523 = new cjs.Shape();
	this.shape_523.graphics.f("#D6D8D8").s().p("AgHgKIABgEIAOAdg");
	this.shape_523.setTransform(40.5577,-21.2231,1.0844,1.0844);

	this.shape_524 = new cjs.Shape();
	this.shape_524.graphics.f("#D6D8D8").s().p("AgdAUIAbgwIAAABIABgDIAfA9QgVgDgmgIg");
	this.shape_524.setTransform(36.3559,48.9886,1.0844,1.0844);

	this.shape_525 = new cjs.Shape();
	this.shape_525.graphics.f("#D6D8D8").s().p("AgWAOIAUgjIAAAAIABgCIAYAvg");
	this.shape_525.setTransform(29.2263,48.2837,1.0844,1.0844);

	this.shape_526 = new cjs.Shape();
	this.shape_526.graphics.f("#D6D8D8").s().p("AgHgKIACgDIANAbg");
	this.shape_526.setTransform(26.2443,16.1328,1.0844,1.0844);

	this.shape_527 = new cjs.Shape();
	this.shape_527.graphics.f("#D6D8D8").s().p("AgFgIIABgCIAKAVg");
	this.shape_527.setTransform(29.5787,-3.0874,1.0844,1.0844);

	this.shape_528 = new cjs.Shape();
	this.shape_528.graphics.f("#D6D8D8").s().p("AgHhbIANgGIAUAmIggA0IAfA9IgbAsQgqiqAlgTg");
	this.shape_528.setTransform(11.791,-22.3617,1.0844,1.0844);

	this.shape_529 = new cjs.Shape();
	this.shape_529.graphics.f("#D6D8D8").s().p("AgFgHIABgDIAKAVg");
	this.shape_529.setTransform(29.5787,-27.919,1.0844,1.0844);

	this.shape_530 = new cjs.Shape();
	this.shape_530.graphics.f("#D6D8D8").s().p("AgKgZIAVAoIgHALg");
	this.shape_530.setTransform(13.3948,-5.6898,1.0844,1.0844);

	this.shape_531 = new cjs.Shape();
	this.shape_531.graphics.f("#D6D8D8").s().p("AgHgKIABgEIAOAdg");
	this.shape_531.setTransform(33.401,-21.2231,1.0844,1.0844);

	this.shape_532 = new cjs.Shape();
	this.shape_532.graphics.f("#D6D8D8").s().p("AgHgKIABgDIAOAcg");
	this.shape_532.setTransform(33.401,3.6356,1.0844,1.0844);

	this.shape_533 = new cjs.Shape();
	this.shape_533.graphics.f("#D6D8D8").s().p("AgHgJIACgEIANAag");
	this.shape_533.setTransform(33.4552,-8.8886,1.0844,1.0844);

	this.shape_534 = new cjs.Shape();
	this.shape_534.graphics.f("#D6D8D8").s().p("AgFgIIABgCIAKAVg");
	this.shape_534.setTransform(43.9192,-3.0874,1.0844,1.0844);

	this.shape_535 = new cjs.Shape();
	this.shape_535.graphics.f("#D6D8D8").s().p("AACgaIABAAIABgCIAZAuQgjAIgVADg");
	this.shape_535.setTransform(50.0729,48.8259,1.0844,1.0844);

	this.shape_536 = new cjs.Shape();
	this.shape_536.graphics.f("#D6D8D8").s().p("AggAeIAhg7IAAAAIABgCIAeA6QgWAEgRABQgJAAgQgCg");
	this.shape_536.setTransform(43.1331,49.1241,1.0844,1.0844);

	this.shape_537 = new cjs.Shape();
	this.shape_537.graphics.f("#D6D8D8").s().p("AACgTIABAAIABgCIARAhIgpAKg");
	this.shape_537.setTransform(57.2838,48.0398,1.0844,1.0844);

	this.shape_538 = new cjs.Shape();
	this.shape_538.graphics.f("#D6D8D8").s().p("AgFgIIABgCIAKAVg");
	this.shape_538.setTransform(36.7354,-3.0874,1.0844,1.0844);

	this.shape_539 = new cjs.Shape();
	this.shape_539.graphics.f("#D6D8D8").s().p("AgFgHIABgDIAKAVg");
	this.shape_539.setTransform(36.7625,-27.919,1.0844,1.0844);

	this.shape_540 = new cjs.Shape();
	this.shape_540.graphics.f("#D6D8D8").s().p("AABgJIAAAAIACgCIAIAPIgVAIg");
	this.shape_540.setTransform(64.5761,46.9554,1.0844,1.0844);

	this.shape_541 = new cjs.Shape();
	this.shape_541.graphics.f("#D6D8D8").s().p("AgHgKIABgEIAOAdg");
	this.shape_541.setTransform(47.7145,-21.2231,1.0844,1.0844);

	this.shape_542 = new cjs.Shape();
	this.shape_542.graphics.f("#D6D8D8").s().p("AgIgKIADgDIANAcg");
	this.shape_542.setTransform(26.2172,3.6356,1.0844,1.0844);

	this.shape_543 = new cjs.Shape();
	this.shape_543.graphics.f("#D6D8D8").s().p("AgFgHIABgDIAKAVg");
	this.shape_543.setTransform(51.0759,-27.919,1.0844,1.0844);

	this.shape_544 = new cjs.Shape();
	this.shape_544.graphics.f("#D6D8D8").s().p("AgHgLIACgCIAOAcg");
	this.shape_544.setTransform(62.055,40.9373,1.0844,1.0844);

	this.shape_545 = new cjs.Shape();
	this.shape_545.graphics.f("#D6D8D8").s().p("AgHgLIABgCIAOAcg");
	this.shape_545.setTransform(54.8712,40.9373,1.0844,1.0844);

	this.shape_546 = new cjs.Shape();
	this.shape_546.graphics.f("#D6D8D8").s().p("AAAAAIAAgBIABADg");
	this.shape_546.setTransform(64.9556,-16.2893,1.0844,1.0844);

	this.shape_547 = new cjs.Shape();
	this.shape_547.graphics.f("#D6D8D8").s().p("AgFgHIABgDIAKAVg");
	this.shape_547.setTransform(43.9192,-27.919,1.0844,1.0844);

	this.shape_548 = new cjs.Shape();
	this.shape_548.graphics.f("#D6D8D8").s().p("AgHgJIACgEIANAag");
	this.shape_548.setTransform(47.7687,-8.8886,1.0844,1.0844);

	this.shape_549 = new cjs.Shape();
	this.shape_549.graphics.f("#D6D8D8").s().p("AgFgIIABgCIAKAVg");
	this.shape_549.setTransform(51.0759,-3.0874,1.0844,1.0844);

	this.shape_550 = new cjs.Shape();
	this.shape_550.graphics.f("#D6D8D8").s().p("AgIgKIADgEIANAdg");
	this.shape_550.setTransform(26.2172,-21.2231,1.0844,1.0844);

	this.shape_551 = new cjs.Shape();
	this.shape_551.graphics.f("#D6D8D8").s().p("AgHgKIABgDIAOAcg");
	this.shape_551.setTransform(47.7145,3.6356,1.0844,1.0844);

	this.shape_552 = new cjs.Shape();
	this.shape_552.graphics.f("#D6D8D8").s().p("AgHgJIACgEIANAag");
	this.shape_552.setTransform(26.2985,-8.8886,1.0844,1.0844);

	this.shape_553 = new cjs.Shape();
	this.shape_553.graphics.f("#D6D8D8").s().p("AgHgKIABgDIAOAcg");
	this.shape_553.setTransform(40.5577,3.6356,1.0844,1.0844);

	this.shape_554 = new cjs.Shape();
	this.shape_554.graphics.f("#D6D8D8").s().p("AgIgLIADgCIANAcg");
	this.shape_554.setTransform(26.2172,-33.8287,1.0844,1.0844);

	this.shape_555 = new cjs.Shape();
	this.shape_555.graphics.f("#D6D8D8").s().p("AgHgKIACgDIANAbg");
	this.shape_555.setTransform(33.4552,28.4401,1.0844,1.0844);

	this.shape_556 = new cjs.Shape();
	this.shape_556.graphics.f("#D6D8D8").s().p("AgCgDIABgCIAEAKIAAABg");
	this.shape_556.setTransform(65.1183,8.976,1.0844,1.0844);

	this.shape_557 = new cjs.Shape();
	this.shape_557.graphics.f("#D6D8D8").s().p("AgHgKIADgBIAMAXg");
	this.shape_557.setTransform(19.1418,-33.5576,1.0844,1.0844);

	this.shape_558 = new cjs.Shape();
	this.shape_558.graphics.f("#D6D8D8").s().p("AgIgKIACgEIAPAdg");
	this.shape_558.setTransform(19.0605,-21.2231,1.0844,1.0844);

	this.shape_559 = new cjs.Shape();
	this.shape_559.graphics.f("#D6D8D8").s().p("AgHgJIACgEIANAag");
	this.shape_559.setTransform(19.1147,-8.8886,1.0844,1.0844);

	this.shape_560 = new cjs.Shape();
	this.shape_560.graphics.f("#D6D8D8").s().p("AgFgHIABgCIAKATg");
	this.shape_560.setTransform(65.3623,34.1872,1.0844,1.0844);

	this.shape_561 = new cjs.Shape();
	this.shape_561.graphics.f("#D6D8D8").s().p("AgHgJIACgEIANAag");
	this.shape_561.setTransform(69.2659,-8.8886,1.0844,1.0844);

	this.shape_562 = new cjs.Shape();
	this.shape_562.graphics.f("#D6D8D8").s().p("AgHgKIACgDIAOAcg");
	this.shape_562.setTransform(62.055,3.6356,1.0844,1.0844);

	this.shape_563 = new cjs.Shape();
	this.shape_563.graphics.f("#D6D8D8").s().p("AgFgIIABgCIAKAVg");
	this.shape_563.setTransform(43.9192,34.2414,1.0844,1.0844);

	this.shape_564 = new cjs.Shape();
	this.shape_564.graphics.f("#D6D8D8").s().p("AgFgIIABgCIAKAVg");
	this.shape_564.setTransform(22.3949,34.2414,1.0844,1.0844);

	this.shape_565 = new cjs.Shape();
	this.shape_565.graphics.f("#D6D8D8").s().p("AgIgKIACgDIAPAcg");
	this.shape_565.setTransform(19.0605,3.6356,1.0844,1.0844);

	this.shape_566 = new cjs.Shape();
	this.shape_566.graphics.f("#D6D8D8").s().p("AgFgIIABgCIAKAVg");
	this.shape_566.setTransform(15.2382,-3.0874,1.0844,1.0844);

	this.shape_567 = new cjs.Shape();
	this.shape_567.graphics.f("#D6D8D8").s().p("AgHgJIABgEIAOAag");
	this.shape_567.setTransform(62.1092,-8.8886,1.0844,1.0844);

	this.shape_568 = new cjs.Shape();
	this.shape_568.graphics.f("#D6D8D8").s().p("AgHgLIACgCIAOAcg");
	this.shape_568.setTransform(62.055,-33.8287,1.0844,1.0844);

	this.shape_569 = new cjs.Shape();
	this.shape_569.graphics.f("#D6D8D8").s().p("AgFgIIABgCIAKAVg");
	this.shape_569.setTransform(58.2327,34.2414,1.0844,1.0844);

	this.shape_570 = new cjs.Shape();
	this.shape_570.graphics.f("#D6D8D8").s().p("AgHgKIACgEIAOAdg");
	this.shape_570.setTransform(62.055,-21.2231,1.0844,1.0844);

	this.shape_571 = new cjs.Shape();
	this.shape_571.graphics.f("#D6D8D8").s().p("AgFgIIABgCIAKAVg");
	this.shape_571.setTransform(51.0759,34.2414,1.0844,1.0844);

	this.shape_572 = new cjs.Shape();
	this.shape_572.graphics.f("#D6D8D8").s().p("AgHgKIACgDIANAbg");
	this.shape_572.setTransform(26.2985,28.4401,1.0844,1.0844);

	this.shape_573 = new cjs.Shape();
	this.shape_573.graphics.f("#D6D8D8").s().p("AAAABIABgDIAAABIgBAEg");
	this.shape_573.setTransform(17.9761,39.88,1.0844,1.0844);

	this.shape_574 = new cjs.Shape();
	this.shape_574.graphics.f("#D6D8D8").s().p("AgHgKIABgDIAOAbg");
	this.shape_574.setTransform(62.1092,28.4401,1.0844,1.0844);

	this.shape_575 = new cjs.Shape();
	this.shape_575.graphics.f("#D6D8D8").s().p("AgHgKIABgEIAPAdg");
	this.shape_575.setTransform(69.2117,-21.2231,1.0844,1.0844);

	this.shape_576 = new cjs.Shape();
	this.shape_576.graphics.f("#D6D8D8").s().p("AgFgHIABgDIAKAVg");
	this.shape_576.setTransform(65.3894,-27.919,1.0844,1.0844);

	this.shape_577 = new cjs.Shape();
	this.shape_577.graphics.f("#D6D8D8").s().p("AgFgIIABgCIAKAVg");
	this.shape_577.setTransform(58.2327,-3.0874,1.0844,1.0844);

	this.shape_578 = new cjs.Shape();
	this.shape_578.graphics.f("#D6D8D8").s().p("AgGgIIACgDIALAWIAAABg");
	this.shape_578.setTransform(61.8923,15.8617,1.0844,1.0844);

	this.shape_579 = new cjs.Shape();
	this.shape_579.graphics.f("#D6D8D8").s().p("AgFgIIABgCIAKAVg");
	this.shape_579.setTransform(65.3894,-3.0874,1.0844,1.0844);

	this.shape_580 = new cjs.Shape();
	this.shape_580.graphics.f("#D6D8D8").s().p("AgHgKIACgDIANAbg");
	this.shape_580.setTransform(54.8983,16.1328,1.0844,1.0844);

	this.shape_581 = new cjs.Shape();
	this.shape_581.graphics.f("#D6D8D8").s().p("AgHgKIABgDIAOAbg");
	this.shape_581.setTransform(47.7416,16.1328,1.0844,1.0844);

	this.shape_582 = new cjs.Shape();
	this.shape_582.graphics.f("#D6D8D8").s().p("AgFgIIABgCIAKAVg");
	this.shape_582.setTransform(22.3949,-3.0874,1.0844,1.0844);

	this.shape_583 = new cjs.Shape();
	this.shape_583.graphics.f("#D6D8D8").s().p("AgDgFIABgCIAHAPg");
	this.shape_583.setTransform(58.0971,9.1929,1.0844,1.0844);

	this.shape_584 = new cjs.Shape();
	this.shape_584.graphics.f("#D6D8D8").s().p("AgFgHIABgDIAKAVg");
	this.shape_584.setTransform(15.2382,-27.919,1.0844,1.0844);

	this.shape_585 = new cjs.Shape();
	this.shape_585.graphics.f("#D6D8D8").s().p("AgFgHIABgDIAKAVg");
	this.shape_585.setTransform(58.2327,-27.919,1.0844,1.0844);

	this.shape_586 = new cjs.Shape();
	this.shape_586.graphics.f("#D6D8D8").s().p("AgHgKIACgDIANAbg");
	this.shape_586.setTransform(40.5577,16.1328,1.0844,1.0844);

	this.shape_587 = new cjs.Shape();
	this.shape_587.graphics.f("#D6D8D8").s().p("AgHgKIACgDIANAbg");
	this.shape_587.setTransform(40.612,28.4401,1.0844,1.0844);

	this.shape_588 = new cjs.Shape();
	this.shape_588.graphics.f("#D6D8D8").s().p("AgHgKIACgDIANAbg");
	this.shape_588.setTransform(47.7687,28.4401,1.0844,1.0844);

	this.shape_589 = new cjs.Shape();
	this.shape_589.graphics.f("#D6D8D8").s().p("AgHgKIACgDIANAbg");
	this.shape_589.setTransform(33.401,16.1328,1.0844,1.0844);

	this.shape_590 = new cjs.Shape();
	this.shape_590.graphics.f("#D6D8D8").s().p("AgFgHIABgDIAKAVg");
	this.shape_590.setTransform(22.3949,-27.919,1.0844,1.0844);

	this.shape_591 = new cjs.Shape();
	this.shape_591.graphics.f("#D6D8D8").s().p("AgHgKIACgDIANAbg");
	this.shape_591.setTransform(54.9254,28.4401,1.0844,1.0844);

	this.shape_592 = new cjs.Shape();
	this.shape_592.graphics.f("#2F2F35").s().p("ACBLIIg/gJIgIlwQgJl2gFgkIgglJQg5GXAAAPIgrKwIjFAAIANorIAOlSIAyoOQA0AiDLgKQBmgFBcgMIAZCtQAEApAIBZQAIBsAAAkQAAAigLHHIgLHBIguAcQgOAHggAAQgSAAgZgCg");
	this.shape_592.setTransform(40.1782,122.3095,1.0844,1.0844);

	this.shape_593 = new cjs.Shape();
	this.shape_593.graphics.f("#00001F").s().p("AArBDIhwgiQhBADgIgGQgFgEgBgdIAAgcIAMgdICUgGIAQAkIAhASQAlASASAIQAjAQgDAXQgBAOgEAAg");
	this.shape_593.setTransform(65.8594,204.5929,1.0844,1.0844);

	this.shape_594 = new cjs.Shape();
	this.shape_594.graphics.f("#00001F").s().p("AhCBNQgPgNgHgUQgHgTAYglIAagjIAJgmIB/AAIAABcQAAAXgEAFQgJASghARQgZANADACIhMACQgGgDgHgHg");
	this.shape_594.setTransform(17.2412,207.2224,1.0844,1.0844);

	this.instance = new lib.Cuadro_2();
	this.instance.parent = this;
	this.instance.setTransform(-221.6,-91.2,0.5427,0.5427,0,0,0,54.8,54.9);

	this.instance_1 = new lib.Mueble_4();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-83.05,44.65,1,1,0,0,0,201.7,118.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance},{t:this.shape_594},{t:this.shape_593},{t:this.shape_592},{t:this.shape_591},{t:this.shape_590},{t:this.shape_589},{t:this.shape_588},{t:this.shape_587},{t:this.shape_586},{t:this.shape_585},{t:this.shape_584},{t:this.shape_583},{t:this.shape_582},{t:this.shape_581},{t:this.shape_580},{t:this.shape_579},{t:this.shape_578},{t:this.shape_577},{t:this.shape_576},{t:this.shape_575},{t:this.shape_574},{t:this.shape_573},{t:this.shape_572},{t:this.shape_571},{t:this.shape_570},{t:this.shape_569},{t:this.shape_568},{t:this.shape_567},{t:this.shape_566},{t:this.shape_565},{t:this.shape_564},{t:this.shape_563},{t:this.shape_562},{t:this.shape_561},{t:this.shape_560},{t:this.shape_559},{t:this.shape_558},{t:this.shape_557},{t:this.shape_556},{t:this.shape_555},{t:this.shape_554},{t:this.shape_553},{t:this.shape_552},{t:this.shape_551},{t:this.shape_550},{t:this.shape_549},{t:this.shape_548},{t:this.shape_547},{t:this.shape_546},{t:this.shape_545},{t:this.shape_544},{t:this.shape_543},{t:this.shape_542},{t:this.shape_541},{t:this.shape_540},{t:this.shape_539},{t:this.shape_538},{t:this.shape_537},{t:this.shape_536},{t:this.shape_535},{t:this.shape_534},{t:this.shape_533},{t:this.shape_532},{t:this.shape_531},{t:this.shape_530},{t:this.shape_529},{t:this.shape_528},{t:this.shape_527},{t:this.shape_526},{t:this.shape_525},{t:this.shape_524},{t:this.shape_523},{t:this.shape_522},{t:this.shape_521},{t:this.shape_520},{t:this.shape_519},{t:this.shape_518},{t:this.shape_517},{t:this.shape_516},{t:this.shape_515},{t:this.shape_514},{t:this.shape_513},{t:this.shape_512},{t:this.shape_511},{t:this.shape_510},{t:this.shape_509},{t:this.shape_508},{t:this.shape_507},{t:this.shape_506},{t:this.shape_505},{t:this.shape_504},{t:this.shape_503},{t:this.shape_502},{t:this.shape_501},{t:this.shape_500},{t:this.shape_499},{t:this.shape_498},{t:this.shape_497},{t:this.shape_496},{t:this.shape_495},{t:this.shape_494},{t:this.shape_493},{t:this.shape_492},{t:this.shape_491},{t:this.shape_490},{t:this.shape_489},{t:this.shape_488},{t:this.shape_487},{t:this.shape_486},{t:this.shape_485},{t:this.shape_484},{t:this.shape_483},{t:this.shape_482},{t:this.shape_481},{t:this.shape_480},{t:this.shape_479},{t:this.shape_478},{t:this.shape_477},{t:this.shape_476},{t:this.shape_475},{t:this.shape_474},{t:this.shape_473},{t:this.shape_472},{t:this.shape_471},{t:this.shape_470},{t:this.shape_469},{t:this.shape_468},{t:this.shape_467},{t:this.shape_466},{t:this.shape_465},{t:this.shape_464},{t:this.shape_463},{t:this.shape_462},{t:this.shape_461},{t:this.shape_460},{t:this.shape_459},{t:this.shape_458},{t:this.shape_457},{t:this.shape_456},{t:this.shape_455},{t:this.shape_454},{t:this.shape_453},{t:this.shape_452},{t:this.shape_451},{t:this.shape_450},{t:this.shape_449},{t:this.shape_448},{t:this.shape_447},{t:this.shape_446},{t:this.shape_445},{t:this.shape_444},{t:this.shape_443},{t:this.shape_442},{t:this.shape_441},{t:this.shape_440},{t:this.shape_439},{t:this.shape_438},{t:this.shape_437},{t:this.shape_436},{t:this.shape_435},{t:this.shape_434},{t:this.shape_433},{t:this.shape_432},{t:this.shape_431},{t:this.shape_430},{t:this.shape_429},{t:this.shape_428},{t:this.shape_427},{t:this.shape_426},{t:this.shape_425},{t:this.shape_424},{t:this.shape_423},{t:this.shape_422},{t:this.shape_421},{t:this.shape_420},{t:this.shape_419},{t:this.shape_418},{t:this.shape_417},{t:this.shape_416},{t:this.shape_415},{t:this.shape_414},{t:this.shape_413},{t:this.shape_412},{t:this.shape_411},{t:this.shape_410},{t:this.shape_409},{t:this.shape_408},{t:this.shape_407},{t:this.shape_406},{t:this.shape_405},{t:this.shape_404},{t:this.shape_403},{t:this.shape_402},{t:this.shape_401},{t:this.shape_400},{t:this.shape_399},{t:this.shape_398},{t:this.shape_397},{t:this.shape_396},{t:this.shape_395},{t:this.shape_394},{t:this.shape_393},{t:this.shape_392},{t:this.shape_391},{t:this.shape_390},{t:this.shape_389},{t:this.shape_388},{t:this.shape_387},{t:this.shape_386},{t:this.shape_385},{t:this.shape_384},{t:this.shape_383},{t:this.shape_382},{t:this.shape_381},{t:this.shape_380},{t:this.shape_379},{t:this.shape_378},{t:this.shape_377},{t:this.shape_376},{t:this.shape_375},{t:this.shape_374},{t:this.shape_373},{t:this.shape_372},{t:this.shape_371},{t:this.shape_370},{t:this.shape_369},{t:this.shape_368},{t:this.shape_367},{t:this.shape_366},{t:this.shape_365},{t:this.shape_364},{t:this.shape_363},{t:this.shape_362},{t:this.shape_361},{t:this.shape_360},{t:this.shape_359},{t:this.shape_358},{t:this.shape_357},{t:this.shape_356},{t:this.shape_355},{t:this.shape_354},{t:this.shape_353},{t:this.shape_352},{t:this.shape_351},{t:this.shape_350},{t:this.shape_349},{t:this.shape_348},{t:this.shape_347},{t:this.shape_346},{t:this.shape_345},{t:this.shape_344},{t:this.shape_343},{t:this.shape_342},{t:this.shape_341},{t:this.shape_340},{t:this.shape_339},{t:this.shape_338},{t:this.shape_337},{t:this.shape_336},{t:this.shape_335},{t:this.shape_334},{t:this.shape_333},{t:this.shape_332},{t:this.shape_331},{t:this.shape_330},{t:this.shape_329},{t:this.shape_328},{t:this.shape_327},{t:this.shape_326},{t:this.shape_325},{t:this.shape_324},{t:this.shape_323},{t:this.shape_322},{t:this.shape_321},{t:this.shape_320},{t:this.shape_319},{t:this.shape_318},{t:this.shape_317},{t:this.shape_316},{t:this.shape_315},{t:this.shape_314},{t:this.shape_313},{t:this.shape_312},{t:this.shape_311},{t:this.shape_310},{t:this.shape_309},{t:this.shape_308},{t:this.shape_307},{t:this.shape_306},{t:this.shape_305},{t:this.shape_304},{t:this.shape_303},{t:this.shape_302},{t:this.shape_301},{t:this.shape_300},{t:this.shape_299},{t:this.shape_298},{t:this.shape_297},{t:this.shape_296},{t:this.shape_295},{t:this.shape_294},{t:this.shape_293},{t:this.shape_292},{t:this.shape_291},{t:this.shape_290},{t:this.shape_289},{t:this.shape_288},{t:this.shape_287},{t:this.shape_286},{t:this.shape_285},{t:this.shape_284},{t:this.shape_283},{t:this.shape_282},{t:this.shape_281},{t:this.shape_280},{t:this.shape_279},{t:this.shape_278},{t:this.shape_277},{t:this.shape_276},{t:this.shape_275},{t:this.shape_274},{t:this.shape_273},{t:this.shape_272},{t:this.shape_271},{t:this.shape_270},{t:this.shape_269},{t:this.shape_268},{t:this.shape_267},{t:this.shape_266},{t:this.shape_265},{t:this.shape_264},{t:this.shape_263},{t:this.shape_262},{t:this.shape_261},{t:this.shape_260},{t:this.shape_259},{t:this.shape_258},{t:this.shape_257},{t:this.shape_256},{t:this.shape_255},{t:this.shape_254},{t:this.shape_253},{t:this.shape_252},{t:this.shape_251},{t:this.shape_250},{t:this.shape_249},{t:this.shape_248},{t:this.shape_247},{t:this.shape_246},{t:this.shape_245},{t:this.shape_244},{t:this.shape_243},{t:this.shape_242},{t:this.shape_241},{t:this.shape_240},{t:this.shape_239},{t:this.shape_238},{t:this.shape_237},{t:this.shape_236},{t:this.shape_235},{t:this.shape_234},{t:this.shape_233},{t:this.shape_232},{t:this.shape_231},{t:this.shape_230},{t:this.shape_229},{t:this.shape_228},{t:this.shape_227},{t:this.shape_226},{t:this.shape_225},{t:this.shape_224},{t:this.shape_223},{t:this.shape_222},{t:this.shape_221},{t:this.shape_220},{t:this.shape_219},{t:this.shape_218},{t:this.shape_217},{t:this.shape_216},{t:this.shape_215},{t:this.shape_214},{t:this.shape_213},{t:this.shape_212},{t:this.shape_211},{t:this.shape_210},{t:this.shape_209},{t:this.shape_208},{t:this.shape_207},{t:this.shape_206},{t:this.shape_205},{t:this.shape_204},{t:this.shape_203},{t:this.shape_202},{t:this.shape_201},{t:this.shape_200},{t:this.shape_199},{t:this.shape_198},{t:this.shape_197},{t:this.shape_196},{t:this.shape_195},{t:this.shape_194},{t:this.shape_193},{t:this.shape_192},{t:this.shape_191},{t:this.shape_190},{t:this.shape_189},{t:this.shape_188},{t:this.shape_187},{t:this.shape_186},{t:this.shape_185},{t:this.shape_184},{t:this.shape_183},{t:this.shape_182},{t:this.shape_181},{t:this.shape_180},{t:this.shape_179},{t:this.shape_178},{t:this.shape_177},{t:this.shape_176},{t:this.shape_175},{t:this.shape_174},{t:this.shape_173},{t:this.shape_172},{t:this.shape_171},{t:this.shape_170},{t:this.shape_169},{t:this.shape_168},{t:this.shape_167},{t:this.shape_166},{t:this.shape_165},{t:this.shape_164},{t:this.shape_163},{t:this.shape_162},{t:this.shape_161},{t:this.shape_160},{t:this.shape_159},{t:this.shape_158},{t:this.shape_157},{t:this.shape_156},{t:this.shape_155},{t:this.shape_154},{t:this.shape_153},{t:this.shape_152},{t:this.shape_151},{t:this.shape_150},{t:this.shape_149},{t:this.shape_148},{t:this.shape_147},{t:this.shape_146},{t:this.shape_145},{t:this.shape_144},{t:this.shape_143},{t:this.shape_142},{t:this.shape_141},{t:this.shape_140},{t:this.shape_139},{t:this.shape_138},{t:this.shape_137},{t:this.shape_136},{t:this.shape_135},{t:this.shape_134},{t:this.shape_133},{t:this.shape_132},{t:this.shape_131},{t:this.shape_130},{t:this.shape_129},{t:this.shape_128},{t:this.shape_127},{t:this.shape_126},{t:this.shape_125},{t:this.shape_124},{t:this.shape_123},{t:this.shape_122},{t:this.shape_121},{t:this.shape_120},{t:this.shape_119},{t:this.shape_118},{t:this.shape_117},{t:this.shape_116},{t:this.shape_115},{t:this.shape_114},{t:this.shape_113},{t:this.shape_112},{t:this.shape_111},{t:this.shape_110},{t:this.shape_109},{t:this.shape_108},{t:this.shape_107},{t:this.shape_106},{t:this.shape_105},{t:this.shape_104},{t:this.shape_103},{t:this.shape_102},{t:this.shape_101},{t:this.shape_100},{t:this.shape_99},{t:this.shape_98},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_94},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-284.7,-121,403.29999999999995,342.6);


(lib.personaje2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.Postit();
	this.instance.parent = this;
	this.instance.setTransform(210.85,23.65,0.911,0.911,0,0,0,7.2,9.5);

	this.instance_1 = new lib.Postit();
	this.instance_1.parent = this;
	this.instance_1.setTransform(192.8,23.65,0.911,0.911,0,0,0,7.2,9.5);

	this.instance_2 = new lib.Postit();
	this.instance_2.parent = this;
	this.instance_2.setTransform(373.7,46.75,0.911,0.911,0,0,0,7.2,9.4);

	this.instance_3 = new lib.Postits();
	this.instance_3.parent = this;
	this.instance_3.setTransform(335.05,93.6,0.911,0.911,0,0,0,36.7,9.5);

	this.instance_4 = new lib.Mesa_1();
	this.instance_4.parent = this;
	this.instance_4.setTransform(275.5,151.75,0.911,0.911,0,0,0,154,80.2);

	this.instance_5 = new lib.Telefono();
	this.instance_5.parent = this;
	this.instance_5.setTransform(367.3,57.95,0.911,0.911,0,0,0,27.9,22.4);

	this.instance_6 = new lib.Computadora_por_atras();
	this.instance_6.parent = this;
	this.instance_6.setTransform(223.4,40.2,0.911,0.911,0,0,0,53,42);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#A9B1BA").s().p("AgbAGIAugaIAKAUQgCANgcAIg");
	this.shape.setTransform(262.6368,0.9341,2.2519,2.2519);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#A9B1BA").s().p("AgdgDIAKgUIAxAhIgXAOQgigPgCgMg");
	this.shape_1.setTransform(249.5759,0.2022,2.2519,2.2519);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#3F3231").s().p("AhaBDIgHgCQgEACgIgyQgDgZAVgQQgDghAegOIgFAHQgFAJgCAGIABABIABAAQALgMATgJQAegOAqgBQgPACgMAHQAAAAAAAAQAAAAAAAAQAAABAAAAQAAAAAAAAQAAABAAAAQAAAAAAAAQABAAAAAAQAAAAAAAAQA0gFAeATQgFgBgHAAIgBACQAnAQAAAjIgJgLQAAgBgBAAQAAAAAAAAQgBAAAAABQABAAAAABQAGAQgFAQQAAgFgGgFQgBAagHAhQgHgBgFAIIgEAJQADgvgLgSQgTgcg0ABIgxAGQgKAWgMAOIgCAeIgBAZQgBgNgHgFg");
	this.shape_2.setTransform(256.7256,-54.0117,2.2519,2.2519);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#3F3231").s().p("AAYAPQgNgCAAgLIAAgBQgFgCgEAAIgBAAQgDAAgFACIAAABQAAALgMACIgnAAIgBAAQgLgFAAgIIAAgCIgLABIgCgHIAOgCQADgFAJgBIAkAAQAKgBAEAIQAGgCADAAQAEAAAGACQAEgIAKABIAkAAQAJABADAFIAKABIgBAFIgIACIAAACQAAAIgLAFIgCAAgAARgHIAAALQAAAFAGACIApAAQAFABAAgIIAAgKQgBgEgFAAIgpAAQgFABAAACgAhAgHIAAALQAAAFAGACIApAAQAFABAAgIIAAgKQgBgEgFAAIgpAAQgFABAAACg");
	this.shape_3.setTransform(254.9241,-39.3182,2.2519,2.2519);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#3F3231").s().p("AAFgCQgVAGgFgFIASgEIALAAQANABABAKQgGgMgLAEg");
	this.shape_4.setTransform(264.669,-44.4473,2.2518,2.2518,-14.9977);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#3F3231").s().p("AgHgFQgPgKgTALIgOAKQAKgZAfAEQAQACANAGQAjAQAGAFQgFADgIAAQgTAAgfgWg");
	this.shape_5.setTransform(245.7547,-44.0167,0.9109,0.9109);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#E8AE91").s().p("AAMAAIgIgBIgDAAIgKABIgLADIAKgFIALgCIADAAIADABIAGABQAGADACAEQgEgEgFgBg");
	this.shape_6.setTransform(246.0292,-41.176,2.2519,2.2519);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#E8AE91").s().p("AgOAEIgGgEIgBAAIABAAQAKgGALgBQAPAAAFAIIABAAIgBABQgDACgHACIgHABIgDAAQgHAAgIgDgAgSAAQAJAHANgBIAGgBQAHgCADgCQgHgGgMAAQgKABgJAEg");
	this.shape_7.setTransform(246.1418,-40.4442,2.2519,2.2519);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#3F3231").s().p("AgFAAQAAgFAFAAQAGAAAAAFQAAAGgGAAQgFAAAAgGg");
	this.shape_8.setTransform(264.6072,-40.4442,2.2519,2.2519);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#3F3231").s().p("AgFAAQAAgFAFAAQAGAAAAAFQAAAGgGAAQgFAAAAgGg");
	this.shape_9.setTransform(246.367,-40.4442,2.2519,2.2519);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AABAHQgIgBgHgDIgGgDIAIgDQAJgDAEABIAJABQAJACACAEQgMAFgHAAIgBAAg");
	this.shape_10.setTransform(246.1418,-40.4672,2.2519,2.2519);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#E8AE91").s().p("AgMgCIAGgBIADgBIADAAIALACIAKAFIgLgDIgKgBIgDAAIgIABQgFABgEAEQACgEAGgDg");
	this.shape_11.setTransform(264.8324,-41.176,2.2519,2.2519);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#E8AE91").s().p("AgDAHIgHgBQgHgCgDgCIgBgBIABAAQAAgBAEgCQAGgFAKAAIAGABQAJACAGAEIABAAIgBAAQgJAHgMAAgAgTABQAFADALACQANABAJgHQgGgDgIgBIgFgBQgMAAgHAGg");
	this.shape_12.setTransform(264.7198,-40.4442,2.2519,2.2519);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgMAFIgIgDQADgEAJgCIAIgBQAHgCAOAHQgHAGgOABIgCAAQgEAAgGgCg");
	this.shape_13.setTransform(264.7198,-40.4646,2.2519,2.2519);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#E6A57F").s().p("AgNAEIABgBQACACAFgCQAAAAAAgBQAAgBABAAQAAAAABgBQAAAAABAAIACAAQAJABADgCQAAgBAAAAQAAAAAAgBQAAAAAAgBQAAAAAAgBIACAAQABACgCADQgDADgKgBIAAAAQgDAAgBACIAAABIgFABQgBAAAAAAQgBAAAAAAQgBgBAAAAQgBAAAAgBg");
	this.shape_14.setTransform(257.7765,-28.7907,2.2519,2.2519);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#E6A57F").s().p("AAFAFIAAgBIAAAAQgBAAAAgBQAAAAAAgBQgBAAAAAAQAAAAgBAAIgCAAQgJABgDgDIgBgFIACAAIAAAEQADACAIgBIACAAQAEAAAAADQAFACACgCIABABQgBABAAAAQgBAAAAABQgBAAAAAAQgBAAAAAAIgFgBg");
	this.shape_15.setTransform(253.4604,-28.7907,2.2519,2.2519);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#E6A37E").s().p("AgXAAIgGgFIA7AAQgCADgFACQgJAGgOAAQgNAAgKgGg");
	this.shape_16.setTransform(255.5997,-21.7536,2.2519,2.2519);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#E19D7A").s().p("AAAADQgOACgPgEIAUgEIACACQADABAEAAQAHAAADgDIAUAEQgJACgMABg");
	this.shape_17.setTransform(255.5997,-23.3299,2.2519,2.2519);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#E2BD90").s().p("AgEgMQAEgIAEABQABAAAAAAQABAAAAABQABAAAAAAQABABAAAAQACARgJALIgIAJg");
	this.shape_18.setTransform(275.7949,-32.5096,2.2519,2.2519);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#E2BD90").s().p("AAAALQgJgLACgRIAEgCQAEgBAEAIIADAgQgFgDgDgGg");
	this.shape_19.setTransform(235.6296,-32.5096,2.2519,2.2519);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#E2BD90").s().p("AgdB1QghgWgSgmQgFgDgEgGQgJgNACgQIAEgDQAFAAAEAHQgGgSgDgVQgGgvASgWIATgUQAagWAfgDIAJAAQAfADAaAWQAMAKAHAKQASAWgGAvQgDAVgGASQAEgHAFAAQABAAAAAAQABABABAAQAAAAAAABQABAAAAABQACAQgJANIgJAJQgTAmghAWIgdAOQgMgDgRgLg");
	this.shape_20.setTransform(255.7123,-40.7819,2.2519,2.2519);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#D7AD85").s().p("AgHArQg+gCAPgQQAOgNAGgZIAEgWIAegGQAdgFABALQABASAbA7IgmABIgbAAg");
	this.shape_21.setTransform(256.0411,-7.4212,2.2519,2.2519);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#A9B3BC").s().p("AkxE9IgCglIG3g8IhongICZh9QAeArAfBbQA+C2ACD1QAHBYgfAqQgcAlhJAOQguAIiGAEQicAHhlAKQgngbgKgqg");
	this.shape_22.setTransform(239.9556,42.8979,1.0173,1.0173,0,0.4606,-179.5394);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#D6D8D8").s().p("Ai4I1QiAgfgBgOQgDgnAPhmIAQh1QADhFAHgnQACgNgGgSQhCi+goiqQg8j/AzgcQA/gkCsgYQBWgMBJgFICfARQCtAYA/AkQAyAcg7D/QgoCnhCDBQgGASACANQAHAnADBFIAQB1QAPBmgDAnQgBANiHAgQiDAeg2ADQg2gDh7geg");
	this.shape_23.setTransform(254.9379,45.0346,0.8145,0.8145);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#CCD1D0").s().p("ABvEvQgqgBiTg+IiLg+QACgQAAgZQAAgygKgxQgShbAtgRQAXgJAbAKIAWANQAaAQAUAQQAzApA3BHQAuA6ABAAIkxmLICXg1IEqGfQASAegCAvQgCAhgKAjQgHAXgXAHQg0APgbAAIgBAAg");
	this.shape_24.setTransform(304.5775,10.906,0.9109,0.9109);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#1D2024").s().p("AgJADQgBgBAAAAQAAAAABAAQAAgBAAAAQAAAAABAAIARgEIACABIgBACIgSADIgBABIAAgBg");
	this.shape_25.setTransform(286.6869,-45.5269,0.9109,0.9109);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#515356").s().p("AgKADIACgCIARgDIACAAIgBACIgSAEQAAAAgBAAQAAgBAAAAQAAAAAAAAQgBAAAAAAg");
	this.shape_26.setTransform(286.6926,-45.5071,0.9109,0.9109);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#1D2024").s().p("AgNgBIAYgHIADAKIgYAHg");
	this.shape_27.setTransform(290.7459,-30.0149,0.9109,0.9109);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#A5A8A2").s().p("AgsAWQAAgMAGgJQASgfBBgBIhYA/IgBgKg");
	this.shape_28.setTransform(192.0842,17.1405,2.2519,2.2519);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#A9B1BA").s().p("AgbAGIAugaIAKAUQgCANgcAIg");
	this.shape_29.setTransform(262.7368,1.8841,2.2519,2.2519);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#A9B1BA").s().p("AgdgDIAKgUIAxAhIgXAOQgigPgCgMg");
	this.shape_30.setTransform(249.6759,1.1522,2.2519,2.2519);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#4D4E4E").s().p("AAFAfQgcgRgPgCQgOgBgNgFQgOgFAAgEIgDggIBJAAQBXAoAEAKQAGAPgbAEQgRACgNAAQgSAAgIgFg");
	this.shape_31.setTransform(292.0777,203.3688,2.2519,2.2519);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#70767C").s().p("AA/D1Ig1l9IgHgYIAEAZIhygDIgfhnIDigDIAWAjQAOAXAGAuQADAaADAxIADE2g");
	this.shape_32.setTransform(258.2331,136.0959,2.2519,2.2519);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#70767C").s().p("AiKD2IADk3QAEgxACgZQAGgvAOgXIAWgkIDiAEIgfBoIhyACIAEgZIgHAYIg1F+g");
	this.shape_33.setTransform(247.3115,136.0396,2.2519,2.2519);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#121112").s().p("AgiARIAAgvIBFAAIgFAvQgUAPgPAAQgRAAgMgPg");
	this.shape_34.setTransform(224.3986,189.1839,2.2519,2.2519);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#4D4E4E").s().p("Ag8AhQgMgBgGgGQgFgFADgGQAEgKBWgoIBJAAIgDAgQAAAEgOAFQgMAEgPACQgTADgYAQQgIAFgRAAQgNAAgSgDg");
	this.shape_35.setTransform(213.9696,201.2395,2.2519,2.2519);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#121112").s().p("AgbAXIgIg6IBEAAIAEA6QgMANgQAAQgPAAgVgNg");
	this.shape_36.setTransform(280.977,190.1973,2.2519,2.2519);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#E2BD90").s().p("AgECPIhDh3QgBgSgDgXIgGgeIgBgJQAFgYAAgKQAAgOABgJQgCgNABgIIABAAQAAAAAAgBQAAAAABAAQAAAAAAAAQABAAAAAAQAJgCAFAHQAFAHADAQIABAQIACAVIABAEQADALAFADIAEACQADgBAEgFIBbgoIgBgBIgFgTIgBgBQgCgCgBgNIAAgDQABgGAGgBQADgBADABQACAAAEADIAEAIIACAIQADARADAyQACAUgPAeIgSAhQgDAKAOAoQANAkgDACQgFADgiAOQgdAMgHAAQAAAAgBAAQAAAAAAAAQgBgBAAAAQAAAAAAAAg");
	this.shape_37.setTransform(287.4416,-18.9939,0.9108,0.9108,-29.9931);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#1D2024").s().p("AgXBtQgGgDgCgHIguipQgCgGAEgGQADgFAHgCIBNgUQAHgCAGADQAFADACAGIAuCqQACAGgEAFQgDAGgHACIhNAUIgFABQgEAAgDgCg");
	this.shape_38.setTransform(278.9985,-30.9373,0.9108,0.9108,-29.9931);

	this.instance_7 = new lib.Silla_de_frente();
	this.instance_7.parent = this;
	this.instance_7.setTransform(252.3,75.5,0.911,0.911,0,0,0,73.5,132.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_7},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(135.2,-73.2,280.5,298.1);


(lib.MUJER1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.brazo_1();
	this.instance.parent = this;
	this.instance.setTransform(37.15,104,2.8153,2.8153,0,0,0,7.7,9.2);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FDD5B7").s().p("AgyAWIAcgVIAFgHQAEgHADgCIAPgJIAFgHQABgBABAAQAAgBABAAQAAAAAAAAQABAAAAABQABAFgFAGIgFAEQgBAAAAABQgBAAAAABQAAAAAAAAQAAABAAAAQABABATgCIAaAAQAEACgDAIQgDAHgLAHQgCACgKACIgMADIgWAAQgFAAgNAJIgMAJg");
	this.shape.setTransform(64.2112,105.1022,2.8153,2.8153);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#231F20").s().p("AAAAAQgDAAgIADQAFgFAHAAQAHAAAEAFQgFgDgHAAg");
	this.shape_1.setTransform(47.3498,28.5866,2.8153,2.8153);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#231F20").s().p("AAGAAIgEgBIgEABIgHACIgDAAIgCgCIANgDQALgDAFALg");
	this.shape_2.setTransform(47.2794,30.2694,2.8153,2.8153);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAAAAIAAAAIABAAIgBABg");
	this.shape_3.setTransform(49.5316,30.3512,2.8153,2.8153);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#797C7E").s().p("AAAAFIgBAAQgEgBABgEIAAgDIABgBIACAAQAEgBACAEQAAADgCACIgDABIAAAAg");
	this.shape_4.setTransform(49.0108,30.7177,2.8153,2.8153);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgGAEQgCAAgEgEIAFgCIAAgBIAEgBIAEgBIAEACIAEADIAEADIgCAAQgDACgIAAg");
	this.shape_5.setTransform(47.772,30.8438,2.8153,2.8153);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#3D261E").s().p("AgKAFIAHgVQALALADAMQABAGgBAEg");
	this.shape_6.setTransform(48.5322,13.3187,2.8153,2.8153);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#E84E4D").s().p("AgEAAIgEgFIAPAEIABABIAAADIgBADQgHgBgEgFg");
	this.shape_7.setTransform(50.2706,47.1725,2.8153,2.8153);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#EE5C5E").s().p("AgJAAIAEAAIAGgDIAFAAQAEABAAABQAAABgEAEg");
	this.shape_8.setTransform(50.6577,45.4833,2.8153,2.8153);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#231F20").s().p("AABgCQAHAAAEAFQgGgEgGABQgEAAgHADQAFgFAHAAg");
	this.shape_9.setTransform(47.2794,28.5212,2.8153,2.8153);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#3D261E").s().p("AABgEIAMADIADABQAAAAABAAQAAABAAAAQABAAAAABQAAAAgBABQAAAAAAABQgBAAAAAAQgBAAAAAAQgBAAAAAAIgKgEQgLgFgIAIIgCACQAHgLALACg");
	this.shape_10.setTransform(46.475,25.1012,2.8153,2.8153);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#3D261E").s().p("AANBnQhJgKgMgbQgPggAEgpQAEgsAWgcQASgXAhgFQAhgFAiARQAaAOgDACIgSBRQgMBWAeAVQgiAAglgGg");
	this.shape_11.setTransform(23.8217,30.6135,2.8153,2.8153);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#F8B796").s().p("AgiBsQgEgegJgVQgKgCgKgMQgVgZACg1QACg2AqgSQAVgJAVACIAeAHQAgAMAIAfIABAyIACALQAEAMAJAHQACAGgEADQgDABgFABQgBAAAAAAQgBAAAAAAQgBAAAAAAQAAABAAAAQAAAHADADQADADgHAEQAEADgDAFIgEAEIABAHQABAGgBACQgGAIgJAAIgVgEQgOgDgDAEQgDAFgCAOQgDAMAAAHg");
	this.shape_12.setTransform(31.8569,33.9598,2.8153,2.8153);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#EAA483").s().p("AAAAIQgGgIACgLIACgCQADAAADAFIACAWQgEgCgCgEg");
	this.shape_13.setTransform(26.1226,43.0141,2.8153,2.8153);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#7F171B").s().p("AgiAqIgCgGQgOgyAWgcQAUgbAaAcQAWAXACAlQAAATgDAPQgZgJgZAFIgWAHQABgGgCgIg");
	this.shape_14.setTransform(25.7483,84.809,2.8153,2.8153);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#D6A491").s().p("AACAUIgBgCIAAAAIAAAAIgBgEIAAgBIgCgCQgGgHgBgEIgBgHIABgEIABgDQACgDAEgCQACgBAEABQAEABACAEIAAAHQAAgEgBgDQgCgDgDgBQgEgBgBACIgFAEQgCADAAADIABAHQACAGAEAEIACAEIABAEIAAAAIACACg");
	this.shape_15.setTransform(28.5812,45.5185,2.8153,2.8153);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#7F171B").s().p("AgbCoIgngPQAXhUgMg0QgSgzgEglQgGguAOgfIAOgVQAbgIAXALQALAFAGAHIAwBDQAXAggDAWQgCAPgRAkQgJAdADA+QABAfAEAZQgXAIgZAAQgSAAgVgFg");
	this.shape_16.setTransform(35.2962,112.6805,2.8153,2.8153);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#10121D").s().p("AgmABQAYgCAhgBIAUABIgBABQgvAAgcADQgBAAAAAAQAAAAAAAAQAAgBAAAAQAAAAAAgBg");
	this.shape_17.setTransform(48.6635,172.8042,2.8153,2.8153);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#00011E").s().p("AiDBNQgrgFAMhGIAUhDIAFgDQAFgCAIgCQArgJAOAAQATAAATALIAIAaIAJAoIAyACQBIAEASADQAhAGAEAPQADAJgKAWIAAABQgFAJg0AHIg0AFQgxADgoAAQg1AAgmgFg");
	this.shape_18.setTransform(57.7767,173.2711,2.8153,2.8153);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#7F171B").s().p("AAEAmQgGgGgGgPQgDgIgGgIQgGgFgDAAQgGAAADASIAFAYIgGABQgFgfgIgMQgGgKACgMQAEgKgBgCQAFAGAJAHIAOAMQAFAFAKAMIAFALIAFAJQAGAEAGAAIAKgFQAEgBAHAEQAJAEgEAEQAAABgKABQgHADgKAAIgIAAQgFAAgDgBg");
	this.shape_19.setTransform(112.9064,261.8373,2.8153,2.8153);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#F8B796").s().p("AAuCSQgIgCgFgJIgDgJIgEgIIgRgOQgFgGgEgCIgJgFQgDgCAAgCIABgFIAAgNQgBgKgCgIQgFgQgHgKQgWgdgFgiQgBgKAAgTIABgPIgBgPIgIgSIgFgPIAfgFIgGgGQAJAAAJgDQAGgCADACQACABABAGIAgCzQACAKAGANIAJAWQAKAcAJAPQACADAFADIAFAEIgDAEIgFACg");
	this.shape_20.setTransform(103.7961,229.8638,2.8153,2.8153);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#7F171B").s().p("AAcAlIgMAAQgJgBgJgDIgBgBIgBgBIgEgNIgEgOQgBgEgEgDQgFgEgDAAQgDAAgBACIgCADIAAAJIABASIACAJIgFAAIgDgUQgDgKgFgHQgGgJABgNQAEgLgBgBQAGAHAWAUQASAOAGAOQADAIAKAAQANgFgBgBIAGAEIAHAEQAFADABADQACAEgLAAIgNgBg");
	this.shape_21.setTransform(118.46,257.8959,2.8153,2.8153);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#F7B194").s().p("AAnCGQgFgMgEgFQgCgEgGgDIgTgOIgIgEQgDgCAAgCIAAgGIAAgMQgBgLgDgHQgGgQgIgJQgXgdgGghQgCgMAAgRQABgVgDgJIgIgSIgGgPIAegGIgGgGQAKgBAIgCQAGgDADACQADACABAFIAoCyQACAJAGANIALAWQAMAcAIAOIAIAGIAFADIgDAEIgFADIgOABQgIgCgFgJg");
	this.shape_22.setTransform(107.7374,225.8634,2.8153,2.8153);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#881A1E").s().p("AABBkQgJgBg+hyQgGgLgGgNQgLgaAGgOQAKgaAVAHQALAEAIAJIASAhIAWA0QAMAfACABQAEACAsg5IAaAQQgPAbgTAbQglA1gSAAIgBAAg");
	this.shape_23.setTransform(45.9959,95.3645,2.8153,2.8153);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FDD5B7").s().p("AgmAlQAPgbABgEQAAgPADgFQAIgLABgFIACgIQABgCAAgBQAAAAABgBQAAAAAAAAQABAAAAABQADAFgBAHIgDAFQAAABgBABQAAABAAAAQAAABAAAAQAAAAAAAAQACAAAPgKIAXgLQAEgBABAIQABAJgGALIgJAJIgKAHQgDAEgPAHQgFACgHAPIgHANg");
	this.shape_24.setTransform(73.4669,84.6056,2.8153,2.8153);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.MUJER1, new cjs.Rectangle(0,0,132.7,272.8), null);


(lib.mc_imagenmodulo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_24 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(24).call(this.frame_24).wait(1));

	// Capa_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("Ah7B7QgzgzAAhIQAAhIAzgzQAzgzBIAAQBJAAAzAzQAzAzAABIQAABIgzAzQgzA0hJAAQhIAAgzg0g");
	var mask_graphics_1 = new cjs.Graphics().p("AkNENQhwhvAAieQAAidBwhwQBwhwCdAAQCeAABvBwQBxBwAACdQAACehxBvQhvBxieAAQidAAhwhxg");
	var mask_graphics_2 = new cjs.Graphics().p("AmYGXQioioAAjvQAAjuCoiqQCqioDuAAQDvAACpCoQCpCqAADuQAADvipCoQipCqjvAAQjuAAiqiqg");
	var mask_graphics_3 = new cjs.Graphics().p("AoaIaQjfjeAAk8QAAk6DfjhQDfjdE7gBQE7ABDeDdQDhDhgBE6QABE8jhDeQjeDfk7ABQk7gBjfjfg");
	var mask_graphics_4 = new cjs.Graphics().p("AqVKTQkRkQAAmDQAAmCERkTQETkQGCgBQGDABEREQQESETAAGCQAAGDkSEQQkREUmDAAQmCAAkTkUg");
	var mask_graphics_5 = new cjs.Graphics().p("AsIMGQk/k/AAnHQAAnFE/lDQFDk/HFAAQHGAAFAE/QFCFDAAHFQAAHHlCE/QlAFDnGgBQnFABlDlDg");
	var mask_graphics_6 = new cjs.Graphics().p("AtzNwQlrlrAAoFQAAoDFrlwQFvlrIEAAQIEAAFsFrQFvFwAAIDQAAIFlvFrQlsFvoEAAQoEAAlvlvg");
	var mask_graphics_7 = new cjs.Graphics().p("AvWPTQmUmUAAo/QAAo9GUmYQGYmVI+AAQI/AAGUGVQGYGYAAI9QAAI/mYGUQmUGYo/AAQo+AAmYmYg");
	var mask_graphics_8 = new cjs.Graphics().p("AwxQuQm5m6AAp0QAApzG5m+QG+m5JzAAQJ0AAG5G5QG+G+AAJzQAAJ0m+G6Qm5G9p0AAQpzAAm+m9g");
	var mask_graphics_9 = new cjs.Graphics().p("AyESAQncnbAAqlQAAqjHcnhQHhncKjAAQKkAAHcHcQHhHhAAKjQAAKlnhHbQncHhqkAAQqjAAnhnhg");
	var mask_graphics_10 = new cjs.Graphics().p("AzPTLQn7n6AArRQAArPH7oAQH/n6LQAAQLQAAH7H6QIAIAAALPQAALRoAH6Qn7H/rQABQrQgBn/n/g");
	var mask_graphics_11 = new cjs.Graphics().p("A0SUOQoXoWABr4QgBr2IXodQIboVL3AAQL3AAIXIVQIcIdAAL2QAAL4ocIWQoXIcr3gBQr3ABobocg");
	var mask_graphics_12 = new cjs.Graphics().p("A1NVJQowouABsbQgBsZIwo0QIzowMaABQMagBIvIwQI1I0AAMZQAAMbo1IuQovI1saAAQsaAAozo1g");
	var mask_graphics_13 = new cjs.Graphics().p("A2BV8QpEpEAAs4QAAs4JEpJQJKpEM3AAQM4AAJEJEQJKJJAAM4QAAM4pKJEQpEJKs4AAQs3AApKpKg");
	var mask_graphics_14 = new cjs.Graphics().p("A2tWoQpVpWAAtSQAAtQJVpdQJcpVNRAAQNSAAJVJVQJdJdAANQQAANSpdJWQpVJctSAAQtRAApcpcg");
	var mask_graphics_15 = new cjs.Graphics().p("A3QXLQplpkAAtnQAAtmJlpqQJqplNmAAQNnAAJkJlQJrJqAANmQAANnprJkQpkJrtnAAQtmAApqprg");
	var mask_graphics_16 = new cjs.Graphics().p("A3sXnQpwpwAAt3QAAt2Jwp2QJ2pwN2AAQN3AAJwJwQJ2J2AAN2QAAN3p2JwQpwJ2t3AAQt2AAp2p2g");
	var mask_graphics_17 = new cjs.Graphics().p("A4AX6Qp4p4AAuCQAAuCJ4p+QJ+p4OCAAQOCAAJ4J4QJ/J+AAOCQAAOCp/J4Qp4J+uCABQuCgBp+p+g");
	var mask_graphics_18 = new cjs.Graphics().p("A4LYHQp9p9AAuKQAAuIJ9qEQKCp8OJAAQOJAAJ9J8QKDKEAAOIQAAOKqDJ9Qp9KDuJgBQuJABqCqDg");
	var mask_graphics_19 = new cjs.Graphics().p("A4PYKQp/p+AAuMQAAuKJ/qFQKEp/OLAAQOMAAJ+J/QKFKFAAOKQAAOMqFJ+Qp+KFuMAAQuLAAqEqFg");
	var mask_graphics_20 = new cjs.Graphics().p("A33XyQp0p0AAt+QAAt8J0p6QJ6p1N9AAQN9AAJ0J1QJ7J6AAN8QAAN+p7J0Qp0J6t9AAQt9AAp6p6g");
	var mask_graphics_21 = new cjs.Graphics().p("A3eXZQpqpqAAtvQAAttJqpxQJwpqNuAAQNuAAJqJqQJxJxAANtQAANvpxJqQpqJwtuAAQtuAApwpwg");
	var mask_graphics_22 = new cjs.Graphics().p("A3FXAQpfpgAAtgQAAtfJfpmQJmpfNfAAQNgAAJgJfQJlJmAANfQAANgplJgQpgJltgAAQtfAApmplg");
	var mask_graphics_23 = new cjs.Graphics().p("A2sWnQpVpWAAtRQAAtQJVpcQJcpVNQAAQNRAAJWJVQJbJcAANQQAANRpbJWQpWJbtRAAQtQAApcpbg");
	var mask_graphics_24 = new cjs.Graphics().p("A2TWOQpLpLAAtDQAAtBJLpSQJRpLNCAAQNCAAJMJLQJRJSAANBQAANDpRJLQpMJRtCAAQtCAApRpRg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:219.45,y:213.55}).wait(1).to({graphics:mask_graphics_1,x:220.175,y:214.075}).wait(1).to({graphics:mask_graphics_2,x:220.85,y:214.575}).wait(1).to({graphics:mask_graphics_3,x:221.5,y:215.05}).wait(1).to({graphics:mask_graphics_4,x:222.1,y:215.5}).wait(1).to({graphics:mask_graphics_5,x:222.675,y:215.9}).wait(1).to({graphics:mask_graphics_6,x:223.2,y:216.275}).wait(1).to({graphics:mask_graphics_7,x:223.675,y:216.65}).wait(1).to({graphics:mask_graphics_8,x:224.125,y:216.975}).wait(1).to({graphics:mask_graphics_9,x:224.55,y:217.275}).wait(1).to({graphics:mask_graphics_10,x:224.925,y:217.55}).wait(1).to({graphics:mask_graphics_11,x:225.25,y:217.8}).wait(1).to({graphics:mask_graphics_12,x:225.55,y:218}).wait(1).to({graphics:mask_graphics_13,x:225.8,y:218.2}).wait(1).to({graphics:mask_graphics_14,x:226,y:218.35}).wait(1).to({graphics:mask_graphics_15,x:226.175,y:218.475}).wait(1).to({graphics:mask_graphics_16,x:226.325,y:218.575}).wait(1).to({graphics:mask_graphics_17,x:226.425,y:218.65}).wait(1).to({graphics:mask_graphics_18,x:226.475,y:218.7}).wait(1).to({graphics:mask_graphics_19,x:226.5,y:218.7}).wait(1).to({graphics:mask_graphics_20,x:226.675,y:218.175}).wait(1).to({graphics:mask_graphics_21,x:226.825,y:217.675}).wait(1).to({graphics:mask_graphics_22,x:226.975,y:217.175}).wait(1).to({graphics:mask_graphics_23,x:227.125,y:216.675}).wait(1).to({graphics:mask_graphics_24,x:227.3,y:216.15}).wait(1));

	// Capa_1
	this.instance = new lib.imgmod1();
	this.instance.parent = this;
	this.instance.setTransform(225.45,217.45,1,1,0,0,0,386.9,219.2);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(25));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(7.4,-0.4,438.20000000000005,438.2);


(lib.M03_TMR_MODERADOR = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgXAZQgKgKAAgPQAAgNAKgLQAKgKANAAQAOAAAKAKQALAKgBAOQABAPgLAKQgKAJgOABQgNgBgKgJg");
	this.shape.setTransform(359.55,199);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgXAZQgLgKABgPQgBgOALgKQAKgKANAAQAPAAAJAKQAKALAAANQAAAPgKAKQgJAJgPABQgNgBgKgJg");
	this.shape_1.setTransform(371.9,199);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgXAZQgLgKAAgPQAAgNALgLQAKgKANAAQAOAAALAKQAKALgBANQABAPgKAKQgLAJgOABQgNgBgKgJg");
	this.shape_2.setTransform(384.2,199);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#FFFFFF").p("AjvC6IBohFQA/AiBOAAQBjAABGgyQBFgzAAhGQAAhIhFgyQhGgzhjAAQhhAAhGAzQhGAyAABIQAAAuAhAog");
	this.shape_3.setTransform(371.2795,201.1121);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#B1C0C9").s().p("AjIBGQgigoAAgvQABhHBGgyQBGgzBhAAQBiAABGAzQBGAyAABHQAABHhGAyQhGAzhiAAQhPAAg+giIhoBFg");
	this.shape_4.setTransform(371.5,200.75);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgYAZQgJgLgBgOQABgNAJgLQALgKANABQAOgBALAKQAKALgBANQABAOgKALQgLAJgOABQgNgBgLgJg");
	this.shape_5.setTransform(123.1,23.85);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgYAZQgKgLAAgOQAAgNAKgLQALgKANABQAOgBALAKQAJALABANQgBAOgJALQgLAJgOABQgNgBgLgJg");
	this.shape_6.setTransform(135.4,23.85);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgXAZQgKgLAAgOQAAgNAKgLQAKgKANABQAOgBAKAKQAKALAAANQAAAOgKALQgKAJgOABQgNgBgKgJg");
	this.shape_7.setTransform(147.7,23.85);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#FFFFFF").p("AjvC6IBohFQA/AiBOAAQBiAABGgyQBGgzAAhGQAAhIhGgyQhGgzhiAAQhiAAhGAzQhFAyAABIQAAAuAhAog");
	this.shape_8.setTransform(134.8287,25.9647);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#B1C0C9").s().p("AjIBGQgigoABgvQAAhHBFgyQBGgzBhAAQBjAABGAzQBGAyAABHQAABHhGAzQhGAyhjAAQhNAAg/giIhoBFg");
	this.shape_9.setTransform(135.05,25.6);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgXAZQgLgKABgPQgBgNALgLQAKgJANgBQAPABAJAJQAKAKAAAOQAAAPgKAKQgJAKgPAAQgNAAgKgKg");
	this.shape_10.setTransform(301.25,51.05);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgYAZQgKgKAAgPQAAgOAKgKQALgJANgBQAPABAKAJQAKALAAANQAAAPgKAKQgKAKgPAAQgNAAgLgKg");
	this.shape_11.setTransform(313.575,51.05);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgXAZQgKgKAAgPQAAgNAKgLQAKgJANgBQAOABAKAJQAKALAAANQAAAPgKAKQgKAKgOAAQgNAAgKgKg");
	this.shape_12.setTransform(325.9,51.05);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#E0EBB9").s().p("AjJBGQgggogBguQAAhIBGgzQBGgyBiAAQBiAABHAyQBFAzAABIQAABGhFAyQhHAzhiAAQhPAAg+giIhoBFg");
	this.shape_13.setTransform(313.2,52.8);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgYAYQgKgKAAgOQAAgNAKgKQALgKANAAQAPAAAKAKQAJAKABANQgBAOgJAKQgKAKgPAAQgNAAgLgKg");
	this.shape_14.setTransform(257,333.6);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgXAYQgLgKABgOQgBgNALgKQAKgKANAAQAPAAAJAKQAKAJAAAOQAAAOgKAKQgJAKgPAAQgNAAgKgKg");
	this.shape_15.setTransform(269.3,333.6);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgYAYQgKgKAAgOQAAgOAKgJQALgKANAAQAOAAALAKQAJAKABANQgBAOgJAKQgLAKgOAAQgNAAgLgKg");
	this.shape_16.setTransform(281.65,333.6);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#E0EBB9").s().p("AikCMQhFgzAAhIQAAguAggoIgoh4IBoBFQA+giBOAAQBjAABGAyQBGAzAABGQAABIhGAzQhGAyhjAAQhhAAhGgyg");
	this.shape_17.setTransform(268.95,331.85);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#B1C0C9").p("AgiAAQAAAOAKALQAKAKAOAAQAOAAALgKQAKgLAAgOQAAgOgKgKQgLgKgOAAQgNAAgLAKQgKALAAANg");
	this.shape_18.setTransform(88.575,313.075);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgYAZQgKgLAAgOQAAgNAKgLQALgKANAAQAOAAALAKQAKAKAAAOQAAAOgKALQgLAKgOAAQgOAAgKgKg");
	this.shape_19.setTransform(88.575,313.075);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().s("#B1C0C9").p("AghAAQAAAOAKALQAKAKANAAQAOAAAKgKQAKgLAAgOQAAgNgKgLQgKgKgOAAQgNAAgKAKQgKALAAANg");
	this.shape_20.setTransform(100.9,313.075);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AgXAZQgKgLAAgOQAAgNAKgLQAKgKANAAQAOAAAKAKQAKALAAANQAAAOgKALQgKAKgOAAQgNAAgKgKg");
	this.shape_21.setTransform(100.9,313.075);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f().s("#B1C0C9").p("AghAAQAAAOAKALQAKAKANAAQAOAAAKgKQAKgLAAgOQAAgNgKgLQgKgKgOAAQgNAAgKAKQgKALAAANg");
	this.shape_22.setTransform(113.2,313.075);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AgYAZQgJgLgBgOQABgNAJgLQALgKANAAQAOAAALAKQAKALgBANQABAOgKALQgLAKgOAAQgNAAgLgKg");
	this.shape_23.setTransform(113.2,313.075);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f().s("#FFFFFF").p("Ajvi6IBoBFQBAgiBNAAQBjAABGAzQBFAyAABHQAABHhFAzQhGAzhjAAQhhAAhGgzQhGgzAAhHQAAguAhgpg");
	this.shape_24.setTransform(100.2795,310.9629);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#B1C0C9").s().p("AijCMQhGgzgBhIQAAgtAigpIgph4IBoBFQBAgiBNAAQBiAABGAyQBGAzAABGQAABIhGAzQhGAyhiAAQhhAAhGgyg");
	this.shape_25.setTransform(100.5,311.325);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AgYAZQgJgKgBgPQABgNAJgLQAKgKAOAAQAPAAAKAKQAKALAAANQAAAPgKAKQgKAKgPAAQgOAAgKgKg");
	this.shape_26.setTransform(36.15,164.725);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AgYAZQgKgKAAgPQAAgNAKgLQALgKANAAQAOAAALAKQAJALABANQgBAPgJAKQgLAKgOAAQgNAAgLgKg");
	this.shape_27.setTransform(23.8,164.725);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AgYAZQgJgKgBgPQABgNAJgLQALgKANAAQAOAAALAKQAKALAAANQAAAPgKAKQgLAKgOAAQgNAAgLgKg");
	this.shape_28.setTransform(11.5,164.725);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#E0EBB9").s().p("AisCMQhFgzAAhHQAAhHBFgzQBGgyBjAAQBNAABAAiIBohFIgoB4QAgApAAAuQAABHhFAzQhGAyhiAAQhjAAhGgyg");
	this.shape_29.setTransform(24.2,162.975);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#E3989C").s().p("Ag9C+IAomFIBTAJIgnGGg");
	this.shape_30.setTransform(188.1,258.225);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#E3989C").s().p("Aieg1IAvhHIEOCyIgvBHg");
	this.shape_31.setTransform(257.1,222.925);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#C0DADE").s().p("AgjAeIgHgzIBLgIIAJA7g");
	this.shape_32.setTransform(305.4,278.325);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#C0DADE").s().p("AgsBJQAAgRgDgeIgCgaIAChHIAsAIQAtAMAHAXQAGAVgRBQg");
	this.shape_33.setTransform(319.938,274.05);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#C0DADE").s().p("AgpBBIgEgWQgGgdAbgpQAOgVANgPIAaAcQAXAdgGAJQgLAQACAug");
	this.shape_34.setTransform(281.7995,274.85);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#DDEAEC").s().p("AgqAKIBFgoIAQAeIgtAfg");
	this.shape_35.setTransform(304.8,268.075);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#DDEAEC").s().p("AgPAXQgbgQgBgLIAPgfIBIAyIghAVIgagNg");
	this.shape_36.setTransform(296.075,267.6);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#3F3231").s().p("AB5BpIAAgzQAAgOgNggQgPgkgPgEQgMgEgZANQgdAPgKAAIgDAAQgKAAgdgPQgZgNgMAEQgPAEgPAkQgNAgAAAOIAAAzQgCADgEgIQgCgEgFgDQgHhPAUgwQAehLBaAEIAAAAQBagEAfBLQAUAvgHBQQgFADgCAEQgDAGgCAAIgBgBg");
	this.shape_37.setTransform(299.614,236.617);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#805F50").s().p("AgWCuQgQgGgUgOQgngcgWgmIgCgEIAAgZIgBAAQgIAAgDgGQgCgFgEgSIgEgeQgCgLAAgIQAAgJACgBQADgBAGAEQACADABACIACAAIgCgOQgCgPAAgPQAAg2AbgNIABAAIAdgWQAkgWAiAAIADAAIAAAAIACAAIABAAIABAAIAAAAQAjgBAlAWQASALAMAMIABAAQAbANAAA2QAAAXgEAVIgBAEIADgDIAGgGQAFgDADABQAFADgEAXIgFAgQgEAUgCADIAAAAQgEAGgGAAIgBAAIgDAeQAAABAAAAQAAABAAAAQgBABAAAAQAAABgBAAQgmA1gzAbIgCABIgTADIgHAAQgMAAgKgDg");
	this.shape_38.setTransform(299.6592,246.1401);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#947668").s().p("AgLA4QhYgCAYgYQAVgVAFgcIABgZIAugJQAtgHABAQQACAcAkBFQgoADgkAAIgRAAg");
	this.shape_39.setTransform(300.294,262.7661);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#AEC7C9").s().p("AitBKQgGh9gDgBIBbgMIB2gHQB6gFAUAIQAOAHAACHg");
	this.shape_40.setTransform(300.0625,273.892);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f().s("#E9C3C5").ss(2.8).p("AGTAAQAACnh2B2Qh2B2inAAQimAAh2h2Qh2h2AAinQAAimB2h2QB2h2CmAAQCnAAB2B2QB2B2AACmg");
	this.shape_41.setTransform(301.825,257.45);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#F7DA98").s().p("AkcEdQh2h2AAinQAAimB2h2QB2h2CmAAQCnAAB2B2QB2B2AACmQAACnh2B2Qh2B2inAAQimAAh2h2g");
	this.shape_42.setTransform(301.825,257.45);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#C9C9C9").s().p("AgrBVIAHgmIASiDIAiAuQAhAygGAeIgHArg");
	this.shape_43.setTransform(237.4278,66.75);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#C9C9C9").s().p("AghBOQgDgVgFgRQgOgtAkgoQASgUAUgMIAIAmQAIApADAaIAHAyg");
	this.shape_44.setTransform(202.554,67.425);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#BBCACB").s().p("AgPAWQgagPgCgLIAPgdIBIAtIgjAWQgLgFgNgHg");
	this.shape_45.setTransform(215.525,57.675);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#BBCACB").s().p("AgoAJIBDgmIAOAdQgBAMgWAKIgUAIg");
	this.shape_46.setTransform(223.725,58.125);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#9D9393").s().p("AAfAdQgGgBgFgGQgGgHAAgKIAAgCQgHgHgGABIgBAAQgIgBgFAHIAAACQAAAKgGAHQgGAGgGABIg3AAIgCgBQgIgEgFgIQgDgHAAgFIAAgEIgQACIgCgOIAUgEQAEgJAMgDIA0AAQAPAAAFAOQAHgFAHACQAHgCAIAFQAEgOAQAAIA0AAQAMADAEAJIAUAEIgDAOIgPgCIAAAEQAAAQgQAIIgCABgAAcgJIAAAOQAAAHAGACIAxAAQAHgEAAgFIAAgOQAAgCgGgCIgxAAQgFAAgCAEgAhZgJIAAAOIABADQACAEAEACIAxAAQAFgBAAgIIAAgOQgBgEgFAAIgyAAQgFADAAABg");
	this.shape_47.setTransform(219.025,35.375);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#71706F").s().p("AB2BIIgIg1QgBgJgHgKQgNgRgZAAQgMABgNAGQgtAUghgXIAAgBQgRgGgRABQgfADgFAhIgHA2QAAAAgBABQAAAAAAABQgBAAAAAAQgBAAAAAAQgBAAAAAAQgBAAAAAAQgBgBAAAAQAAgBAAAAQgOhrAhgDQAAAAABgBQABAAAAgBQAAAAABgBQAAAAAAgBIAHgIQALgIAYgCQATgBARgGQAQgGAKAAQBMgBAXAgIACACQAIAEAGAMQAKATgCAiIgDAsQAAABgBAAQAAABAAAAQgBAAAAABQgBAAAAAAQgBAAAAAAQgBgBAAAAQgBAAAAgBQAAAAAAgBg");
	this.shape_48.setTransform(218.8269,25.6235);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#EDAB86").s().p("AAmACIhxACQAVgEARgBIAlgCQAWAAAQACQAVABARAEIgmgCg");
	this.shape_49.setTransform(219.3,27.15);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#EDAB86").s().p("AAmABIhxACQAZgDANgBIAlgBIAmABQAWABAQADIgmgCg");
	this.shape_50.setTransform(219.1,28.925);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#F9BD9C").s().p("AgUCiQgPgFgSgNQglgagVgkIgBgEIgBgXIgBAAQgDAAgEgCIgCgDQgCgDgEgTIgEgcIgDgSQAAgIADgBQADgBAFAEQACABABADIACAAQgEgTAAgWQAAgyAagNIAAAAIAbgUQAigVAgAAIADAAIADAAQAhgBAjAVQARAKALALQAaANAAAyQAAAWgEATIgBAEIADgDQAJgJAEACQAFACgDAWIgFAdQgEAVgCABIAAABQgEAFgGAAIgBAAIgCAcIgCAEQglAzguAYIgCABQgOADgLAAQgLAAgJgEg");
	this.shape_51.setTransform(219.0971,36.2565);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#EDAB86").s().p("AgKA+QhagEAXgWQATgTAKgjIAFghIArgJQAqgGABAPQACAbAmBVQgeACgcAAIgjgBg");
	this.shape_52.setTransform(219.5,52.819);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#D6D8D8").s().p("AjIBdIgChcQAFgiAWgTQAXgSAmgJQAUgFAOgBQA9gGA/gBQBHAAASAHQAbAKAWA4QAUA0AAAtIAAAPg");
	this.shape_53.setTransform(220.55,65.9233);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#1C140B").s().p("AgDAAQABgKACAAQADAAAAAKQAAALgDAAQgCAAgBgLg");
	this.shape_54.setTransform(192.35,320.575);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#927954").s().p("AgEAPQgCgGAAgJQAAgIACgGQACgHACAAQADAAACAHQACAGAAAIQAAAIgCAHQgCAGgDAAQgCAAgCgGg");
	this.shape_55.setTransform(192.325,320.3);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#E6E4EA").s().p("AgCAAQAAgKACAAQADAAAAAKQAAALgDAAQgCAAAAgLg");
	this.shape_56.setTransform(169.925,320.575);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#927954").s().p("AgEAPQgCgHAAgIQAAgIACgGQACgHACAAQADAAACAHQACAGAAAIQAAAJgCAGQgCAGgDAAQgCAAgCgGg");
	this.shape_57.setTransform(169.925,320.3);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#1C140B").s().p("Ai5CKQgNgNAAgTQAAgRAMgNQgUgMAAgWQAAgSAPgNQgEgGgBgIQABgKAFgHQAGgIAIgCQgBgGgBgHQAAgTAOgOQANgNATAAIADAAQAEgMAKgHQALgHANAAQAJAAAKAFQAEgPAMgKQAMgKAQAAQALAAAMAGQALgLAPAAQAVAAAMARIAEgBQAJAAAHAGQAGAHABAIQAIgCAIAAQAUAAAQAPQAOAPAAAVIAAAAIAHAAQARAAAMAMQAMALAAARQAAAMgGAKQAMAMAAATQAAAVgPANQAVAOAAAZQgBATgNANQgNAOgTAAQgOAAgMgIQgLgIgGgNQgKgCgHgJQgHgJAAgLIAAgEIgMABQgWAAgPgPQgPgQAAgVIAAgFQgHAEgHAAQgMAAgJgIQgJgHgEgMIgBAAQgLAAgIgFQgIgHgDgKIgCgBIAAAEQAAATgRALQAGAKAAAMQAAAPgJAMQgKALgPAEQACAEAAAEQAAARgOAHQgCARgOALQgMALgRAAQgTAAgNgNg");
	this.shape_58.setTransform(180.5,304.025);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#A25F37").s().p("AgGgQQAGgKAFABQADAAACADQADAVgMAQQgFAIgGAEg");
	this.shape_59.setTransform(192.555,317.4457);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#A25F37").s().p("AAAAPQgMgQADgVIAFgDQAFgBAGAKIAEArQgHgEgEgIg");
	this.shape_60.setTransform(169.22,317.4457);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#A25F37").s().p("AglCZQgsgcgYgzQgGgEgGgIQgMgRADgVIAFgDQAGgBAGAKQgIgYgEgdQgIg7AYgeQAJgNAQgOQAigbApgEIALAAQAqAEAhAbQAQAOAJANQAYAegIA7QgEAdgIAYQAGgKAGABQADAAACADQADAVgMARQgGAIgGAEQgYAzgrAcQgWAOgRAEQgQgEgVgOg");
	this.shape_61.setTransform(180.9334,312.625);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#1C140B").s().p("AgSBAIgHABQgJAAgHgHQgGgHAAgJIAAgFIgHABQgQAAgLgMQgMgLAAgPQAAgLAHgKQAGgJAKgEQgJgIAAgNQAAgLAIgHQAHgIALAAQAQAAAHAMQAIgEAKAAQATAAAOAOQAOAOAAAUQAAAOgHALQARAEAJAQQAFgCAGAAQAMAAAIAJQAJAIAAAMQAAAMgJAJQgIAJgMAAQgKAAgJgHQgMAMgSAAQgWAAgMgSg");
	this.shape_62.setTransform(171.125,321.075);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#1C140B").s().p("AhGA3QgJgJAAgNQAAgMAJgKQAJgJANAAQAAgMAJgJQAIgJANgBQACgNALgJQAJgKAOABQAMAAAIAFQAIgIAKAAQAKAAAHAHQAHAIAAAJQAAAKgHAHQgHAHgKAAIgBAAQgCAKgHAIQgIAIgLADIAAACQAAAQgLALQgLALgPAAQgGAAgIgDQgJANgPAAQgNAAgJgJg");
	this.shape_63.setTransform(191.275,323.15);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#9D9D9E").s().p("AgUA5IgagkQgEgMADgOQAFggAigSIASAkQAXArAQAhg");
	this.shape_64.setTransform(192.9019,342.4);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#9D9D9E").s().p("AghA6QADg7AIgiIAJgWIAvAmIgMBNg");
	this.shape_65.setTransform(170.575,342.275);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#FFFFFF").s().p("AgcgPIAbgKIAeAbIgXAYg");
	this.shape_66.setTransform(177.75,335.525);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#FFFFFF").s().p("AgcADIAfgdIAaAKIgkArg");
	this.shape_67.setTransform(183.5,335.425);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#CCCBCB").s().p("AAHASIgigkIAUgHIAjAZIgSAag");
	this.shape_68.setTransform(177.85,335.9);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#CCCBCB").s().p("AgaAAIAlgYIAQAHIgiAhIgDAJg");
	this.shape_69.setTransform(183.275,335.775);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#9F5733").s().p("AgzAIIAWgJQAEgFABgCQACgGAAgPIgBgPIAugBIgBASQgBATACADIAdAMIgmAkIgRgQIgVATg");
	this.shape_70.setTransform(181.025,333.1);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#FFFFFF").s().p("AgXgDIgcgnIAXgLIAbgJIA1ATIgmAkIgRBGg");
	this.shape_71.setTransform(181,338.175);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#626568").s().p("AgHBRIgqhIIATgKIgfgGIgZgrIBWgdIBXAfIgoAvIgaAAIAQAMIgiBGg");
	this.shape_72.setTransform(181.1,340);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#606060").s().p("AgHBPIgshFIAVgKIgigFIgagpIAPgGIAhgMIAsgOIAiAMIAFACIAyAXIgnApIgcAAIARAMIglBDg");
	this.shape_73.setTransform(181.025,340.15);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#9D9D9E").s().p("AhUBRIgFgOQgDgKACgMIAFgXQACgJgFgKIgLgRIgHgKQgGgLgBABQAOgGAcgKIAigMIAtgRIAmARIAiAPIAiAQIgHAJQgFAFgDAKQgDAHABAEIADAIQAMAfgLAaIgHAMg");
	this.shape_74.setTransform(180.575,340);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#4D4D4D").s().p("AgeAAIAMgVIAxAcIgcAPQgfgIgCgOg");
	this.shape_75.setTransform(60.975,234.825);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#4D4D4D").s().p("AgfALIA0gkIALAWQgCAOglAPg");
	this.shape_76.setTransform(67.225,234.475);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#744C28").s().p("ABaAeQgDgRgfAAQgoADgSgBQgXAAgVgRIgQgRQgKAkgFAEQgEACgEAYIgEAXIgLgPQgKgPABgDQAGgVgDgPQgCgJAAgLQABgPAFgEIAAgBQgBgDAegNQAjgPAfgCQAigDApAYQAoAXABATQABATgDAXQgDAZgFABQgEAAgFAIIgDAHQAHgQgEgcg");
	this.shape_77.setTransform(64.458,210.4211);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#CCCCCC").s().p("AAeBuQgPgmgBgHQgBgPgEA8Ih2AAIABiEIABg8QAHgKANgIQAZgPAcAKIAeADQAfAGAPAKQAPAKA1C6g");
	this.shape_78.setTransform(73.7417,244.7658);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#CCCCCC").s().p("AgJBuQgEg8gBAPQgBALgOAiIhUAAQARhHAWg8QAVg6ALgHQAPgKAfgGIAdgDQAcgKAaAPQANAIAHAKIADA8QACBHABA9g");
	this.shape_79.setTransform(54.2,244.7658);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#F9BD9C").s().p("AgSB5IgBAAQgkgTgaglIgBgDIgCgVIgBAAQgDAAgCgCIgCgCIAAAAQgCgBgCgPIgEgVIAAgBQgCgPADgDIAAAAQADgBAHAGIACADIgBgEQgDgOAAgQQAAgmATgJIABAAQAIgIANgIQAagPAYABIACAAIADgBQAYABAYAPQANAHAIAIQATAJAAAmQAAAQgDAOIACABIACgEQAEgDACABQACACAAAFIgFAiIgEAQQgEAEgDAAIgBAAIgBASIgBADQgPAagbATQgOAKgLAEQgIADgIAAQgIAAgKgDg");
	this.shape_80.setTransform(64.46,218.5375);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#EDAB86").s().p("Ag9AtQAdg/ABgUQABgLAfAFQAQACAQAEIAEAYQAHAbAPAOQARARhDACg");
	this.shape_81.setTransform(64.147,230.8597);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f().s("#E9C3C5").ss(2.8).p("AGTAAQAACnh2B2Qh2B2inAAQimAAh2h2Qh2h2AAinQAAimB2h2QB2h2CmAAQCnAAB2B2QB2B2AACmg");
	this.shape_82.setTransform(218.6,49.325);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#7995A3").s().p("AkcEdQh2h2AAinQAAimB2h2QB2h2CmAAQCnAAB2B2QB2B2AACmQAACnh2B2Qh2B2inAAQimAAh2h2g");
	this.shape_83.setTransform(218.6,49.325);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f().s("#E9C3C5").ss(2.8).p("AGTAAQAACnh2B2Qh2B2inAAQimAAh2h2Qh2h2AAinQAAimB2h2QB2h2CmAAQCnAAB2B2QB2B2AACmg");
	this.shape_84.setTransform(180.525,318.5);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#E6E4EA").s().p("AkcEdQh2h2AAinQAAimB2h2QB2h2CmAAQCnAAB2B2QB2B2AACmQAACnh2B2Qh2B2inAAQimAAh2h2g");
	this.shape_85.setTransform(180.525,318.5);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f().s("#E9C3C5").ss(2.8).p("AGTAAQAACnh2B2Qh2B2inAAQimAAh2h2Qh2h2AAinQAAimB2h2QB2h2CmAAQCnAAB2B2QB2B2AACmg");
	this.shape_86.setTransform(64.5,231.9);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#ABC9CE").s().p("AkcEdQh2h2AAinQAAimB2h2QB2h2CmAAQCnAAB2B2QB2B2AACmQAACnh2B2Qh2B2inAAQimAAh2h2g");
	this.shape_87.setTransform(64.5,231.9);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#7F795E").s().p("AgeAHIAygdIALAWQgCAOgfAIg");
	this.shape_88.setTransform(324.775,138.25);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#7F795E").s().p("AgfgCIALgXIA0AjIgYAQQglgPgCgNg");
	this.shape_89.setTransform(318.425,137.9);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#DAA675").s().p("ABcAeQgDgSgfAAQgpAEgSgBQgYgBgWgQIgQgSQgKAkgFAFQgEACgFAYIgEAXIgKgPQgKgPABgDQAGgWgEgPQgCgJABgMQAAgOAGgFIAAAAQgCgEAfgMQAkgPAfgDQAjgDAqAYQAoAYABATQABATgDAYQgDAZgFABQgEABgFAIIgEAHQAIgQgEgdg");
	this.shape_90.setTransform(321.233,113.4586);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#C4B98C").s().p("AhkBIQAjhxAMgIQAZgQA0gDQAdgKAaAQQANAIAHAKIACB0g");
	this.shape_91.setTransform(312.925,144.4077);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#C4B98C").s().p("AhnBIIAEh0IAVgSQAagQAcAKIAdAEQAhAFAPAKQAIAGAOAiQAPAhAOAwg");
	this.shape_92.setTransform(330.725,144.4077);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#F9BD9C").s().p("AgPB7QgLgEgOgKQgcgUgQgbIgBgDIAAgRIgBAAQgDAAgCgCIgCgCQgCgCgDgPIgDgVIgCgNQAAgGACgCQACAAAEADIACADIACAAQgDgPAAgQQAAgmAUgKIAVgPQAZgQAYAAIAFAAQAYgBAbAQQANAIAJAIQAUAKAAAmQAAAQgEAPIAAADIACgCQAHgHADABQAEADgDAQIgBABIgDAVQgDAQgBAAIAAABQgDAEgFAAIAAAAIgCAVIgCADQgaAmglATIgBAAQgKADgJAAQgIAAgHgDg");
	this.shape_93.setTransform(321.2393,121.6846);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#EDAB86").s().p("AgIAvQhEgCARgRQAPgPAHgbIAEgYIAhgHQAggFAAAMQABAUAeBAIgwACIgXgBg");
	this.shape_94.setTransform(321.555,134.2284);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f().s("#E9C3C5").ss(2.8).p("AGTAAQAACnh2B2Qh2B2inAAQimAAh2h2Qh2h2AAinQAAimB2h2QB2h2CmAAQCnAAB2B2QB2B2AACmg");
	this.shape_95.setTransform(321.825,131);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#5A7D69").s().p("AkcEdQh2h2AAinQAAimB2h2QB2h2CmAAQCnAAB2B2QB2B2AACmQAACnh2B2Qh2B2inAAQimAAh2h2g");
	this.shape_96.setTransform(321.825,131);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#3F3231").s().p("AiiB4IgMgDQgCABgEgLQgHgUgIg4QgHgtAmgeQgCgWAIgTQAMgdAfgOIgJANQgJAPgDAMQAAAAAAAAQAAAAAAABQAAAAAAAAQABAAAAABQAAAAABAAQAAAAAAAAQABAAAAAAQAAAAABgBQASgVAigQQA2gaBNgBQgcAEgVALQAAAAgBABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAABABQAAAAAAAAQABAAAAAAQABAAAAAAQBegKA0AiQgJgBgMAAQgBAAAAAAQAAAAgBABQAAAAAAAAQAAAAAAABQAAAAAAAAQAAAAAAABQAAAAAAAAQABAAAAAAQAZAKARARQAcAbAAAlQgKgMgHgHQAAgBAAAAQgBAAAAAAQAAAAAAAAQgBAAAAABQAAAAAAAAQgBAAAAAAQAAABAAAAQAAAAABAAQAKAdgIAdQgBgIgJgJQgCAugNA7QgNgBgJAPIgGAPQABgVgBgZQgDgygNgUQgig0hdACQgeABggAFIgaAGQgRAogWAZQgCAIgCAuIgCAsQgCgYgMgIg");
	this.shape_97.setTransform(197.1456,162.975);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#3F3231").s().p("AArAbQgIgBgGgEQgJgHAAgKIAAgCQgHgHgJABIgCAAQgHgBgIAHIAAACQAAAKgIAHQgGAEgIABIhFAAIgCAAQgLgEgFgIQgEgGAAgFIAAgFIgUADIgDgOIAZgDQAFgJAPgDIBBAAQASAAAHANQAKgEAHABQAJgBAKAEQAHgNASAAIBAAAQAQADAFAJIASACIgBAJIgPADIAAAFQAAAOgUAJIgCAAgAAegNIAAAUIACAGQACAEAGAEIBKAAQAJgBAAgMIAAgUQgDgHgHAAIhKAAQgJADAAADgAh0gNIAAAUIACAGQACAEAGAEIBKAAQAJgBAAgMIAAgUQgCgHgIAAIhKAAQgJADAAADg");
	this.shape_98.setTransform(195.725,174.65);

	this.instance = new lib.Group();
	this.instance.parent = this;
	this.instance.setTransform(221.3,209.4,1,1,0,0,0,1.9,4.8);
	this.instance.alpha = 0.3906;

	this.instance_1 = new lib.Group_1();
	this.instance_1.parent = this;
	this.instance_1.setTransform(218.55,211.25,1,1,0,0,0,1.2,2.8);
	this.instance_1.alpha = 0.3906;

	this.instance_2 = new lib.Group_2();
	this.instance_2.parent = this;
	this.instance_2.setTransform(218.4,208.8,1,1,0,0,0,2.6,5.4);
	this.instance_2.alpha = 0.3906;

	this.instance_3 = new lib.Group_3();
	this.instance_3.parent = this;
	this.instance_3.setTransform(175.75,208.8,1,1,0,0,0,2.5,5.4);
	this.instance_3.alpha = 0.3906;

	this.instance_4 = new lib.Group_4();
	this.instance_4.parent = this;
	this.instance_4.setTransform(174.55,210.4,1,1,0,0,0,1.4,3.8);
	this.instance_4.alpha = 0.3906;

	this.instance_5 = new lib.Group_5();
	this.instance_5.parent = this;
	this.instance_5.setTransform(172.45,209.1,1,1,0,0,0,1.8,5);
	this.instance_5.alpha = 0.3906;

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#A9B3BC").s().p("AgyAMIBTgwIASAkQgBAOgbANIgaAKg");
	this.shape_99.setTransform(201.825,201.65);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#A9B3BC").s().p("AgSAbQgggSgCgOIATglIBWA8IgoAZQgOgGgRgKg");
	this.shape_100.setTransform(191.425,201.075);

	this.instance_6 = new lib.Group_6();
	this.instance_6.parent = this;
	this.instance_6.setTransform(199.1,208.25,1,1,0,0,0,0.6,5.9);
	this.instance_6.alpha = 0.3906;

	this.instance_7 = new lib.Group_7();
	this.instance_7.parent = this;
	this.instance_7.setTransform(202.85,208,1,1,0,0,0,0.6,6.1);
	this.instance_7.alpha = 0.3906;

	this.instance_8 = new lib.Group_8();
	this.instance_8.parent = this;
	this.instance_8.setTransform(206,207.8,1,1,0,0,0,0.6,6.2);
	this.instance_8.alpha = 0.3906;

	this.instance_9 = new lib.Group_9();
	this.instance_9.parent = this;
	this.instance_9.setTransform(215.25,208.05,1,1,0,0,0,0.7,6);
	this.instance_9.alpha = 0.3906;

	this.instance_10 = new lib.Group_10();
	this.instance_10.parent = this;
	this.instance_10.setTransform(212.55,207.6,1,1,0,0,0,0.6,6.4);
	this.instance_10.alpha = 0.3906;

	this.instance_11 = new lib.Group_11();
	this.instance_11.parent = this;
	this.instance_11.setTransform(208.85,207.35,1,1,0,0,0,0.7,6.6);
	this.instance_11.alpha = 0.3906;

	this.instance_12 = new lib.Group_12();
	this.instance_12.parent = this;
	this.instance_12.setTransform(194.9,208.25,1,1,0,0,0,0.6,5.9);
	this.instance_12.alpha = 0.3906;

	this.instance_13 = new lib.Group_13();
	this.instance_13.parent = this;
	this.instance_13.setTransform(191.15,208,1,1,0,0,0,0.6,6.1);
	this.instance_13.alpha = 0.3906;

	this.instance_14 = new lib.Group_14();
	this.instance_14.parent = this;
	this.instance_14.setTransform(188,207.8,1,1,0,0,0,0.6,6.2);
	this.instance_14.alpha = 0.3906;

	this.instance_15 = new lib.Group_15();
	this.instance_15.parent = this;
	this.instance_15.setTransform(178.9,208.05,1,1,0,0,0,0.7,6);
	this.instance_15.alpha = 0.3906;

	this.instance_16 = new lib.Group_16();
	this.instance_16.parent = this;
	this.instance_16.setTransform(181.45,207.6,1,1,0,0,0,0.6,6.4);
	this.instance_16.alpha = 0.3906;

	this.instance_17 = new lib.Group_17();
	this.instance_17.parent = this;
	this.instance_17.setTransform(185.3,207.35,1,1,0,0,0,0.7,6.6);
	this.instance_17.alpha = 0.3906;

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#BBCACB").s().p("AiYBRQAmhyAPgKQAagQA1gJQAagFAWgBQAvgQAqAaQAWANAMAQIACB0g");
	this.shape_101.setTransform(183.575,208.0202);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("#CCD0D0").s().p("AidBRIAFh0IAigdQAqgaAwAQIAvAGQA1AJAaAQQAJAHARAhQAQAhARAzg");
	this.shape_102.setTransform(210.55,208.0202);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("#E8AF93").s().p("AAVAAIgJgCIgKgBIgSADIgUAFQAIgFAKgDQAJgDALgBIALAAIAKAEQALADADAIQgGgGgKgCg");
	this.shape_103.setTransform(188.625,173.175);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f("#E1BB93").s().p("AgaDKQgSgHgXgQQgugggagtQgBgCAAgDIgBgcIgBAAQgJgBgDgGQgCgDgFgZIgGgiQgCgMAAgKQAAgLADgBQAEgCAGAGQADADAAACIADAAQgFgYAAgcQAAg9AggQIAigaQAqgaAoAAIAEAAIAAABIAEAAIAAgBQApgBArAaQAWANANAOIABAAQAgAQAAA9QAAAcgFAYIgBAFIADgEQALgLAFACIABAAQAGADgFAbIgGAlQgFAagCABIAAABQgEAGgIABIgBAAIgEAiQAAADgBACQgsA+g8AfIgCABQgQAFgPAAQgNAAgNgFg");
	this.shape_104.setTransform(196.0714,174.4546);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f("#D6AE89").s().p("AgNBNQhwgEAcgcQAZgYALgsIAHgpIA2gLQA1gHABASQABAhAwBqQgnADglAAIgogBg");
	this.shape_105.setTransform(196.569,195.0532);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f().s("#E9C3C5").ss(5.7).p("AIsAAQAADnijCiQijCjjmAAQjlAAijijQijiiAAjnQAAjlCjijQCiijDmAAQDmAACjCjQCjCjAADlg");
	this.shape_106.setTransform(197,183.475);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f("#F0F4E7").s().p("AmIGJQijiiAAjnQAAjlCjijQCjijDlAAQDmAACjCjQCjCjAADlQAADnijCiQijCjjmAAQjlAAijijg");
	this.shape_107.setTransform(197,183.475);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f("#3F3F3F").s().p("AggA/IgJh6QAAgBAAAAQABgBAAAAQAAAAABgBQAAAAABAAQAZABARAIQAVAKAFATQAHAaAFA9g");
	this.shape_108.setTransform(95.925,114.975);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f("#3F3F3F").s().p("AgqA/QAGg4AIgfQAFgTAVgKQAQgIAagBQABAAABAAQAAABAAAAQABAAAAABQAAAAAAABIgQB6g");
	this.shape_109.setTransform(69.95,114.975);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f("#2F2F2F").s().p("AgnBLIAviVIAQANQAFACAFAYIAHAdIgcgDIAUAiQABABghAxg");
	this.shape_110.setTransform(87.45,113.75);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f("#2F2F2F").s().p("AAABIQghgxABgBIATgiIgbADIAHgbQAEgWAGgDIARgKIAvCPg");
	this.shape_111.setTransform(77.95,114.05);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.f("#ACADAD").s().p("AAmAuIgMgUIgaggIgUAZIgEAHIgNAUQgBAMgDgMIgWhFIABgCIAZgWIAFAJQATAbANAAQASAAAMgRIALgXIAXAaIAAACIgWBFQgCAGgBAAQgBAAAAgGg");
	this.shape_112.setTransform(82.675,111.0439);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.f("#B3B3B3").s().p("AgvBKIAliTQAAADAaAPQAKAFASADQgDAbACAhIAFA9g");
	this.shape_113.setTransform(88.225,113.9);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.f("#B3B3B3").s().p("AgrBGIACg+QgBghgDgaIAOgDQAJgBAGgDQARgJAAgCQAGAXAPAoQAPAnAFAXIAEAOg");
	this.shape_114.setTransform(77.5,114.275);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.f("#E5E6E6").s().p("AgQA3IgdhEQgCgDADgDQAVgcAXgHQAZAHAVAcQACACgCAEIgdBEg");
	this.shape_115.setTransform(82.679,115.75);

	this.instance_18 = new lib.ClipGroup();
	this.instance_18.parent = this;
	this.instance_18.setTransform(82.85,91,1,1,0,0,0,11.4,15.7);

	this.instance_19 = new lib.ClipGroup_1();
	this.instance_19.parent = this;
	this.instance_19.setTransform(82.75,72.95,1,1,0,0,0,7.3,4.2);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.f("#ECAA86").s().p("AgEgNQAEgJAFABQAAAAABABQAAAAABAAQAAAAABABQAAAAABABQACARgKANIgJAKg");
	this.shape_116.setTransform(92.3924,94.2697);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.f("#ECAA86").s().p("AAAAMQgKgNACgRIAFgDQAEgBAFAJIADAjQgFgDgEgHg");
	this.shape_117.setTransform(73.2576,94.2697);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.f("#F9BD9C").s().p("AgeB9QgkgWgUgqQgFgDgFgHQgJgOACgSIAEgCQAFAAAFAIQgHgUgDgXQgGgxATgYIAVgXQAbgWAigDIAJAAQAiADAbAWQAOAMAHALQATAYgGAxQgDAXgHAUQAFgIAFAAQABAAAAAAQABABABAAQAAAAAAABQABAAAAAAQACASgJAOIgKAKQgUAqgkAWIgfAQQgNgEgRgMg");
	this.shape_118.setTransform(82.825,90.3);

	this.shape_119 = new cjs.Shape();
	this.shape_119.graphics.f("#ECAA86").s().p("Ah2BdQgQAAgMgOQgLgOAAgUQAAgUALgPQAMgNAQAAIA0gIQAMgDALgLQALgKAAgIIAAgxQANAHAVAAQAVAAAPgHIgBAxQAAAIAJAKQAJAKAMAEIA0AIQAQAAAMANQALAPAAAUQAAAUgLAOQgMAOgQAAg");
	this.shape_119.setTransform(82.825,109.875);

	this.shape_120 = new cjs.Shape();
	this.shape_120.graphics.f().s("#E9C3C5").ss(2.8).p("AGTAAQAACnh2B2Qh2B2inAAQimAAh2h2Qh2h2AAinQAAimB2h2QB2h2CmAAQCnAAB2B2QB2B2AACmg");
	this.shape_120.setTransform(83.5,95.925);

	this.shape_121 = new cjs.Shape();
	this.shape_121.graphics.f("#7DA489").s().p("AkcEdQh2h2AAinQAAimB2h2QB2h2CmAAQCnAAB2B2QB2B2AACmQAACnh2B2Qh2B2inAAQimAAh2h2g");
	this.shape_121.setTransform(83.5,95.925);

	this.shape_122 = new cjs.Shape();
	this.shape_122.graphics.f("#E3989C").s().p("AhJC/IBAmKIBTANIhAGKg");
	this.shape_122.setTransform(212,109.375);

	this.shape_123 = new cjs.Shape();
	this.shape_123.graphics.f("#E3989C").s().p("AjWhsIAzhEIF7EdIg0BEg");
	this.shape_123.setTransform(135.4,133.475);

	this.shape_124 = new cjs.Shape();
	this.shape_124.graphics.f("#E3989C").s().p("AjJAZIF3iBIAcBQIl4CBg");
	this.shape_124.setTransform(264.975,150.925);

	this.shape_125 = new cjs.Shape();
	this.shape_125.graphics.f("#E3989C").s().p("AjsAbIHBiGIAYBRInBCGg");
	this.shape_125.setTransform(122.625,210.375);

	this.shape_126 = new cjs.Shape();
	this.shape_126.graphics.f("#E6E6E6").s().p("AnYaeQiRiRABjNQgBhfAkhYIl4kvQhEA8hTAgQhWAihdAAQjNAAiSiRQiQiRgBjNQAAjKCNiQQCNiPDJgFIA2mGQgvgQgogWQhzhAhFhyQhHh1AAiKQAAjNCRiRQCSiRDMAAQBuAABiAuQBfArBFBPIHliYQACjMCQiRQCQiQDNAAQDNAACRCRQCRCRAADNQAAB3g3BqIEWDOQBCg0BOgcQBRgeBXAAQDNAACRCRQCQCSABDNQgBDJiMCQQiNCQjKAFIg1EpQCYAvBhCBQBiCEAACkQAADNiRCRQiRCRjNAAQhoAAhfgpQhbgphFhIIl4CrQAJAvAAAwQgBDNiQCRQiSCRjLAAQjNAAiSiRg");
	this.shape_126.setTransform(193.15,183.925);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_126},{t:this.shape_125},{t:this.shape_124},{t:this.shape_123},{t:this.shape_122},{t:this.shape_121},{t:this.shape_120},{t:this.shape_119},{t:this.shape_118},{t:this.shape_117},{t:this.shape_116},{t:this.instance_19},{t:this.instance_18},{t:this.shape_115},{t:this.shape_114},{t:this.shape_113},{t:this.shape_112},{t:this.shape_111},{t:this.shape_110},{t:this.shape_109},{t:this.shape_108},{t:this.shape_107},{t:this.shape_106},{t:this.shape_105},{t:this.shape_104},{t:this.shape_103},{t:this.shape_102},{t:this.shape_101},{t:this.instance_17},{t:this.instance_16},{t:this.instance_15},{t:this.instance_14},{t:this.instance_13},{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.shape_100},{t:this.shape_99},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance},{t:this.shape_98},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_94},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.M03_TMR_MODERADOR, new cjs.Rectangle(0,0,396.7,367.9), null);


(lib.M03_TMR_DESICION = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#121C1F").s().p("AhYBkQglglAIgvQAHgqAqgqQAqgpAqgIQAvgIAlAmQAKAKAJANQgigUgoALQglALgjAjQgkAjgKAlQgMAoAVAiQgNgIgLgLg");
	this.shape.setTransform(33.5789,27.6797);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#182529").s().p("Ag4FJIABABQgagSgYgZQhOhNgnhQQgkhLgBhGQAAgzATguQgjABgigOQgjgOgYgXQglglAIgwQAIgqApgqQAqgqArgHQAvgIAlAlQAVAVANAeQANAdADAgQBZg1BvAbQB4AdBxBxQBiBigDB0QgDBuhZBZQhNBNhgANQgQACgRAAQhSAAhLg1g");
	this.shape_1.setTransform(61.8084,54.2636);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#923B24").s().p("Ag7AwQg0gHgigPIEShNIAOAdQAKAfgXALQhDAghKAAQgYAAgYgEg");
	this.shape_2.setTransform(73.0493,86.8142);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#923B24").s().p("AgVCPQgQgFgNgKIBMkRIAIAYQAKAdAEAhQAOBlgqBYQgIAQgRAAQgHAAgJgDg");
	this.shape_3.setTransform(91.0392,68.8493);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#D79182").s().p("ABvMyQnsiohCgaQg8gXgigcQgmgdgUgsQhkjSgshzQg8ifgMh1QgOiGArhxQAth5ByhxIAsgtQByhyB5gtQBxgqCFAOQB1ALCfA9QB0ArDSBkQAsAUAdAmQAbAjAYA8QAUAzCuH6QACAIgDAHQgEAGgIACIixAxQgHACgGgDQgHgEgCgHQgzitigl3QgDgHgJgDQhOgWh9g5Qh2g3gKgCQgIgCAeBOQAYBkgxBdQgOAchAAsQhNA0gMAMQgIAIg2BPQguBCgcAOQhdAxhkgXQgZgGghgNQgUgIABAEQACAKA3B3QA6B8AWBOQACAJAIADQBuAvB6AxQDSBUBpAfQAHADAEAGQAEAHgCAHIgxCxQgCAHgHAEQgEACgEAAIgGgBg");
	this.shape_4.setTransform(101.9036,101.5496);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgzBXIArjFIA8AHIg6DWg");
	this.shape_5.setTransform(118.05,173.675);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AhsABIDCg3IAXA4IjQA1g");
	this.shape_6.setTransform(173.825,116.925);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#F9BD9C").s().p("AAeCuIgehXQgUg7gGACQgIADAjB8QAIAbgPAGQgKAEgIgIQgGgGgGgQIgdhbQgUg/gFgBQgFgBgHAUIgMAfQgNAXgMgBQgIAAgEgIQgDgIACgKQAEgPAFgmQAFggAFgOQAFgtAHgeQAOg2AxgSQAggLAaAIQAaAIAaAdQAZAcAfBPQAWA2AUBBQAEAQAAAHQgBAKgIADQgIADgIgGQgHgFgEgLIgUg4QgOglgFACQgGACAQAzQALAnAOAkQAFALgCAJQgCALgJADQgJADgHgHQgHgFgEgKQguiAgJAEQgFABAWBEIAbBPQAEANgCAJQgCAKgJADIgGABQgNAAgKgYg");
	this.shape_7.setTransform(179.3254,134.2196);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#F9BD9C").s().p("AhBB+QgrgRgVgJQgkgSgSgSQgfghgGgfQgHgfAQgjQAag4A9gHQBCACAUgDQAYgCATADQAWAFAHAKQAEAHgDAPQgDAOACABQAbANAsARQAsARAiAKQATAGALAJQANAJgFALQgEAKgJACQgKADgSgFQghgIg8gRQgsgMgBAFQgBABAEAKQADAJgEAJQgEAKgJAGIgKAFIABAMQABAKgEAKQgDAHgJAFIgJAHIABAHQABAHgDAKQgFALgSADIgHAAQgPAAgRgGg");
	this.shape_8.setTransform(137.4506,177.7429);

	this.instance = new lib.Path();
	this.instance.parent = this;
	this.instance.setTransform(63.75,59.65,1,1,0,0,0,34,33.9);
	this.instance.alpha = 0.1016;

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#411918").s().p("AgvFEQh0gyhBh8IgFgKIgEgLQgEgLgDgNIgBgBQgNgygMh0QgLAAgSAKQAIg0AOgpQAIgbATgZQAPgTAMgJQgaAJgVAWQAGgUAPgXQAdgvAugUQAdgNAjgCQAdgBAcAHQgPgKgagDQgggFgXAKQAOgRAkgHQAzgKBEAVQBoAgA+BOQAWAdArBXIADAGQATAlAMAqQAcBfgWBYQgXBZhAAzQgQAMgTALQgzAag3AAQg1AAg5gZg");
	this.shape_9.setTransform(328.0889,328.5711);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#ECAE7E").s().p("AhJB2QgNgGgKgKQgUgUgIgeQgLgjATgWQAggqA2gjQA7goAnABQAQAAARAQQALAKAJANQAQAVgQAIQgoASg/A+Qg8A9gKAcQgDAGgGAAQgFAAgHgEg");
	this.shape_10.setTransform(240.6788,337.1099);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#ECAE7E").s().p("AhSB9QglgcgDgQQgHgmAshDQAog8AqgiQAXgSAjAKQAdAIAUAUQALALAGAMQAIARgLAEQgcAKg/A9QhABBgSAnQgEAKgIAAQgHAAgIgGg");
	this.shape_11.setTransform(338.2934,241.5337);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#F3B783").s().p("AgtKBQhrgCiNgfQg3gMi/g0IgkgJQgkgKgMgMQgPgNAFgZICFiLQAGgBALAAQAVAAAUAKQApAUBhAXIBuAYQAGABAHghQALg3AKgiQAxiaB9h/QCSiQCPgfQAogIApAAQAcABgBgDIhJkJQgGgRAGgUIAHgQIB+iOQAlgSAWAvQAKAUAPBEIA3D2QAbCMgCBoQgEEQjNDNQjADAkOAAIgJAAg");
	this.shape_12.setTransform(297.7427,297.5039);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#F9BD9C").s().p("AhmhSIgOgQQgmgwgpitQgDgPABgHQACgJAIgDQAHgCAHAGQAHAFACAKIAQA3QALAlAFgCQAGgBgMgyQgJgogLghQgDgLACgJQADgKAIgCQAJgCAHAGQAGAGADAKQAKAmAMAjQARAyAGgCQAEgBgRhBIgUhNQgDgMACgJQADgKAIgCQARgGAJAdIAYBVQAQA5AFgCQAIgCgah3QgFgbAPgEQARgFAJAfQAGATAPBGQAPA9AFABQAEABAIgTIAOgcQAOgVALABQAIACADAHQADAIgEAJQgEAOgIAjQgGAfgGAOQgCAFgHAjQgGAggKASICdGZIihCDg");
	this.shape_13.setTransform(228.2275,301.7312);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#F9BD9C").s().p("Ak3CJQgHgBgEgHQgFgKARgTQAEgEAUgRQAQgNgCgDQgCgEg/ABIhbABQgQAAgHgEQgJgEAAgKQAAgQAbgCQB6gGAAgIQAAgFg7gBIhYgBQgegBABgRQAAgJAIgFQAIgEANAAQCTAAAAgGQAAgGg1gDQghgDgrAAQgZAAAAgTQgBgIAKgFQAIgFALABQAjABAogBQA0gBgBgHQABgFgngBIg4gBQgLAAgHgFQgIgFABgIQAAgIAIgEQAHgDAPgBQBCgCA3ADQBQAEAhAOQARAGAMAJII6A8IA4AkIiMCLInxhSQgMAHgYALQgUAKgHAFQgKAJgdAOQggAQgMAIQgHAFgHAAIgDAAg");
	this.shape_14.setTransform(297.3996,234.6883);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#972528").s().p("Ah6gQQAagdAVgWQAcgcAfgbICLDHIgWAVIgDADIgVAWg");
	this.shape_15.setTransform(318.3,314.075);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#474543").s().p("AhhiPQAbgEAgAJQBBASAeBBQAXAxALBQQAGApABAeg");
	this.shape_16.setTransform(341.075,306.4135);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#474543").s().p("ABLBbQhQgLgygXQhBgegShBQgGgUAAgWIABgRIEgDDg");
	this.shape_17.setTransform(309.225,339.125);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AkWBcQA2hyBphpQBqhpBigxIDCEcIkXEXg");
	this.shape_18.setTransform(322.675,320.1);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#1F1814").s().p("AhvFXQgwgdgxhEQgSgYgNgcQgHgRAAACQgBAdAnBJIAnBDIgrgfQgygvghhMQgmhXAShqQATh4BZhkIADgDIATgUQBkhkB/gOQCAgOBQBRQAyAyAPBGQAPBFgTBMIgOAsQgaBEgzA9IgSAVIgQAPIgSAQQgIAIgHAEQg9AthDAJQgqAFgZgIQgKgEgBAEQgBADARAPQATARAdAGIAbADIgeASQgjANgigRQgZgNgUgaIgVgeQgPgOA9BtIAHALg");
	this.shape_19.setTransform(341.18,60.2036);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#F1E2A8").s().p("AkMI0QBtgeDyhiIDdhcQAWhPA6iAQA5h7ACgJQABgEgdgDQgugFgkgKQiOgnh/h/Qh3h4gihwQgJgcgEgiQgDgUgEABQgJACh8A3QiBA6hQAVIAJDTQAKDvAICQIjeAgIgUlHQgVlLAEgeQAHg5AkgnQAcggA1gYQGEi5DRgPQD+gSDDDDQDQDQgKDtQgFBxgzCTQgrB9hcDDQgVAsglAeQgiAag9AYIonDhg");
	this.shape_20.setTransform(304.5974,106.6988);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("Ag5heIA4gOIA8DCIg+AWg");
	this.shape_21.setTransform(281.5,173.45);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FED393").s().p("AhbCaQgKgBgDgIQgDgIAGgIQAGgHAKgEIA4gUQAlgOgCgFQgCgGgyAQQgrANggANQgLAEgKgCQgLgCgCgJQgDgJAGgHQAFgHAKgEQCAgugDgJQgCgFhDAWIhQAbQgMAEgKgCQgKgCgDgIQgHgSAegMIBXgeQA7gUgCgGQgDgIh8AjQgbAIgGgPQgDgKAHgIQAHgGAPgGIBcgdQA+gUABgFQABgEgUgIIgfgMQgXgNABgMQABgIAIgEQAHgDALACQAPAEAlAFQAgAFAOAFQAuAFAdAHQA2AOASAxQALAggIAaQgIAagcAaQgdAZhOAfQg2AWhCAUQgOAEgHAAIgCAAg");
	this.shape_22.setTransform(265.947,178.0754);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AhrgJIDHgiIAQA7IjVAcg");
	this.shape_23.setTransform(251.25,131.175);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FED393").s().p("AgZDLQgJAAgEgJQgFgJABgOIAFhTQAEhHgFAAQgGgBgHA3QgFAmgDAqQgBALgFAHQgGAIgJgBQgJAAgFgKQgEgIABgMQAEgnABgoQACg3gGAAQgGgBgEApIgEA7QgBALgGAIQgGAHgIgBQgJgBgDgJQgDgHABgQQAChFAHg5QAKhUARgiQARgjAYgOQAYgPAhADQAzAFAbAwQAWA3AKAOQAIANANAfQAPAjAHAMQAGAJgCAIQgBAJgIADQgLAEgTgTIgUgaQgMgRgEACQgFACgDBBIgFBfQgCAjgTgCQgRgCABgcIAAhMQgCg1gFAAQgFgBgFA/IgGBcQgFAdgQAAIgCAAg");
	this.shape_24.setTransform(253.5869,146.7303);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#CC8D61").s().p("AloGMQgmgfgbgrQApAJAngFQBPgMgFhJQgCgtAUgiQgHgKABgNQAAgMAKgJIAJgKQgTgvAAgyQAAgwAQgyQAGgTAHgQQAphlBjhiIAOgOIABAAIAOgNQBkhUBvAFQBpAFBTBSQBVBWACBuQADB0hfBmIgOAOQhmBmhkApQgRAHgSAGQgoAMgqADQhJACg8giIgDAEQgKAJgMABQgNAAgKgHIAAAAQgIATACAXQABANAEAaQAFAvgsAoQgdAbghAAQgkAAgpghg");
	this.shape_25.setTransform(47.9032,347.0455);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AkKgxIFqjbQAKANAdAqQAWAhANAMQAKALAgAYIA3AsIjYFmg");
	this.shape_26.setTransform(71.525,323.675);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#3F3F3F").s().p("AjQMJQiTg2iFiFQhyhygth4QgrhxAOiGQAMh1A8ifQAsh0BjjSQAVgsAmgdQAigbA8gYQA1gUH4itQAIgDAHAEQAHADACAIIAwCxQACAHgDAHQgEAGgHACQiWAsmOCnQgIAEgCAIQgWBOg5B9Qg3B3gCAJQgBAFAUgIQAhgNAYgGQBlgXBcAwQAcAPAnA3QAwBEAJAJIBRBCQA9AxARAhQAnBNgTBuQgKA5gVBJQgCANEWheQAGgCAEgFQAEgFgBgGIgdndQAAgHAFgGQAFgFAHgBIC4gTQAHgBAGAFQAGAFAAAHIAsJbQACAfgSAYQgSAZgeAIIjZA/QjrBBhWAOQguAHgsAAQhkAAhggjg");
	this.shape_27.setTransform(87.7025,296.2661);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#E1BB93").s().p("AAbDJQgzgDgdgvQgQgagSgqQgJgMgOgeQgQgjgIgMQgFgJABgIQABgJAIgDQALgFATATIAVAZQANARAEgCQAEgCABhBIAChgQABgiATABQARAAABAdQACCAAIABQgDhvAEgoQACggASACQATABgBAeQAAAVAEA9QAEBFAFAAQAAhkACgiQABgLAEgHQAGgIAJABQAJAAAGALQAGAKAAAMIAABNQAAAzAGABQADAAABgmIACg6QABgLAFgHQAFgIAIABQAJAAAEAJQADAIAAAQIADB8QgBBTgPAhQgQAjgXAQQgVANgcAAIgIAAg");
	this.shape_28.setTransform(136.8089,278.2831);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#E1BB93").s().p("AA3CZQgQgEglgFQgggGgOgEQgQgFg6gHQg3gOgRgxQgMggAIgaQAIgbAdgZQAcgZBPgfQA2gWBBgUQAPgEAIAAQAKABADAIQADAIgGAIQgFAHgLAEIg4AUQglAOACAGQACAFAzgQQApgMAigNQALgFAJACQALACADAJQADAIgGAIQgGAHgKAEQh/AuADAJQACAICSg0QANgEAJACQAKACADAJQAHARgdALQgTAIhEAXQg7AUACAGQACAHB8giQAbgIAGAPQAEAKgIAIQgGAGgQAGIhbAdQg/AUgBAFQgBAEAUAIIAfAMQAYANgCAMQAAAIgIAEQgFACgFAAIgIgBg");
	this.shape_29.setTransform(132.0454,220.7996);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#E3989C").s().p("AlGBTID0mZICdBeIgIAOQgFAIgIADQgeALgNAcQgLAYAGAbQAGAbAWAQQAcAVAigHQAigGARgeQAOgXgEgbQgCgJAFgHIAIgOICfBeIhmCrIgOgJQgIgFgDgIQgLgdgcgNQgZgMgaAHQgbAGgQAWQgVAbAHAiQAGAiAeARQAXAOAbgEQAIgBAIAFIAOAIIhWCRg");
	this.shape_30.setTransform(153.85,217.375);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#D48A7D").s().p("AlGhKICRhWIgIgPQgEgHgJgEQgZgIgOgYQgSgeAKggQALghAfgPQAZgLAaAHQAbAHAQAWQASAZgEAfQgCAIAFAJIAJAOICqhmIBeCeIgOAJQgHAEgJgBQgfgFgZATQgWAQgHAbQgHAaALAZQAOAgAhAJQAhAKAdgRQAYgNAJgaQADgIAIgFIAOgIIBeCdImZD0g");
	this.shape_31.setTransform(219.925,258.1139);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#C2F0F3").s().p("AioCPIgQAGQgIAEgEAIQgNAXgZALQgfANgfgOQgggPgKghQgHgaAKgaQALgZAYgMQAbgPAeAIQAJADAIgEIAPgGIhIipICrhJIAHAQQADAHgCAKQgIAbALAYQANAfAhAMQAgAKAegRQAXgNAKgZQALgagJgaQgKgegbgOQgHgEgDgIIgGgQICnhHIC6G3Im3C6g");
	this.shape_32.setTransform(252.6438,175.6);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#E0EBB9").s().p("AjZFFQgWgQgHgbQgHgaALgZQANgdAdgLQAIgEAEgHIAIgOIighbIDsmeIGeDsIhaCeIAOAIQAIAEAJgBQAegFAaASQAWAPAIAbQAIAbgLAYQgOAgghALQggALgegRQgYgOgJgZQgEgJgHgDIgPgJIhcCiIifhcIgIAPQgFAHACAJQAEAbgNAYQgRAegiAHQgJACgIAAQgYAAgUgPg");
	this.shape_33.setTransform(191.252,140.4505);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#C3CDD1").s().p("AoGT+QkChpjGjGQjGjHhpkBQhlj5AAkOQAAkNBlj5QBpkBDGjHQDGjGEChoQD5hmENAAQEOAAD5BmQEBBoDHDGQDGDHBpEBQBlD5AAENQAAEOhlD5QhpEBjGDHQjHDGkBBpQj5BkkOAAQkNAAj5hkg");
	this.shape_34.setTransform(200.275,199.9);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#103F58").s().p("AjzDBIG/m0IAoAoIm0G/g");
	this.shape_35.setTransform(86.975,309.775);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#4C8DA9").s().p("AnthzIH7l5IHgHfIl6H6g");
	this.shape_36.setTransform(84,312.775);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#25676D").s().p("AjzjKIAogpIG/G0IgzAzg");
	this.shape_37.setTransform(296.675,297.05);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#2E7F86").s().p("AnsgOIHfneIH6F5IpgJhg");
	this.shape_38.setTransform(299.675,300.05);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#1F1D1B").s().p("AjzDMIG0m/IAzA0Im/Gzg");
	this.shape_39.setTransform(310.525,88.2);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#605D5A").s().p("AnsAOIF5n6IJgJgIn6F5g");
	this.shape_40.setTransform(313.525,85.225);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#453019").s().p("AjzjAIAzgzIG0G/IgoAog");
	this.shape_41.setTransform(88.175,87.45);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#A89787").s().p("AnsB0IJgpgIF5H6InfHfg");
	this.shape_42.setTransform(85.175,84.475);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#182735").s().p("AAAHmQhsgOhlgwQhmgwhHhHQiHiHAfiqQAdiXCZiZQCZiaCXgcQCqgfCHCHQBHBHAwBmQAwBlAOBsQAiD2iJCJQhuBui1AAQgsAAgwgHg");
	this.shape_43.setTransform(302.8388,307.4311);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#19354E").s().p("AmEHJQgugJgYgkQAbASAkABQAlABAigTQDoiCC7i8QC8i7CCjoQATgigBglQgBgkgTgbQAlAYAJAuQAJAwgZAsQiCDoi8C7Qi7C8joCCQggASgjAAQgMAAgNgCg");
	this.shape_44.setTransform(336.6191,341.0191);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#182735").s().p("AmCHQQgzgNgUgsQgTgsAQguQARguArgYQDLhyCmikQCkilByjMQAYgrAugRQAugRAsAUQAsAUANAyQAOAzgcAxQiCDoi8C7Qi7C8jnCCQgiATgiAAQgQAAgQgFg");
	this.shape_45.setTransform(335.6941,340.1055);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#182735").s().p("AAAHnQiXgciZiaQiaiZgciYQgfipCHiHQBHhHBmgwQBlgwBsgOQD2giCJCJQCICJghD1QgPBtgvBlQgwBmhHBHQhuBuiEAAQgfAAgggGg");
	this.shape_46.setTransform(306.2733,90.8189);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#19354E").s().p("AGvGMQABgmgTgiQiCjni8i7Qi7i8joiCQgigTglABQgkABgbASQAYgkAugJQAwgJAsAZQDoCCC7C8QC8C6CCDoQAZAtgJAwQgJAuglAYQATgcABgjg");
	this.shape_47.setTransform(346.9691,49.9809);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#182735").s().p("AE9HNQgugRgYgrQhyjMikilQimikjLhyQgrgYgRguQgQguATgsQAUgsAzgNQAzgNAxAbQDnCCC7C8QC8C6CCDoQAcAygOAzQgNAygsAUQgYAKgYAAQgVAAgVgHg");
	this.shape_48.setTransform(346.0441,50.8819);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#182735").s().p("AkwF/QhHhHgwhmQgwhlgOhtQgij1CJiJQCJiJD1AiQBtAOBlAwQBmAwBHBHQCHCHgfCpQgdCYiZCZQiZCaiYAcQgfAGgfAAQiFAAhthug");
	this.shape_49.setTransform(89.1689,86.6189);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#19354E").s().p("AnIGFQgJgwAZgsQCCjoC8i7QC6i8DoiCQAtgZAvAJQAvAJAYAkQgcgSgjgBQgmgBgiATQjnCCi7C8Qi8C6iCDoQgTAiABAmQABAjASAcQgkgYgJgug");
	this.shape_50.setTransform(48.3309,45.9309);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#182735").s().p("AmWHKQgsgUgNgyQgOgzAcgxQCCjoC8i7QC6i8DoiCQAygbAzANQAyANAUAsQAUAsgRAuQgRAugrAYQjLByimCkQikCmhyDLQgYArguARQgVAHgVAAQgYAAgYgKg");
	this.shape_51.setTransform(49.221,46.8319);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#182735").s().p("Al+F/QiJiJAij2QAOhsAwhlQAwhmBHhHQCHiHCpAfQCYAcCZCaQCaCZAcCXQAfCqiHCHQhHBHhmAwQhlAwhtAOQgvAHgsAAQi1AAhuhug");
	this.shape_52.setTransform(86.6189,310.1811);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#19354E").s().p("AEpG5QjoiCi7i8Qi8i7iCjnQgZgtAJgvQAJgvAkgYQgSAcgBAkQgBAlATAiQCCDoC8C6QC7C8DoCCQAiATAlgBQAjAAAcgTQgYAkguAJQgNACgMAAQgjAAgggSg");
	this.shape_53.setTransform(45.9309,350.9941);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#182735").s().p("AEgHCQjoiCi7i8Qi8i7iCjnQgbgyANgyQANgzAsgUQAsgTAuAQQAuARAYArQByDLCkCmQCmCkDLByQArAYARAuQARAugUAsQgUAsgyANQgRAEgQAAQgiAAghgSg");
	this.shape_54.setTransform(46.8372,350.0915);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.instance},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.M03_TMR_DESICION, new cjs.Rectangle(0,0,392.9,397), null);


(lib.instruccionesmc4t1TMR = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_46 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(46).call(this.frame_46).wait(1));

	// flecha 
	this.instance = new lib.lapizmueve("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(-18.2,14.4,0.2312,0.2312,0,0,0,23.4,23.6);
	this.instance.alpha = 0.0703;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({regY:23.4,scaleX:1,scaleY:1,y:14.3,alpha:1},8,cjs.Ease.get(1)).to({_off:true},1).wait(38));

	// flecha mueve
	this.instance_1 = new lib.lapizmueve("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(-18.2,14.3,1,1,0,0,0,23.4,23.4);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(9).to({_off:false},0).wait(5).to({x:-8.7},0).to({x:275.3},32,cjs.Ease.get(1)).wait(1));

	// tapa circulo
	this.instance_2 = new lib.tapageneralgris("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(3089.65,91.55,29.2175,2.0526,0,0,0,106.8,44.6);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(14).to({_off:false},0).to({scaleX:7.8318,x:1036.5,y:91.6},17,cjs.Ease.get(1)).to({scaleX:2.353,x:510.5,y:91.55},14).to({_off:true},1).wait(1));

	// Instruccion
	this.text = new cjs.Text("Selecciona tus recomendaciones.", "18px 'Arial'", "#606060");
	this.text.lineHeight = 23;
	this.text.lineWidth = 417;
	this.text.parent = this;
	this.text.setTransform(-14.4,6.35);
	this.text._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text).wait(14).to({_off:false},0).wait(33));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-37.2,-9.3,441.8,52);


(lib.ilustracion2222 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.M03_TMR_DESICION();
	this.instance.parent = this;
	this.instance.setTransform(125.15,110,0.3551,0.3551,0,0,0,196.6,198.7);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(55.4,39.5,139.5,140.9);


(lib.HOMBRE1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D6D8D8").s().p("AgyB+QAGgTAOgoQAQgtAEgEQAEgDgBgMQgCgUABgNIAAhPQAIgQALgHQAXgPARApIgFAoQgFAtgGAUIgCAZQgCAJgWApIghA/g");
	this.shape.setTransform(29.025,36.8106);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#747887").s().p("AgEABIAEgOIAFANIgFAOg");
	this.shape_1.setTransform(22.7,46.95);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#747887").s().p("AgEAAIAEgOIAFAOIgFAPg");
	this.shape_2.setTransform(22.7,43.75);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#747887").s().p("AgEABIAEgPIAFAOIgFAPg");
	this.shape_3.setTransform(22.7,40.375);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#747887").s().p("AgEABIAEgPIAFAOIgFAOg");
	this.shape_4.setTransform(33.85,27.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#747887").s().p("AgFAAIAFgOIAGAOIgGAPg");
	this.shape_5.setTransform(35,27.975);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#747887").s().p("AgCAEIgIgNIAOAFIAHAOg");
	this.shape_6.setTransform(34.175,22.675);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#747887").s().p("AgCAEIgIgNIAOAFIAHAOg");
	this.shape_7.setTransform(32.7,22.575);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#747887").s().p("AgFACIABgPIAJAMIgBAPg");
	this.shape_8.setTransform(34.55,25);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#747887").s().p("AgEACIABgPIAJAMIgCAPg");
	this.shape_9.setTransform(35.85,25.5);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#747887").s().p("AgFAAIAFgNIAGANIgGAPg");
	this.shape_10.setTransform(36.2,28.65);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#747887").s().p("AgEAAIAGgNIADAOIgHANg");
	this.shape_11.setTransform(33.75,30.775);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#747887").s().p("AgEAAIAGgNIADAOIgHANg");
	this.shape_12.setTransform(33.15,33.9);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#747887").s().p("AgFAAIAHgNIAEAOIgIANg");
	this.shape_13.setTransform(34.85,31.075);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#747887").s().p("AgFAAIAHgNIAEAOIgIANg");
	this.shape_14.setTransform(35.9,31.925);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#747887").s().p("AgFAAIAHgOIAEAPIgIANg");
	this.shape_15.setTransform(35.275,34.9);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#747887").s().p("AgFAAIAIgNIADAOIgIANg");
	this.shape_16.setTransform(34.275,34.075);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#747887").s().p("AgEABIAEgPIAFAOIgFAPg");
	this.shape_17.setTransform(32.8,37.225);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#747887").s().p("AgEAAIAEgOIAFAOIgFAPg");
	this.shape_18.setTransform(32.025,49.3);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#747887").s().p("AgEAAIAEgPIAFAPIgFAQg");
	this.shape_19.setTransform(33.075,49.725);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#747887").s().p("AgCAAIAFgOIAAANIgDAQg");
	this.shape_20.setTransform(33.875,50.35);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#747887").s().p("AgEAAIAEgPIAFAPIgFAQg");
	this.shape_21.setTransform(32.25,46.025);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#747887").s().p("AgEAAIAEgPIAFAPIgFAQg");
	this.shape_22.setTransform(33.3,46.425);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#747887").s().p("AgCAAIAFgPIAAAOIgDARg");
	this.shape_23.setTransform(34.125,47.1);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#747887").s().p("AgEAAIAEgPIAFAPIgFAQg");
	this.shape_24.setTransform(31.45,42.925);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#747887").s().p("AgEAAIAEgPIAFAPIgFAQg");
	this.shape_25.setTransform(32.65,42.875);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#747887").s().p("AgEAAIAEgPIAFAPIgFAQg");
	this.shape_26.setTransform(33.7,43.275);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#747887").s().p("AgEAAIAEgPIAFAPIgFAQg");
	this.shape_27.setTransform(33.9,40.125);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#747887").s().p("AgCAAIAFgPIAAAOIgDARg");
	this.shape_28.setTransform(34.475,43.925);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#747887").s().p("AgCAAIAEgPIABAOIgCARg");
	this.shape_29.setTransform(34.85,40.775);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#747887").s().p("AgFAAIAFgNIAGANIgGAOg");
	this.shape_30.setTransform(28.275,49.55);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#747887").s().p("AgFAAIAFgNIAGANIgGAPg");
	this.shape_31.setTransform(29.6,49.35);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#747887").s().p("AgFAAIAFgOIAGAOIgGAPg");
	this.shape_32.setTransform(30.875,49.25);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#747887").s().p("AgFABIAFgPIAGAOIgGAPg");
	this.shape_33.setTransform(29.75,46.175);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#747887").s().p("AgFABIAFgPIAGAOIgGAPg");
	this.shape_34.setTransform(31.125,46.025);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#747887").s().p("AgFAAIAFgNIAGANIgGAOg");
	this.shape_35.setTransform(32.875,40.1);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#747887").s().p("AgFAAIAFgNIAGANIgGAPg");
	this.shape_36.setTransform(35.075,37.75);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#747887").s().p("AgFABIAFgPIAGAOIgGAOg");
	this.shape_37.setTransform(33.95,37.15);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#747887").s().p("AgEABIAEgPIAFAOIgFAPg");
	this.shape_38.setTransform(22.7,37.225);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#747887").s().p("AgCAAIAAgMIAFANIgBAMg");
	this.shape_39.setTransform(21.875,46.95);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#747887").s().p("AgDAAIACgNIAFANIgDAOg");
	this.shape_40.setTransform(21.775,43.6);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#747887").s().p("AgDAAIACgNIAFANIgDAOg");
	this.shape_41.setTransform(21.775,40.45);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#747887").s().p("AgEABIAEgPIAFAOIgFAPg");
	this.shape_42.setTransform(21.675,37.275);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#747887").s().p("AgEABIAEgPIAFAOIgFAPg");
	this.shape_43.setTransform(21.675,34.3);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#747887").s().p("AgEABIAEgPIAFAOIgFAPg");
	this.shape_44.setTransform(22.625,34.3);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#747887").s().p("AgEABIAEgPIAFAOIgFAPg");
	this.shape_45.setTransform(21.6,31.475);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#747887").s().p("AgEAAIAEgNIAFANIgFAPg");
	this.shape_46.setTransform(22.625,31.45);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#747887").s().p("AgEAAIAHgNIACAOIgHANg");
	this.shape_47.setTransform(22.9,28.425);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#747887").s().p("AgEAAIAJgMIAAAOIgJAMg");
	this.shape_48.setTransform(23.725,25.5);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#747887").s().p("AgBAAIAGgMIAAAOIgJAMg");
	this.shape_49.setTransform(24.65,22.8);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#747887").s().p("AgFABIAFgPIAGAOIgGAPg");
	this.shape_50.setTransform(23.575,47.075);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#747887").s().p("AgFABIAFgPIAGAOIgGAPg");
	this.shape_51.setTransform(27.475,29.025);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#747887").s().p("AgFABIAFgPIAGAOIgGAPg");
	this.shape_52.setTransform(27.3,31.875);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#747887").s().p("AgFABIAFgPIAGAOIgGAPg");
	this.shape_53.setTransform(27.25,34.675);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#747887").s().p("AgFABIAFgPIAGAOIgGAPg");
	this.shape_54.setTransform(27.475,37.525);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#747887").s().p("AgFAAIAFgNIAGANIgGAPg");
	this.shape_55.setTransform(26.25,40.45);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#747887").s().p("AgFABIAFgPIAGAOIgGAOg");
	this.shape_56.setTransform(26.15,37.7);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#747887").s().p("AgFABIAFgPIAGAOIgGAOg");
	this.shape_57.setTransform(26.05,34.9);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#747887").s().p("AgFABIAFgPIAGAOIgGAPg");
	this.shape_58.setTransform(25.95,32.025);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#747887").s().p("AgFAAIAIgNIADAOIgJANg");
	this.shape_59.setTransform(26.275,28.975);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#747887").s().p("AgEgBIAKgLIAAAOIgLALg");
	this.shape_60.setTransform(27.25,26.075);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#747887").s().p("AgCgEIAIACIgLAHg");
	this.shape_61.setTransform(28.4,21.675);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#747887").s().p("AgCgFIAIACIgLAJg");
	this.shape_62.setTransform(29.825,21.55);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#747887").s().p("AgEgBIAKgLIAAAOIgLALg");
	this.shape_63.setTransform(28.675,23.425);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#747887").s().p("AgFAAIAFgOIAGAOIgGAPg");
	this.shape_64.setTransform(25.15,43.4);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#747887").s().p("AgFABIAFgPIAGAOIgGAPg");
	this.shape_65.setTransform(23.575,43.875);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#747887").s().p("AgFABIAFgPIAGAOIgGAOg");
	this.shape_66.setTransform(25.1,40.5);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#747887").s().p("AgFABIAFgPIAGAOIgGAOg");
	this.shape_67.setTransform(23.575,40.5);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#747887").s().p("AgFAAIAFgNIAGANIgGAPg");
	this.shape_68.setTransform(24.975,37.75);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#747887").s().p("AgFABIAFgPIAGAOIgGAOg");
	this.shape_69.setTransform(23.575,37.35);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#747887").s().p("AgFABIAFgPIAGAOIgGAPg");
	this.shape_70.setTransform(24.875,34.975);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#747887").s().p("AgFABIAFgPIAGAOIgGAPg");
	this.shape_71.setTransform(24.775,32.075);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#747887").s().p("AgFAAIAIgNIADAOIgJANg");
	this.shape_72.setTransform(25.125,29.075);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#747887").s().p("AgEgBIAKgLIAAAPIgLALg");
	this.shape_73.setTransform(26.075,26.15);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#747887").s().p("AgEgBIAKgLIAAAPIgLALg");
	this.shape_74.setTransform(27.275,23.45);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#747887").s().p("AgFABIAFgPIAGAOIgGAOg");
	this.shape_75.setTransform(23.6,34.45);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#747887").s().p("AgFAAIAFgNIAGANIgGAOg");
	this.shape_76.setTransform(23.5,31.55);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#747887").s().p("AgFAAIAIgNIADAOIgJANg");
	this.shape_77.setTransform(23.825,28.525);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#747887").s().p("AgEgBIAKgLIAAAOIgLALg");
	this.shape_78.setTransform(24.8,25.625);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#747887").s().p("AgEgBIAKgLIAAAOIgLALg");
	this.shape_79.setTransform(25.975,22.925);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#805F50").s().p("AgDgIQADgGADABQAAAAABAAQAAAAABAAQAAAAAAAAQABABAAAAQABAMgGAIQgDAFgDACg");
	this.shape_80.setTransform(30.8141,10.1979);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#231F20").s().p("AAEgCQgRAEgEgHIAPgCIAKABQAKADAAALQgDgNgLADg");
	this.shape_81.setTransform(23.975,8.2);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#3F3231").s().p("AAfBMQgFgBgBgFIgLgvQAAgHgDgLQgDgOgFgHIgKgOQgLgIgVACQgSgBgFgCQgEgCABgFQAAgEAHgGIALgIIABAAQAIgFALgDIACAAIALgCQAwgJAVAgQAOAWgDAhQgDAmgJARQgFAIgFACIgEAFQgDADgDAAIgDgBg");
	this.shape_82.setTransform(29.0979,7.6725);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#35343A").s().p("AgBAAIABgDIACgBIAAAFIgCAEQgCgCABgDg");
	this.shape_83.setTransform(23.28,50.6);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#35343A").s().p("AAAADQgDgCgCABQACgFgBgBIAEABQAEACABABQACADgEACIgDgCg");
	this.shape_84.setTransform(25.2833,50.65);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#C3C3C1").s().p("AgFAAQAAgFAFAAQAGAAAAAFQAAAGgGAAQgFAAAAgGg");
	this.shape_85.setTransform(24.1,50.375);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#35343A").s().p("AgGAAQAAgGAGAAQADAAACACQACACAAACQAAAHgHAAQgGAAAAgHg");
	this.shape_86.setTransform(24.125,50.375);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#805F50").s().p("AAEAwQgHgCgGgEQgIgHgCgKQgCgGAAgGQACgNAKgWQACgEAFgGQAEgFAAgEIADgGIAPAGQgEAIADAKIABAIQAAAJgEAJQgEAJAAAIQABAJAFAFQAEADAAAEQAAABAAABQAAABgBAAQAAABAAAAQgBABAAAAIgHACIgDAAIgGAAg");
	this.shape_87.setTransform(23.62,54.025);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#805F50").s().p("AgDgJQADgGADABQABAAAAAAQAAAAABAAQAAAAABAAQAAABAAAAQACANgHAJQgCAFgEACg");
	this.shape_88.setTransform(31.1882,10.4481);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#947668").s().p("AgGADIgBgDQAAgBAGAAIAJgCQgEAEgFACIgDABIgCgBg");
	this.shape_89.setTransform(22.375,14.3625);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#947668").s().p("AgIgCIAHAAQAHAAADACIgPADQgDgDABgCg");
	this.shape_90.setTransform(22.2857,13.975);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#473834").s().p("AgEAAQAAgEAEAAQAFAAAAAEQAAAFgFgBQgEABAAgFg");
	this.shape_91.setTransform(23.075,9);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#947668").s().p("AgCAFQgKgBgDgDIgBAAIAAAAIAEgDQAFgDAHAAIAFABQAHABAEADIABAAIgBAAQgGAGgKAAgAgOABQADACAJABQALACAGgGIgLgDIgEgBQgJAAgFAFg");
	this.shape_92.setTransform(23.625,9.025);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#FFFFFF").s().p("AgJAEIgGgCQACgEAGgBIAHgBQAGgBAKAFQgFAFgLAAIgBAAIgIgBg");
	this.shape_93.setTransform(23.6,8.9973);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#B6BCC5").s().p("AgfAKIA8geIAFAUQgCAKhBALg");
	this.shape_94.setTransform(28.95,19.55);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#ADB2B2").s().p("AgCCmIhCgEQgIixgDgYQgCgPAWguIAWgrIBJgWIAJAHQALAJAHAOQAaAsgNBFQgbCQAJAhQAEALg0AAIgMAAg");
	this.shape_95.setTransform(28.7611,36.0828);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#805F50").s().p("AgPBVQADgPgCgEQgCgEgNADIgTAEQgIAAgFgHQgBgCABgFIABgHIAAgBIgDgJQgCgDABgEIABgIIgDgBQgFgBgCgBQgDgCAAgDIABgDQAEgMAFgHIAEgHIABgsQAHgcAcgLQAPgGAMAAIAlAHQAlAPACAwQABAvgSAWQgIALgKABQgHATgEAaIgyALIAEgTg");
	this.shape_96.setTransform(27.9308,10.525);

	this.instance = new lib.brazo();
	this.instance.parent = this;
	this.instance.setTransform(23.25,30.4,0.9989,0.9989,43.1659,0,0,10.2,14.5);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#805F50").s().p("AguAnQgIgEAAgFQABgEAGgHIAJgKQARgOAAgCQAAgBgBAAQAAAAAAAAQgBAAgBAAQAAAAgCAAIgHACQgIAAgFgFQgCgDAGAAIALABQACAAAIgDIAKgEQAGgBARADQAFAAAlgYIgGAgIgPADQgOAFgEAGQgGANgLAGIgLAJQgJAIgGACIgGABQgGAAgGgEg");
	this.shape_97.setTransform(6.2236,29.7375,0.9989,0.9989,43.1659);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#111011").s().p("AhOCeIgojgQgDgOAIgOQAPgdA2gCQA1gBgCgPIgLgPIBygCIAFAjQAFAlAAAJQAAAQgsASQg0AWgygRIASDFg");
	this.shape_98.setTransform(23.0591,68.175);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#353335").s().p("AhWCUQgRgrgRg0QgihnABguQAAgvBUgGQArgDA0AFQAPgBAXgFIBbALIgqAqQgJAIhMAhQgKAGgmAAQgJAAgbgDIgZgDIAgBZIAMAqQALAnAIALQAIALAAAIIgDAKQgBADgMAAQgRAAgrgGg");
	this.shape_99.setTransform(15.4496,67.69);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#5E4A39").s().p("Ag/AeQgCAAgBgHQgBgJAQgHIAngUIAHgQIBCADIAFAMQABAYgDADQgEADgdgCIgxAQg");
	this.shape_100.setTransform(16.0081,86.85);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#5E4A39").s().p("Ag/AeQgCAAAAgGQgCgKAQgHIAogUIAHgQIBBADIAFANQABAYgDADQgEACgdgBIgxAPg");
	this.shape_101.setTransform(8.0795,85.575);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_101},{t:this.shape_100},{t:this.shape_99},{t:this.shape_98},{t:this.shape_97},{t:this.instance},{t:this.shape_96},{t:this.shape_95},{t:this.shape_94},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.HOMBRE1, new cjs.Rectangle(0,0,36.8,89.9), null);


(lib.flechamueve = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.flechainstrucciones("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(22.55,22.35);

	this.instance_1 = new lib.circulo1instrucciones("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(24,24.45,1,1,0,0,0,105.2,10.2);

	this.instance_2 = new lib.circulo2instrucciones("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(23.3,23.45,1.6513,1.6513,0,0,0,14.1,14.2);
	this.instance_2.alpha = 0;

	this.instance_3 = new lib.circulo2instrucciones("synched",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(23.3,23.3,1,1,0,0,0,14.2,14.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(1.5,1.5,43.3,43.3);


(lib.escenario3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.CERRO();
	this.instance.parent = this;
	this.instance.setTransform(865.4,164.95,2.3063,2.3063,0,0,0,19.7,8.9);

	this.instance_1 = new lib.Cuadros_1();
	this.instance_1.parent = this;
	this.instance_1.setTransform(912.3,139.05,0.7737,0.7737,0,0,0,124.7,64.3);

	this.instance_2 = new lib.Maseta1();
	this.instance_2.parent = this;
	this.instance_2.setTransform(843.15,293.3,1,1,0,0,0,64.2,87.1);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#24272A").s().p("ABDCJQgnAAgcADIAAAAQh0gJgmARQACgrAKgtQAShaAlgMQA4gTAIgWQACgFAAgqIADgIQAGgIAMgBIAAAAQANABAGAIQADAEAAAEIABAWQAAAWABADQAIAWA4ATQAlAMASBaQAKAtACArQgYgLhAAAg");
	this.shape.setTransform(98.2647,66.4814,1.3956,1.3956);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#BDB971").s().p("AgqAoQgRgRAAgXQAAgWARgRQASgQAYAAQAZAAASAQQARARAAAWQAAAYgRAQQgSAQgZAAQgYAAgSgQg");
	this.shape_1.setTransform(98.474,87.1365,1.3956,1.3956);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#24272A").s().p("AgJCwIAAlfIATAAIAAFfg");
	this.shape_2.setTransform(98.16,24.5781,1.3956,1.3956);

	this.instance_3 = new lib.Pantallaamedias();
	this.instance_3.parent = this;
	this.instance_3.setTransform(53.7,244,0.8242,0.8242,0,0,0,65.7,142.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.4,0,915.1,380.5);


(lib.escenario1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.Cuadro_2();
	this.instance.parent = this;
	this.instance.setTransform(820.9,141.65,0.6531,0.6531,0,0,0,55.1,55.1);

	this.instance_1 = new lib.PINTURAS();
	this.instance_1.parent = this;
	this.instance_1.setTransform(801.15,134.85,0.7809,0.7809,0,0,0,106.4,37.4);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#24272A").s().p("ABDCJQgnAAgcADIAAAAQh0gJgmARQACgrAKgtQAShaAlgMQA4gTAIgWQACgFAAgqIADgIQAGgIAMgBIAAAAQANABAGAIQADAEAAAEIABAWQAAAWABADQAIAWA4ATQAlAMASBaQAKAtACArQgYgLhAAAg");
	this.shape.setTransform(197.2251,60.9822,1.28,1.28);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#BDB971").s().p("AgqAoQgRgRAAgXQAAgWARgRQASgQAYAAQAZAAASAQQARARAAAWQAAAYgRAQQgSAQgZAAQgYAAgSgQg");
	this.shape_1.setTransform(197.4171,79.9267,1.28,1.28);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#24272A").s().p("AgJCwIAAlfIATAAIAAFfg");
	this.shape_2.setTransform(197.1291,22.5494,1.28,1.28);

	this.instance_2 = new lib.Mueble1();
	this.instance_2.parent = this;
	this.instance_2.setTransform(902.55,271.45,1,1,0,0,0,45.8,103.7);

	this.instance_3 = new lib.Maseta1();
	this.instance_3.parent = this;
	this.instance_3.setTransform(808.5,301.7,0.751,0.751,0,0,0,64.3,87.1);

	this.instance_4 = new lib.Pantallaamedias();
	this.instance_4.parent = this;
	this.instance_4.setTransform(65.7,224.75,1,1,0,0,0,65.7,142.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,948.3,375.1);


(lib.escenario4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.Pisarron_2();
	this.instance.parent = this;
	this.instance.setTransform(745.95,234.7,1,1,0,0,0,113.7,188.7);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(411.2,15.6,498.50000000000006,407.9);


(lib.escenario2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.Pisarron_1();
	this.instance.parent = this;
	this.instance.setTransform(795.4,259.85,1.0038,1.0038,0,0,0,113.7,188.8);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#24272A").s().p("AAnBQQgVAAgSACIAAAAQhEgGgWALQACgZAFgbQALg1AVgHQAigLAEgNQABgCAAgZIACgFQAEgFAGAAIAAAAQAMAAABAKIABAbQAEANAiALQAVAHALA1QAGAbABAZQgOgHgmAAg");
	this.shape.setTransform(259.1614,69.9765,2.479,2.479);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#BDB971").s().p("AgYAYQgKgKAAgOQAAgNAKgJQALgKANAAQAPAAAKAKQAKAJAAANQAAAOgKAKQgKAJgPAAQgNAAgLgJg");
	this.shape_1.setTransform(259.3473,91.4199,2.479,2.479);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#24272A").ss(2).p("AAABnIAAjN");
	this.shape_2.setTransform(259.0375,26.2221,2.479,2.479);

	this.instance_1 = new lib.Mueble2();
	this.instance_1.parent = this;
	this.instance_1.setTransform(96.2,376.35,1.0038,1.0038,0,0,0,214.8,72.6);

	this.instance_2 = new lib.Cafetera();
	this.instance_2.parent = this;
	this.instance_2.setTransform(184.05,245.1,1.0038,1.0038,0,0,0,36.5,49.4);

	this.instance_3 = new lib.Cuadro_2();
	this.instance_3.parent = this;
	this.instance_3.setTransform(82.45,125.65,1.0038,1.0038,0,0,0,55.1,55.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.instance}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-119.4,-0.3,1028.9,449.6);


(lib.ch2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// Layer 2
	this.instance = new lib.respuestadecheckboxes("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(19.35,19.1,0.6364,0.6364,0,0,0,11.1,10.8);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).wait(1));

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AiUCVIAAkqIEpAAIAAEqg");
	this.shape.setTransform(18.575,18.65);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(3.7,3.7,29.8,29.900000000000002);


(lib.bullet6ultimomc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.text = new cjs.Text("Entender mejor a los colaboradores. Identificar habilidades, aspiraciones, fortalezas, áreas de oportunidad y las necesidades de desarrollo para generar planes de crecimiento que motiven y soporten los objetivos de la empresa.", "16px 'Arial'", "#333333");
	this.text.lineHeight = 17;
	this.text.lineWidth = 480;
	this.text.parent = this;
	this.text.setTransform(13.95,39);

	this.instance = new lib.bullet("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(3.5,49.1,1,1,0,0,0,5.9,5.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance},{t:this.text}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,37,496.2,86.1);


(lib.bullet6penultimomc111 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.text = new cjs.Text("Dar seguimiento a los planes de desarrollo establecidos.", "17px 'Arial'", "#333333");
	this.text.lineHeight = 28;
	this.text.lineWidth = 480;
	this.text.parent = this;
	this.text.setTransform(13.95,58);

	this.instance = new lib.bullet("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(3.5,68.1,1,1,0,0,0,5.9,5.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance},{t:this.text}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,56,496.2,86.1);


(lib.bullet5ultimomc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.bullet("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(3.5,30.8,1,1,0,0,0,5.9,5.9);

	this.text = new cjs.Text("Identificar, retener y desarrollar a personas con alto potencial (“Top Talent”) en la organización.", "16px 'Arial'", "#333333");
	this.text.lineHeight = 17;
	this.text.lineWidth = 456;
	this.text.parent = this;
	this.text.setTransform(15.75,21);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text},{t:this.instance}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,19,474.2,50.099999999999994);


(lib.bullet5penultimomc111 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.bullet("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(3.5,52.8,1,1,0,0,0,5.9,5.9);

	this.text = new cjs.Text("Brindar retroalimentación de los resultados a los colaboradores evaluados.", "16px 'Arial'", "#333333");
	this.text.lineHeight = 17;
	this.text.lineWidth = 456;
	this.text.parent = this;
	this.text.setTransform(15.75,43);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text},{t:this.instance}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,41,474.2,51);


(lib.bullet4ultimomc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.text = new cjs.Text("Contar con tablas de reemplazo para los diferentes niveles de la organización.", "17px 'Arial'", "#333333");
	this.text.lineHeight = 19;
	this.text.lineWidth = 458;
	this.text.parent = this;
	this.text.setTransform(14.8,6);

	this.instance = new lib.bullet("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(3.5,16.65,1,1,0,0,0,5.9,5.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance},{t:this.text}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,4,475.2,42);


(lib.bullet4penultimomc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.text = new cjs.Text("Elaborar los planes de desarrollo para cerrar las brechas de sucesiones.", "16px 'Arial'", "#333333");
	this.text.lineHeight = 17;
	this.text.lineWidth = 458;
	this.text.parent = this;
	this.text.setTransform(14.8,20);

	this.instance = new lib.bullet("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(3.5,30.65,1,1,0,0,0,5.9,5.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance},{t:this.text}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,18,475.2,51);


(lib.bullet2ultimomc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.bullet("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(3.5,1.8,1,1,0,0,0,5.9,5.9);

	this.text = new cjs.Text("Contar con una oferta sostenible de talento adecuado en el lugar y momento correctos.", "16px 'Arial'", "#333333");
	this.text.lineHeight = 17;
	this.text.lineWidth = 464;
	this.text.parent = this;
	this.text.setTransform(15.75,-8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text},{t:this.instance}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-10,482.2,48.1);


(lib.bullet2penultimomc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.bullet("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(3.5,12.4,1,1,0,0,0,5.9,5.9);

	this.text = new cjs.Text("Calibrar las evaluaciones de los colaboradores en conjunto con los pares del área.", "16px 'Arial'", "#333333");
	this.text.lineHeight = 17;
	this.text.lineWidth = 445;
	this.text.parent = this;
	this.text.setTransform(15.75,2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text},{t:this.instance}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,463.2,56.1);


(lib.bullet1ultimomc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.bullet("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(3.5,5.45,1,1,0,0,0,5.9,5.9);

	this.text = new cjs.Text("El mapeo de habilidades y fortalezas permite contar con un inventario de talento dentro de la organización.", "16px 'Arial'", "#333333");
	this.text.lineHeight = 17;
	this.text.lineWidth = 491;
	this.text.parent = this;
	this.text.setTransform(15.75,-4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text},{t:this.instance}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-6,509.2,42);


(lib.bullet1penultimomc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.text = new cjs.Text("Evaluar el potencial de los colaboradores con base en sus habilidades, compromiso y aspiraciones.", "16px 'Arial'", "#333333");
	this.text.lineHeight = 17;
	this.text.lineWidth = 489;
	this.text.parent = this;
	this.text.setTransform(15.75,16);

	this.instance = new lib.bullet("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(3.5,25.45,1,1,0,0,0,5.9,5.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance},{t:this.text}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,14,507.2,57.099999999999994);


(lib.bullet7ultimomc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.text = new cjs.Text("Anticipar las necesidades de desarrollo alineadas a la estrategia de la empresa.", "16px 'Arial'", "#333333");
	this.text.lineHeight = 17;
	this.text.lineWidth = 472;
	this.text.parent = this;
	this.text.setTransform(13.95,50);

	this.instance = new lib.bullet("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(3.5,58.6,1,1,0,0,0,5.9,5.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance},{t:this.text}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,48,488.2,51);


(lib.bullet3ultimomc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.text = new cjs.Text("Identificación adecuada de los mejores candidatos internos para los puestos con los que cuenta la organización.", "16px 'Arial'", "#333333");
	this.text.lineHeight = 17;
	this.text.lineWidth = 463;
	this.text.parent = this;
	this.text.setTransform(15.75,8);

	this.instance = new lib.bullet("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(3.5,18.15,1,1,0,0,0,5.9,5.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance},{t:this.text}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,6,481.2,38.8);


(lib.bullet3penultimomc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.text = new cjs.Text("Planear la sucesión de las posiciones seleccionadas.", "16px 'Arial'", "#333333");
	this.text.lineHeight = 17;
	this.text.lineWidth = 463;
	this.text.parent = this;
	this.text.setTransform(15.75,28);

	this.instance = new lib.bullet("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(3.5,38.15,1,1,0,0,0,5.9,5.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance},{t:this.text}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,26,481.2,38.8);


(lib.AS_LG_MOV_10ss = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,255,0.298)").s().p("AieF5QhKgfg4g5Qg4g5gghJQgghMAAhTQAAhSAghNQAghJA4g4QA4g5BKgfQBMggBSAAQBUAABLAgQBKAfA5A5QA4A4AfBJQAgBNAABSQAABTggBMQgfBJg4A5Qg5A5hKAfQhLAghUAAQhSAAhMggg");
	this.shape.setTransform(28.9,33.15);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(255,255,255,0.239)").s().p("AieF5QhKgfg4g5Qg4g5gghJQgghMAAhTQAAhSAghNQAghJA4g4QA4g5BKgfQBMggBSAAQBUAABLAgQBKAfA5A5QA4A4AfBJQAgBNAABSQAABTggBMQgfBJg4A5Qg5A5hKAfQhLAghUAAQhSAAhMggg");
	this.shape_1.setTransform(28.9,33.15);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(255,255,255,0.18)").s().p("AieF5QhKgfg4g5Qg4g5gghJQgghMAAhTQAAhSAghNQAghJA4g4QA4g5BKgfQBMggBSAAQBUAABLAgQBKAfA5A5QA4A4AfBJQAgBNAABSQAABTggBMQgfBJg4A5Qg5A5hKAfQhLAghUAAQhSAAhMggg");
	this.shape_2.setTransform(28.9,33.15);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("rgba(255,255,255,0.118)").s().p("AieF5QhKgfg4g5Qg4g5gghJQgghMAAhTQAAhSAghNQAghJA4g4QA4g5BKgfQBMggBSAAQBUAABLAgQBKAfA5A5QA4A4AfBJQAgBNAABSQAABTggBMQgfBJg4A5Qg5A5hKAfQhLAghUAAQhSAAhMggg");
	this.shape_3.setTransform(28.9,33.15);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("rgba(255,255,255,0.059)").s().p("AieF5QhKgfg4g5Qg4g5gghJQgghMAAhTQAAhSAghNQAghJA4g4QA4g5BKgfQBMggBSAAQBUAABLAgQBKAfA5A5QA4A4AfBJQAgBNAABSQAABTggBMQgfBJg4A5Qg5A5hKAfQhLAghUAAQhSAAhMggg");
	this.shape_4.setTransform(28.9,33.15);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("rgba(255,255,255,0)").s().p("AieF5QhKgfg4g5Qg4g5gghJQgghMAAhTQAAhSAghNQAghJA4g4QA4g5BKgfQBMggBSAAQBUAABLAgQBKAfA5A5QA4A4AfBJQAgBNAABSQAABTggBMQgfBJg4A5Qg5A5hKAfQhLAghUAAQhSAAhMggg");
	this.shape_5.setTransform(28.9,33.15);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("rgba(255,255,255,0.039)").s().p("AieF5QhKgfg4g5Qg4g5gghJQgghMAAhTQAAhSAghNQAghJA4g4QA4g5BKgfQBMggBSAAQBUAABLAgQBKAfA5A5QA4A4AfBJQAgBNAABSQAABTggBMQgfBJg4A5Qg5A5hKAfQhLAghUAAQhSAAhMggg");
	this.shape_6.setTransform(28.9,33.15);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("rgba(255,255,255,0.075)").s().p("AieF5QhKgfg4g5Qg4g5gghJQgghMAAhTQAAhSAghNQAghJA4g4QA4g5BKgfQBMggBSAAQBUAABLAgQBKAfA5A5QA4A4AfBJQAgBNAABSQAABTggBMQgfBJg4A5Qg5A5hKAfQhLAghUAAQhSAAhMggg");
	this.shape_7.setTransform(28.9,33.15);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("rgba(255,255,255,0.114)").s().p("AieF5QhKgfg4g5Qg4g5gghJQgghMAAhTQAAhSAghNQAghJA4g4QA4g5BKgfQBMggBSAAQBUAABLAgQBKAfA5A5QA4A4AfBJQAgBNAABSQAABTggBMQgfBJg4A5Qg5A5hKAfQhLAghUAAQhSAAhMggg");
	this.shape_8.setTransform(28.9,33.15);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("rgba(255,255,255,0.149)").s().p("AieF5QhKgfg4g5Qg4g5gghJQgghMAAhTQAAhSAghNQAghJA4g4QA4g5BKgfQBMggBSAAQBUAABLAgQBKAfA5A5QA4A4AfBJQAgBNAABSQAABTggBMQgfBJg4A5Qg5A5hKAfQhLAghUAAQhSAAhMggg");
	this.shape_9.setTransform(28.9,33.15);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("rgba(255,255,255,0.188)").s().p("AieF5QhKgfg4g5Qg4g5gghJQgghMAAhTQAAhSAghNQAghJA4g4QA4g5BKgfQBMggBSAAQBUAABLAgQBKAfA5A5QA4A4AfBJQAgBNAABSQAABTggBMQgfBJg4A5Qg5A5hKAfQhLAghUAAQhSAAhMggg");
	this.shape_10.setTransform(28.9,33.15);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("rgba(255,255,255,0.224)").s().p("AieF5QhKgfg4g5Qg4g5gghJQgghMAAhTQAAhSAghNQAghJA4g4QA4g5BKgfQBMggBSAAQBUAABLAgQBKAfA5A5QA4A4AfBJQAgBNAABSQAABTggBMQgfBJg4A5Qg5A5hKAfQhLAghUAAQhSAAhMggg");
	this.shape_11.setTransform(28.9,33.15);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("rgba(255,255,255,0.263)").s().p("AieF5QhKgfg4g5Qg4g5gghJQgghMAAhTQAAhSAghNQAghJA4g4QA4g5BKgfQBMggBSAAQBUAABLAgQBKAfA5A5QA4A4AfBJQAgBNAABSQAABTggBMQgfBJg4A5Qg5A5hKAfQhLAghUAAQhSAAhMggg");
	this.shape_12.setTransform(28.9,33.15);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape}]},1).wait(12));

	// Layer 1
	this.instance = new lib.AS_LG_153ss("single",0);
	this.instance.parent = this;
	this.instance.setTransform(35.85,14.9,1,1,0,0,0,23.9,23.9);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#DC6842").s().p("AiEE7Qg9gagwgvQgvgvgag+Qgbg/AAhGQAAhFAbg/QAag+AvgvQAwgvA9gaQBAgbBEAAQBGAAA/AbQA+AaAvAvQAwAvAaA+QAaA/AABFQAABGgaA/QgaA+gwAvQgvAvg+AaQg/AbhGAAQhEAAhAgbg");
	this.shape_13.setTransform(28.775,32.775);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#EFEFEF").s().p("AmdPUQi/hRiTiTQiTiThRi/QhUjFAAjZQAAjXBUjGQBRi/CTiTQCTiTC/hRQDGhUDXABQDYgBDGBUQC/BRCTCTQCTCTBRC/QBTDGABDXQgBDZhTDFQhRC/iTCTQiTCTi/BRQjGBUjYgBQjXABjGhUg");
	this.shape_14.setTransform(28.9064,33.1377,0.3846,0.3846);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_14},{t:this.shape_13},{t:this.instance}]}).wait(25));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-12,-7.7,81.8,81.8);


(lib.Actividad_checkbox = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		/*NOTA!!
		Para el correcto funcionamiento del template se requiere
		que los nombres de los checkbox esten en orden de izquierda a dedecha
		ejemplo: la primera fila seria 1,2,3 en ese orden y la segunda 4,5,6
		*/
		console.log("si llama los checkboxs");
		var root = this;
		//cuantso check son en total
		var cuantos = 5;
		//cuantos check por fila
		var cuantosFila = 5;
		//respuestas correctas
		var respuestas = [1];
		//variable que decide si se usaran mutliples opciones por fila
		var multiOp = true; //true, se admiten multiples opciones por fila
		//activar las funciones de overMouse
		stage.enableMouseOver();
		//root.validar.alpha = 0;
		root.retros_mc4.visible=false;
		root.btn_validar_mc4.visible=false;
		for (var i = 1; i <= cuantos; i++) {
			root["c" + i].sel = false;
			root["c" + i].n = i;
			root["c" + i].cursor = "pointer";
		
			if (multiOp) {
				root["c" + i].on("click", function (event) {
					console.log("se admiten multiples checks");
					///switch para el cambio en la seleccion
					if (this.sel) {
						this.gotoAndStop(0);
						this.sel = false;
					} else {
						this.gotoAndStop(1);
						this.sel = true;
					}
					checa();
				});
			} else {
				root["c" + i].on("click", function (event) {
					console.log("No se admiten multiples checks");
					var posicion = this.n;
					var seleccionado = this.n;
					//while para saber en que posicionse encuentra el check
					while (posicion > cuantosFila) {
						posicion -= cuantosFila;
					}
					console.log(posicion);
					var margenIzq = 0;
					var margenDer = 0;
					//cual es el margen izquierdo
					if (posicion > 1) {
						margenIzq = posicion - 1;
						console.log("margenIzq: " + margenIzq);
					}
					//cual es el margen derecho
					if (posicion < cuantosFila) {
						margenDer = cuantosFila - posicion;
						console.log("margenDer: " + margenDer);
					}
					this.gotoAndStop(1);
					this.sel = true;
					///////////////////////////
					for (var i = 1; i <= margenDer; i++) {
						root["c" + (seleccionado + i)].gotoAndStop(0);
						root["c" + (seleccionado + i)].sel = false;
						console.log("derecha " + i);
					}
					//////////////////////////
					for (var j = 1; j <= margenIzq; j++) {
						root["c" + (seleccionado - j)].gotoAndStop(0);
						root["c" + (seleccionado - j)].sel = false;
						console.log("izquierda " + j);
					}
					checa();
				});
		
			}
		}
		
		//funcion para checar cuantos estan activos
		function checa() {
			var cuantosSelect = 0;
			for (var j = 1; j <= cuantos; j++) {
				if (root["c" + j].sel) {
					cuantosSelect++;
				}
			}
			if (cuantosSelect >= respuestas.length) {
				root.btn_validar_mc4.visible = true;
			}
		}
		
		root.btn_validar_mc4.on("click",function(c){
			root.retros_mc4.visible=true;
			parent.siguiente_naranja();
			});
		/*
		//Funcion que valida si las respuestas estan correctas
		root.validar.on("click", function (event) {
			console.log("valida");
			var bien = true;
			for (var i = 1; i <= cuantos; i++) {
				if (root["c" + i].sel) {
					console.log("boton" + i + " seleccionado");
					if (respuestas.indexOf(root["c" + i].n) >= 0) {
						console.log("bien");
					} else {
						console.log("mal");
						bien = false;
					}
				}
			}
			if (bien) {
				console.log("Actividad correcta");
				deshabilitarbtn();
				parent.llamarRetros("retrobien");
				try {
					console.log("Termino la actividad");
					_root.siguiente_verde();
					_root.final_tema();
				} catch {
					console.log("no hay comunicacion con start.js");
				}
		
			} else {
				deshabilitarElementos();
		
				//habilita todo despies de la reproduccion de la retro
				var tiempo = (root.retro.timeline.duration / 2) / 24;
				tiempo = tiempo * 1000;
				console.log("el tiempo es: " + tiempo);
				var my_timedProcess = setTimeout(habilitarElementos, tiempo);
		
				console.log("Actividad incorrecta");
				parent.llamarRetros("retromal");
			}
		});
		*/
		function deshabilitarbtn() {
			for (var i = 1; i <= cuantos; i++) {
				root["c" + i].removeAllEventListeners();
				root["c" + i].cursor = "";
			}
		}
		
		function deshabilitarElementos() {
			for (var i = 1; i <= cuantos; i++) {
				root["c" + i].cursor = "";
				root["c" + i].mouseEnabled = false;
			}
		}
		
		function habilitarElementos() {
			for (var i = 1; i <= cuantos; i++) {
				root["c" + i].cursor = "pointer";
				root["c" + i].mouseEnabled = true;
			}
		}
		console.log("termina checkboxs");
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// lo que va en la retro no la encontre
	this.retros_mc4 = new lib.mc4r_etro();
	this.retros_mc4.name = "retros_mc4";
	this.retros_mc4.parent = this;
	this.retros_mc4.setTransform(165.2,133.75,1,1,0,0,0,250.2,142.8);

	this.timeline.addTween(cjs.Tween.get(this.retros_mc4).wait(1));

	// Texto
	this.btn_validar_mc4 = new lib.btn_Validar();
	this.btn_validar_mc4.name = "btn_validar_mc4";
	this.btn_validar_mc4.parent = this;
	this.btn_validar_mc4.setTransform(151,254.5,1,1,0,0,0,108.8,17.2);
	new cjs.ButtonHelper(this.btn_validar_mc4, 0, 1, 2, false, new lib.btn_Validar(), 3);

	this.t5 = new cjs.Text("Considerar características del puesto/función.", "9px 'Arial'", "#333333");
	this.t5.name = "t5";
	this.t5.lineHeight = 12;
	this.t5.lineWidth = 227;
	this.t5.parent = this;
	this.t5.setTransform(-31.4,204.3,2.0043,1.9497);

	this.t4 = new cjs.Text("Evaluar disposición y actitud al cambio.", "9px 'Arial'", "#333333");
	this.t4.name = "t4";
	this.t4.lineHeight = 12;
	this.t4.lineWidth = 224;
	this.t4.parent = this;
	this.t4.setTransform(-31.4,161.5,2.0043,1.9497);

	this.t3 = new cjs.Text("Analizar sus conocimientos y apego a la cultura.", "9px 'Arial'", "#333333");
	this.t3.name = "t3";
	this.t3.lineHeight = 12;
	this.t3.lineWidth = 225;
	this.t3.parent = this;
	this.t3.setTransform(-31.4,121.3,2.0043,1.9497);

	this.t2 = new cjs.Text("Revisar historial de desempeño.", "9px 'Arial'", "#333333");
	this.t2.name = "t2";
	this.t2.lineHeight = 12;
	this.t2.lineWidth = 222;
	this.t2.parent = this;
	this.t2.setTransform(-31.4,82.8,2.0043,1.9497);

	this.t1 = new cjs.Text("Entrevistar al jefe y sus colaboradores.", "9px 'Arial'", "#333333");
	this.t1.name = "t1";
	this.t1.lineHeight = 12;
	this.t1.lineWidth = 221;
	this.t1.parent = this;
	this.t1.setTransform(-31.4,41.4,2.0043,1.9497);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.t1},{t:this.t2},{t:this.t3},{t:this.t4},{t:this.t5},{t:this.btn_validar_mc4}]}).wait(1));

	// Graficos
	this.c5 = new lib.ch2();
	this.c5.name = "c5";
	this.c5.parent = this;
	this.c5.setTransform(-59.8,213.2,1.008,1.008,0,0,0,18.6,18.6);

	this.c4 = new lib.ch2();
	this.c4.name = "c4";
	this.c4.parent = this;
	this.c4.setTransform(-59.8,173.1,1.008,1.008,0,0,0,18.6,18.6);

	this.c3 = new lib.ch2();
	this.c3.name = "c3";
	this.c3.parent = this;
	this.c3.setTransform(-59.8,133,1.008,1.008,0,0,0,18.6,18.6);

	this.c2 = new lib.ch2();
	this.c2.name = "c2";
	this.c2.parent = this;
	this.c2.setTransform(-59.8,92.9,1.008,1.008,0,0,0,18.6,18.6);

	this.c1 = new lib.ch2();
	this.c1.name = "c1";
	this.c1.parent = this;
	this.c1.setTransform(-78.55,34.05,1.008,1.008);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.c1},{t:this.c2},{t:this.c3},{t:this.c4},{t:this.c5}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Actividad_checkbox, new cjs.Rectangle(-85,-9,512.1,285.7), null);


(lib.titulomodulot1TMR = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_86 = function() {
		this.stop();
		parent.siguiente_naranja();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(86).call(this.frame_86).wait(1));

	// Capa_3
	this.instance = new lib.mc_numMod01();
	this.instance.parent = this;
	this.instance.setTransform(219.45,213.6,1,1,0,0,0,26.6,32.8);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(4).to({_off:false},0).to({scaleX:8.5991,scaleY:8.5991,x:227.25,y:220.05},20).to({scaleX:7.7092,scaleY:7.7092,x:227.3,y:219.95},10).to({scaleX:7.6294,scaleY:7.6294,rotation:360,x:648.55,y:219.9},15).to({regY:32.7,scaleX:0.9999,scaleY:0.9999,x:542.55,y:152},14,cjs.Ease.get(1)).to({x:692.55},11,cjs.Ease.get(1)).wait(13));

	// Capa_5
	this.instance_1 = new lib.tapabca("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(647.8,152.3,1,1,0,0,0,106.5,44.6);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(63).to({_off:false},0).to({scaleX:0.4364,x:767.8},11,cjs.Ease.get(1)).to({_off:true},1).wait(12));

	// Capa_2
	this.instance_2 = new lib.txt_modulo();
	this.instance_2.parent = this;
	this.instance_2.setTransform(567.9,155.3,1,1,0,0,0,87.3,28.8);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(63).to({_off:false},0).wait(24));

	// Capa_7
	this.instance_3 = new lib.Tema("synched",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(1026.7,242.55,1,1,0,0,0,132.1,45.9);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(71).to({_off:false},0).to({x:614.7},15,cjs.Ease.get(1)).wait(1));

	// Capa_1
	this.instance_4 = new lib.mc_imagenmodulo("synched",0,false);
	this.instance_4.parent = this;
	this.instance_4.setTransform(225.5,217.4,1,1,0,0,0,225.5,217.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(87));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1.5,-66.4,1256.2,569.3);


(lib.tiprecuerdamod3mc2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_28 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(28).call(this.frame_28).wait(1));

	// icono
	this.instance = new lib.AS_LG_MOV_10ss();
	this.instance.parent = this;
	this.instance.setTransform(-154.45,11.85,1,1,0,0,0,30,29.9);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:-243.7,y:-57.75},26,cjs.Ease.get(1)).wait(3));

	// Layer 1
	this.instance_1 = new lib.info01ss();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-62,-42);
	this.instance_1.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({x:-25.35,y:0,alpha:1},28,cjs.Ease.get(1)).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-372.4,-95.4,257.79999999999995,213.9);


(lib.rh1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.M03_TMR_MODERADOR();
	this.instance.parent = this;
	this.instance.setTransform(76.05,123.05,0.494,0.494,0,0,0,198.1,183.9);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-21.8,32.2,195.8,181.7);


(lib.personajes1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.MUJER1();
	this.instance.parent = this;
	this.instance.setTransform(115.9,132.15,0.9583,0.9583,0,0,0,67.7,137.9);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#323436").s().p("ACdAzQgBgMADgUQAEgnAMgkQAKgbAUgjQAMgXgDgIQgHgNgJgEQgMgGgpgDQgwgDhbAHQhiAGgyAMQgvAMgWgDQgPgBgBgIQgBgEAKgBIAZgCIBsgOIAWgDQAZgEAUgBQCggFAOACQAiACAJADQAgAKgDAfQgBAHgHAPQgRAdgRAsQgKAYgFBoQgDA0gBAwIgNACg");
	this.shape.setTransform(55.2504,184.1469,1.3376,1.3376);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#B7BBC1").s().p("ACUC/IgEAAQgDgEAAgEIABgHIAGh0QgBgMABgTQADgjANgkQAQgxANgUIAIgOQADgEgBgEQAAgGgEgIQgHgJgMgCIgvgCQg4gDhOADQhcAFguALQhEAQgRgLQgEgCgCgHQgBgEADgDQAEgFAUgCIALgCIBtgOIAWgEQAZgDAUAAIAcgBQCKgHAMAEIAIABQAWACAQAJQAYANABAYIgHAaIgNAZQgOAcgJAWQgJAXgHBkIgFBiQAAAFgEABIgOADgACdA3IgCB6IABAAQAGirANgsQgRA0gBApgACXirQAkABANAHQAKAEAFAPIACAEQADAHgBAHIABgCQACgagRgMQgMgHgagDIgJgBQgLgDiHAGIgdABQgTABgZADIgVADIgBAAIiFASQANAGA9gOQAvgMBlgDIBPgCQAlAAAdACg");
	this.shape_1.setTransform(55.6915,183.6016,1.3376,1.3376);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#10121D").s().p("AhKAEQAAAAAAAAQAAgBAAAAQAAAAABAAQAAgBABAAQAzgGA6gBIAAAAIAmACQAAAAAAAAQAAABAAAAQgBAAAAAAQAAAAAAAAQhbAAg2AIQgBAAAAAAQgBAAAAAAQAAgBgBAAQAAAAAAgBg");
	this.shape_2.setTransform(79.6331,170.2592,1.3376,1.3376);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#323436").s().p("AgPAWQAEgKALgMQAVgcgKgEIADAAQAEABgBAFQAAAJgRAVQgOAZgBAEQgDgDADgIg");
	this.shape_3.setTransform(43.8879,192.7641,1.3376,1.3376);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#252931").s().p("AAAACIABgJIAAAPg");
	this.shape_4.setTransform(74.6573,207.8453,1.3376,1.3376);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#626666").s().p("AgQCGQgTggAAghQAAgiAJg+IAKg+QADgWACgGQAFgYAKgDQASgGAOgHIgYBLQgYBPgDAaQgEAtAJA8IAMAeQgJgJgJgPg");
	this.shape_5.setTransform(28.0425,184.9392,1.3376,1.3376);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#626666").s().p("AAKBXQgLgEgFgOQgEgKgFgfIgGgwIgMhDIBDCqQgHAGgJAAIgIgCg");
	this.shape_6.setTransform(27.474,151.2989,1.3376,1.3376);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#626666").s().p("AjSHbQgHgEgQgYQgKgPAVhzQAVhzgKgRQgQgbhEipQhFisgFgdQgBgGgBiIQgBhpgMgRIAQAQQATASAJAAQAFAAAFgIQAEgGAJAIQAMAJAEATQAEAQAAAbQAABBADAnQAHBVATApQAgBAAmBfQAvB2AFAnQADAcgLA1QgJArgJAWQgGAQAAAgQAAAfAFAAQADAACNgiQCcggBaAOQBbAOAtAXQAWAMAFAJIAEAVQADAYgEAXQABgMgGgMQgRgghBgHQgggFgUgBQgjgCgmAIQk2BAgiAGQgPACgJAAQgJAAgEgCg");
	this.shape_7.setTransform(69.0602,135.7328,1.3376,1.3376);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#323436").s().p("Ag5BSQgCgOgVhCQgQgxACggQADgcgGhXQgFhUACgVQADgfADgFQACgEAKAAQAQAAAFAiQAFAcgCBiQgCBYAIAVQAaBGAgBeQAQAxBQC1QggAEgUAGIgOAGQhUjOgJg0g");
	this.shape_8.setTransform(27.2686,116.8227,1.3376,1.3376);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#323436").s().p("AjkC8QgtgCgTgKQgmgTgSg9QgThCAhhvIAkhiIA7gIQAKgBgEAZQgCATgOBJQgOBPACAeQADApAdAEQAYAEDDgpQDEgpANABQAfADAkACIAmAAQAoAIAIAhQALAsgXAdQgaAhgzgPQgwgOiXAQQh8AOgyAMQgmAJgVAEQgbAEgXAAIgJAAg");
	this.shape_9.setTransform(72.7845,187.8905,1.3376,1.3376);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#454748").s().p("AgmAKIAPgGQAQgFAOgDIAggFIgsARIgXACg");
	this.shape_10.setTransform(28.5441,234.898,1.3376,1.3376);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#717677").s().p("AABADIgEgDQABAAAAAAQAAAAAAAAQAAAAAAgBQAAAAAAAAIgBgCQADAAAEAHg");
	this.shape_11.setTransform(67.7688,225.769,1.3376,1.3376);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#717677").s().p("AAAgCIgJAAIASgJIgBADQAAAEABACQACACgDAMQgEgNgEgBg");
	this.shape_12.setTransform(65.9496,228.4107,1.3376,1.3376);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#717677").s().p("AgIAfIAGgbQACgSAAgFQgBgBgHgBIgHAAIAXgMIAJAEIgCAAQgDABgDAFQgEAFAAAaIAAAag");
	this.shape_13.setTransform(57.5697,231.6209,1.3376,1.3376);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#717677").s().p("AgZAGIgLgHIAAgHIANAIQAQAGAMgBQAVgDAJgJIgBgDIADAFIgBAGQgGAHgVACIgKABQgNAAgLgFg");
	this.shape_14.setTransform(62.7862,226.7292,1.3376,1.3376);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#3D4659").s().p("AAjBHQgBgFg1hqQgyhkAFACQAKADAagBIBTDPQAIAVACAuIgZABQABg0gGgQg");
	this.shape_15.setTransform(69.9788,246.2314,1.3376,1.3376);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#9B9D9E").s().p("AAAAyIgShkQAPANALAtQAHAXADAUg");
	this.shape_16.setTransform(78.2354,257.9379,1.3376,1.3376);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#9B9D9E").s().p("AApBtQgCgigLgUQgFgJgYg4QgUgvgJgIIgkgKQgCAAACg6IAOgGIAPADQAEgBgEAEIAUAWQATAbAEAZQAEAXAaA1QAaA4ACAHQAFAXgBAkIgaACQABgOgCgSg");
	this.shape_17.setTransform(66.971,246.2675,1.3376,1.3376);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#252931").s().p("AixBcIAFgTQAIgXAOgQQASgVB7gvQB9gxA+gIIAAA3IgwADQg2AEgfAHIgsAMIgxAQQgyARgPAGQgYAKgLAUQgPAeADADg");
	this.shape_18.setTransform(33.7272,240.7834,1.3376,1.3376);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#252931").s().p("AC3BUQAEgLgQgbQgGgKgdgHIhHgSIgygPIgsgKQgfgIhBgBIg7AAIgSg7QA/AHCcAvQCcAwARARQANAOAAASQAAAIgDAHg");
	this.shape_19.setTransform(93.3166,239.0445,1.3376,1.3376);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#9B9D9E").s().p("AjCBiQABgLAFgOQAIgcAPgNQAdgYB9gwQCBgzA9gHIAQAFQhzAzgzAMQgZAGgNANQgRANgdAJQg5ATgLAEQgZAKgHAMQgRAbgCAQg");
	this.shape_20.setTransform(33.3259,239.8136,1.3376,1.3376);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#9B9D9E").s().p("ACrAuQgHgLgbgKIhHgWIgzgPIgsgLQgggHhTgZIhOgXIAYgLQBCAICbAwQCeAxAZAWQAPANACAVQABAKgDAIIghAAQgBgRgQgbg");
	this.shape_21.setTransform(94.4058,238.242,1.3376,1.3376);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#B3B5B8").s().p("AgCBDIAAiFIAFAAIAACFg");
	this.shape_22.setTransform(58.2385,217.5428,1.3376,1.3376);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#3D4659").s().p("AgNBGIAAiLIAbAAIAACLg");
	this.shape_23.setTransform(63.1875,218.2785,1.3376,1.3376);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#252931").s().p("AgJBGQgQgCgHgIIgDgIIAAh5IBGAAIAACAQgOALgVAAIgJAAg");
	this.shape_24.setTransform(62.5856,218.3055,1.3376,1.3376);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#454748").s().p("AgLAhQgMgJgEgPQgFgPAFgNQAFgOAMgDQALgEALAJQAMAIAEAQQAFAOgFAOQgFANgMADIgHABQgHAAgIgFg");
	this.shape_25.setTransform(121.5643,258.6909,1.3376,1.3376);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#454748").s().p("AgTAhQgLgMgBgSQgDgQAJgOQAIgNANgCQANgCALAMQALAMABARQADASgJANQgIANgNACIgEAAQgKAAgKgKg");
	this.shape_26.setTransform(75.9615,273.2867,1.3376,1.3376);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#040D1C").s().p("AgVAoQgOgEgGgXQgCgIABgXIABgWIAogBIAAAIIAQACQASAEAGANQAHAOgEAOQgDAOgNAHQgLAGgPABIgHAAQgIAAgGgCg");
	this.shape_27.setTransform(124.1742,255.8169,1.3376,1.3376);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#040D1C").s().p("AgWArQgQgEgGgZQgCgJABgZIABgYIA1AAIAAAIIAOACQAPAFAEAOQAGARgDAOQgEAPgMAGQgMAHgRABIgGAAQgJAAgHgCg");
	this.shape_28.setTransform(79.2022,271.1298,1.3376,1.3376);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#454748").s().p("AgTAbQgJgMAAgPQAAgPAJgLQAIgLALAAQAMAAAIALQAJALAAAPQAAAQgJALQgIALgMAAQgLAAgIgLg");
	this.shape_29.setTransform(9.1156,259.6099,1.3376,1.3376);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#454748").s().p("AgFAVQgIgFgEgJQgDgJACgJQADgIAHgDQAHgDAHAFQAHAFAEAJQAEAJgDAIQgCAJgHADIgGABQgDAAgFgDg");
	this.shape_30.setTransform(19.8661,240.6691,1.3376,1.3376);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#454748").s().p("AgIAgQgMgHgGgPQgFgNAEgOQAEgNALgEQALgFAKAIQAMAIAGAOQAFANgDAOQgEANgLAEQgEACgFAAQgGAAgHgFg");
	this.shape_31.setTransform(84.0991,240.5828,1.3376,1.3376);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#040D1C").s().p("AgUAoQgPgFgFgWQgCgIABgXIABgXIAxAAIAAAHIANACQAOAFAEANQAFAPgDANQgDAOgMAGQgLAHgQABIgFAAQgJAAgGgCg");
	this.shape_32.setTransform(86.0463,238.1249,1.3376,1.3376);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#040D1C").s().p("AgRAXQgPgIAHgYQADgIAJgDIAIgCIAAgFIAgABIABAOQABAPgCAGQgDAOgKADQgGACgGAAQgJAAgKgFg");
	this.shape_33.setTransform(21.0835,239.9709,1.3376,1.3376);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#040D1C").s().p("AAAAkQgNgBgJgFQgLgFgCgMQgDgMAFgNQADgLAMgEQAGgCAGAAIAAgHIAqABIABATQAAAUgBAIQgEATgNAEQgFACgIAAIgGgBg");
	this.shape_34.setTransform(8.0277,257.4554,1.3376,1.3376);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#717677").s().p("AhyApQgEgDgLABIgJABQAAAAAAgBQAAAAgBAAQAAAAAAgBQAAAAAAAAQAAgEAIgGQAGgFCEggICFggIAAAHIiaArIgZAKQgHACgXAEQgXAEgGADQgFADgFAFQAAABAAAAQgBABAAAAQgBAAAAAAQAAAAgBAAIgDgBg");
	this.shape_35.setTransform(39.111,231.1221,1.3376,1.3376);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#454748").s().p("AgLAgQgMgIgEgQQgFgOAFgOQAFgNAMgEQAKgDAMAJQAMAIAEAQQAFAOgFAOQgFANgMAEIgHABQgHAAgIgHg");
	this.shape_36.setTransform(127.4753,256.1656,1.3376,1.3376);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#454748").s().p("AgTAhQgKgMgCgRQgDgSAJgNQAIgNAOgCQAMgBALALQALAMACASQABAQgIAOQgIANgNACIgEAAQgKAAgKgKg");
	this.shape_37.setTransform(82.7832,271.4141,1.3376,1.3376);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#454748").s().p("AgTAbQgJgMAAgPQAAgPAJgLQAIgLALAAQAMAAAIALQAJALAAAPQAAAQgJALQgIALgMAAQgLAAgIgLg");
	this.shape_38.setTransform(3.8322,258.3392,1.3376,1.3376);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#454748").s().p("AgIAgQgMgHgFgPQgGgNAEgOQADgNALgEQAMgEALAHQALAHAGAPQAFANgDAOQgEANgMAEIgIACQgGAAgHgFg");
	this.shape_39.setTransform(91.2768,237.8073,1.3376,1.3376);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#323436").s().p("ACdA0QgBgNADgUQAEgnAMgkQAKgbAUgjQAMgXgDgIQgHgNgJgEQgNgGgogCQgwgDhbAGQhiAHgyAMQgvALgWgCQgPgCgBgIQgBgEAKgBIAZgCICCgRQAZgEAUAAQChgFANABQAnAEAEABQAgAKgDAfQgBAGgHARQgQAbgSAtQgKAYgFBoQgDA0gBAwIgNADg");
	this.shape_40.setTransform(55.2504,174.2274,1.3376,1.3376);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#B7BBC1").s().p("ACQC+QgDgCAAgFIABgHIAGh0QgBgMABgTQADgkANgkQAQguANgWIAIgOQADgEgBgFQAAgGgEgGQgHgKgMgCIgvgCQg2gEhQAEQhbAEgvAMQhEAQgRgKQgFgEgBgGQgBgDADgEQAEgFAUgDIB4gPIAWgEQAZgDAUAAIAcgCQCJgGANADIAIABQAWADAQAJQAYANABAXIgHAbIgNAYQgOAdgJAWQgJAXgHBkIgFBiQAAAFgEABIgOADIgCABIgEgCgACdA2IgCB7IABAAQAGirANgrQgRAzgBAogACXirQAjACAOAGQAKAFAFANIACAGQAEAFgCAIIABgCQACgagRgLQgMgIgagDIgJgCQgLgCiHAGIgdABQgTABgZADIgVADQAlgEAzgCIBKgBQAoAAAfACgAi/iYIgZAEQAMAHA+gPIAggGIhRAKg");
	this.shape_41.setTransform(55.6915,173.67,1.3376,1.3376);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#CCD1D0").s().p("AjyByQAkgUBLgjQBWgpAMABQALAAAOgRQAaghAUgSQAvgsBAhCIAVgFQAXgDARADQA2AMgjBSQhvBbg7AiQgdAbgLAHQgPAKhZAbIiHAog");
	this.shape_42.setTransform(420.608,111.5894,1.3376,1.3376);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#E2BD90").s().p("AhKA0IgJgLQgDgEgDgNQgCgRAEgNIAFgLQAIgNALgHIAHgEQAIgFAHgCQAIgDAXgBQAXgBATACQALABAPAGQAMAFAHgCIAOABIgBAgQgMgBgLAFIgLAGQgFAEgJADQgSAHgVgBQgSgBgQAGQgRAHgFANQgEAJgHADIgGABQgCAAgCgBg");
	this.shape_43.setTransform(375.2153,132.9061,1.3376,1.3376);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#E2BD90").s().p("AgHgTQAHgMAGABQAEAAACADQADAagNASIgOAPg");
	this.shape_44.setTransform(438.8849,50.5069,1.3376,1.3376);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#E6A37E").s().p("AgOAGIgCgGQAAgBANgCIAUgDQgKAKgKADIgGAAQgBAAgBAAQAAAAgBAAQAAAAgBAAQAAgBgBAAg");
	this.shape_45.setTransform(415.2735,60.9376,1.3376,1.3376);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#E19D7A").s().p("AgQABQgCgEABgCIAOAAQAOABAHAEIghAGIgBgFg");
	this.shape_46.setTransform(415.1129,59.9753,1.3376,1.3376);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#3F3231").s().p("AhJAYQgHgBgFgEQgIgGABgJIAAgCIgGgBIgBgGIABgJQAAgDAFgBIAEgBIgCABQgBAAAAABQgBAAAAAAQAAABAAAAQAAABAAAAQgBABAAABQABAAAAAAQAAABABAAQAAAAABAAQAFgLAQAAIA4AAQAOADADAHIBgAIIgBAMIhdgHIAAADQgBANgPAHIgCABgAhTgLIAAASIAAAEQADAEAFADIBAAAQAHgDAAgIIAAgSQgBgFgHAAIhAAAQgIADABACg");
	this.shape_47.setTransform(425.4057,46.8669,1.3376,1.3376);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#3F3231").s().p("AAbAAQgJgHgLAEQggAKgIgJIAFgBQAHgDAPgDIASAAQAUADACAQQgCgFgFgFg");
	this.shape_48.setTransform(418.5505,43.5564,1.3376,1.3376);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#3F3231").s().p("AgIAAQAAgIAIAAQAJAAABAIQgBAJgJAAQgIAAAAgJg");
	this.shape_49.setTransform(417.1795,46.6663,1.3376,1.3376);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#E8AE91").s().p("AgFALQgUgEgGgEIgCgBIABAAQAAgCAGgEQAKgGAPAAIALABQANADAKAFIABABIgBAAQgOALgTAAgAgdACQAHAEARADQARACASgLQgJgFgNgCIgJgBQgUAAgIAKg");
	this.shape_50.setTransform(418.6509,46.6663,1.3376,1.3376);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#FFFFFF").s().p("AgUAHIgLgEQADgIAOgDIANgBQAMgCAVALQgLAKgWAAIgCAAQgGAAgLgDg");
	this.shape_51.setTransform(418.6509,46.6494,1.3376,1.3376);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#3F3231").s().p("AgZgMIAPAKQASAKASACIgtADg");
	this.shape_52.setTransform(433.5984,23.1248,1.3376,1.3376);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#3F3231").s().p("AgagMIAQAKQASAKASACIgtADg");
	this.shape_53.setTransform(426.0076,22.2219,1.3376,1.3376);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#3F3231").s().p("AgZgMIAPAKQASAKASACIgtADg");
	this.shape_54.setTransform(419.1525,22.757,1.3376,1.3376);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#3F3231").s().p("AA1AWIgmgRQgcgUgfgTQg/gogMAFQgLgPgKgRQgVgiAAgJQAAgHAKADQAWAEAVgBIBfgJQBCgFAWAJQAkAOAXAhQAhAugGBDQgFBAgpAwIgoAjQgRhvgFgYg");
	this.shape_55.setTransform(431.1436,44.001,1.3376,1.3376);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#A9B1BA").s().p("Ag+AUIB4g9IAKArQgDAMhCAPIhCANg");
	this.shape_56.setTransform(432.8961,74.8225,1.3376,1.3376);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#CCD1D0").s().p("AgGFMIiEgIQgOligHgwQgFgeAshcIAthXICSgsIATAOQAVATAQAbQAyBYgZCKQg1EgASBDQAGAWhrAAIgWAAg");
	this.shape_57.setTransform(432.3704,118.978,1.3376,1.3376);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#E2BD90").s().p("AggCqQAHgegEgHQgFgJgaAGQgdAHgIAAQgQAAgKgNQgCgEACgKIACgNIgBgEIABAAIgFgLIgBgGQgEgHACgHIABgRQAAgBgGAAQgIgBgFgDQgFgEgBgGIABgFQAJgYAKgQIAIgNIABhZQAOg3A6gXQAcgLAZAAIAXABQAcABAXAKQBLAgADBfQADBfgkAsQgLANgNAHIgMAFQgPAkgHA1IhmAVIAIglg");
	this.shape_58.setTransform(430.1695,50.7125,1.3376,1.3376);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#CCD1D0").s().p("AjyBzQAlgVBKgjQBWgpAMABQALABAOgSQAaggAUgSQAvgtBAhCIAVgFQAXgDARAEQA2AMgjBRQhvBbg7AiQgdAbgLAHQgPAKhZAbIiHAog");
	this.shape_59.setTransform(410.5761,100.6958,1.3376,1.3376);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#E2BD90").s().p("AhKA0IgJgLQgDgEgCgNQgDgRAEgNIAGgLQAIgNAKgHIAHgEQAIgFAHgCQAJgDAWgBQAXgBATACQALABAPAGQAMAFAIgCIANABIgBAgQgLgBgMAFIgLAGQgFAEgJADQgSAHgUgBQgTgBgQAGQgRAHgFANQgDAIgIAEIgGABQAAAAgBAAQAAAAgBAAQAAAAgBgBQAAAAgBAAg");
	this.shape_60.setTransform(365.9978,122.8576,1.3376,1.3376);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#000008").s().p("AidF1IhQoTQgBgIAAgMQABgZAKgVQAfhCBrgFQBqgEgDgjQAAgLgMgMIgLgLIDlgHIAKBUQAJBYAAAUQAAAOgYAXQgaAZgmATQhnAzhlgoIAkHTg");
	this.shape_61.setTransform(418.1743,212.2594,1.3376,1.3376);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#1F2226").s().p("AhlFmIhJgKQgihlghh6QhDj0ABhuQABhuCogOQBWgIBoANQAegCAmgLIC9AZQhCBQgRASQgLALhMAqIhUAtQgJAGggAEQgbAEgbAAQgUAAg1gHIgxgHQA6DEAGAPQADAIAUBaQAWBcAQAaQAQAcgBARQgBAKgFAPQgBAFgVAAQgSAAghgEg");
	this.shape_62.setTransform(397.7835,210.8151,1.3376,1.3376);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#564437").s().p("Ah/BHQgDgBgCgOQgBgYAegRQAZgNA2giIAPgmICEAHIAKAeQACA6gHAHQgHAHg6gEIhkAkg");
	this.shape_63.setTransform(399.2475,271.18,1.3376,1.3376);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#564437").s().p("Ah/BHQgEgBgBgOQgCgYAfgRQAZgNA2giIAOgmICEAHIALAeQACA6gIAHQgHAHg6gEIhjAkg");
	this.shape_64.setTransform(378.1043,267.2341,1.3376,1.3376);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#252931").s().p("AAAgHIABAJIgBAGg");
	this.shape_65.setTransform(423.0315,203.03,1.3376,1.3376);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#717677").s().p("AAAAAQACgCACgBIAAADIgEADIgDABg");
	this.shape_66.setTransform(429.92,220.9537,1.3376,1.3376);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#AEB1B1").s().p("AgWACIAugDQgKACgSABg");
	this.shape_67.setTransform(180.2931,153.6397,1.3376,1.3376);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#FFFFFF").s().p("Ag7ABIAMgDQAPgFANAAQBPgEAAASIhzACg");
	this.shape_68.setTransform(175.2438,153.7697,1.3376,1.3376);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#AEB1B1").s().p("AgoAHQgRgDAAgEQAAgDARgDQARgDAXAAQAYAAARADQARADAAADQAAAEgRADQgRADgYAAQgXAAgRgDg");
	this.shape_69.setTransform(175.5113,153.5728,1.3376,1.3376);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#FFFFFF").s().p("Ag7gGIBzgCIAEAIQgTAHgVABIgdABQgyAAAAgPg");
	this.shape_70.setTransform(324.8527,153.5503,1.3376,1.3376);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#FFFFFF").s().p("AgoAHQgRgDAAgEQAAgDARgDQARgDAXAAQAYAAARADQARADAAADQAAAEgRADQgRADgYAAQgXAAgRgDg");
	this.shape_71.setTransform(324.5852,152.3356,1.3376,1.3376);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#AEB1B1").s().p("AgoAHQgRgDAAgEQAAgDARgDQARgDAXAAQAYAAARADQARADAAADQAAAEgRADQgRADgYAAQgXAAgRgDg");
	this.shape_72.setTransform(324.5852,153.7066,1.3376,1.3376);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#FFFFFF").s().p("Ai5AUIAAgnIFzAAIAAAng");
	this.shape_73.setTransform(155.2134,147.8546,1.3376,1.3376);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#AEB1B1").s().p("Ai5AUIAAgnIFzAAIAAAng");
	this.shape_74.setTransform(155.2134,149.6269,1.3376,1.3376);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#FFFFFF").s().p("Ai5AUIAAgnIFzAAIAAAng");
	this.shape_75.setTransform(334.383,147.8546,1.3376,1.3376);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#AEB1B1").s().p("Ai5AUIAAgnIFzAAIAAAng");
	this.shape_76.setTransform(334.383,149.6269,1.3376,1.3376);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#585B5C").s().p("AiUDuQgOgDgEgCIgBgDQECgDAhgFQAVgDAIgUIAEgTIh4l9QgFgRgIgGIgHgCIACgMIAGADQAOAIAFAQIBzFkQAKAigCAOQgBAIgHAKQgHANgOAGIiHAFQhfAEgkAAIgUgBg");
	this.shape_77.setTransform(190.5471,120.4753,1.3376,1.3376);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#585B5C").s().p("AhHFkICIrGIAHgBIiFLHg");
	this.shape_78.setTransform(180.36,86.8942,1.3376,1.3376);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#FFFFFF").s().p("AhcFeICPrGIAqAKIiGLHg");
	this.shape_79.setTransform(183.0017,87.9977,1.3376,1.3376);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#AEB1B1").s().p("ABBljIAFB5QAACNgYBgQgYBhgwCJQgYBFgTAyg");
	this.shape_80.setTransform(186.7811,88.6665,1.3376,1.3376);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#585B5C").s().p("AiJDmQgPgGgGgNIgIgSQgCgNAKgjQAQg2BikuQAGgQAOgIIAFgDIADAMQgDAAgEACQgIAGgFARIh5F9IAEATQAJAUAVADQAhAFEBADQAEAEgWAEIgZABQg9AAjIgJg");
	this.shape_81.setTransform(288.8914,120.4906,1.3376,1.3376);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#585B5C").s().p("AA/FkIiGrHIAHABICILGg");
	this.shape_82.setTransform(299.0038,86.8942,1.3376,1.3376);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#FFFFFF").s().p("AhcleIAqgKICPLGIg0ALg");
	this.shape_83.setTransform(296.429,87.9977,1.3376,1.3376);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#AEB1B1").s().p("AAbDtQgwiJgYhhQgYhgAAiNIAGh5ICFLHQgTgygYhFg");
	this.shape_84.setTransform(292.5828,88.6665,1.3376,1.3376);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#B7BBC1").s().p("AgEh9IAVDbIghAgg");
	this.shape_85.setTransform(196.8792,132.3052,1.3376,1.3376);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#4E5153").s().p("AgNB/QgIAAgGgGQgGgFAAgJIAAjZQAAgGAEgFQAFgEAGgBIAgAAQAIAAAGAFQAGAGAAAIIAADYQAAARgFABg");
	this.shape_86.setTransform(227.4096,130.5636,1.3376,1.3376);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#4E5153").s().p("AgKALQgEgFAAgGQAAgGAEgEQAEgEAGAAQAGAAAFAEQAEAEAAAGQAAAGgEAFQgFAEgGAAQgGAAgEgEg");
	this.shape_87.setTransform(251.7536,146.3833,1.3376,1.3376);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#4E5153").s().p("AgLALQgDAAgCgDQgDgCAAgEIAAgEQAAgIAIAAIAWAAQAEAAACADQADACAAADIAAAEQAAAEgDACQgCADgEAAg");
	this.shape_88.setTransform(251.9543,141.568,1.3376,1.3376);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#4E5153").s().p("AgLALQgDAAgCgDQgDgCAAgEIAAgEQAAgIAIAAIAWAAQAEAAACADQADACAAADIAAAEQAAAEgDACQgCADgEAAg");
	this.shape_89.setTransform(251.9543,137.2208,1.3376,1.3376);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#4E5153").s().p("AgLAKQgIABAAgJIAAgDQAAgJAIABIAWAAQAEgBACADQADACAAAEIAAADQAAAEgDACQgCADgEgBg");
	this.shape_90.setTransform(251.9543,132.8402,1.3376,1.3376);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#4E5153").s().p("AgLALQgIAAAAgIIAAgEQAAgEADgCQACgDADAAIAWAAQAEAAACADQADACAAAEIAAAEQAAADgDACQgCADgEAAg");
	this.shape_91.setTransform(251.9543,128.6603,1.3376,1.3376);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#4E5153").s().p("AgLALQgDAAgCgDQgCgCgBgEIAAgEQAAgIAIAAIAXAAQAHAAAAAIIAAAEQAAAEgCACQgCADgDAAg");
	this.shape_92.setTransform(245.4335,141.568,1.3376,1.3376);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#4E5153").s().p("AgLALQgDAAgCgDQgCgCgBgEIAAgEQAAgIAIAAIAXAAQAHAAAAAIIAAAEQAAAEgCACQgCADgDAAg");
	this.shape_93.setTransform(245.4335,137.2208,1.3376,1.3376);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#4E5153").s().p("AgLAKQgIABAAgJIAAgDQAAgJAIABIAXAAQAHgBAAAJIAAADQAAAJgHgBg");
	this.shape_94.setTransform(245.4335,132.8402,1.3376,1.3376);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#4E5153").s().p("AgLALQgIAAAAgIIAAgEQABgEACgCQACgDADAAIAXAAQADAAACADQACACAAAEIAAAEQAAAIgHAAg");
	this.shape_95.setTransform(245.4335,128.6603,1.3376,1.3376);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#4E5153").s().p("AgLALQgDAAgCgDQgDgCAAgEIAAgEQAAgIAIAAIAWAAQAEAAACADQADACAAADIAAAEQAAAEgDACQgCADgEAAg");
	this.shape_96.setTransform(238.9128,141.568,1.3376,1.3376);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#4E5153").s().p("AgLALQgDAAgCgDQgDgCAAgEIAAgEQAAgIAIAAIAWAAQAEAAACADQADACAAADIAAAEQAAAEgDACQgCADgEAAg");
	this.shape_97.setTransform(238.9128,137.2208,1.3376,1.3376);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#4E5153").s().p("AgLAKQgIABAAgJIAAgDQAAgJAIABIAWAAQAEgBACADQADACAAAEIAAADQAAAEgDACQgCADgEgBg");
	this.shape_98.setTransform(238.9128,132.8402,1.3376,1.3376);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#4E5153").s().p("AgLALQgIAAAAgIIAAgEQAAgEADgCQACgDADAAIAWAAQAEAAACADQADACAAAEIAAAEQAAADgDACQgCADgEAAg");
	this.shape_99.setTransform(238.9128,128.6603,1.3376,1.3376);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#4E5153").s().p("Ag4AWQgHAAgFgFQgEgEAAgHIAAgLQAAgHAEgEQAFgFAHAAIBxAAQAHAAAFAFQAEAEAAAHIAAALQAAAHgEAEQgFAFgHAAg");
	this.shape_100.setTransform(245.8683,123.3768,1.3376,1.3376);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#24272A").s().p("AioCCIgCgJIAAivIAAggQgBgiADgHQADgGALgCIAKAAICAAAQCEAAAWgCQAWgBAHAMQAEAGgBAGQACDKgCAaQgBARgJAFIgKACIkrAAIgCAAQgNAAgEgIg");
	this.shape_101.setTransform(239.6437,130.8305,1.3376,1.3376);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("#C4B49B").s().p("ALUGlIkZsQIt1AAIkZMQIguAAICHsQIAAg5IT2AAIAAA5ICGMQg");
	this.shape_102.setTransform(247.373,212.0922,1.3376,1.3376);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("#DED0BE").s().p("AtzAnIAAhOIbnAAIAABOg");
	this.shape_103.setTransform(250.5833,150.4964,1.3376,1.3376);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f("#E62F33").s().p("AgwAmQgEgwAIgfIARADQAUACASgCQAdgBAFgCIADAaQADAdgCAYQgcAEgYAAQgYAAgVgEg");
	this.shape_104.setTransform(321.1529,120.4594,1.3376,1.3376);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f("#2A1213").s().p("AghCaQgMgEgBgVIAAgXQACgGABgHQAEgPgGgZQgHgmAIhPQABgGAHgNIANgYQAIgOgCgZIgEAAIAAgHIArAAIAAAHIgFAAIABAOQABAQAFAJIAMAYQAJANAAAGQAIBPgIAmQgEAZACAPQACAHACAGIAAAXQgCAVgLAEg");
	this.shape_105.setTransform(321.1409,123.6443,1.3376,1.3376);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f("#E62F33").s().p("AgWAKIAAgQIABgBQABgBAGAAIAgAAIADAAQAAAAABAAQAAABAAAAQABAAAAABQAAAAAAABIAAAPg");
	this.shape_106.setTransform(321.191,101.3903,1.3376,1.3376);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f("#323436").s().p("AimC4QgEi+gPgmQgRgqgRgeQgHgNgBgKQgEgeAggKQAGgCAmgEQANgBChAFQAgABAiAGIBtAOIAZACQAKABgBAEQgEAUhRgTQgygMhjgHQhagGgxADQgoACgNAGQgJAEgGANQgEAIANAXQAUAkAJAaQANAkAEAnQACAUAAANIACCHg");
	this.shape_107.setTransform(442.4718,179.3771,1.3376,1.3376);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f("#B7BBC1").s().p("AiVC/IgOgDQgEgBAAgFQgGi4gOglQgJgWgPgdIgNgYIgHgbQACgXAXgNQAQgJAWgDIAIgBQAOgDCIAGIAdACQAfABAkAGIB3APQAVADADAFQADADgBAEQAAAGgGAEQgQAKhEgQQgwgMhbgEQhPgEg3AEIguACQgNACgHAKQgCACgCAKQAAAHAKAQQAMATARAxQANAkADAkQABATgBANIAGBzIABAHQAAAFgDACQAAABgBAAQAAAAgBAAQAAABgBAAQgBAAAAAAgAigBLQAEA8ABAqIACABIgDh7QgBgpgRgzQAIAcAGBUgAidiyIgJACQgaADgMAIQgRALACAaIACACQgCgHADgGIACgGQAFgNALgFQANgGAjgCQA5gEBYADQAyACAlAEQghgGgfgBIgdgBQhfgEghAAIgSAAgACQicQA9APAMgHIgOgCIgLgCIhNgKIAdAGg");
	this.shape_108.setTransform(442.0084,178.8197,1.3376,1.3376);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f("#323436").s().p("AABAFIgLgRQgGgJAAgEQgBgGAEgBIADAAQgLAFAWAbQALAMADAKQADAJgCACQAAgEgPgYg");
	this.shape_109.setTransform(453.8343,187.932,1.3376,1.3376);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f("#626666").s().p("AALCAQAJg8gEgsQgDgagYhRIgYhKIAJAEIAXAJQAKAEAGAXQADAMABAQIAKA+QAJA+AAAiQAAAhgTAgIgSAYg");
	this.shape_110.setTransform(469.6463,180.1573,1.3376,1.3376);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f("#626666").s().p("AghBTIBDiqIgMBDQgKBNgFANQgFANgLAEIgIACQgJAAgHgGg");
	this.shape_111.setTransform(470.2148,146.4836,1.3376,1.3376);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.f("#626666").s().p("ACuHbQgjgFk0hBQgmgIgkACIg0AGQhAAHgRAhQgGAKABALIAAAGQgFgZADgZIAEgWIAbgUQAugYBagOQBagOCdAgQBOAQBBATQAFAAABggQAAgggHgQQgJgWgJgrQgLg0ADgdQAFgnAvh2QAnhgAfg/QAUgpAGhVQADglAAhDQAAgbAEgQQAEgTAMgJQAJgHAEAFQAFAJAFAAQANAAAfgjQgMASAABoQgBCHgCAHQgEAdhGCtQhECogQAbQgKARAVBzQAVBzgKAPQgQAYgHAEQgEACgJAAQgKAAgOgCg");
	this.shape_112.setTransform(428.6781,130.9509,1.3376,1.3376);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.f("#323436").s().p("AhlFEQBQi1AQgxQAkhqAWg6QAIgVgChYQgChhAFgdQAHgiAOAAQAKAAACAEQADAFADAfQACAVgFBUQgFBXACAcQACAggQAxQgVBCgCAOQgJA0hUDOQgPgKgzgGg");
	this.shape_113.setTransform(470.4342,112.0073,1.3376,1.3376);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.f("#323436").s().p("ABvCrQgygMh8gOQiXgPgwANQgzAPgaggQgXgeALgsQAIghAogIQAUgDASADIBDgFQAOgBDDApQDDApAYgDQAdgEADgqQADgegOhPQgPhJgCgSQgEgaALABIA6AIIAkBjQAhBugTBCQgSA9glATQgUAKgtACIgIAAQgsAAhCgRg");
	this.shape_114.setTransform(424.9342,183.1052,1.3376,1.3376);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.f("#454748").s().p("AAdAKIgXgCIgsgRIAhAFQAWAEAWAKg");
	this.shape_115.setTransform(469.1447,230.0827,1.3376,1.3376);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.f("#717677").s().p("AgIAFQgBgHABgBQACgBgCgHIARAIIgIAAQgCABgEAGIgCAIIgBgHg");
	this.shape_116.setTransform(431.7592,223.6623,1.3376,1.3376);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.f("#717677").s().p("AgHgXQgEgFgCgBIgDAAIAJgEIAYANIgHAAQgIAAAAACQgCAEAEASIAFAcIgMACQAAgygEgHg");
	this.shape_117.setTransform(440.1191,226.8391,1.3376,1.3376);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.f("#717677").s().p("AgJAKQgUgDgGgHIgCgFIAEgFIAAADIAHAFQAJAFANABQATADAXgPIgBAHQgDADgIAEQgMAFgOAAIgJgBg");
	this.shape_118.setTransform(434.936,221.934,1.3376,1.3376);

	this.shape_119 = new cjs.Shape();
	this.shape_119.graphics.f("#3D4659").s().p("AhACKIACgZQADgdAGgNIBSjPIAOAAQAQAAAGgCQAFgCgyBkIg2BvQgEAKgBAeIAAAcg");
	this.shape_119.setTransform(427.7437,241.4173,1.3376,1.3376);

	this.shape_120 = new cjs.Shape();
	this.shape_120.graphics.f("#9B9D9E").s().p("AgIAIQAMgtAOgNIgSBkIgSABQAEgUAGgXg");
	this.shape_120.setTransform(419.5203,253.1226,1.3376,1.3376);

	this.shape_121 = new cjs.Shape();
	this.shape_121.graphics.f("#9B9D9E").s().p("AhDCLQgBgkAFgWQACgHAbg5QAZg0AEgYQAEgZATgbQALgOAJgIIgCgCQAAAAAAgBQAAAAAAAAQAAgBABAAQAAAAABAAQAFABAKgEIAOAHQACA7gCgBQgCAAgiAKQgJAIgUAvQgYA4gFAKQgLATgCAjQgCARABAOg");
	this.shape_121.setTransform(430.7449,241.4856,1.3376,1.3376);

	this.shape_122 = new cjs.Shape();
	this.shape_122.graphics.f("#252931").s().p("ACgBcQAEgDgQgeQgKgTgYgLIhCgWIgwgRIgsgLQgfgIg2gEIgwgDIAAg3QA9AHB+AyQB7AvASAVQAVAaAGAgg");
	this.shape_122.setTransform(464.0284,236.0015,1.3376,1.3376);

	this.shape_123 = new cjs.Shape();
	this.shape_123.graphics.f("#252931").s().p("AjHBUQgDgGAAgJQAAgRANgOQARgSCdgvQCbgwA/gIIgRA8QhqgDgyAMIgsALIgyAPQgOAEg4AOQgdAHgHAJQgKARgCAMQAAAGABADg");
	this.shape_123.setTransform(404.4044,234.2292,1.3376,1.3376);

	this.shape_124 = new cjs.Shape();
	this.shape_124.graphics.f("#9B9D9E").s().p("ACcA4QgIgMgYgKIhEgXQgdgJgRgNQgNgMgZgGQgggIhGgdIhAgcIAPgEQA9AHCCAyQB9AxAdAZQAPANAIAaQAEAOACAMIgUABQgCgQgRgbg");
	this.shape_124.setTransform(464.3963,235.0318,1.3376,1.3376);

	this.shape_125 = new cjs.Shape();
	this.shape_125.graphics.f("#9B9D9E").s().p("AjcBaQgCgIABgKQABgVAPgNQAagXCegwQCbgxBBgHIAYALQiOArgzAMIgsALIgzAPIhGAWQgbAKgHALQgLARgEAPQgDAIAAAEg");
	this.shape_125.setTransform(403.3288,233.4601,1.3376,1.3376);

	this.shape_126 = new cjs.Shape();
	this.shape_126.graphics.f("#B3B5B8").s().p("AgCBDIAAiFIAFAAIAACFg");
	this.shape_126.setTransform(439.5172,212.7275,1.3376,1.3376);

	this.shape_127 = new cjs.Shape();
	this.shape_127.graphics.f("#3D4659").s().p("AgNBGIAAiLIAbAAIAACLg");
	this.shape_127.setTransform(434.5013,213.4966,1.3376,1.3376);

	this.shape_128 = new cjs.Shape();
	this.shape_128.graphics.f("#252931").s().p("AgXBBIgMgGIAAiAIBHAAIAAB6QAAADgDAEQgHAIgRACIgHAAQgMAAgNgFg");
	this.shape_128.setTransform(435.1408,213.4833,1.3376,1.3376);

	this.shape_129 = new cjs.Shape();
	this.shape_129.graphics.f("#454748").s().p("AgLAmQgLgEgFgNQgFgNAEgPQAFgQAMgJQALgIALADQAMAFAFAMQAFAOgEAPQgGAPgLAIQgIAHgIAAIgHgBg");
	this.shape_129.setTransform(376.1825,253.8917,1.3376,1.3376);

	this.shape_130 = new cjs.Shape();
	this.shape_130.graphics.f("#454748").s().p("AgEArQgNgBgIgOQgIgOABgQQACgSALgMQALgLAMABQAOABAIAOQAIAOgCAQQgCASgKAMQgKAKgKAAIgEAAg");
	this.shape_130.setTransform(421.7273,268.4776,1.3376,1.3376);

	this.shape_131 = new cjs.Shape();
	this.shape_131.graphics.f("#040D1C").s().p("AAAApQgOgBgLgGQgMgGgEgOQgDgOAGgOQAGgNASgFQAJgCAHABIAAgIIAoAAIABAXQABAXgCAIQgFAWgPAFQgGACgJAAIgHgBg");
	this.shape_131.setTransform(373.548,251.035,1.3376,1.3376);

	this.shape_132 = new cjs.Shape();
	this.shape_132.graphics.f("#040D1C").s().p("AAAAtQgQgBgMgGQgNgHgDgPQgDgOAFgRQAFgNAPgFQAHgDAHAAIAAgIIA0AAIACAYQAAAZgCAKQgFAXgQAGQgGABgJAAIgIAAg");
	this.shape_132.setTransform(418.5199,266.3169,1.3376,1.3376);

	this.shape_133 = new cjs.Shape();
	this.shape_133.graphics.f("#454748").s().p("AgTAbQgJgLAAgQQAAgOAJgMQAIgLALAAQAMAAAJALQAHALAAAPQAAAQgHALQgJALgMAAQgLAAgIgLg");
	this.shape_133.setTransform(488.6066,254.7946,1.3376,1.3376);

	this.shape_134 = new cjs.Shape();
	this.shape_134.graphics.f("#454748").s().p("AgIAXQgHgDgCgJQgDgIAEgJQADgJAIgFQAHgEAHACQAHACACAKQADAIgEAJQgEAJgHAFQgFADgEAAIgFgBg");
	this.shape_134.setTransform(477.8888,235.9012,1.3376,1.3376);

	this.shape_135 = new cjs.Shape();
	this.shape_135.graphics.f("#454748").s().p("AgMAjQgLgEgEgNQgEgOAFgNQAGgPAMgHQAKgHAMAEQALAEAEANQADAOgFANQgGAPgMAHQgHAFgGAAIgIgCg");
	this.shape_135.setTransform(413.6133,235.8009,1.3376,1.3376);

	this.shape_136 = new cjs.Shape();
	this.shape_136.graphics.f("#040D1C").s().p("AAAAqQgPgBgLgGQgMgHgDgNQgDgNAGgQQAEgNAOgFQAHgCAGAAIAAgHIAwAAIABAXQABAXgCAIQgFAXgOAEQgGACgJAAIgHAAg");
	this.shape_136.setTransform(411.6469,233.312,1.3376,1.3376);

	this.shape_137 = new cjs.Shape();
	this.shape_137.graphics.f("#040D1C").s().p("AgNAaQgKgDgDgOQgBgGAAgPIABgPIAfAAIAAAFIAJACQAJADADAIQAIAXgRAJQgHAEgKAAIgDABIgKgCg");
	this.shape_137.setTransform(476.6984,235.1739,1.3376,1.3376);

	this.shape_138 = new cjs.Shape();
	this.shape_138.graphics.f("#040D1C").s().p("AgSAjQgMgEgFgUQgCgHABgUIABgTIAqgBIAAAHIAMACQAMAEADALQAKAfgVALQgKAFgNABIgDABQgJAAgGgCg");
	this.shape_138.setTransform(489.7023,252.6946,1.3376,1.3376);

	this.shape_139 = new cjs.Shape();
	this.shape_139.graphics.f("#717677").s().p("ABsAoQgEgGgFgCQgGgDgXgEQgXgEgGgDIgagKIiagqIABgHQEFA9AJAHQAIAHAAADQAAABAAAAQAAABgBAAQAAAAAAABQAAAAgBAAQgQgDgHAEIgDABQgBAAAAAAQgBAAAAAAQgBgBAAAAQAAgBgBAAg");
	this.shape_139.setTransform(458.6132,226.3403,1.3376,1.3376);

	this.shape_140 = new cjs.Shape();
	this.shape_140.graphics.f("#454748").s().p("AgKAlQgMgDgFgOQgFgNAFgPQAEgPAMgJQALgIALADQAMAEAFANQAFAOgFAOQgEAQgMAJQgIAGgHAAIgHgCg");
	this.shape_140.setTransform(370.2303,251.3676,1.3376,1.3376);

	this.shape_141 = new cjs.Shape();
	this.shape_141.graphics.f("#454748").s().p("AgEArQgNgBgIgOQgJgOACgQQACgSALgMQALgLAMABQAOABAIAOQAIAOgBAQQgCASgLAMQgKAKgLAAIgDAAg");
	this.shape_141.setTransform(414.9294,266.605,1.3376,1.3376);

	this.shape_142 = new cjs.Shape();
	this.shape_142.graphics.f("#454748").s().p("AgTAbQgIgLgBgQQABgPAIgLQAIgLALAAQAMAAAIALQAIALAAAPQAAAQgIALQgIALgMAAQgLAAgIgLg");
	this.shape_142.setTransform(493.89,253.5239,1.3376,1.3376);

	this.shape_143 = new cjs.Shape();
	this.shape_143.graphics.f("#454748").s().p("AgNAjQgLgEgDgNQgEgOAFgNQAGgPAMgHQAKgHALAEQALAEAEAOQAEANgFANQgGAPgMAHQgHAFgGAAQgFAAgEgCg");
	this.shape_143.setTransform(406.4454,233.0118,1.3376,1.3376);

	this.shape_144 = new cjs.Shape();
	this.shape_144.graphics.f("#323436").s().p("AimC4QgEi+gPglQgQgpgSggQgHgLgBgMQgEgeAggKQAGgCAmgEQANgBChAFQAgABAiAGIBtAOIAZACQAKABgBAFQgBAHgPACQgXACgugLQgygMhjgHQhbgGgwADQgoACgNAGQgJAEgGANQgEAJANAWQAUAkAJAaQANAkAEAnQACAUAAANIACCHg");
	this.shape_144.setTransform(442.4718,169.4121,1.3376,1.3376);

	this.shape_145 = new cjs.Shape();
	this.shape_145.graphics.f("#B7BBC1").s().p("AiVDAIgOgEQgEgCAAgEQgGi5gOgkQgJgVgPgeIgNgYIgHgbQACgWAXgNQAQgKAWgDIAIgBQAMgDCKAHIAdABQAfABAkAGIBsAOIALABQAVADADAFQADADgBAEQgBAGgFADQgQALhEgQQgvgMhcgEQhOgEg4AEIguACQgNACgHAJQgCAEgCAKQAAAGAKAQQAMASARAzQANAjADAlQABASgBAMIAGB0IABAIQAAADgDAEIgEABgAigBMQAEA7ABAqIACAAIgDh6QgBgpgRg0QAIAdAGBVgAiwgrIAAgCQgJgYgPgZQAPAeAJAVgAjZh/QgCgGADgGIACgGQAFgNALgFQANgHAjgCQA6gDBXADQA8ADAqAFIAHABIAEAAIAKABIgKgBIgEAAIgHgBIgNgCQgjgGgfgBIgdgCQiKgEgIACIgJABQgaADgMAIQgRALACAaIACABIAAAAgACQidQA9APAMgGIhjgOIAaAFg");
	this.shape_145.setTransform(442.0084,168.8882,1.3376,1.3376);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_145},{t:this.shape_144},{t:this.shape_143},{t:this.shape_142},{t:this.shape_141},{t:this.shape_140},{t:this.shape_139},{t:this.shape_138},{t:this.shape_137},{t:this.shape_136},{t:this.shape_135},{t:this.shape_134},{t:this.shape_133},{t:this.shape_132},{t:this.shape_131},{t:this.shape_130},{t:this.shape_129},{t:this.shape_128},{t:this.shape_127},{t:this.shape_126},{t:this.shape_125},{t:this.shape_124},{t:this.shape_123},{t:this.shape_122},{t:this.shape_121},{t:this.shape_120},{t:this.shape_119},{t:this.shape_118},{t:this.shape_117},{t:this.shape_116},{t:this.shape_115},{t:this.shape_114},{t:this.shape_113},{t:this.shape_112},{t:this.shape_111},{t:this.shape_110},{t:this.shape_109},{t:this.shape_108},{t:this.shape_107},{t:this.shape_106},{t:this.shape_105},{t:this.shape_104},{t:this.shape_103},{t:this.shape_102},{t:this.shape_101},{t:this.shape_100},{t:this.shape_99},{t:this.shape_98},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_94},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.instance}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,497.7,280.7);


(lib.personajes3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.HOMBRE1();
	this.instance.parent = this;
	this.instance.setTransform(72.45,49.5,3.4295,3.0265,0,0,180,18.4,44.9);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#323436").s().p("ACdAzQgBgMADgUQAEgnAMgkQAKgbAUgjQAMgXgDgIQgHgNgJgEQgMgGgpgDQgwgDhbAHQhiAGgyAMQgvAMgWgDQgPgBgBgIQgBgEAKgBIAZgCIBsgOIAWgDQAZgEAUgBQCggFAOACQAiACAJADQAgAKgDAfQgBAHgHAPQgRAdgRAsQgKAYgFBoQgDA0gBAwIgNACg");
	this.shape.setTransform(451.5887,100.1995,1.4562,1.4562,0,0,180);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#B6BCC5").s().p("AhrF+QgggXgRgRIgMgLQASgeAPgSQAdgmAohdIA7iKQAUgqgHgeQgNgogGgmQgIgwgCgWQgDgnADgfQAFg6AbgqQAkg4A2ATIALAFQA1AfAACCQgBBRAGCjQABAXg6B4Qg+CBgoAvQgMAOgVAkQgXAogKAMIgygkg");
	this.shape_1.setTransform(408.8771,34.9379,1.1346,1.1346);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#D6D8D8").s().p("AiRFsQAPg4AphyQAuiCANgLQAMgKgEghQgGg8ACgnQACg6AAhaIgBhPQAGgLAKgOQATgcAVgNQBDgqAwB2IgNB0QgQB/gQA7IgCAeQgCAhgCAMQgFAZhAB3IhgCzg");
	this.shape_2.setTransform(411.4013,29.8679,1.1346,1.1346);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#E8C496").s().p("AAMCJQgWgEgRgNQgGgFgGgIQgOgRgEgTQgGgSABgQQABgNAKgeQALgiALgZQAHgNAPgSQAMgNACgMIAIgRIAqARQgHAPACASQABAJACAJIADAXQABAcgMAaQgMAaABAYQABAbAPANQAKAIABAOQABAJgGADIgUAHQgDABgGAAIgRgCg");
	this.shape_3.setTransform(393.6725,86.1767,1.1346,1.1346);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#E8C496").s().p("AgLgcQALgSAJACQAGAAADAFQAEAkgUAbIgUAVg");
	this.shape_4.setTransform(418.4258,-56.3297,1.1346,1.1346);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#E9A981").s().p("AgUAJQgCgCgBgEIAAgEQABgBASgDIAcgFQgNAPgPAEIgKACQgEAAgCgCg");
	this.shape_5.setTransform(389.5609,-43.5469,1.1346,1.1346);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#E5A47C").s().p("AgYACQgCgGACgEIAUAAQAVABAJAHIgvAIIgDgGg");
	this.shape_6.setTransform(389.3402,-44.7742,1.1346,1.1346);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#473834").s().p("AhpAiIgBAAQgJgBgIgGQgKgIAAgNIAAgDQgGgBgCgBQgCgBAAgIIABgOQABgDAGgCIAHgCIgEACQgDACAAADQgBAFAEAAQAIgRAXABIBRAAQATADAGALICLAMIgDARIiGgLIAAAGQAAAGgFAIQgFAJgOAFIgDABgAh5gQIAAAaIACAFQADAHAIAEIBcAAQAKgDAAgNIAAgaQgDgHgJAAIhdAAQgKADAAAEg");
	this.shape_7.setTransform(401.9276,-60.7716,1.1346,1.1346);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#473834").s().p("AAnABQgNgMgPAFQgLAFgOABQgaAFgJgJIAIgCIAhgHIAagBQAcAFADAYQgDgIgHgGg");
	this.shape_8.setTransform(393.5602,-64.8276,1.1346,1.1346);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#473834").s().p("AgJAJQgEgEAAgFQAAgFAEgDQAEgEAFAAQAGAAAEAEQAEAEAAAEQAAAFgEAEQgEAEgGAAQgFAAgEgEg");
	this.shape_9.setTransform(391.9151,-61.0268,1.1346,1.1346);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#ECB697").s().p("AgIAQQgcgFgKgHIgBgBIAAgBIAKgIQAOgJAVAAIAQACQATAEAOAIIABAAIgBABQgUAQgcAAgAgrADQAKAFAaAFQAcADAWgQQgNgHgSgEIgOgCQgdAAgMAQg");
	this.shape_10.setTransform(393.702,-61.0268,1.1346,1.1346);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgcAKIgRgGQAFgLATgFQAKgCAJAAQARgCAfAPQgEADgIAEQgQAIgUABIgDAAQgIAAgPgFg");
	this.shape_11.setTransform(393.6737,-61.0378,1.1346,1.1346);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#473834").s().p("AglgSIAWAPQAaAOAbAEIhCADg");
	this.shape_12.setTransform(411.9969,-89.8165,1.1346,1.1346);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#473834").s().p("AglgSIAWAPQAaAOAbAEIhBADg");
	this.shape_13.setTransform(402.6935,-90.9511,1.1346,1.1346);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#473834").s().p("AglgRIAWAOQAaAOAbADIhBAFg");
	this.shape_14.setTransform(394.2977,-90.2703,1.1346,1.1346);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#473834").s().p("ABMAfIg2gXQgpgdgtgdQhbg6gRAHIgeguQgfgxAAgMQAAgKAPADQAfAHAegCQAggCBpgKQBggHAfAMQA0AUAiAwQAvBCgHBhQgHBdg8BFQgTAVgWARIgSAMQgXiggIgjg");
	this.shape_15.setTransform(408.9638,-64.2648,1.1346,1.1346);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#B6BCC5").s().p("AhaAdICshZIAQA+QgEAShfAWIhgATg");
	this.shape_16.setTransform(411.146,-26.5644,1.1346,1.1346);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#D6D8D8").s().p("AgIHfIi/gMQgUn/gLhFQgGgrA/iGIBBh9IDTg/IAaAUQAfAbAXAoQBJB/glDHQgpDhgMB/QgKBxANAuQAJAhiYAAIgiAAg");
	this.shape_17.setTransform(410.4972,27.4067,1.1346,1.1346);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#E8C496").s().p("AgvD1QAKgqgGgMQgHgLgmAHQgpALgMAAQgPAAgJgGQgGgEgHgJQgDgGADgQQADgQgBgCQAAgBAAgBQAAAAAAgBQAAAAAAgBQAAAAAAAAIABAAQgEgIgDgJIgBgJQgGgJACgLQACgIAAgQQAAgCgJAAQgMgCgHgEQgHgEAAgJIABgJQATg2ATgXIACh/QAUhQBTggQApgQAlAAIAhAAQAoADAiAPQBrAsAFCKQAECIgzBAQgQATgUALIgRAGQgVA2gLBMIiUAeIAMg2g");
	this.shape_18.setTransform(407.8195,-56.0631,1.1346,1.1346);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#B6BCC5").s().p("AgbDkQgzgVhcg4Qhjg8gqgoQAIgWAVgfQAagmAIgQQgIASDYBNQAbgYAYglQAQgXAbgvQAthPAughQBDgxBCAxQAzAlgZBAQgSAxg2AwQgeAahkB3QhTBbgkAAQgGAAgEgCg");
	this.shape_19.setTransform(376.6807,16.8634,1.1346,1.1346);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#E8C496").s().p("AAzBYQglgagTgDQgQgCgggXIgcgYQgFgDgCgMQgCgMAFgKQAEgNADgGQAGgKALADIgCgCIglgYQgjgaAFgHIAAgBQAGgEBEAlIAjAVQAbAQAEgBQAEgBgFgKIgJgRQgIgZAIgMQAEgHAHAOIALAbQAHAQAUAhQAJAQAHATQAEAMA/A5IgxAkQgOgNgSgNg");
	this.shape_20.setTransform(336.0809,9.6346,1.1346,1.1346);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#111011").s().p("AjiHIIh0qJQgIgnAWgpQAthSCagFQCZgFgEgrQgBgNgRgPIgPgNIFLgJIAOBnQANBrAAAZQAAAQgiAcQgmAfg3AXQiVA+iSgxIA0I7g");
	this.shape_21.setTransform(392.1232,132.3034,1.1346,1.1346);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#353335").s().p("AiTG3IhogNQgxh7gxiWQhhkqACiGQACiGDygSQB8gJCWAQQAsgDBAgPIEHAgIgzAzQg2A3gPAOQgPANhuAzIh5A4QgNAHgvAFQgnAEgnAAQgcAAhNgIIhHgIQBUDuAIAUQAFAKAdBtQAgBxAWAgQAXAhgBAWQgBAMgHASQgBAGgfAAQgbAAgvgEg");
	this.shape_22.setTransform(367.2076,130.7176,1.1346,1.1346);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#5F4A38").s().p("Ai4BXQgFgBgCgRQgBgPAIgLQAJgNAagMQAkgQBOgpIAUgvIC/AJIAPAkQADBHgKAIQgKAJhUgFIiRAtg");
	this.shape_23.setTransform(369.0118,193.3999,1.1346,1.1346);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#5F4A38").s().p("Ai4BXQgFgBgCgSQgBgOAIgLQAKgNAZgLQAkgRBOgpIAVgvIC+AJIAPAlQADBGgKAJQgKAIhUgFIiQAtg");
	this.shape_24.setTransform(343.1031,189.2871,1.1346,1.1346);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#323436").s().p("AjpECQgChDgEhKQgIiSgNghQgXg7gYgrQgKgSgCgNQgFgrAtgOQAJgDA0gFQAZgCDcAHQAsACAwAJICZATQANACAVABQAPACgBAGQgCAKgVADQgfADhCgQQhGgRiKgJQh/gJhEAEQg4ADgTAJQgMAFgJATQgFAMASAfQAcAyANAlQASAzAFA2QADAcAAASIADC+g");
	this.shape_25.setTransform(424.9798,100.9313,1.1732,1.1732);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#323436").s().p("AACAHIgRgZQgIgMAAgGQgBgHAFgCIAEAAQgOAGAeAmQAPARAGAPQAEAMgDAEQgBgHgUghg");
	this.shape_26.setTransform(438.9505,111.4998,1.1732,1.1732);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#626666").s().p("AAPCzQANhTgGg/QgEglgihwIghhpIAMAHQAQAHAQAFQAPAEAHAhIAGAnQAIArAHAtQAMBXAAAwQAAAugaAsQgNAWgNANg");
	this.shape_27.setTransform(458.4407,101.8945,1.1732,1.1732);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#626666").s().p("AD1KZQgngFhbgTIlghJQg1gLgyACIhJAJQhbAJgXAuQgKASACAQQgGghAEgiIAGgeQAHgMAfgRQA/ggB/gUQB+gUDcAtQBvAWBbAaQAHABAAgtQAAgsgJgWQgMgggNg8QgPhJAEgoQAHg3BCilQA1iHAshZQAcg5AJh4QAEg1AAhcQAAgnAFgWQAHgaAQgNQANgKAFAIQAIAMAHAAQAMgBAbgZIAWgWQgRAaAACQQgCDAgBAHQgHAohhDyQhgDtgWAmQgOAYAdCgQAdCigOAVQgVAigLAFQgGADgNAAQgMAAgUgDg");
	this.shape_28.setTransform(407.9581,41.4761,1.1732,1.1732);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#323436").s().p("ADvECQgggFg0gNQhHgSitgSQjUgXhDATQhHAVgkgtQghgpAPg+QAMgvA4gKQAcgFAZAEIBegGQATgCESA6QESA5AhgFQAqgGAEg5QADgrgUhvQgUhmgDgaQgGgkAPACQAXACA7AIIARAoQAUAyAOAxQAuCbgbBcQgZBWg1AbQgaANhAADIgOAAQghAAgjgFg");
	this.shape_29.setTransform(403.4336,105.5727,1.1732,1.1732);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#454748").s().p("AAJALIg+gZIAtAIQAfAFAfAPIgOABg");
	this.shape_30.setTransform(457.7955,163.3394,1.1732,1.1732);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#717677").s().p("AgLghQgEgHgEgBIgEAAIANgFIAiARIgKAAQgKABgCACQgCAFAFAbIAIAmIgSADQAChGgIgKg");
	this.shape_31.setTransform(422.0724,159.3213,1.1732,1.1732);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#717677").s().p("AgNAOQgcgDgJgKIgCgJIAGgHIgBAFIAKAHQANAHASACQARACAXgJQALgFAIgGIgBAKQgFAFgLAFQgPAIgTAAIgPgCg");
	this.shape_32.setTransform(415.7079,153.2878,1.1732,1.1732);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#3D4659").s().p("AhaDCQAChBAMgeIB0kiQAlABANgEQAIgDhGCMIhNCdQgHAWABBJg");
	this.shape_33.setTransform(406.8637,177.2389,1.1732,1.1732);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#252931").s().p("ADhCBQAFgEgWgqQgOgcgigOQgzgRgpgPIhFgXIg9gRQgrgLhMgGIhDgCIAAhOQBVALCxBEQCtBDAZAeQATAWALAgQAFAQACALg");
	this.shape_34.setTransform(451.4603,170.5837,1.1732,1.1732);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#252931").s().p("AkYB1QgEgIAAgMQAAgYASgUQAZgZDbhCQDahEBZgKIgZBTQglgBguABQhcACgsALIg9AOQgJACg+AUQgTAGhPATQgpAKgJAOQgOAYgDAQQgBAIACAEg");
	this.shape_35.setTransform(378.195,168.4133,1.1732,1.1732);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#B3B5B8").s().p("AgCBeIAAi7IAGAAIAAC7g");
	this.shape_36.setTransform(421.3391,141.9876,1.1732,1.1732);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#3D4659").s().p("AgSBhIAAjBIAlAAIAADBg");
	this.shape_37.setTransform(415.18,142.8969,1.1732,1.1732);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#252931").s().p("AggBcIgRgJIAAi0IBjAAIAACqIgEALQgJALgYACIgMABQgQAAgRgGg");
	this.shape_38.setTransform(415.9719,142.9024,1.1732,1.1732);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#454748").s().p("AgPA1QgQgFgHgUQgHgSAGgVQAHgVAQgMQAQgMAQAEQAQAFAHAUQAHASgGAVQgHAVgQANQgLAIgLAAIgKgBg");
	this.shape_39.setTransform(343.4698,192.5807,1.1732,1.1732);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#454748").s().p("AgFA8QgTgCgMgTQgLgTACgYQADgYAPgRQAQgQARACQATACAMATQALATgCAYQgDAZgPAQQgNAPgPAAIgFgBg");
	this.shape_40.setTransform(399.4888,210.5075,1.1732,1.1732);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#040D1C").s().p("AAAA6QgUgBgQgJQgRgJgFgTQgFgUAKgUQAIgSAZgHQANgDAKABIAAgLIA3ABIACAfQABAggDAMQgGAggVAGQgIADgNAAIgKgBg");
	this.shape_41.setTransform(340.2305,189.0852,1.1732,1.1732);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#454748").s().p("AgbAmQgMgQAAgWQAAgVAMgQQALgPAQAAQARAAALAPQAMAQAAAVQAAAWgMAQQgLAPgRAAQgQAAgLgPg");
	this.shape_42.setTransform(481.6988,193.6952,1.1732,1.1732);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#454748").s().p("AgLAgQgKgEgEgMQgEgMAFgMQAGgOAKgGQALgHAJAEQALADADANQAEAMgFAMQgGAOgKAGQgIAFgFAAIgHgCg");
	this.shape_43.setTransform(468.5007,170.4371,1.1732,1.1732);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#454748").s().p("AgSAxQgQgFgFgTQgGgTAIgTQAIgVARgKQAPgKAQAGQAPAGAGASQAFATgHATQgJAVgQAKQgKAHgJAAQgGAAgGgDg");
	this.shape_44.setTransform(389.4875,170.3198,1.1732,1.1732);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#040D1C").s().p("AAAA7QgVgCgQgIQgQgJgEgTQgFgTAIgVQAFgTAUgGQAKgEAIABIAAgLIBFABIABAfQACAhgDAMQgHAfgVAHQgIACgMAAIgKAAg");
	this.shape_45.setTransform(387.1008,167.2959,1.1732,1.1732);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#040D1C").s().p("AgTAlQgNgEgFgVQgCgIABgVIABgUIAtgBIAAAHIAMACQANAEADAMQALAhgWAMQgLAFgOABIgGABQgIAAgFgCg");
	this.shape_46.setTransform(467.0205,169.5474,1.1732,1.1732);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#040D1C").s().p("AgaAxQgSgGgGgbQgCgKABgcIABgcIA8AAIAAAJIAQADQARAFAFAQQAGATgDAQQgEARgPAHQgNAHgTACIgHAAQgLAAgIgCg");
	this.shape_47.setTransform(483.0553,191.0996,1.1732,1.1732);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#717677").s().p("ACYA4QgGgIgHgDQgIgEghgGQgggFgJgEIgkgOIjYg8IABgKQFuBWANALQALAJAAAFQAAABAAAAQAAABAAAAQgBAAAAABQgBAAAAAAIgNgBQgOgBgGAEIgEABQgDAAgCgDg");
	this.shape_48.setTransform(444.8319,158.6878,1.1732,1.1732);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#454748").s().p("AgOA0QgRgFgHgSQgIgTAHgVQAHgWAQgMQAQgLAPAFQARAFAHASQAHAUgGAUQgHAWgQAMQgLAIgLAAIgJgCg");
	this.shape_49.setTransform(336.1669,189.4718,1.1732,1.1732);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#454748").s().p("AgbAlQgMgPAAgWQAAgVAMgPQALgQAQAAQARAAAMAQQALAPAAAVQAAAWgLAPQgMAQgRAAQgQAAgLgQg");
	this.shape_50.setTransform(488.1806,192.1701,1.1732,1.1732);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#323436").s().p("AjpECQgChDgEhKQgIiSgNghQgXg7gYgrQgLgVgBgKQgFgrAtgOQAIgDA1gFQAZgCDcAHQAsACAwAIICZAUIAiADQAPACgBAGQgCAKgVADQgfADhCgQQhGgRiKgJQh/gJhEAEQg4ADgTAJQgMAFgJATQgFAMASAfQAcAyANAlQASAyAFA3QADAcAAASIADC+g");
	this.shape_51.setTransform(424.9798,88.7303,1.1732,1.1732);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#323436").s().p("AhFHVQgcgKgsgFQBvj+AXhEQAwiNAihaQALgdgDh7QgDiIAHgpQAJgwAUAAQAOAAADAFQAEAJAEArQADAdgHB2QgHB5ADAnQAEAugXBFQgdBcgEATQgIAug+CjQgeBSgeBIQgFgEgPgEg");
	this.shape_52.setTransform(459.3734,18.13,1.1732,1.1732);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#626666").s().p("AgvB0IBfjvIgHAjQgIAmgDAXIgIBDQgGArgGAPQgHASgQAGQgGACgFAAQgMAAgLgIg");
	this.shape_53.setTransform(459.0859,60.537,1.1732,1.1732);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#B7BBC1").s().p("AjkEHQgHgCAAgGQgChCgEhHQgJiNgNggQgMgfgVgoIgSgiIgKgmQACggAhgSQAWgNAggEIALgBQAQgEDCAIIAoACQAsABAyAJICnAVQARACAFACQAJACAEAFQADAEgBAHQgBAHgHAGQgXAPhggYQhCgQiAgFQhugGhOAFIhBADQgSADgKANIgDAJIgCAJQgBAGADAGIAMAUQASAdAXBDQARAyAFAzQACAagCASIAICiIACAKQAAACgCADQgBAEgCABIgFACgAjhBqQAGBNABBBIADABIgEitQAAgOgEgYQgGgtgPguQALAoAIB3gAj3g+IAAgBQgPgngSgeQAUAnANAfgAjcj5IgNABQgkAFgRALQgXAQACAkIACADQgDgKAFgJIADgHQAHgTAPgHQASgJAxgDQBTgEB5AEQCOAGBCAQQBUAUAUgJQgLgDgJAAIgPgCIiYgUIgBAAQgwgIgrgCIgpgCQiJgFguAAIgWABg");
	this.shape_54.setTransform(424.4024,100.2912,1.1732,1.1732);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#B7BBC1").s().p("AjREMIgTgFQgHgCAAgGQgChCgEhHQgJiNgNggQgMgfgVgoIgSgiIgKgmQACggAhgSQAWgNAggEIALgBQAQgEDCAIIAoACQAsABAyAJICnAVIAWAEQAJACAEAFQADAEgBAHQgBAIgHAEQgYAPhfgXQhCgQiAgGQhwgFhMAFQg0ABgNACQgSADgKANIgDAJIgCAJQgBAGADAGIAMAUQARAbAYBFQARAyAFAzQACAagCASIAICiIACAKQAAAFgFAFQgCABgDAAgAjhBqQAGBNABBBIADABIgEitQAAgOgEgYQgGgtgPguQALAoAIB3gAj3g+IAAgBQgOgngTgeQAUAnANAfgAkxiyQgDgJAFgJIADgHQAHgTAPgHQASgJAxgDQBRgFB7AFQBRADA5AHIAEAAIASACIAHABIgHgBIgSgCIgEAAIgNgCIgBAAQgwgJgrgBIgpgCQi8gJgRAEIgNACQgkAFgRALQgXAQACAkIACACIAAAAgADJjcQBVAVATgJQgGgCgOgBIh9gRQAXAEASAEg");
	this.shape_55.setTransform(424.4024,88.0608,1.1732,1.1732);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#717677").s().p("AgMAHQgBgJACgCQACgCgDgKIAZANQgHgCgEABQgEABgFAKIgDAKIgCgKg");
	this.shape_56.setTransform(411.813,155.3618,1.1732,1.1732);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#9B9D9E").s().p("AgLAKQARg+AUgSIgZCNIgaAAQAFgcAJghg");
	this.shape_57.setTransform(396.7319,191.6421,1.1732,1.1732);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#9B9D9E").s().p("AheDCQgBgxAHggQACgKAlhPQAkhKAGghQAGgjAbgmIAbgfIgCgCQgBgDAEAAQAGAAAOgEIAUAJQADBTgDgBQgBgBgZAHIgZAHQgMAMgcBBQghBPgIAOQgPAbgEAxQgBAYABATg");
	this.shape_58.setTransform(410.5451,177.3001,1.1732,1.1732);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#9B9D9E").s().p("ADbBPQgKgRgjgOQgQgHhQgZQgpgOgWgSQgTgSgkgIQgtgLhigoIhZgmIAWgHQBWAJC1BIQCwBEAnAjQAVASAMAmQAGATACAQIgcACQgDgWgXgmg");
	this.shape_59.setTransform(451.9296,169.3812,1.1732,1.1732);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#9B9D9E").s().p("Ak1B+QgDgLABgPQACgdAVgSQAkggDehEQDZhEBcgKIAhAPQjHA9hHAQIg+AQIhIAVQhKAWgYAJQgmANgKAQQgPAYgGAWQgDAKAAAGg");
	this.shape_60.setTransform(376.8424,167.4455,1.1732,1.1732);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#040D1C").s().p("AAAA/QgWgBgRgKQgSgJgFgVQgEgUAIgXQAGgUAVgHQALgEAJABIAAgMIBKABIABAiQACAjgDANQgIAigWAHQgJADgMAAIgMgBg");
	this.shape_61.setTransform(395.5223,207.868,1.1732,1.1732);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#454748").s().p("AgFA8QgTgCgLgTQgMgTACgYQADgYAPgRQAQgQARACQATACAMATQALATgCAYQgDAZgPAQQgNAPgPAAIgFgBg");
	this.shape_62.setTransform(391.1094,208.2198,1.1732,1.1732);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#454748").s().p("AgSAxQgPgGgGgSQgFgTAHgTQAJgVAQgKQAQgKAPAGQAQAFAFATQAGATgJATQgIAVgQAKQgKAGgJABQgGAAgGgDg");
	this.shape_63.setTransform(380.6887,166.9176,1.1732,1.1732);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#323436").s().p("ADcBIQgBgSADgcQAGg2ASgzQANglAcgyQASgfgFgMQgJgTgNgFQgSgJg4gDQhEgEh/AJQiKAJhGARQhCAQgfgDQgVgDgCgKQgBgGAOgCIAjgDICYgTIAegFQAjgEAcgCQDcgHAYACQA0AFAJADQAuAOgFArQgDAQgJAPQgXAogYA+QgOAhgICSQgEBKgBBDIgSAEg");
	this.shape_64.setTransform(-5.7425,103.7797,1.0433,1.0433);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#323436").s().p("AgVAeQAFgNAPgSQAggngPgFIAEAAQAEABAAAIQgBAGgIAMIgQAZQgUAggBAHQgDgDAEgNg");
	this.shape_65.setTransform(-18.2056,113.1917,1.0433,1.0433);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#626666").s().p("AgXC7QgagsAAguQAAgvAMhYIAOhXIAGgoQAIghAPgEQAZgIATgLIghBpQgiBwgEAlQgEAnAFA5QACAdAEAVIARAqQgMgMgOgWg");
	this.shape_66.setTransform(-35.4999,104.6363,1.0433,1.0433);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#626666").s().p("AknKZQgKgEgWgiQgOgWAeihQAdihgOgXQgXgnhfjsQhhjygHgoQgBgKgCi9QgBiUgRgXIAWAWQAcAaAMAAQAHAAAHgLQAGgJANAKQAQAOAGAaQAGAWAAAmQAABcAEA1QAJB4AbA5QAsBYA2CIQBCClAHA3QAEAogPBJQgNA8gMAgQgJAWAAAtQAAAsAHAAQBbgaBvgXQDbgsB+ATQB/AUA/AgQAgARAGAMIAGAfQAEAggFAgQABgPgJgRQgXguhbgJQgtgHgcgBQgygDg1ALIlgBJQhcATgmAFQgUADgNAAQgNAAgGgDg");
	this.shape_67.setTransform(9.3052,50.8524,1.0433,1.0433);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#323436").s().p("AlAEHQhAgDgbgNQg0gbgZhWQgbhcAuibQAOgxAUgyIARgoIBSgKQAPgCgGAkQgDAagUBmQgUBvADArQAEA5AqAGQAhAFESg5QESg6ATACQAsAEAyACIA1ABQA4AKALAvQAQA+ghApQgkAthIgVQhCgTjUAXQiuAShGASQg0ANggAFQgjAFghAAIgOAAg");
	this.shape_68.setTransform(13.4074,107.9074,1.0433,1.0433);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#454748").s().p("Ag1AOIATgIQAYgJATgDIAtgIIg+AZIgfAEg");
	this.shape_69.setTransform(-34.9521,159.281,1.0433,1.0433);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#717677").s().p("AgMAsIAIgmQAFgbgCgFQgBgCgLgBIgKAAIAigSIANAGIgDAAQgFACgEAGQgFAHgBAlIAAAlgAAYgpIAAAAg");
	this.shape_70.setTransform(-3.2217,155.7076,1.0433,1.0433);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#717677").s().p("AgjAIIgQgKIgBgKIAUALQAWAJARgCQAdgEAMgMIgBgFIAGAHIgDAJQgIAKgcADIgPACQgTAAgPgIg");
	this.shape_71.setTransform(2.4775,150.3418,1.0433,1.0433);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#3D4659").s().p("AAyBkQgCgHhLiWQhGiMAIADQANAEAlgBIB0EiQAMAeACBBIgjABQABhJgHgWg");
	this.shape_72.setTransform(10.3168,171.6422,1.0433,1.0433);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#252931").s().p("Aj4CBQACgMAFgPQAMggASgWQAZgdCuhDQCwhGBVgKIAABOQgdAAglADQhMAFgsAMIg9AQIhFAXQgoAPg0ARQgiAPgOAbQgOAbgDAMQgBAGABABg");
	this.shape_73.setTransform(-29.3442,165.7236,1.0433,1.0433);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#252931").s().p("AEAB1QACgDgCgJQgCgQgOgYQgJgOgpgKQhPgTgUgGIhGgWIg9gPQgsgKhcgCIhTAAIgZhTQBZAKDaBDQDbBDAYAZQATAUAAAYQgBAMgEAIg");
	this.shape_74.setTransform(35.8649,163.7934,1.0433,1.0433);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#B3B5B8").s().p("AgDBeIAAi7IAGAAIAAC7g");
	this.shape_75.setTransform(-2.5044,140.2923,1.0433,1.0433);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#3D4659").s().p("AgTBiIAAjDIAnAAIAADDg");
	this.shape_76.setTransform(2.947,141.1009,1.0433,1.0433);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#252931").s().p("AgMBhQgYgCgJgLIgEgLIAAiqIBjAAIAAC0QgGAEgLAFQgQAGgSAAIgLgBg");
	this.shape_77.setTransform(2.2428,141.1058,1.0433,1.0433);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#454748").s().p("AgQAuQgQgMgHgWQgGgVAHgSQAHgUAQgEQAQgFAQAMQARALAGAWQAGAVgHATQgHASgQAGIgKABQgLAAgLgIg");
	this.shape_78.setTransform(66.7209,185.2861,1.0433,1.0433);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#454748").s().p("AgbAuQgPgQgDgZQgCgYALgTQALgTAUgCQARgCAQAQQAPAQADAZQACAYgLATQgMATgTACIgFABQgPAAgNgPg");
	this.shape_79.setTransform(16.9016,201.2289,1.0433,1.0433);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#040D1C").s().p("AgeA4QgUgGgIggQgCgMABggIABgfIA4gBIAAALIAXACQAZAHAJASQAIAUgFAUQgEATgRAJQgQAJgVABIgJABQgNAAgIgDg");
	this.shape_80.setTransform(69.59,182.1774,1.0433,1.0433);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#454748").s().p("AgbAlQgMgPAAgWQAAgVAMgQQAMgPAPAAQAQAAANAPQALAQAAAVQAAAWgLAPQgNAQgQAAQgPAAgMgQg");
	this.shape_81.setTransform(-56.2362,186.2773,1.0433,1.0433);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#454748").s().p("AgIAdQgKgGgFgOQgFgMADgMQAEgMAKgEQAKgEAKAHQAKAGAFAOQAGAMgEAMQgEAMgKAEIgHACQgGAAgHgFg");
	this.shape_82.setTransform(-44.4599,165.5932,1.0433,1.0433);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#454748").s().p("AgMAtQgRgKgHgVQgIgTAFgTQAFgSAQgGQAQgGAPAKQARAKAHAVQAIATgFATQgGATgPAFQgGADgGAAQgJgBgKgGg");
	this.shape_83.setTransform(25.77,165.4888,1.0433,1.0433);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#040D1C").s().p("AgdA5QgVgHgHgfQgDgMABghIACgfIBFgBIAAALIASADQATAGAGATQAHAWgEASQgEATgRAJQgPAIgWACIgJAAQgMAAgIgCg");
	this.shape_84.setTransform(27.9176,162.7996,1.0433,1.0433);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#040D1C").s().p("AAAAmQgNgBgKgFQgLgGgDgNQgDgMAFgOQAEgMAMgEQAHgCAFAAIAAgHIAtABIABAUQABAVgCAIQgEAUgOAFQgFACgHAAIgIgBg");
	this.shape_85.setTransform(-43.1454,164.802,1.0433,1.0433);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#040D1C").s().p("AAAAzQgSgCgNgHQgPgHgEgRQgDgQAGgTQAFgQARgFQAIgDAIAAIAAgJIA7AAIACAcQABAcgDAKQgFAbgTAGQgHACgLAAIgIAAg");
	this.shape_86.setTransform(-57.4067,183.9689,1.0433,1.0433);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#717677").s().p("AigA6QgGgEgOABIgNABQAAAAgBAAQAAgBAAAAQgBAAAAgBQAAAAAAgBQAAgFALgJQAIgHC6gtIC6gtIAAAKIjYA8IgkAOQgJAEghAFQggAGgIAEQgHADgGAIQgCADgDAAIgEgBg");
	this.shape_87.setTransform(-23.4233,155.1442,1.0433,1.0433);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#454748").s().p("AgQAtQgQgLgHgWQgGgUAHgUQAHgSAQgGQAQgFAQAMQAQANAHAVQAGAVgHASQgHAUgQAEIgKACQgLAAgLgJg");
	this.shape_88.setTransform(73.2156,182.5213,1.0433,1.0433);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#454748").s().p("AgbAlQgMgPAAgWQAAgVAMgPQALgQAQAAQARAAAMAQQALAPAAAVQAAAWgLAPQgMAQgRAAQgQAAgLgQg");
	this.shape_89.setTransform(-62.0006,184.9209,1.0433,1.0433);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#323436").s().p("ADcBIQgBgSADgcQAGg3ASgyQANgmAcgxQASgfgFgMQgJgTgNgFQgSgJg4gDQhEgEh/AJQiKAJhGARQhCAQgfgDQgVgDgCgKQgBgGAOgCIAjgDIC2gYQAjgFAcgBQDcgHAYACQA1AFAIADQAuAOgFArQgCAOgKARQgXAogYA+QgOAhgICSQgEBKgBBDIgSAEg");
	this.shape_90.setTransform(-5.7425,92.929,1.0433,1.0433);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#323436").s().p("AgKFDQg+ijgIguQgDgSgehdQgXhFAEguQADgngHh5QgHh2ADgdQAEgrAEgJQADgFAOAAQAUAAAJAwQAHAogDCJQgDB7ALAdQAoBoAqB/QAXBFBvD9QgsAGgcAJIgUAIIg8iag");
	this.shape_91.setTransform(-36.3815,30.1422,1.0433,1.0433);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#626666").s().p("AAOB6QgQgGgHgSQgGgPgGgrIgIhDIgKg9IgHgjIBdDvQgKAIgMAAQgFAAgGgCg");
	this.shape_92.setTransform(-36.0998,67.8559,1.0433,1.0433);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#B7BBC1").s().p("ADKELQgFgEAAgGIACgKIAIiiQgBgSACgaQAEgzARgyQAZhFARgbQAJgPACgFQADgGAAgGQgCgNgEgFQgKgNgSgDIhBgDQhNgFhuAGQiBAFhCAQQhgAYgWgPQgIgFgBgIQgBgGADgFQAEgEAJgDIAWgEICngVIAggFQAjgEAbgBIApgCQDBgIAQAEIALABQAgAEAWANQAhASACAgIgKAmIgSAiQgVApgMAeQgNAggJCNQgEBHgCBCQAAAHgHABIgVAGQgDAAgDgCgADgAmQgDAYgBAOIgECtIADgBQAJjwARg9QgPAugGAtgADUjxQAxADATAJQAOAHAIATIADAHQAEAIgDALIACgDQADgkgYgQQgQgLglgFIgNgBQgOgDi/AHIgoACQgcABgiAFQgdADgBABIgBAAIiYAUIgjAFQAUAJBUgUQBCgQCPgGQA8gCAzAAQAzAAApACg");
	this.shape_93.setTransform(-5.273,103.2104,1.0433,1.0433);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#B7BBC1").s().p("ADQEMQgDAAgDgBQgFgFAAgFIACgKIAIiiQgBgSACgaQAEgzARgyQAZhGARgaIALgUQADgGAAgGQgCgNgEgFQgKgNgSgDIhBgDQhMgFhvAFQiBAGhCAQQhgAYgWgQQgIgEgBgIQgBgGADgFQAEgFAJgCIAWgEICngVIAggFQAjgEAbgBIApgCQDBgIAQAEIALABQAgAEAWANQAhASACAgIgKAmIgSAiQgVApgMAeQgNAggJCNQgEBHgCBCQAAAHgHABIgTAFgADgAmQgDAYgBAOIgECtIADgBQAJjwARg9QgPAugGAtgADUjxQAxADATAJQAOAHAIATIADAHQAEAIgDAKIACgCQADgkgYgQQgQgLglgFIgNgCQgRgEi8AJIgoACQgbABgjAEIgeAFIgBAAIgHABIgNABIgKACIgPACIAPgCIAKgCIANgBQA3gGBOgDQA6gCAwAAQA2AAArACgAkcjTQgOABgGACQATAJBVgVIAmgHg");
	this.shape_94.setTransform(-5.273,92.3336,1.0433,1.0433);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#717677").s().p("AgBgEIgLABIAZgNIgBAGQgBAFACABQACADgEASQgFgTgHgCg");
	this.shape_95.setTransform(5.9446,152.1863,1.0433,1.0433);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#9B9D9E").s().p("AAABHIgZiNQAUASARA+QAJAgAFAdg");
	this.shape_96.setTransform(19.3274,184.4514,1.0433,1.0433);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#9B9D9E").s().p("AA6CaQgEgxgPgbQgIgOghhPQgchBgMgMIgZgHQgZgHgBABQgDABADhTIAUgJIAIACIAMACQAHAAgGAFIAbAfQAcAmAGAjQAFAhAkBKQAlBPACAKQAIAggCAxIgkADQABgTgCgYg");
	this.shape_97.setTransform(7.051,171.6967,1.0433,1.0433);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#9B9D9E").s().p("AkRCJQADgQAFgTQAMgmAVgSQAogjCwhEQC2hIBVgJIAWAHQihBIhHARQgjAIgUASQgWASgqAOQhOAZgRAHQgjAOgKARQgYAmgCAWg");
	this.shape_98.setTransform(-29.7354,164.6541,1.0433,1.0433);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#9B9D9E").s().p("ADvBAQgKgQgmgNIhigfIhIgVIg+gQQgsgKh2giIhsghIAhgPQBcAKDaBEQDdBEAkAgQAVASACAdQABAPgDALIgvAAQAAgYgYgmg");
	this.shape_99.setTransform(37.025,162.9326,1.0433,1.0433);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#040D1C").s().p("AggA9QgWgHgIgiQgDgNACgjIABgiIBLgBIAAAMIAUADQAVAHAGAUQAHAYgEATQgFAVgSAJQgRAKgXABIgKABQgNAAgJgDg");
	this.shape_100.setTransform(20.4066,198.8816,1.0433,1.0433);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#454748").s().p("AgbAuQgPgQgDgZQgCgYALgTQAMgTATgCQASgCAPAQQAPARADAYQACAYgLATQgMATgTACIgFABQgOAAgOgPg");
	this.shape_101.setTransform(24.3354,199.1944,1.0433,1.0433);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("#454748").s().p("AgMAtQgQgKgIgVQgIgTAFgTQAGgTAPgFQAQgGAPAKQARAKAHAVQAIATgFATQgGASgPAGQgGACgGAAQgJAAgKgGg");
	this.shape_102.setTransform(33.6211,162.4631,1.0433,1.0433);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("#AEB1B1").s().p("AgWACIAugDQgKACgSABg");
	this.shape_103.setTransform(151.5418,67.6371,1.4562,1.4562);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f("#FFFFFF").s().p("Ag7ABIAMgDQAPgFANAAQBPgEAAASIhzACg");
	this.shape_104.setTransform(146.0447,67.7786,1.4562,1.4562);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f("#AEB1B1").s().p("AgoAHQgRgDAAgEQAAgDARgDQARgDAXAAQAYAAARADQARADAAADQAAAEgRADQgRADgYAAQgXAAgRgDg");
	this.shape_105.setTransform(146.3359,67.5643,1.4562,1.4562);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f("#FFFFFF").s().p("Ag7gGIBzgCIAEAIQgTAHgVABIgdABQgyAAAAgPg");
	this.shape_106.setTransform(308.9198,67.5398,1.4562,1.4562);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f("#FFFFFF").s().p("AgoAHQgRgDAAgEQAAgDARgDQARgDAXAAQAYAAARADQARADAAADQAAAEgRADQgRADgYAAQgXAAgRgDg");
	this.shape_107.setTransform(308.6285,66.2173,1.4562,1.4562);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f("#AEB1B1").s().p("AgoAHQgRgDAAgEQAAgDARgDQARgDAXAAQAYAAARADQARADAAADQAAAEgRADQgRADgYAAQgXAAgRgDg");
	this.shape_108.setTransform(308.6285,67.7099,1.4562,1.4562);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f("#FFFFFF").s().p("Ai5AUIAAgnIFzAAIAAAng");
	this.shape_109.setTransform(124.2382,61.3391,1.4562,1.4562);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f("#AEB1B1").s().p("Ai5AUIAAgnIFzAAIAAAng");
	this.shape_110.setTransform(124.2382,63.2686,1.4562,1.4562);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f("#FFFFFF").s().p("Ai5AUIAAgnIFzAAIAAAng");
	this.shape_111.setTransform(319.2952,61.3391,1.4562,1.4562);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.f("#AEB1B1").s().p("Ai5AUIAAgnIFzAAIAAAng");
	this.shape_112.setTransform(319.2952,63.2686,1.4562,1.4562);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.f("#585B5C").s().p("AiUDuQgOgDgEgCIgBgDQECgDAhgFQAVgDAIgUIAEgTIh4l9QgFgRgIgGIgHgCIACgMIAGADQAOAIAFAQIBzFkQAKAigCAOQgBAIgHAKQgHANgOAGIiHAFQhfAEgkAAIgUgBg");
	this.shape_113.setTransform(162.705,31.532,1.4562,1.4562);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.f("#585B5C").s().p("AhHFkICIrGIAHgBIiFLHg");
	this.shape_114.setTransform(151.6146,-5.0269,1.4562,1.4562);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.f("#FFFFFF").s().p("AhcFeICPrGIAqAKIiGLHg");
	this.shape_115.setTransform(154.4906,-3.8255,1.4562,1.4562);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.f("#AEB1B1").s().p("ABBljIAFB5QAACNgYBgQgYBhgwCJQgYBFgTAyg");
	this.shape_116.setTransform(158.6051,-3.0974,1.4562,1.4562);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.f("#585B5C").s().p("AiJDmQgPgGgGgNIgIgSQgCgNAKgjQAQg2BikuQAGgQAOgIIAFgDIADAMQgDAAgEACQgIAGgFARIh5F9IAEATQAJAUAVADQAhAFEBADQAEAEgWAEIgZABQg9AAjIgJg");
	this.shape_117.setTransform(269.7697,31.5487,1.4562,1.4562);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.f("#585B5C").s().p("AA/FkIiGrHIAHABICILGg");
	this.shape_118.setTransform(280.7789,-5.0269,1.4562,1.4562);

	this.shape_119 = new cjs.Shape();
	this.shape_119.graphics.f("#FFFFFF").s().p("AhcleIAqgKICPLGIg0ALg");
	this.shape_119.setTransform(277.9757,-3.8255,1.4562,1.4562);

	this.shape_120 = new cjs.Shape();
	this.shape_120.graphics.f("#AEB1B1").s().p("AAbDtQgwiJgYhhQgYhgAAiNIAGh5ICFLHQgTgygYhFg");
	this.shape_120.setTransform(273.7884,-3.0974,1.4562,1.4562);

	this.shape_121 = new cjs.Shape();
	this.shape_121.graphics.f("#B7BBC1").s().p("AgEh9IAVDbIghAgg");
	this.shape_121.setTransform(169.5986,44.4109,1.4562,1.4562);

	this.shape_122 = new cjs.Shape();
	this.shape_122.graphics.f("#4E5153").s().p("AgNB/QgIAAgGgGQgGgFAAgJIAAjZQAAgGAEgFQAFgEAGgBIAgAAQAIAAAGAFQAGAGAAAIIAADYQAAARgFABg");
	this.shape_122.setTransform(202.8362,42.5148,1.4562,1.4562);

	this.shape_123 = new cjs.Shape();
	this.shape_123.graphics.f("#4E5153").s().p("AgKALQgEgFAAgGQAAgGAEgEQAEgEAGAAQAGAAAFAEQAEAEAAAGQAAAGgEAFQgFAEgGAAQgGAAgEgEg");
	this.shape_123.setTransform(229.3389,59.7373,1.4562,1.4562);

	this.shape_124 = new cjs.Shape();
	this.shape_124.graphics.f("#4E5153").s().p("AgLALQgDAAgCgDQgDgCAAgEIAAgEQAAgIAIAAIAWAAQAEAAACADQADACAAADIAAAEQAAAEgDACQgCADgEAAg");
	this.shape_124.setTransform(229.5573,54.495,1.4562,1.4562);

	this.shape_125 = new cjs.Shape();
	this.shape_125.graphics.f("#4E5153").s().p("AgLALQgDAAgCgDQgDgCAAgEIAAgEQAAgIAIAAIAWAAQAEAAACADQADACAAADIAAAEQAAAEgDACQgCADgEAAg");
	this.shape_125.setTransform(229.5573,49.7624,1.4562,1.4562);

	this.shape_126 = new cjs.Shape();
	this.shape_126.graphics.f("#4E5153").s().p("AgLAKQgIABAAgJIAAgDQAAgJAIABIAWAAQAEgBACADQADACAAAEIAAADQAAAEgDACQgCADgEgBg");
	this.shape_126.setTransform(229.5573,44.9933,1.4562,1.4562);

	this.shape_127 = new cjs.Shape();
	this.shape_127.graphics.f("#4E5153").s().p("AgLALQgIAAAAgIIAAgEQAAgEADgCQACgDADAAIAWAAQAEAAACADQADACAAAEIAAAEQAAADgDACQgCADgEAAg");
	this.shape_127.setTransform(229.5573,40.4427,1.4562,1.4562);

	this.shape_128 = new cjs.Shape();
	this.shape_128.graphics.f("#4E5153").s().p("AgLALQgDAAgCgDQgCgCgBgEIAAgEQAAgIAIAAIAXAAQAHAAAAAIIAAAEQAAAEgCACQgCADgDAAg");
	this.shape_128.setTransform(222.4584,54.495,1.4562,1.4562);

	this.shape_129 = new cjs.Shape();
	this.shape_129.graphics.f("#4E5153").s().p("AgLALQgDAAgCgDQgCgCgBgEIAAgEQAAgIAIAAIAXAAQAHAAAAAIIAAAEQAAAEgCACQgCADgDAAg");
	this.shape_129.setTransform(222.4584,49.7624,1.4562,1.4562);

	this.shape_130 = new cjs.Shape();
	this.shape_130.graphics.f("#4E5153").s().p("AgLAKQgIABAAgJIAAgDQAAgJAIABIAXAAQAHgBAAAJIAAADQAAAJgHgBg");
	this.shape_130.setTransform(222.4584,44.9933,1.4562,1.4562);

	this.shape_131 = new cjs.Shape();
	this.shape_131.graphics.f("#4E5153").s().p("AgLALQgIAAAAgIIAAgEQABgEACgCQACgDADAAIAXAAQADAAACADQACACAAAEIAAAEQAAAIgHAAg");
	this.shape_131.setTransform(222.4584,40.4427,1.4562,1.4562);

	this.shape_132 = new cjs.Shape();
	this.shape_132.graphics.f("#4E5153").s().p("AgLALQgDAAgCgDQgDgCAAgEIAAgEQAAgIAIAAIAWAAQAEAAACADQADACAAADIAAAEQAAAEgDACQgCADgEAAg");
	this.shape_132.setTransform(215.3594,54.495,1.4562,1.4562);

	this.shape_133 = new cjs.Shape();
	this.shape_133.graphics.f("#4E5153").s().p("AgLALQgDAAgCgDQgDgCAAgEIAAgEQAAgIAIAAIAWAAQAEAAACADQADACAAADIAAAEQAAAEgDACQgCADgEAAg");
	this.shape_133.setTransform(215.3594,49.7624,1.4562,1.4562);

	this.shape_134 = new cjs.Shape();
	this.shape_134.graphics.f("#4E5153").s().p("AgLAKQgIABAAgJIAAgDQAAgJAIABIAWAAQAEgBACADQADACAAAEIAAADQAAAEgDACQgCADgEgBg");
	this.shape_134.setTransform(215.3594,44.9933,1.4562,1.4562);

	this.shape_135 = new cjs.Shape();
	this.shape_135.graphics.f("#4E5153").s().p("AgLALQgIAAAAgIIAAgEQAAgEADgCQACgDADAAIAWAAQAEAAACADQADACAAAEIAAAEQAAADgDACQgCADgEAAg");
	this.shape_135.setTransform(215.3594,40.4427,1.4562,1.4562);

	this.shape_136 = new cjs.Shape();
	this.shape_136.graphics.f("#4E5153").s().p("Ag4AWQgHAAgFgFQgEgEAAgHIAAgLQAAgHAEgEQAFgFAHAAIBxAAQAHAAAFAFQAEAEAAAHIAAALQAAAHgEAEQgFAFgHAAg");
	this.shape_136.setTransform(222.9316,34.6908,1.4562,1.4562);

	this.shape_137 = new cjs.Shape();
	this.shape_137.graphics.f("#24272A").s().p("AioCCIgCgJIAAivIAAggQgBgiADgHQADgGALgCIAKAAICAAAQCEAAAWgCQAWgBAHAMQAEAGgBAGQACDKgCAaQgBARgJAFIgKACIkrAAIgCAAQgNAAgEgIg");
	this.shape_137.setTransform(216.1552,42.8054,1.4562,1.4562);

	this.shape_138 = new cjs.Shape();
	this.shape_138.graphics.f("#C4B49B").s().p("ALUGlIkZsQIt1AAIkZMQIguAAICHsQIAAg5IT2AAIAAA5ICGMQg");
	this.shape_138.setTransform(224.5699,131.2727,1.4562,1.4562);

	this.shape_139 = new cjs.Shape();
	this.shape_139.graphics.f("#DED0BE").s().p("AtzAnIAAhOIbnAAIAABOg");
	this.shape_139.setTransform(228.0647,64.2151,1.4562,1.4562);

	this.shape_140 = new cjs.Shape();
	this.shape_140.graphics.f("#E62F33").s().p("AgwAmQgEgwAIgfIARADQAUACASgCQAdgBAFgCIADAaQADAdgCAYQgcAEgYAAQgYAAgVgEg");
	this.shape_140.setTransform(304.892,31.5147,1.4562,1.4562);

	this.shape_141 = new cjs.Shape();
	this.shape_141.graphics.f("#2A1213").s().p("AghCaQgMgEgBgVIAAgXQACgGABgHQAEgPgGgZQgHgmAIhPQABgGAHgNIANgYQAIgOgCgZIgEAAIAAgHIArAAIAAAHIgFAAIABAOQABAQAFAJIAMAYQAJANAAAGQAIBPgIAmQgEAZACAPQACAHACAGIAAAXQgCAVgLAEg");
	this.shape_141.setTransform(304.8789,34.982,1.4562,1.4562);

	this.shape_142 = new cjs.Shape();
	this.shape_142.graphics.f("#E62F33").s().p("AgWAKIAAgQIABgBQABgBAGAAIAgAAIADAAQAAAAABAAQAAABAAAAQABAAAAABQAAAAAAABIAAAPg");
	this.shape_142.setTransform(304.9335,10.7546,1.4562,1.4562);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_142},{t:this.shape_141},{t:this.shape_140},{t:this.shape_139},{t:this.shape_138},{t:this.shape_137},{t:this.shape_136},{t:this.shape_135},{t:this.shape_134},{t:this.shape_133},{t:this.shape_132},{t:this.shape_131},{t:this.shape_130},{t:this.shape_129},{t:this.shape_128},{t:this.shape_127},{t:this.shape_126},{t:this.shape_125},{t:this.shape_124},{t:this.shape_123},{t:this.shape_122},{t:this.shape_121},{t:this.shape_120},{t:this.shape_119},{t:this.shape_118},{t:this.shape_117},{t:this.shape_116},{t:this.shape_115},{t:this.shape_114},{t:this.shape_113},{t:this.shape_112},{t:this.shape_111},{t:this.shape_110},{t:this.shape_109},{t:this.shape_108},{t:this.shape_107},{t:this.shape_106},{t:this.shape_105},{t:this.shape_104},{t:this.shape_103},{t:this.shape_102},{t:this.shape_101},{t:this.shape_100},{t:this.shape_99},{t:this.shape_98},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_94},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.instance}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-66.2,-93,559.1,310.6);


(lib.mc7t1TMR = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_243 = function() {
		this.stop();
		parent.siguiente_verde();
		parent.comando("terminar");
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(243).call(this.frame_243).wait(1));

	// interrogacion mueve
	this.instance = new lib.interrogamover("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(148.05,40.4,0.4194,0.4194,0,0,0,15.4,21.7);
	this.instance.alpha = 0.0703;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleX:1.6246,scaleY:1.6246,alpha:1},7).to({scaleX:1,scaleY:1},7).to({x:759.55},35).to({_off:true},1).wait(194));

	// tapa circulo
	this.instance_1 = new lib.tapabca2("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(520.8,47.2,2.7597,0.4666,0,0,0,106.8,44.7);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(19).to({_off:false},0).to({regX:107.4,scaleX:2.12,x:999.35},41,cjs.Ease.get(1)).to({_off:true},1).wait(183));

	// pregunta 3
	this.text = new cjs.Text("¿Cuáles son los beneficios de gestionar el talento?", "bold 25px 'Arial'", "#990000");
	this.text.textAlign = "center";
	this.text.lineHeight = 28;
	this.text.lineWidth = 794;
	this.text.parent = this;
	this.text.setTransform(456.25,28.25);
	this.text._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text).wait(19).to({_off:false},0).wait(225));

	// TIP
	this.info = new lib.tiprecuerdamod3mc2();
	this.info.name = "info";
	this.info.parent = this;
	this.info.setTransform(443.15,319);
	this.info._off = true;

	this.timeline.addTween(cjs.Tween.get(this.info).wait(232).to({_off:false},0).wait(12));

	// bullet 7 ultimo mc
	this.instance_2 = new lib.bullet7ultimomc("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(634.7,348.8,1,1,0,0,0,376.9,11.5);
	this.instance_2.alpha = 0.1484;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(210).to({_off:false},0).to({x:734.7,alpha:1},22,cjs.Ease.get(1)).wait(12));

	// bullet6 ultimo mc
	this.instance_3 = new lib.bullet6ultimomc("synched",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(628.3,309.05,1,1,0,0,0,370.5,36.1);
	this.instance_3.alpha = 0.1484;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(189).to({_off:false},0).to({x:728.3,alpha:1},21,cjs.Ease.get(1)).wait(34));

	// bullet5 ultimo mc
	this.instance_4 = new lib.bullet5ultimomc("synched",0);
	this.instance_4.parent = this;
	this.instance_4.setTransform(645.2,268.45,1,1,0,0,0,387.4,25.5);
	this.instance_4.alpha = 0.1484;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(169).to({_off:false},0).to({x:745.2,alpha:1},20,cjs.Ease.get(1)).wait(55));

	// bullet4 ultimo mc
	this.instance_5 = new lib.bullet4ultimomc("synched",0);
	this.instance_5.parent = this;
	this.instance_5.setTransform(639.4,231.25,1,1,0,0,0,381.6,18.9);
	this.instance_5.alpha = 0.1484;
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(150).to({_off:false},0).to({x:739.4,alpha:1},19,cjs.Ease.get(1)).wait(75));

	// bullet 3 ultimo mc
	this.instance_6 = new lib.bullet3ultimomc("synched",0);
	this.instance_6.parent = this;
	this.instance_6.setTransform(632.6,189.9,1,1,0,0,0,374.8,25.5);
	this.instance_6.alpha = 0.1484;
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(130).to({_off:false},0).to({x:732.6,alpha:1},19,cjs.Ease.get(1)).wait(95));

	// bullet2 ultimo mc
	this.instance_7 = new lib.bullet2ultimomc("synched",0);
	this.instance_7.parent = this;
	this.instance_7.setTransform(645.2,156.9,1,1,0,0,0,387.4,22.2);
	this.instance_7.alpha = 0.1484;
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(110).to({_off:false},0).to({x:745.2,alpha:1},19,cjs.Ease.get(1)).wait(115));

	// bullet1 ultimo mc
	this.instance_8 = new lib.bullet1ultimomc("synched",0);
	this.instance_8.parent = this;
	this.instance_8.setTransform(632.6,109.05,1,1,0,0,0,374.8,25.2);
	this.instance_8.alpha = 0.1484;
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(91).to({_off:false},0).to({x:732.6,alpha:1},19,cjs.Ease.get(1)).wait(134));

	// ilustra
	this.instance_9 = new lib.rh3("synched",0);
	this.instance_9.parent = this;
	this.instance_9.setTransform(374.7,226.7,1.3118,1.3118,0,0,0,125.1,82);
	this.instance_9.alpha = 0;
	this.instance_9._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(73).to({_off:false},0).to({x:277.7,y:205.4,alpha:1},18,cjs.Ease.get(1)).wait(153));

	// ventana 3
	this.instance_10 = new lib.ventana3mod1("synched",0);
	this.instance_10.parent = this;
	this.instance_10.setTransform(446.7,106.1,1,1,0,0,0,370.1,28.4);
	this.instance_10.alpha = 0.0703;
	this.instance_10._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(73).to({_off:false},0).to({y:58.6,alpha:1},18,cjs.Ease.get(1)).wait(153));

	// guia
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CCCCCC").s().p("Ah7CCQgyg1AAhNQAAhLAyg3QAzg2BIAAQBIAAA0A2QAzA3gBBLQABBNgzA1Qg0A2hIAAQhIAAgzg2g");
	this.shape.setTransform(-131.8,477.2);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(244));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-149.2,-36,1373.4,531.7);


(lib.mc6t1TMR = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_228 = function() {
		this.stop();
		parent.siguiente_naranja();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(228).call(this.frame_228).wait(1));

	// interrogacion mueve
	this.instance = new lib.interrogamover("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(226.05,40.4,0.4194,0.4194,0,0,0,15.4,21.7);
	this.instance.alpha = 0.0703;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleX:1.6246,scaleY:1.6246,alpha:1},7).to({scaleX:1,scaleY:1},7).to({x:759.55},35).to({_off:true},1).wait(179));

	// ilustra
	this.instance_1 = new lib.ilustracion2222("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(157.7,145.4,1.3118,1.3118,0,0,0,125.1,82);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(73).to({_off:false},0).to({y:205.4,alpha:1},18,cjs.Ease.get(1)).wait(138));

	// tapa circulo
	this.instance_2 = new lib.tapabca2("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(539.7,47.2,2.375,0.4666,0,0,0,106.8,44.7);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(19).to({_off:false},0).to({regX:107.4,scaleX:2.12,x:972.85},38,cjs.Ease.get(1)).to({_off:true},1).wait(171));

	// pregunta 2
	this.text = new cjs.Text("¿Cuáles son las actividades clave del proceso?", "bold 25px 'Arial'", "#990000");
	this.text.textAlign = "center";
	this.text.lineHeight = 28;
	this.text.lineWidth = 794;
	this.text.parent = this;
	this.text.setTransform(466,28.25);
	this.text._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text).wait(19).to({_off:false},0).wait(210));

	// bullet6 ultimo mc
	this.instance_3 = new lib.bullet6penultimomc111("synched",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(628.3,349.05,1,1,0,0,0,370.5,36.1);
	this.instance_3.alpha = 0.1484;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(189).to({_off:false},0).to({x:728.3,alpha:1},21,cjs.Ease.get(1)).wait(19));

	// bullet5 ultimo mc
	this.instance_4 = new lib.bullet5penultimomc111("synched",0);
	this.instance_4.parent = this;
	this.instance_4.setTransform(645.2,298.45,1,1,0,0,0,387.4,25.5);
	this.instance_4.alpha = 0.1484;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(169).to({_off:false},0).to({x:745.2,alpha:1},20,cjs.Ease.get(1)).wait(40));

	// bullet4 ultimo mc
	this.instance_5 = new lib.bullet4penultimomc("synched",0);
	this.instance_5.parent = this;
	this.instance_5.setTransform(639.4,251.25,1,1,0,0,0,381.6,18.9);
	this.instance_5.alpha = 0.1484;
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(150).to({_off:false},0).to({x:739.4,alpha:1},19,cjs.Ease.get(1)).wait(60));

	// bullet 3 ultimo mc
	this.instance_6 = new lib.bullet3penultimomc("synched",0);
	this.instance_6.parent = this;
	this.instance_6.setTransform(632.6,209.9,1,1,0,0,0,374.8,25.5);
	this.instance_6.alpha = 0.1484;
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(130).to({_off:false},0).to({x:732.6,alpha:1},19,cjs.Ease.get(1)).wait(80));

	// bullet2 ultimo mc
	this.instance_7 = new lib.bullet2penultimomc("synched",0);
	this.instance_7.parent = this;
	this.instance_7.setTransform(645.2,176.9,1,1,0,0,0,387.4,22.2);
	this.instance_7.alpha = 0.1484;
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(110).to({_off:false},0).to({x:745.2,alpha:1},19,cjs.Ease.get(1)).wait(100));

	// bullet1 ultimo mc
	this.instance_8 = new lib.bullet1penultimomc("synched",0);
	this.instance_8.parent = this;
	this.instance_8.setTransform(632.6,109.05,1,1,0,0,0,374.8,25.2);
	this.instance_8.alpha = 0.1484;
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(91).to({_off:false},0).to({x:732.6,alpha:1},19,cjs.Ease.get(1)).wait(119));

	// ventana2
	this.instance_9 = new lib.ventana1mod1("synched",0);
	this.instance_9.parent = this;
	this.instance_9.setTransform(446.7,106.1,1,1,0,0,0,370.1,28.4);
	this.instance_9.alpha = 0.0703;
	this.instance_9._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(73).to({_off:false},0).to({y:58.6,alpha:1},18,cjs.Ease.get(1)).wait(138));

	// guia
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CCCCCC").s().p("Ah7CCQgyg1AAhNQAAhLAyg3QAzg2BIAAQBIAAA0A2QAzA3gBBLQABBNgzA1Qg0A2hIAAQhIAAgzg2g");
	this.shape.setTransform(-131.8,477.2);

	this.timeline.addTween(cjs.Tween.get(this.shape).to({_off:true},1).wait(228));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-149.2,5.2,1346.9,490.5);


(lib.mc5t1TMR = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_109 = function() {
		this.stop();
		parent.siguiente_naranja();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(109).call(this.frame_109).wait(1));

	// flecha mueve
	this.instance = new lib.interrogamover("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(226.05,40.4,0.4194,0.4194,0,0,0,15.4,21.7);
	this.instance.alpha = 0.0703;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleX:1.6246,scaleY:1.6246,alpha:1},6).to({scaleX:1,scaleY:1},7).to({x:701.05},35).to({_off:true},1).wait(61));

	// tapa circulo
	this.instance_1 = new lib.tapabca2("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(479.7,47.2,2.375,0.4666,0,0,0,106.8,44.7);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(18).to({_off:false},0).to({regX:106.9,scaleX:0.0786,x:723.7},39,cjs.Ease.get(1)).to({_off:true},1).wait(52));

	// pregunta1
	this.text = new cjs.Text("¿En qué consiste la gestión de talento?", "bold 25px 'Arial'", "#990000");
	this.text.textAlign = "center";
	this.text.lineHeight = 28;
	this.text.lineWidth = 794;
	this.text.parent = this;
	this.text.setTransform(475.5,28.25);
	this.text._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text).wait(18).to({_off:false},0).wait(92));

	// respuesta1
	this.instance_2 = new lib.txtprimertextogde("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(556.7,259.8,1,1,0,0,0,249.6,114.2);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(80).to({_off:false},0).to({x:606.7,alpha:1},14,cjs.Ease.get(1)).wait(16));

	// ilustra
	this.instance_3 = new lib.rh1("synched",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(264.7,166.7,1.3118,1.3118,0,0,0,125.1,82);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(64).to({_off:false},0).to({y:206.7,alpha:1},16,cjs.Ease.get(1)).wait(30));

	// ventana1
	this.instance_4 = new lib.ventana1mod1("synched",0);
	this.instance_4.parent = this;
	this.instance_4.setTransform(446.7,106.1,1,1,0,0,0,370.1,28.4);
	this.instance_4.alpha = 0.0703;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(62).to({_off:false},0).to({y:63.6,alpha:1},18,cjs.Ease.get(1)).wait(30));

	// guia
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CCCCCC").s().p("Ah7CCQgyg1AAhNQAAhLAyg3QAzg2BIAAQBIAAA0A2QAzA3gBBLQABBNgzA1Qg0A2hIAAQhIAAgzg2g");
	this.shape.setTransform(-131.8,477.2);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(110));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-149.2,-36,1026.6,531.7);


(lib.mc4t1TMR = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_109 = function() {
		this.stop();
		console.log("termina timeline se inician los checkbox");
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(109).call(this.frame_109).wait(1));

	// txt
	this.text = new cjs.Text("¿Qué recomiendas hacer para asegurar que tenemos el talento listo y adecuado ahora que Andrea se va?", "17px 'Arial'", "#333333");
	this.text.textAlign = "center";
	this.text.lineHeight = 19;
	this.text.lineWidth = 323;
	this.text.parent = this;
	this.text.setTransform(208.85,59.55);

	this.text_1 = new cjs.Text("¡Hola! ¡Qué bueno que llegas! ", "17px 'Arial'", "#333333");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 19;
	this.text_1.lineWidth = 331;
	this.text_1.parent = this;
	this.text_1.setTransform(207.6,28.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text_1},{t:this.text}]},49).wait(61));

	// dialogos
	this.instance = new lib.globodialogo2bcambio();
	this.instance.parent = this;
	this.instance.setTransform(76.3,137,0.6172,0.6172,0,0,180,128.2,141.1);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(38).to({_off:false},0).to({y:117,alpha:1},11,cjs.Ease.get(1)).wait(61));

	// ACTIVIDAD
	this.instance_1 = new lib.Actividad_checkbox();
	this.instance_1.parent = this;
	this.instance_1.setTransform(945.55,297.7,0.9583,1.0588,0,0,0,480.2,245.2);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(49).to({_off:false},0).wait(61));

	// instrucciones
	this.instance_2 = new lib.instruccionesmc4t1TMR();
	this.instance_2.parent = this;
	this.instance_2.setTransform(536,59.9,1,1,0,0,0,95.7,21.1);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(49).to({_off:false},0).wait(61));

	// escenario1
	this.instance_3 = new lib.escenario4("synched",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(436.95,147.15,1,1,0,0,0,474.2,187.5);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(8).to({_off:false},0).to({regX:474.1,scaleX:1.0288,scaleY:1.0288,x:457,y:176,alpha:0.7188},8,cjs.Ease.get(1)).to({regX:474.2,scaleX:1.0336,scaleY:1.0336,y:187.25,alpha:1},10).to({scaleX:1,scaleY:1,x:456.95,y:187.15},11).wait(73));

	// personajes1
	this.instance_4 = new lib.personajes4("synched",0);
	this.instance_4.parent = this;
	this.instance_4.setTransform(450.85,480.85,0.8754,0.8754,0,0,0,248.9,140.3);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(16).to({_off:false},0).to({regX:249,scaleX:1.0027,scaleY:1.0027,x:450.9,y:380.85,alpha:1},10,cjs.Ease.get(1)).to({regX:248.9,scaleX:0.8754,scaleY:0.8754,x:450.85},7,cjs.Ease.get(1)).wait(77));

	// Fondo_oficina_1
	this.instance_5 = new lib.Fondo_oficina_1();
	this.instance_5.parent = this;
	this.instance_5.setTransform(453.95,433.5,1.063,1.0224,0,0,0,476.8,273.5);
	this.instance_5.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).to({regX:476.9,scaleX:1.0397,scaleY:1,y:273.5,alpha:1},8,cjs.Ease.get(1)).to({regY:273.4,scaleX:1.1564,scaleY:1.1122,x:454.05,y:273.4},14,cjs.Ease.get(1)).to({regY:273.5,scaleX:1.0397,scaleY:1,x:453.95,y:273.5},7,cjs.Ease.get(1)).wait(81));

	// guia
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CCCCCC").s().p("Ah7CCQgyg1AAhNQAAhLAyg3QAzg2BIAAQBIAAA0A2QAzA3gBBLQABBNgzA1Qg0A2hIAAQhIAAgzg2g");
	this.shape.setTransform(-131.8,477.2);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(110));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-149.2,-36,1138.4,669.5);


(lib.instrucciones1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_72 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(72).call(this.frame_72).wait(1));

	// flecha 
	this.instance = new lib.flechainstrucciones("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(-7.45,13.9);
	this.instance.alpha = 0.0703;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(16).to({_off:false},0).to({x:-9.55,y:13.25,alpha:1},8,cjs.Ease.get(1)).to({_off:true},1).wait(48));

	// circulo1
	this.instance_1 = new lib.circulo1instrucciones("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(-31.4,13.2,0.2151,0.2151);
	this.instance_1.alpha = 0.3984;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({regX:105.2,regY:10.2,scaleX:1,scaleY:1,x:-8.1,y:15.35,alpha:1},5,cjs.Ease.get(1)).to({_off:true},20).wait(48));

	// circulo2
	this.instance_2 = new lib.circulo2instrucciones("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(-8.75,14.25,0.3684,0.3684,0,0,0,14.2,14.2);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(5).to({_off:false},0).to({scaleX:1.2641,scaleY:1.2641},6,cjs.Ease.get(1)).to({regX:14.1,scaleX:1.6513,scaleY:1.6513,x:-8.8,y:14.35,alpha:0},4,cjs.Ease.get(1)).to({_off:true},10).wait(48));

	// circulo3
	this.instance_3 = new lib.circulo2instrucciones("synched",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(-8.8,14.2,1,1,0,0,0,14.2,14.2);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(11).to({_off:false},0).to({_off:true},14).wait(48));

	// flecha mueve
	this.instance_4 = new lib.flechamueve("synched",0);
	this.instance_4.parent = this;
	this.instance_4.setTransform(-8.7,14.3,1,1,0,0,0,23.4,23.4);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(25).to({_off:false},0).wait(5).to({x:7.95},0).to({x:345.3},37).wait(6));

	// tapa circulo
	this.instance_5 = new lib.tapakakigeneral("synched",0);
	this.instance_5.parent = this;
	this.instance_5.setTransform(3089.65,91.55,29.2175,2.0526,0,0,0,106.8,44.6);
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(30).to({_off:false},0).to({scaleX:2.353,x:580.5},42,cjs.Ease.get(1)).wait(1));

	// Instruccion
	this.text = new cjs.Text("Haz clic sobre cada diálogo para avanzar.", "18px 'Arial'", "#606060");
	this.text.lineHeight = 23;
	this.text.lineWidth = 417;
	this.text.parent = this;
	this.text.setTransform(-14.4,6.35);
	this.text._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text).wait(30).to({_off:false},0).wait(43));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-37.2,-9.3,441.8,52);


(lib.mc3t1TMR = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"dialogo 3a":121,"dialogo 3b":131,"dialogo 3c":153,"dialogo 3d":174});

	// timeline functions:
	this.frame_130 = function() {
		this.stop();
		var raiz = this;
		raiz.e3d1.cursor="pointer";
		raiz.e3d1.addEventListener("click",function(c){
		raiz.play();	
			});
	}
	this.frame_152 = function() {
		this.stop();
		var raiz = this;
		raiz.e3d2.cursor="pointer";
		raiz.e3d2.addEventListener("click",function(c){
		raiz.play();	
			});
	}
	this.frame_173 = function() {
		this.stop();
		var raiz = this;
		raiz.e3d3.cursor="pointer";
		raiz.e3d3.addEventListener("click",function(c){
		raiz.play();	
			});
	}
	this.frame_195 = function() {
		this.stop();
		parent.siguiente_naranja();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(130).call(this.frame_130).wait(22).call(this.frame_152).wait(21).call(this.frame_173).wait(22).call(this.frame_195).wait(1));

	// botones invisibles dialogos
	this.e3d1 = new lib.e3buttons();
	this.e3d1.name = "e3d1";
	this.e3d1.parent = this;
	this.e3d1.setTransform(368.4,104.3,1,1,0,0,0,134.8,57.8);

	this.e3d2 = new lib.e3buttons2();
	this.e3d2.name = "e3d2";
	this.e3d2.parent = this;
	this.e3d2.setTransform(508.9,119.6,1.6267,1,0,0,0,135.6,55.4);

	this.e3d3 = new lib.e3buttons3();
	this.e3d3.name = "e3d3";
	this.e3d3.parent = this;
	this.e3d3.setTransform(366.15,81.2,1,1,0,0,0,134.8,53);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("rgba(76,76,76,0)").ss(1,1,1).p("A1DoRMAqHAAAIAAQjMgqHAAAg");
	this.shape.setTransform(366.15,81.175);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.e3d1}]},130).to({state:[]},1).to({state:[{t:this.e3d2}]},21).to({state:[]},1).to({state:[{t:this.shape},{t:this.e3d3}]},20).to({state:[]},1).wait(22));

	// txt
	this.text = new cjs.Text("...inesperada noticia la salida de Andrea. ¿Ya tienes sucesores en mente?", "17px 'Arial'", "#333333");
	this.text.textAlign = "center";
	this.text.lineHeight = 19;
	this.text.lineWidth = 258;
	this.text.parent = this;
	this.text.setTransform(366.35,71.05);
	this.text._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text).wait(130).to({_off:false},0).to({_off:true},1).wait(21).to({_off:false,x:508.35,y:76.9,text:"Sí, una sorpresa. Ahora necesito tu ayuda. La verdad, no conozco al equipo de trabajo a profundidad. ¡No tengo elementos para proponer quien ocupe su lugar!...",lineHeight:20,lineWidth:380},0).to({_off:true},1).wait(20).to({_off:false,x:371.2,y:44.75,text:"Según recuerdo, necesitamos revisar al desempeño histórico, sus comportamientos, y su potencial para crecer…",lineHeight:19,lineWidth:244},0).to({_off:true},1).wait(21).to({_off:false,x:527.4,y:103.05,text:"Sí pero ¿Por dónde empiezo…?",lineWidth:358},0).wait(1));

	// botones dialogo parpadea
	this.instance = new lib.botondialogos();
	this.instance.parent = this;
	this.instance.setTransform(503.85,144.9,1.4818,1,0,0,180,143,95);
	this.instance._off = true;
	new cjs.ButtonHelper(this.instance, 0, 1, 2, false, new lib.botondialogos(), 3);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(152).to({_off:false},0).to({_off:true},1).wait(20).to({_off:false,regX:143.1,scaleX:0.9583,skewY:0,x:371.65,y:110.75},0).to({_off:true},1).wait(21).to({_off:false,regX:142.8,regY:95.3,scaleX:1.1834,scaleY:0.9628,skewY:180,x:519.3,y:137.25},0).wait(1));

	// dialogos
	this.instance_1 = new lib.globodialogo2b();
	this.instance_1.parent = this;
	this.instance_1.setTransform(207.3,149,0.6172,0.6172,0,0,180,128.2,141.1);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.instance_2 = new lib.globodialogo3cambio();
	this.instance_2.parent = this;
	this.instance_2.setTransform(580.6,196.05,0.6172,0.6172,0,0,0,128.2,141.1);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.instance_3 = new lib.globodialogo5cambio();
	this.instance_3.parent = this;
	this.instance_3.setTransform(589.6,156,0.6172,0.6172,0,0,0,128.2,141.1);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(121).to({_off:false},0).to({y:137,alpha:1},9,cjs.Ease.get(1)).to({y:129,alpha:0},10,cjs.Ease.get(1)).to({_off:true,skewY:0,x:580.6,y:196.05},1,cjs.Ease.get(1)).wait(22).to({_off:false,skewY:180,x:207.3,y:129},1).to({y:117,alpha:1},9,cjs.Ease.get(1)).to({y:129,alpha:0},10,cjs.Ease.get(1)).to({_off:true,skewY:0,x:589.6,y:156},1,cjs.Ease.get(1)).wait(12));
	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(140).to({_off:false},1,cjs.Ease.get(1)).to({y:206.05,alpha:1},11).to({y:196.05,alpha:0},11,cjs.Ease.get(1)).to({_off:true,skewY:180,x:207.3,y:129},1).wait(32));
	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(183).to({_off:false},1,cjs.Ease.get(1)).to({y:172,alpha:1},11).wait(1));

	// instrucciones
	this.instance_4 = new lib.instrucciones1();
	this.instance_4.parent = this;
	this.instance_4.setTransform(646,21.75,1,1,0,0,0,95.7,21.1);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(42).to({_off:false},0).to({_off:true},142).wait(12));

	// escenario1
	this.instance_5 = new lib.escenario3("synched",0);
	this.instance_5.parent = this;
	this.instance_5.setTransform(436.95,147.15,1,1,0,0,0,474.2,187.5);
	this.instance_5.alpha = 0;
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(8).to({_off:false},0).to({regX:474.1,scaleX:1.0288,scaleY:1.0288,x:457,y:176,alpha:0.7188},8,cjs.Ease.get(1)).to({regX:474.2,scaleX:1.04,scaleY:1.04,y:187.2,alpha:1},9).to({scaleX:1.0336,scaleY:1.0336,y:187.25},1,cjs.Ease.get(1)).to({scaleX:1,scaleY:1,x:456.95,y:187.15},11).wait(159));

	// personajes1
	this.instance_6 = new lib.personajes3("synched",0);
	this.instance_6.parent = this;
	this.instance_6.setTransform(450.85,480.85,0.8754,0.8754,0,0,0,248.9,140.3);
	this.instance_6.alpha = 0;
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(16).to({_off:false},0).to({regX:249,scaleX:1.0027,scaleY:1.0027,x:450.9,y:380.85,alpha:1},10,cjs.Ease.get(1)).to({regX:248.9,scaleX:0.8754,scaleY:0.8754,x:450.85},7,cjs.Ease.get(1)).wait(163));

	// Fondo_oficina_1
	this.instance_7 = new lib.Fondo_oficina_1();
	this.instance_7.parent = this;
	this.instance_7.setTransform(453.95,433.5,1.063,1.0224,0,0,0,476.8,273.5);
	this.instance_7.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).to({regX:476.9,scaleX:1.0397,scaleY:1,y:273.5,alpha:1},8,cjs.Ease.get(1)).to({regY:273.4,scaleX:1.1564,scaleY:1.1122,x:454.05,y:273.4},14,cjs.Ease.get(1)).to({regY:273.5,scaleX:1.0397,scaleY:1,x:453.95,y:273.5},7,cjs.Ease.get(1)).wait(167));

	// guia
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s().p("Ah7CCQgyg1AAhNQAAhLAyg3QAzg2BIAAQBIAAA0A2QAzA3gBBLQABBNgzA1Qg0A2hIAAQhIAAgzg2g");
	this.shape_1.setTransform(-131.8,477.2);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(196));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-149.2,-40.3,1138.4,673.8);


(lib.mc2t1TMR = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"dialogo 2a":121,"dialogo 2b":131,"dialogo 2c":153});

	// timeline functions:
	this.frame_130 = function() {
		this.stop();
		var raiz=this;
		raiz.e2d1.cursor = "pointer";
		raiz.e2d1.addEventListener("click",function(c){
			raiz.play();
			});
	}
	this.frame_152 = function() {
		this.stop();
		var raiz=this;
		raiz.e2d2.cursor = "pointer";
		raiz.e2d2.addEventListener("click",function(c){
			raiz.play();
			});
	}
	this.frame_175 = function() {
		this.stop();
		parent.siguiente_naranja();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(130).call(this.frame_130).wait(22).call(this.frame_152).wait(23).call(this.frame_175).wait(1));

	// botones invisibles dialogo
	this.e2d1 = new lib.e2buttons();
	this.e2d1.name = "e2d1";
	this.e2d1.parent = this;
	this.e2d1.setTransform(349.3,103.55,1,1,0,0,0,140.4,56.1);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("rgba(76,76,76,0)").ss(1,1,1).p("A17oxMAr3AAAIAARjMgr3AAAg");
	this.shape.setTransform(349.3,103.625);

	this.e2d2 = new lib.e2buttons2();
	this.e2d2.name = "e2d2";
	this.e2d2.parent = this;
	this.e2d2.setTransform(409.1,103.6,1.4366,1.275,0,0,0,142,54.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("rgba(76,76,76,0)").ss(1,1,1).p("A/wqyMA/hAAAIAAVlMg/hAAAg");
	this.shape_1.setTransform(409.2,103.775);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape},{t:this.e2d1}]},130).to({state:[]},1).to({state:[{t:this.shape_1},{t:this.e2d2}]},21).to({state:[]},1).wait(23));

	// txt
	this.text = new cjs.Text("Hola Paco, buen día. Acaba de salir Andrea de mi oficina. Vino a avisarme que dentro de un mes deja la empresa. Le ofrecieron una posición en el extranjero...", "17px 'Arial'", "#333333");
	this.text.textAlign = "center";
	this.text.lineHeight = 19;
	this.text.lineWidth = 258;
	this.text.parent = this;
	this.text.setTransform(353.3,51.2);
	this.text._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text).wait(130).to({_off:false},0).to({_off:true},1).wait(21).to({_off:false,x:407.85,y:61.8,text:"Además de avisarte, necesito ayuda para recordar el proceso de selección de talento. No tengo claro si existe talento interno preparado para tomar esa posición...",lineHeight:20,lineWidth:352},0).to({_off:true},1).wait(22).to({_off:false,x:581.4,y:100.95,text:"De acuerdo, te veo en tu oficina más tarde. Gracias.",lineHeight:19,lineWidth:208},0).wait(1));

	// botones dialogo
	this.instance = new lib.botondialogose2d1();
	this.instance.parent = this;
	this.instance.setTransform(353.45,129,1,1,0,0,0,143,95);
	new cjs.ButtonHelper(this.instance, 0, 1, 2, false, new lib.botondialogose2d1(), 3);

	this.instance_1 = new lib.botondialogose2d2();
	this.instance_1.parent = this;
	this.instance_1.setTransform(413.35,146.3,1.4853,1.4299,0,0,0,143.1,95);
	new cjs.ButtonHelper(this.instance_1, 0, 1, 2, false, new lib.botondialogose2d2(), 3);

	this.instance_2 = new lib.botondialogos();
	this.instance_2.parent = this;
	this.instance_2.setTransform(579.45,149,1,1,0,0,0,143,95);
	new cjs.ButtonHelper(this.instance_2, 0, 1, 2, false, new lib.botondialogos(), 3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance}]},130).to({state:[]},1).to({state:[{t:this.instance_1}]},21).to({state:[]},1).to({state:[{t:this.instance_2}]},22).wait(1));

	// dialogos
	this.instance_3 = new lib.globodialogo2();
	this.instance_3.parent = this;
	this.instance_3.setTransform(460.6,186.05,0.6172,0.6172,0,0,0,128.2,141.1);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.instance_4 = new lib.globodialogo();
	this.instance_4.parent = this;
	this.instance_4.setTransform(460.6,186.05,0.6172,0.6172,0,0,0,128.2,141.1);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.instance_5 = new lib.globodialogo2c();
	this.instance_5.parent = this;
	this.instance_5.setTransform(460.6,186.05,0.6172,0.6172,0,0,0,128.2,141.1);
	this.instance_5.alpha = 0;
	this.instance_5._off = true;

	this.instance_6 = new lib.globodialogo2b();
	this.instance_6.parent = this;
	this.instance_6.setTransform(416.35,187.05,0.6172,0.6172,0,0,180,128.2,141.1);
	this.instance_6.alpha = 0;
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(121).to({_off:false},0).to({y:166.05,alpha:1},9).to({_off:true,y:186.05,alpha:0},10,cjs.Ease.get(1)).wait(36));
	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(130).to({_off:false},10,cjs.Ease.get(1)).to({_off:true},1).wait(35));
	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(140).to({_off:false},1).to({y:166.05,alpha:1},11).to({y:186.05,alpha:0},11,cjs.Ease.get(1)).to({_off:true,skewY:180,x:416.35,y:187.05},1).wait(12));
	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(163).to({_off:false},1).to({y:157.05,alpha:1},11,cjs.Ease.get(1)).wait(1));

	// instrucciones
	this.instance_7 = new lib.instrucciones1();
	this.instance_7.parent = this;
	this.instance_7.setTransform(646,28.75,1,1,0,0,0,95.7,21.1);
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(42).to({_off:false},0).to({_off:true},133).wait(1));

	// escenario1
	this.instance_8 = new lib.escenario2("synched",0);
	this.instance_8.parent = this;
	this.instance_8.setTransform(436.95,147.15,1,1,0,0,0,474.2,187.5);
	this.instance_8.alpha = 0;
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(8).to({_off:false},0).to({regX:474.1,scaleX:1.0288,scaleY:1.0288,x:457,y:176,alpha:0.7188},8,cjs.Ease.get(1)).to({regX:474.2,scaleX:1.04,scaleY:1.04,y:187.2,alpha:1},9).to({scaleX:1,scaleY:1,x:456.95,y:187.15},12,cjs.Ease.get(1)).wait(139));

	// personajes1
	this.instance_9 = new lib.personaje2("synched",0);
	this.instance_9.parent = this;
	this.instance_9.setTransform(450.85,480.85,0.8754,0.8754,0,0,0,248.9,140.3);
	this.instance_9.alpha = 0;
	this.instance_9._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(16).to({_off:false},0).to({regX:249,scaleX:1.0027,scaleY:1.0027,x:450.9,y:380.85,alpha:1},10,cjs.Ease.get(1)).to({regX:248.9,scaleX:0.8754,scaleY:0.8754,x:450.85},7,cjs.Ease.get(1)).wait(143));

	// Fondo_oficina_1
	this.instance_10 = new lib.Fondo_oficina_1();
	this.instance_10.parent = this;
	this.instance_10.setTransform(453.95,433.5,1.063,1.0224,0,0,0,476.8,273.5);
	this.instance_10.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_10).to({regX:476.9,scaleX:1.0397,scaleY:1,y:273.5,alpha:1},8,cjs.Ease.get(1)).to({regY:273.4,scaleX:1.1564,scaleY:1.1122,x:454.05,y:273.4},14,cjs.Ease.get(1)).to({regY:273.5,scaleX:1.0397,scaleY:1,x:453.95,y:273.5},7,cjs.Ease.get(1)).wait(147));

	// guia
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#CCCCCC").s().p("Ah7CCQgyg1AAhNQAAhLAyg3QAzg2BIAAQBIAAA0A2QAzA3gBBLQABBNgzA1Qg0A2hIAAQhIAAgzg2g");
	this.shape_2.setTransform(-131.8,477.2);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(176));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-160.3,-40.7,1149.5,674.2);


(lib.mc1t1TMR = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"dialogo 1a":221,"dialogo 1b":231,"dialogo 1c":253,"dialogo 1d":274,"dialogo 1e":294});

	// timeline functions:
	this.frame_230 = function() {
		this.stop();
		var raiz = this;
		raiz.brillom1.alpha = 0;
		raiz.brilloh1.alpha = 100;
		raiz.e1d1.cursor ="pointer";
		raiz.e1d1.addEventListener("click",function (c){
			console.log("evento llamado");
			raiz.play();
			raiz.brilloh1.alpha = 0;
			});
	}
	this.frame_252 = function() {
		this.stop();
		var raiz = this;
		raiz.e1d2.cursor ="pointer";
		raiz.e1d2.addEventListener("click",function (c){
			console.log("evento llamado");
			raiz.play();
			raiz.brillom2.alpha = 0;
			});
	}
	this.frame_273 = function() {
		this.stop();
		var raiz = this;
		
		raiz.e1d3.cursor ="pointer";
		raiz.e1d3.addEventListener("click",function (c){
			console.log("evento llamado");
			raiz.play();
			raiz.brilloh3.alpha = 0;
			});
	}
	this.frame_293 = function() {
		this.stop();
		var raiz = this;
		
		raiz.e1d4.cursor ="pointer";
		raiz.e1d4.addEventListener("click",function (c){
			console.log("evento llamado");
			raiz.play();
			//raiz.brilloh4.alpha = 0;
			});
	}
	this.frame_309 = function() {
		this.stop();
		parent.siguiente_naranja();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(230).call(this.frame_230).wait(22).call(this.frame_252).wait(21).call(this.frame_273).wait(20).call(this.frame_293).wait(16).call(this.frame_309).wait(1));

	// Botones invisibles Dialogos
	this.e1d1 = new lib.e1Buttos();
	this.e1d1.name = "e1d1";
	this.e1d1.parent = this;
	this.e1d1.setTransform(490.75,128.15,1,1,0,0,0,142.7,53.8);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("rgba(51,51,51,0)").ss(1,1,1).p("A2SoZMAslAAAIAAQzMgslAAAg");
	this.shape.setTransform(490.775,128.1);

	this.e1d2 = new lib.e1buttons2();
	this.e1d2.name = "e1d2";
	this.e1d2.parent = this;
	this.e1d2.setTransform(384.6,108.5,1,1,0,0,0,140.4,57.8);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("rgba(51,51,51,0)").ss(1,1,1).p("A17pAMAr3AAAIAASCMgr3AAAg");
	this.shape_1.setTransform(384.6,108.45);

	this.e1d3 = new lib.e1buttons3();
	this.e1d3.name = "e1d3";
	this.e1d3.parent = this;
	this.e1d3.setTransform(488.1,138.55,1,1,0,0,0,142.8,55.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("rgba(51,51,51,0)").ss(1,1,1).p("A2TopMAsnAAAIAARTMgsnAAAg");
	this.shape_2.setTransform(488.1,128.5);

	this.e1d4 = new lib.e1buttons4();
	this.e1d4.name = "e1d4";
	this.e1d4.parent = this;
	this.e1d4.setTransform(384.6,108.5,1,1,0,0,0,140.4,57.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape},{t:this.e1d1}]},230).to({state:[]},1).to({state:[{t:this.shape_1},{t:this.e1d2}]},21).to({state:[]},1).to({state:[{t:this.shape_2},{t:this.e1d3}]},20).to({state:[]},1).to({state:[{t:this.shape_1},{t:this.e1d4}]},19).to({state:[]},1).wait(16));

	// Brillo Mujer
	this.brillom1 = new lib.botondialogos();
	this.brillom1.name = "brillom1";
	this.brillom1.parent = this;
	this.brillom1.setTransform(492.5,167.95,1,1,0,0,0,143,95);
	new cjs.ButtonHelper(this.brillom1, 0, 1, 2, false, new lib.botondialogos(), 3);

	this.brillom2 = new lib.botondialogose1d2();
	this.brillom2.name = "brillom2";
	this.brillom2.parent = this;
	this.brillom2.setTransform(384.5,138.95,1,1.0922,0,0,180,143,95);
	new cjs.ButtonHelper(this.brillom2, 0, 1, 2, false, new lib.botondialogose1d2(), 3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.brillom1}]},230).to({state:[]},1).to({state:[{t:this.brillom2}]},21).to({state:[]},1).wait(57));

	// Brillo Hombre
	this.brilloh1 = new lib.botondialogos();
	this.brilloh1.name = "brilloh1";
	this.brilloh1.parent = this;
	this.brilloh1.setTransform(492.5,167.95,1,1,0,0,0,143,95);
	new cjs.ButtonHelper(this.brilloh1, 0, 1, 2, false, new lib.botondialogos(), 3);

	this.brilloh3 = new lib.botondialogose1d3();
	this.brilloh3.name = "brilloh3";
	this.brilloh3.parent = this;
	this.brilloh3.setTransform(492.5,177.95,1,1,0,0,0,143,95);
	new cjs.ButtonHelper(this.brilloh3, 0, 1, 2, false, new lib.botondialogose1d3(), 3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.brilloh1}]},230).to({state:[]},1).to({state:[{t:this.brilloh3,p:{x:492.5,y:177.95}}]},42).to({state:[]},1).to({state:[{t:this.brilloh3,p:{x:389.15,y:162}}]},19).to({state:[]},1).wait(16));

	// txt
	this.text = new cjs.Text("...por una parte me da gusto que aproveches la oportunidad que se te presenta Andrea, aunque por otra lamento que dejes la organización…", "17px 'Arial'", "#333333");
	this.text.textAlign = "center";
	this.text.lineHeight = 19;
	this.text.lineWidth = 258;
	this.text.parent = this;
	this.text.setTransform(494.35,93.55);
	this.text._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text).wait(230).to({_off:false},0).to({_off:true},1).wait(21).to({_off:false,x:383.8,y:52.95,text:"…no lo esperaba Ramiro, no me imaginé que algún día tendría que emigrar de mi país, pero se presentó esta oportunidad de trabajo y he decidido aprovecharla...",lineWidth:261},0).to({_off:true},1).wait(20).to({_off:false,x:495.85,y:107.55,text:"Bien Andrea, ¿Qué fecha estimas dejarás el puesto?...",lineWidth:251},0).to({_off:true},1).wait(19).to({_off:false,x:383.8,y:61.95,text:"...en un mes Ramiro. Haré todo lo posible para dejar terminados los pendientes y organizado lo demás para entregar el puesto a quien tú me indiques. ¿Te parece bien?...",lineWidth:261},0).to({_off:true},1).wait(15).to({_off:false,x:490.85,y:94.55,text:"De acuerdo, permíteme notificar tu decisión e iniciar el proceso de tu salida y reemplazo. Te veo más tarde para afinar detalles. Gracias Andrea.",lineWidth:251},0).wait(1));

	// dialogos
	this.instance = new lib.globodialogo();
	this.instance.parent = this;
	this.instance.setTransform(460.6,196.05,0.6172,0.6172,0,0,0,128.2,141.1);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(221).to({_off:false},0).to({y:176.05,alpha:1},9).to({y:196.05,alpha:0},10,cjs.Ease.get(1)).to({skewY:180,x:416.35,y:167.05},1).to({y:147.05,alpha:1},11,cjs.Ease.get(1)).to({y:167.05,alpha:0},11,cjs.Ease.get(1)).to({skewY:0,x:460.6,y:196.05},1,cjs.Ease.get(1)).to({y:176.05,alpha:1},9).to({y:196.05,alpha:0},10,cjs.Ease.get(1)).to({skewY:180,x:416.35,y:167.05},1).to({y:147.05,alpha:1},9,cjs.Ease.get(1)).to({y:167.05,alpha:0},10,cjs.Ease.get(1)).to({skewY:0,x:460.6,y:196.05},1,cjs.Ease.get(1)).to({y:176.05,alpha:1},5).wait(1));

	// instrucciones
	this.instance_1 = new lib.instrucciones1();
	this.instance_1.parent = this;
	this.instance_1.setTransform(646,28.75,1,1,0,0,0,95.7,21.1);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(142).to({_off:false},0).to({_off:true},167).wait(1));

	// escenario1
	this.instance_2 = new lib.escenario1("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(456.95,147.15,1,1,0,0,0,474.2,187.5);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(108).to({_off:false},0).to({scaleX:1.04,scaleY:1.04,x:457,y:187.2,alpha:1},17,cjs.Ease.get(1)).to({scaleX:1,scaleY:1,x:456.95,y:187.15},12,cjs.Ease.get(1)).wait(173));

	// personajes1
	this.instance_3 = new lib.personajes1("synched",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(432.75,363.85,1,1,0,0,0,248.8,140.3);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(116).to({_off:false},0).to({regX:249,regY:140.4,scaleX:0.9393,scaleY:0.9393,x:430.95,y:310},10,cjs.Ease.get(1)).to({regX:248.9,regY:140.3,scaleX:0.8754,scaleY:0.8754,x:430.85,y:320.85},7,cjs.Ease.get(1)).wait(177));

	// Fondo_oficina_1
	this.instance_4 = new lib.Fondo_oficina_1();
	this.instance_4.parent = this;
	this.instance_4.setTransform(454,393.55,1.2121,1.1657,0,0,0,476.9,273.5);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(100).to({_off:false},0).to({scaleX:1.0397,scaleY:1,x:453.95,y:273.5,alpha:1},8,cjs.Ease.get(1)).to({scaleX:1.0916,scaleY:1.0499,x:454},14,cjs.Ease.get(1)).to({scaleX:1.0397,scaleY:1,x:453.95},7,cjs.Ease.get(1)).wait(181));

	// guia
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#CCCCCC").s().p("Ah7CCQgyg1AAhNQAAhLAyg3QAzg2BIAAQBIAAA0A2QAzA3gBBLQABBNgzA1Qg0A2hIAAQhIAAgzg2g");
	this.shape_3.setTransform(-131.8,477.2);

	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(310));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-149.2,-40.3,1164.1,661.8);


// stage content:
(lib.AC_TMR_M01_01 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		parent.comando("iniciar",this);
	}
	this.frame_1 = function() {
		this.stop();
		parent.comando("resetear");
	}
	this.frame_2 = function() {
		this.stop();
		parent.comando("resetear");
	}
	this.frame_3 = function() {
		this.stop();
		parent.comando("resetear");
	}
	this.frame_4 = function() {
		this.stop();
		parent.comando("resetear");
	}
	this.frame_5 = function() {
		this.stop();
		parent.comando("resetear");
	}
	this.frame_6 = function() {
		this.stop();
		parent.comando("resetear");
	}
	this.frame_7 = function() {
		this.stop();
		parent.comando("resetear");
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1).call(this.frame_4).wait(1).call(this.frame_5).wait(1).call(this.frame_6).wait(1).call(this.frame_7).wait(1));

	// TITULO
	this.instance = new lib.tema_entrada_titulo();
	this.instance.parent = this;
	this.instance.setTransform(303.6,249.85);

	this.instance_1 = new lib.tituloestatica();
	this.instance_1.parent = this;
	this.instance_1.setTransform(303.6,249.85);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance_1}]},1).wait(6));

	// PAGINAS
	this.instance_2 = new lib.titulomodulot1TMR();
	this.instance_2.parent = this;
	this.instance_2.setTransform(379.95,245.4,1,1,0,0,0,323.9,217.4);

	this.instance_3 = new lib.mc1t1TMR();
	this.instance_3.parent = this;
	this.instance_3.setTransform(17.4,40.15);

	this.instance_4 = new lib.mc2t1TMR();
	this.instance_4.parent = this;
	this.instance_4.setTransform(17.4,40.15);

	this.instance_5 = new lib.mc3t1TMR();
	this.instance_5.parent = this;
	this.instance_5.setTransform(17.4,40.15);

	this.instance_6 = new lib.mc4t1TMR();
	this.instance_6.parent = this;
	this.instance_6.setTransform(17.4,40.15);

	this.instance_7 = new lib.mc5t1TMR();
	this.instance_7.parent = this;
	this.instance_7.setTransform(17.4,40.15);

	this.instance_8 = new lib.mc6t1TMR();
	this.instance_8.parent = this;
	this.instance_8.setTransform(17.4,40.15);

	this.instance_9 = new lib.mc7t1TMR();
	this.instance_9.parent = this;
	this.instance_9.setTransform(17.4,40.15);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2}]}).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_9}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(343.2,250.2,620.2,423.40000000000003);
// library properties:
lib.properties = {
	id: 'D886CFF8C80B4026B28EDF57D18DB692',
	width: 950,
	height: 500,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/AC_TMR_M01_01_atlas_.png?1551717026730", id:"AC_TMR_M01_01_atlas_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['D886CFF8C80B4026B28EDF57D18DB692'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}



})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;