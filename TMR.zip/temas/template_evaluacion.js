(function (lib, img, cjs, ss, an) {

var p; // shortcut to reference prototypes
lib.ssMetadata = [];


// symbols:
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.traingulo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF9900").s().p("AhDBwQgMgIAEgNIAahWQABgFgBgEIgahWQgEgNAMgIQALgHALAIIBzBhQAHAFAAAIQAAAJgHAFIhzBhQgGAEgGAAQgFAAgFgDg");
	this.shape.setTransform(-805.1,8.6,0.9,0.9);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.traingulo, new cjs.Rectangle(-812,-1.7,13.9,20.8), null);


(lib.titulo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#6D3721").s().p("EggbAW7QgHgEhUhsQhShnhCi2QhDi2AqjjQAljjDnj0IFXlVQCoioCOiKIFGlGQD5j5C9jBIC6i6IBXhKQBYhDCXhGQCUhGC+gEQCRgECYBCQCeA+CcCdIXsXrQAEAAARAYQAMAZAAApQAAAqgtAxQgaAeg1AUQgyAVhzAAIsEAAIvHvGQgEgEgtghQgugdhKgEQhKgEhPBKIz/T/QgFAAghAyQgcAugFBKQgDBGBKBTIBGBGIqAKAg");
	this.shape.setTransform(3.8,-11.5,0.072,0.074);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#6D3721").s().p("AtMO9Qicg8imiiIn8oAIKAp/IFfFfQAAAEAuAhQAtAcBKAEQBHAEBShJIO9u+IMqAAQB1AAAsAUQAqARAYAdQAuAyAAAoQAAAmgRAYQgMAagFAAI3vXvQAAAEhXBFQhVBCiWBHQiVBGi9AEQiRAAihhDg");
	this.shape_1.setTransform(8.8,5.9,0.072,0.074);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#C2223C").s().p("Au5XLQgegZgUg2QgUg4AAh5IAAr4IPKvKQAEAAAdgtQAcgyAIhGQAFhKhKhPIhKhGIJ7p8IDnDnQAIAFBTBrQBTBsBCC1QBFC2gkDjQgmDjjnDvQhfBji2CxIzWTXQAAAEgYANQgVAQglAAIgIAAQgpAAgygtg");
	this.shape_2.setTransform(-2.3,-0.3,0.072,0.074);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#C2223C").s().p("EAArAk4QglAAgTgLIgVgRI3030QgFAAhShsQhThshCi5QhGi2AqjiQAljoDrjzIZB5CQAAgEBXhHQBQhACXhDQCThHDAgEQCLgECeBCQCdBCChCdIIEIEIp4J8IliljQgKgIgogdQgtgdhLgEQhGgFhTBLIz/UAQgDAAgiAtQghAtgEBLQgEBGBOBSIO9O/IAAMpQgEB1gQAsQgUApgeAZQgxAugnAAIgHgBg");
	this.shape_3.setTransform(-18.1,-6.6,0.072,0.074);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#6D3721").s().p("AE+IfIhjj4IlOAAIBLi+IC5AAIiYl2Ik2MsIkMAAIGEu1QAAgDAUgiQARghAtgdQApghBDgEQA9AEApAdQApAhAVAhIAVAhIGYO5g");
	this.shape_4.setTransform(43.7,21.8,0.072,0.074);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#C2223C").s().p("AE+IfIhjj4IlNAAIBKi+IC5AAIiYl2Ik2MsIkNAAIGFu1QAAgEAQghQAXgiAngcQAqghBCgEQBBAEApAdQAqAiAUAgIAVAhIGZO5g");
	this.shape_5.setTransform(-35.6,21.8,0.072,0.074);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#C2223C").s().p("AD4IiIkUmlIicAAIBBitICkAAIAygIQAygJAxggQAyglAEhLQgEhKgpgdQgugigtgIQgsgIgOAAIleAAIAAOMIkAAAIAAxCIMHAAQAEgEBCARQBGAVBHBCQBGBGAQCdQAFAEgNBCQgHBCg7BKQg1BOiRAhIEyG6g");
	this.shape_6.setTransform(-52.1,21.7,0.072,0.074);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#C2223C").s().p("AE+IfIhjj4IlOAAIBLi+IC5AAIiYl2Ik2MsIkMAAIGEu1QAAgEARghQAVgiAsgcQApghBDgEQA9AEApAdQAqAiAUAgIAVAhIGYO5g");
	this.shape_7.setTransform(-61.1,21.8,0.072,0.074);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#C2223C").s().p("AgSIfQgoAAgigIQgggEgmgNQiRgthGiMQhKiNgEipQgFisBCiRQBGiQCJg/QA2gUAxgNQAvgIA8AAIGtAAIAADPIm+AAQh3AIgtBvQgtB0AMB/QAEB1AyBiQAsBeBvAJIG2AEIAADCg");
	this.shape_8.setTransform(-44.2,21.8,0.072,0.074);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#6D3721").s().p("AgRIfQgpAAgigIQgggEgmgNQiQgthHiMQhKiNgEipQgEitBCiQQBGiQCIg/QA2gUAygNQAugIA8AAIGuAAIAADPIm+AAQh3AIguBvQgtB0AMB/QAFB1AxBiQAtBeBvAJIG2AEIAADCg");
	this.shape_9.setTransform(-28.1,21.8,0.072,0.074);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#6D3721").s().p("Am1G2QidiNAAk0QgDj4CQiZQCRiZE4gEQDoAACABGQCABHAxB7QAyCCADCvQAFDehOB9QhTCAiIAxQiEAuiiAAIgEAAIgRAAQkTAAiViEgAgHl3QitAIhHBwQhKBrAECNQgICUA+BzQA+B0DaAEIAEAAQC5gIA/hwQA+hwgFiXQAAiZhKhsQhPhnipgEQAAAAAAgBQAAAAAAgBQAAAAAAAAQAAAAgBAAIgGACg");
	this.shape_10.setTransform(-19.9,21.8,0.072,0.074);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#6D3721").s().p("ADbIhIoMscIAFMYIkEAAIAAw9IFaAAIH/MtIAAstIEJAAIAARBg");
	this.shape_11.setTransform(-10.5,21.8,0.072,0.074);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#6D3721").s().p("AiAIdIAAt/ImMAAIAAi6IQZAAIAAC6ImVAAIAAN/g");
	this.shape_12.setTransform(-1.6,21.8,0.072,0.074);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#6D3721").s().p("AiQIfIAAw9IEgAAIAAQ9g");
	this.shape_13.setTransform(4.1,21.6,0.072,0.074);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#6D3721").s().p("ADbIhIoMscIAFMYIkEAAIAAw9IFaAAIH/MtIAAstIEIAAIAARBg");
	this.shape_14.setTransform(10.2,21.8,0.072,0.074);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#6D3721").s().p("AiNIPQg0gNg8gdQiAhCg+iAQg+iFAAiYQAAiXA+iFQBDiAB7hGQBCglA+gNQBBgMBHAAIHrAAIAAC+InHAAQhpgEhLBOQhKBLAEBvILFAAIAAC9IrBAAQgEBjBCBCQBCBTBmAEIHbAAIAAC6IoLAAIgeAAQg0AAgqgMg");
	this.shape_15.setTransform(18.9,21.6,0.072,0.074);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#6D3721").s().p("ADbIhIoQscIAJMYIkFAAIAAw9IFbAAIIAMtIAAstIEIAAIAARBg");
	this.shape_16.setTransform(27.6,21.8,0.072,0.074);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#6D3721").s().p("AiAIdIAAt/ImMAAIAAi6IQZAAIAAC6ImSAAIAAN/g");
	this.shape_17.setTransform(36.6,21.8,0.072,0.074);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#6D3721").s().p("AA6IfQiXAAh9gpQh8gqhCh/QgUgwgJgrQgIgrAAg4IAAqtIEVAAIAAKoQAABTAxBCQAqAyA1AQQA7ANBAAAIFbAAIAACxg");
	this.shape_18.setTransform(51.5,21.9,0.072,0.074);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("AAWBBIgWhTIgVBTIgiAAIgpiBIAiAAIAYBUIAWhUIAgAAIAWBUIAZhUIAiAAIgqCBg");
	this.shape_19.setTransform(387.5,3.2);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#000000").s().p("AgvAuQgNgSAAgbQAAgfARgTQARgSAaAAQAcAAAQATQARATgBAnIhVAAQABAPAIAJQAIAIAKAAQAIAAAGgEQAFgFADgKIAiAGQgGATgOAKQgPAKgVAAQghAAgQgWgAgRggQgHAIAAAOIAyAAQAAgPgHgIQgIgIgKAAQgLAAgHAJg");
	this.shape_20.setTransform(370.7,3.2);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#000000").s().p("AgQBaIAAiBIAhAAIAACBgAgQg5IAAgfIAhAAIAAAfg");
	this.shape_21.setTransform(360.4,0.8);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#000000").s().p("AgOBBIg0iBIAkAAIAYBBIAGAWIAEgLIADgLIAZhBIAjAAIgzCBg");
	this.shape_22.setTransform(349.9,3.2);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#000000").s().p("AgvAuQgNgSAAgbQAAgfARgTQARgSAaAAQAcAAAQATQARATgBAnIhVAAQABAPAIAJQAIAIAKAAQAIAAAGgEQAFgFADgKIAiAGQgGATgOAKQgPAKgVAAQghAAgQgWgAgRggQgHAIAAAOIAyAAQAAgPgHgIQgIgIgKAAQgLAAgHAJg");
	this.shape_23.setTransform(336,3.2);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#000000").s().p("AAlBaIgagoQgNgUgFgFQgFgGgGgCQgGgCgMAAIgHAAIAABLIgkAAIAAiyIBMAAQAbAAANAEQANAFAIAMQAIANAAAPQAAAVgMANQgMAMgXADQALAIAIAIQAIAHANAWIAVAjgAgrgNIAaAAQAZAAAHgCQAGgCAEgGQAEgFAAgIQAAgJgFgGQgFgFgJgCIgZAAIgcAAg");
	this.shape_24.setTransform(320.9,0.8);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#000000").s().p("AgEBWQgIgDgEgFQgDgFgBgIQgBgGAAgTIAAg3IgQAAIAAgbIAQAAIAAgaIAhgUIAAAuIAXAAIAAAbIgXAAIAAAzIABATIADAEQACACAEAAQAEAAAJgEIADAbQgMAFgPAAQgJAAgGgDg");
	this.shape_25.setTransform(300,1.1);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#000000").s().p("AAZBCIAAhCQAAgUgCgGQgDgGgEgEQgFgDgHAAQgIAAgHAFQgHAFgDAIQgDAIAAAVIAAA6IgiAAIAAiAIAgAAIAAATQARgWAZAAQALAAAJAEQAKAEAFAGQAEAHACAIQACAIAAAPIAABPg");
	this.shape_26.setTransform(288.2,3.1);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#000000").s().p("AgvAuQgNgSAAgbQAAgfARgTQARgSAaAAQAcAAAQATQARATgBAnIhVAAQABAPAIAJQAIAIAKAAQAIAAAGgEQAFgFADgKIAiAGQgGATgOAKQgPAKgVAAQghAAgQgWgAgRggQgHAIAAAOIAyAAQAAgPgHgIQgIgIgKAAQgLAAgHAJg");
	this.shape_27.setTransform(273.5,3.2);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#000000").s().p("AA9BCIAAhJQAAgTgEgGQgEgHgKAAQgHAAgHAEQgGAFgDAIQgDAJAAARIAAA+IghAAIAAhGQAAgTgCgFQgCgGgDgCQgEgDgHAAQgIAAgGAEQgHAEgCAJQgDAIAAARIAAA/IgiAAIAAiAIAfAAIAAARQARgUAYAAQAMAAAJAFQAIAFAGAKQAJgKAKgFQAKgFALAAQAOAAAKAGQAKAFAFAMQADAIAAASIAABSg");
	this.shape_28.setTransform(255.4,3.1);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#000000").s().p("AgvAuQgNgSAAgbQAAgfARgTQARgSAaAAQAcAAAQATQARATgBAnIhVAAQABAPAIAJQAIAIAKAAQAIAAAGgEQAFgFADgKIAiAGQgGATgOAKQgPAKgVAAQghAAgQgWgAgRggQgHAIAAAOIAyAAQAAgPgHgIQgIgIgKAAQgLAAgHAJg");
	this.shape_29.setTransform(237.3,3.2);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#000000").s().p("AgsBSQgOgMAAgRIABgFIAmAGQACAGADADQAFADAJAAQAOAAAHgDQAEgDACgGQACgFAAgLIAAgTQgQAVgWAAQgaAAgPgWQgMgRAAgaQAAggAQgSQAPgQAXAAQAXgBAQAWIAAgSIAgAAIAABzQAAAWgDAMQgEAMgHAGQgHAHgLADQgMADgSAAQgfABgOgLgAgTg3QgIAJAAAUQAAAUAIAJQAIAJALAAQAMABAJgLQAJgJAAgSQAAgVgJgJQgIgLgNAAQgLAAgIALg");
	this.shape_30.setTransform(222.6,5.7);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#000000").s().p("AgwA5QgMgLAAgRQAAgLAFgIQAGgJAJgDQAKgFARgDQAXgFAKgEIAAgDQAAgKgFgEQgFgFgNAAQgJAAgFAEQgFAEgDAJIgfgGQAFgTANgJQANgJAZAAQAWAAALAGQALAFAFAIQAEAJAAAWIAAAnQAAARACAIQABAIAFAKIgiAAIgDgKIgCgEQgIAIgKAEQgJAFgMAAQgUAAgLgLgAAAAIQgOADgFADQgHAEAAAIQAAAHAGAFQAFAGAJAAQAIAAAIgHQAGgEACgHQACgEAAgNIAAgHQgHADgNADg");
	this.shape_31.setTransform(208.3,3.2);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#000000").s().p("AAZBCIAAhCQAAgUgCgGQgDgGgEgEQgFgDgHAAQgIAAgHAFQgHAFgDAIQgDAIAAAVIAAA6IgiAAIAAiAIAgAAIAAATQARgWAZAAQALAAAJAEQAKAEAFAGQAEAHACAIQACAIAAAPIAABPg");
	this.shape_32.setTransform(193.7,3.1);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#000000").s().p("AgwA5QgMgLAAgRQAAgLAFgIQAGgJAJgDQAKgFARgDQAXgFAKgEIAAgDQAAgKgFgEQgFgFgNAAQgJAAgFAEQgFAEgDAJIgfgGQAFgTANgJQANgJAZAAQAWAAALAGQALAFAFAIQAEAJAAAWIAAAnQAAARACAIQABAIAFAKIgiAAIgDgKIgCgEQgIAIgKAEQgJAFgMAAQgUAAgLgLgAAAAIQgOADgFADQgHAEAAAIQAAAHAGAFQAFAGAJAAQAIAAAIgHQAGgEACgHQACgEAAgNIAAgHQgHADgNADg");
	this.shape_33.setTransform(179.1,3.2);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#000000").s().p("AA1BaIAAiNIgkCNIgiAAIgjiNIAACNIghAAIAAiyIA2AAIAfB4IAhh4IA2AAIAACyg");
	this.shape_34.setTransform(161.7,0.8);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#000000").s().p("AgEBWQgIgDgEgFQgDgFgBgIQgBgGAAgTIAAg3IgQAAIAAgbIAQAAIAAgaIAhgUIAAAuIAXAAIAAAbIgXAAIAAAzIABATIADAEQACACAEAAQAEAAAJgEIADAbQgMAFgPAAQgJAAgGgDg");
	this.shape_35.setTransform(140.2,1.1);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#000000").s().p("AAZBCIAAhCQAAgUgCgGQgDgGgEgEQgFgDgHAAQgIAAgHAFQgHAFgDAIQgDAIAAAVIAAA6IgiAAIAAiAIAgAAIAAATQARgWAZAAQALAAAJAEQAKAEAFAGQAEAHACAIQACAIAAAPIAABPg");
	this.shape_36.setTransform(128.4,3.1);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#000000").s().p("AgvAuQgNgSAAgbQAAgfARgTQARgSAaAAQAcAAAQATQARATgBAnIhVAAQABAPAIAJQAIAIAKAAQAIAAAGgEQAFgFADgKIAiAGQgGATgOAKQgPAKgVAAQghAAgQgWgAgRggQgHAIAAAOIAyAAQAAgPgHgIQgIgIgKAAQgLAAgHAJg");
	this.shape_37.setTransform(113.7,3.2);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#000000").s().p("AgQBaIAAiyIAhAAIAACyg");
	this.shape_38.setTransform(103.4,0.8);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#000000").s().p("AgwA5QgMgLAAgRQAAgLAFgIQAGgJAJgDQAKgFARgDQAXgFAKgEIAAgDQAAgKgFgEQgFgFgNAAQgJAAgFAEQgFAEgDAJIgfgGQAFgTANgJQANgJAZAAQAWAAALAGQALAFAFAIQAEAJAAAWIAAAnQAAARACAIQABAIAFAKIgiAAIgDgKIgCgEQgIAIgKAEQgJAFgMAAQgUAAgLgLgAAAAIQgOADgFADQgHAEAAAIQAAAHAGAFQAFAGAJAAQAIAAAIgHQAGgEACgHQACgEAAgNIAAgHQgHADgNADg");
	this.shape_39.setTransform(93,3.2);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#000000").s().p("AgRBaIAAiUIg1AAIAAgeICNAAIAAAeIg1AAIAACUg");
	this.shape_40.setTransform(78.4,0.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.titulo, new cjs.Rectangle(-65.3,-24,479.7,50), null);


(lib.mcBanderilla = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.text = new cjs.Text(" Clic en la flecha para continuar", "16px 'Arial'", "#FFFFFF");
	this.text.lineHeight = 20;
	this.text.parent = this;
	this.text.setTransform(-47.7,15);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E0878B").s().p("AylDrQh4AAAAh4IAAjlQAAh4B4AAMAlLAAAQB4AAAAB4IAADlQAAB4h4AAg");
	this.shape.setTransform(65.9,23.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#E0878B").s().p("AjMA3QAHgBDFhOQDMhSABACQAAAChBBmQhCBnABACIgBAAQgQAAkGgyg");
	this.shape_1.setTransform(158.5,-3.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape},{t:this.text}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.mcBanderilla, new cjs.Rectangle(-65.1,-14.3,262,61.3), null);


(lib.mc_radioButton15 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#DDDDDD").ss(3,1,1).p("ABnAAQAAArgeAeQgeAegrAAQgqAAgegeQgegeAAgrQAAgqAegeQAegeAqAAQArAAAeAeQAeAeAAAqg");
	this.shape.setTransform(3.1,19);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AhIBJQgegeAAgrQAAgqAegeQAegeAqAAQArAAAeAeQAeAeAAAqQAAArgeAeQgeAegrAAQgqAAgegeg");
	this.shape_1.setTransform(3.1,19);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#DDDDDD").s().p("AhUBYQglgBgYgZQgZgZgBglQABgkAZgZQAYgZAlgBICoAAQAmABAZAZQAZAZAAAkQAAAlgZAZQgZAZgmABg");
	this.shape_2.setTransform(12.3,19.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#C7E0A3").ss(3,1,1).p("AhgAkQgGgRAAgTQAAgqAegeQAegeAqAAQArAAAeAeQAeAeAAAqQAAArgeAeQgeAegrAAQgqAAgegeQgKgKgHgMQgEgHgDgIg");
	this.shape_3.setTransform(17.1,19);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#339900").s().p("AhIBJQgKgKgHgMQgEgHgDgHQgGgSAAgTQAAgqAegeQAegeAqAAQArAAAeAeQAeAeAAAqQAAArgeAeQgeAegrAAQgqAAgegeg");
	this.shape_4.setTransform(17.1,19);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#C7E0A3").s().p("AhUBYQglgBgYgZQgZgZgBglQABgkAZgZQAYgZAlgBICoAAQAmABAZAZQAZAZAAAkQAAAlgZAZQgZAZgmABg");
	this.shape_5.setTransform(8.8,19.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-8.7,7.2,38.3,23.6);


(lib.mc_radioButton13 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#DDDDDD").ss(3,1,1).p("ABnAAQAAArgeAeQgeAegrAAQgqAAgegeQgegeAAgrQAAgqAegeQAegeAqAAQArAAAeAeQAeAeAAAqg");
	this.shape.setTransform(3.1,19);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AhIBJQgegeAAgrQAAgqAegeQAegeAqAAQArAAAeAeQAeAeAAAqQAAArgeAeQgeAegrAAQgqAAgegeg");
	this.shape_1.setTransform(3.1,19);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#DDDDDD").s().p("AhUBYQglgBgYgZQgZgZgBglQABgkAZgZQAYgZAlgBICoAAQAmABAZAZQAZAZAAAkQAAAlgZAZQgZAZgmABg");
	this.shape_2.setTransform(12.3,19.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#C7E0A3").ss(3,1,1).p("AhgAkQgGgRAAgTQAAgqAegeQAegeAqAAQArAAAeAeQAeAeAAAqQAAArgeAeQgeAegrAAQgqAAgegeQgKgKgHgMQgEgHgDgIg");
	this.shape_3.setTransform(17.1,19);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#339900").s().p("AhIBJQgKgKgHgMQgEgHgDgHQgGgSAAgTQAAgqAegeQAegeAqAAQArAAAeAeQAeAeAAAqQAAArgeAeQgeAegrAAQgqAAgegeg");
	this.shape_4.setTransform(17.1,19);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#C7E0A3").s().p("AhUBYQglgBgYgZQgZgZgBglQABgkAZgZQAYgZAlgBICoAAQAmABAZAZQAZAZAAAkQAAAlgZAZQgZAZgmABg");
	this.shape_5.setTransform(8.8,19.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-8.7,7.2,38.3,23.6);


(lib.mc_radioButton12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#DDDDDD").ss(3,1,1).p("ABnAAQAAArgeAeQgeAegrAAQgqAAgegeQgegeAAgrQAAgqAegeQAegeAqAAQArAAAeAeQAeAeAAAqg");
	this.shape.setTransform(3.1,19);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AhIBJQgegeAAgrQAAgqAegeQAegeAqAAQArAAAeAeQAeAeAAAqQAAArgeAeQgeAegrAAQgqAAgegeg");
	this.shape_1.setTransform(3.1,19);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#DDDDDD").s().p("AhUBYQglgBgYgZQgZgZgBglQABgkAZgZQAYgZAlgBICoAAQAmABAZAZQAZAZAAAkQAAAlgZAZQgZAZgmABg");
	this.shape_2.setTransform(12.3,19.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#C7E0A3").ss(3,1,1).p("AhgAkQgGgRAAgTQAAgqAegeQAegeAqAAQArAAAeAeQAeAeAAAqQAAArgeAeQgeAegrAAQgqAAgegeQgKgKgHgMQgEgHgDgIg");
	this.shape_3.setTransform(17.1,19);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#339900").s().p("AhIBJQgKgKgHgMQgEgHgDgHQgGgSAAgTQAAgqAegeQAegeAqAAQArAAAeAeQAeAeAAAqQAAArgeAeQgeAegrAAQgqAAgegeg");
	this.shape_4.setTransform(17.1,19);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#C7E0A3").s().p("AhUBYQglgBgYgZQgZgZgBglQABgkAZgZQAYgZAlgBICoAAQAmABAZAZQAZAZAAAkQAAAlgZAZQgZAZgmABg");
	this.shape_5.setTransform(8.8,19.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-8.7,7.2,38.3,23.6);


(lib.mc_radioButton10 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#DDDDDD").ss(3,1,1).p("ABnAAQAAArgeAeQgeAegrAAQgqAAgegeQgegeAAgrQAAgqAegeQAegeAqAAQArAAAeAeQAeAeAAAqg");
	this.shape.setTransform(3.1,19);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AhIBJQgegeAAgrQAAgqAegeQAegeAqAAQArAAAeAeQAeAeAAAqQAAArgeAeQgeAegrAAQgqAAgegeg");
	this.shape_1.setTransform(3.1,19);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#DDDDDD").s().p("AhUBYQglgBgYgZQgZgZgBglQABgkAZgZQAYgZAlgBICoAAQAmABAZAZQAZAZAAAkQAAAlgZAZQgZAZgmABg");
	this.shape_2.setTransform(12.3,19.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#C7E0A3").ss(3,1,1).p("AhgAkQgGgRAAgTQAAgqAegeQAegeAqAAQArAAAeAeQAeAeAAAqQAAArgeAeQgeAegrAAQgqAAgegeQgKgKgHgMQgEgHgDgIg");
	this.shape_3.setTransform(17.1,19);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#339900").s().p("AhIBJQgKgKgHgMQgEgHgDgHQgGgSAAgTQAAgqAegeQAegeAqAAQArAAAeAeQAeAeAAAqQAAArgeAeQgeAegrAAQgqAAgegeg");
	this.shape_4.setTransform(17.1,19);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#C7E0A3").s().p("AhUBYQglgBgYgZQgZgZgBglQABgkAZgZQAYgZAlgBICoAAQAmABAZAZQAZAZAAAkQAAAlgZAZQgZAZgmABg");
	this.shape_5.setTransform(8.8,19.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-8.7,7.2,38.3,23.6);


(lib.mc_radioButton9 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#DDDDDD").ss(3,1,1).p("ABnAAQAAArgeAeQgeAegrAAQgqAAgegeQgegeAAgrQAAgqAegeQAegeAqAAQArAAAeAeQAeAeAAAqg");
	this.shape.setTransform(3.1,19);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AhIBJQgegeAAgrQAAgqAegeQAegeAqAAQArAAAeAeQAeAeAAAqQAAArgeAeQgeAegrAAQgqAAgegeg");
	this.shape_1.setTransform(3.1,19);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#DDDDDD").s().p("AhUBYQglgBgYgZQgZgZgBglQABgkAZgZQAYgZAlgBICoAAQAmABAZAZQAZAZAAAkQAAAlgZAZQgZAZgmABg");
	this.shape_2.setTransform(12.3,19.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#C7E0A3").ss(3,1,1).p("AhgAkQgGgRAAgTQAAgqAegeQAegeAqAAQArAAAeAeQAeAeAAAqQAAArgeAeQgeAegrAAQgqAAgegeQgKgKgHgMQgEgHgDgIg");
	this.shape_3.setTransform(17.1,19);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#339900").s().p("AhIBJQgKgKgHgMQgEgHgDgHQgGgSAAgTQAAgqAegeQAegeAqAAQArAAAeAeQAeAeAAAqQAAArgeAeQgeAegrAAQgqAAgegeg");
	this.shape_4.setTransform(17.1,19);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#C7E0A3").s().p("AhUBYQglgBgYgZQgZgZgBglQABgkAZgZQAYgZAlgBICoAAQAmABAZAZQAZAZAAAkQAAAlgZAZQgZAZgmABg");
	this.shape_5.setTransform(8.8,19.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-8.7,7.2,38.3,23.6);


(lib.mc_radioButton8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#DDDDDD").ss(3,1,1).p("ABnAAQAAArgeAeQgeAegrAAQgqAAgegeQgegeAAgrQAAgqAegeQAegeAqAAQArAAAeAeQAeAeAAAqg");
	this.shape.setTransform(3.1,19);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AhIBJQgegeAAgrQAAgqAegeQAegeAqAAQArAAAeAeQAeAeAAAqQAAArgeAeQgeAegrAAQgqAAgegeg");
	this.shape_1.setTransform(3.1,19);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#DDDDDD").s().p("AhUBYQglgBgYgZQgZgZgBglQABgkAZgZQAYgZAlgBICoAAQAmABAZAZQAZAZAAAkQAAAlgZAZQgZAZgmABg");
	this.shape_2.setTransform(12.3,19.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#C7E0A3").ss(3,1,1).p("AhgAkQgGgRAAgTQAAgqAegeQAegeAqAAQArAAAeAeQAeAeAAAqQAAArgeAeQgeAegrAAQgqAAgegeQgKgKgHgMQgEgHgDgIg");
	this.shape_3.setTransform(17.1,19);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#339900").s().p("AhIBJQgKgKgHgMQgEgHgDgHQgGgSAAgTQAAgqAegeQAegeAqAAQArAAAeAeQAeAeAAAqQAAArgeAeQgeAegrAAQgqAAgegeg");
	this.shape_4.setTransform(17.1,19);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#C7E0A3").s().p("AhUBYQglgBgYgZQgZgZgBglQABgkAZgZQAYgZAlgBICoAAQAmABAZAZQAZAZAAAkQAAAlgZAZQgZAZgmABg");
	this.shape_5.setTransform(8.8,19.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-8.7,7.2,38.3,23.6);


(lib.mc_radioButton7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#DDDDDD").ss(3,1,1).p("ABnAAQAAArgeAeQgeAegrAAQgqAAgegeQgegeAAgrQAAgqAegeQAegeAqAAQArAAAeAeQAeAeAAAqg");
	this.shape.setTransform(3.1,19);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AhIBJQgegeAAgrQAAgqAegeQAegeAqAAQArAAAeAeQAeAeAAAqQAAArgeAeQgeAegrAAQgqAAgegeg");
	this.shape_1.setTransform(3.1,19);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#DDDDDD").s().p("AhUBYQglgBgYgZQgZgZgBglQABgkAZgZQAYgZAlgBICoAAQAmABAZAZQAZAZAAAkQAAAlgZAZQgZAZgmABg");
	this.shape_2.setTransform(12.3,19.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#C7E0A3").ss(3,1,1).p("AhgAkQgGgRAAgTQAAgqAegeQAegeAqAAQArAAAeAeQAeAeAAAqQAAArgeAeQgeAegrAAQgqAAgegeQgKgKgHgMQgEgHgDgIg");
	this.shape_3.setTransform(17.1,19);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#339900").s().p("AhIBJQgKgKgHgMQgEgHgDgHQgGgSAAgTQAAgqAegeQAegeAqAAQArAAAeAeQAeAeAAAqQAAArgeAeQgeAegrAAQgqAAgegeg");
	this.shape_4.setTransform(17.1,19);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#C7E0A3").s().p("AhUBYQglgBgYgZQgZgZgBglQABgkAZgZQAYgZAlgBICoAAQAmABAZAZQAZAZAAAkQAAAlgZAZQgZAZgmABg");
	this.shape_5.setTransform(8.8,19.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-8.7,7.2,38.3,23.6);


(lib.mc_radioButton6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#DDDDDD").ss(3,1,1).p("ABnAAQAAArgeAeQgeAegrAAQgqAAgegeQgegeAAgrQAAgqAegeQAegeAqAAQArAAAeAeQAeAeAAAqg");
	this.shape.setTransform(3.1,19);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AhIBJQgegeAAgrQAAgqAegeQAegeAqAAQArAAAeAeQAeAeAAAqQAAArgeAeQgeAegrAAQgqAAgegeg");
	this.shape_1.setTransform(3.1,19);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#DDDDDD").s().p("AhUBYQglgBgYgZQgZgZgBglQABgkAZgZQAYgZAlgBICoAAQAmABAZAZQAZAZAAAkQAAAlgZAZQgZAZgmABg");
	this.shape_2.setTransform(12.3,19.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#C7E0A3").ss(3,1,1).p("AhgAkQgGgRAAgTQAAgqAegeQAegeAqAAQArAAAeAeQAeAeAAAqQAAArgeAeQgeAegrAAQgqAAgegeQgKgKgHgMQgEgHgDgIg");
	this.shape_3.setTransform(17.1,19);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#339900").s().p("AhIBJQgKgKgHgMQgEgHgDgHQgGgSAAgTQAAgqAegeQAegeAqAAQArAAAeAeQAeAeAAAqQAAArgeAeQgeAegrAAQgqAAgegeg");
	this.shape_4.setTransform(17.1,19);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#C7E0A3").s().p("AhUBYQglgBgYgZQgZgZgBglQABgkAZgZQAYgZAlgBICoAAQAmABAZAZQAZAZAAAkQAAAlgZAZQgZAZgmABg");
	this.shape_5.setTransform(8.8,19.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-8.7,7.2,38.3,23.6);


(lib.mc_radioButton5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#DDDDDD").ss(3,1,1).p("ABnAAQAAArgeAeQgeAegrAAQgqAAgegeQgegeAAgrQAAgqAegeQAegeAqAAQArAAAeAeQAeAeAAAqg");
	this.shape.setTransform(3.1,19);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AhIBJQgegeAAgrQAAgqAegeQAegeAqAAQArAAAeAeQAeAeAAAqQAAArgeAeQgeAegrAAQgqAAgegeg");
	this.shape_1.setTransform(3.1,19);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#DDDDDD").s().p("AhUBYQglgBgYgZQgZgZgBglQABgkAZgZQAYgZAlgBICoAAQAmABAZAZQAZAZAAAkQAAAlgZAZQgZAZgmABg");
	this.shape_2.setTransform(12.3,19.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#C7E0A3").ss(3,1,1).p("AhgAkQgGgRAAgTQAAgqAegeQAegeAqAAQArAAAeAeQAeAeAAAqQAAArgeAeQgeAegrAAQgqAAgegeQgKgKgHgMQgEgHgDgIg");
	this.shape_3.setTransform(17.1,19);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#339900").s().p("AhIBJQgKgKgHgMQgEgHgDgHQgGgSAAgTQAAgqAegeQAegeAqAAQArAAAeAeQAeAeAAAqQAAArgeAeQgeAegrAAQgqAAgegeg");
	this.shape_4.setTransform(17.1,19);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#C7E0A3").s().p("AhUBYQglgBgYgZQgZgZgBglQABgkAZgZQAYgZAlgBICoAAQAmABAZAZQAZAZAAAkQAAAlgZAZQgZAZgmABg");
	this.shape_5.setTransform(8.8,19.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-8.7,7.2,38.3,23.6);


(lib.mc_radioButton4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#DDDDDD").ss(3,1,1).p("ABnAAQAAArgeAeQgeAegrAAQgqAAgegeQgegeAAgrQAAgqAegeQAegeAqAAQArAAAeAeQAeAeAAAqg");
	this.shape.setTransform(3.1,19);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AhIBJQgegeAAgrQAAgqAegeQAegeAqAAQArAAAeAeQAeAeAAAqQAAArgeAeQgeAegrAAQgqAAgegeg");
	this.shape_1.setTransform(3.1,19);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#DDDDDD").s().p("AhUBYQglgBgYgZQgZgZgBglQABgkAZgZQAYgZAlgBICoAAQAmABAZAZQAZAZAAAkQAAAlgZAZQgZAZgmABg");
	this.shape_2.setTransform(12.3,19.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#C7E0A3").ss(3,1,1).p("AhgAkQgGgRAAgTQAAgqAegeQAegeAqAAQArAAAeAeQAeAeAAAqQAAArgeAeQgeAegrAAQgqAAgegeQgKgKgHgMQgEgHgDgIg");
	this.shape_3.setTransform(17.1,19);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#339900").s().p("AhIBJQgKgKgHgMQgEgHgDgHQgGgSAAgTQAAgqAegeQAegeAqAAQArAAAeAeQAeAeAAAqQAAArgeAeQgeAegrAAQgqAAgegeg");
	this.shape_4.setTransform(17.1,19);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#C7E0A3").s().p("AhUBYQglgBgYgZQgZgZgBglQABgkAZgZQAYgZAlgBICoAAQAmABAZAZQAZAZAAAkQAAAlgZAZQgZAZgmABg");
	this.shape_5.setTransform(8.8,19.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-8.7,7.2,38.3,23.6);


(lib.mc_radioButton = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#DDDDDD").ss(3,1,1).p("ABnAAQAAArgeAeQgeAegrAAQgqAAgegeQgegeAAgrQAAgqAegeQAegeAqAAQArAAAeAeQAeAeAAAqg");
	this.shape.setTransform(3.1,19);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AhIBJQgegeAAgrQAAgqAegeQAegeAqAAQArAAAeAeQAeAeAAAqQAAArgeAeQgeAegrAAQgqAAgegeg");
	this.shape_1.setTransform(3.1,19);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#DDDDDD").s().p("AhUBYQglgBgYgZQgZgZgBglQABgkAZgZQAYgZAlgBICoAAQAmABAZAZQAZAZAAAkQAAAlgZAZQgZAZgmABg");
	this.shape_2.setTransform(12.3,19.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#C7E0A3").ss(3,1,1).p("AhgAkQgGgRAAgTQAAgqAegeQAegeAqAAQArAAAeAeQAeAeAAAqQAAArgeAeQgeAegrAAQgqAAgegeQgKgKgHgMQgEgHgDgIg");
	this.shape_3.setTransform(17.1,19);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#339900").s().p("AhIBJQgKgKgHgMQgEgHgDgHQgGgSAAgTQAAgqAegeQAegeAqAAQArAAAeAeQAeAeAAAqQAAArgeAeQgeAegrAAQgqAAgegeg");
	this.shape_4.setTransform(17.1,19);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#C7E0A3").s().p("AhUBYQglgBgYgZQgZgZgBglQABgkAZgZQAYgZAlgBICoAAQAmABAZAZQAZAZAAAkQAAAlgZAZQgZAZgmABg");
	this.shape_5.setTransform(8.8,19.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-8.7,7.2,38.3,23.6);


(lib.mc_boton = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CCCCCC").s().p("AqqDIQhTAAg7g7Qg6g6AAhTIAAAAQAAhSA6g6QA7g7BTAAIVWAAQBSAAA6A7QA7A6AABSIAAAAQAABTg7A6Qg6A7hSAAg");
	this.shape.setTransform(88.3,20);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#009900").s().rr(-88.3,-20,176.6,40,20);
	this.shape_1.setTransform(88.3,20);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,176.6,40);


(lib.M03_TMR_TABLA4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#231F20").s().p("AQfIgQgHAAgFgFQgFgFAAgHQAAgHAFgFIAAgrQAAgHAFgFQAFgFAHgBQAIABAFAFQAFAFAAAHIAAA3QAAAHgFAFQgFAFgIAAgAOnIgQgHAAgFgFQgFgFAAgHQAAgHAFgFQAFgFAHgBIA9AAQAHABAFAFQAFAFAAAHQAAAHgFAFQgFAFgHAAgAMwIgQgIAAgFgFQgFgFAAgHQAAgHAFgFQAFgFAIgBIA7AAQAIABAFAFQAFAFAAAHQAAAHgFAFQgFAFgIAAgAK3IgQgHAAgFgFQgFgFAAgHQAAgHAFgFQAFgFAHgBIA8AAQAIABAFAFQAFAFAAAHQAAAHgFAFQgFAFgIAAgAI/IgQgHAAgFgFQgFgFAAgHQAAgHAFgFQAFgFAHgBIA9AAQAHABAFAFQAFAFAAAHQAAAHgFAFQgFAFgHAAgAHIIgQgIAAgFgFQgFgFAAgHQAAgHAFgFQAFgFAIgBIA7AAQAIABAFAFQAFAFAAAHQAAAHgFAFQgFAFgIAAgAFPIgQgHAAgFgFQgFgFAAgHQAAgHAFgFQAFgFAHgBIA8AAQAIABAFAFQAFAFAAAHQAAAHgFAFQgFAFgIAAgADXIgQgHAAgFgFQgFgFAAgHQAAgHAFgFQAFgFAHgBIA9AAQAHABAFAFQAFAFAAAHQAAAHgFAFQgFAFgHAAgABgIgQgIAAgFgFQgFgFAAgHQAAgHAFgFQAFgFAIgBIA7AAQAIABAFAFQAFAFAAAHQAAAHgFAFQgFAFgIAAgAgYIgQgHAAgFgFQgFgFAAgHQAAgHAFgFQAFgFAHgBIA7AAQAIABAFAFQAFAFAAAHQAAAHgFAFQgFAFgIAAgAiQIgQgHAAgFgFQgFgFAAgHQAAgHAFgFQAFgFAHgBIA9AAQAHABAFAFQAFAFAAAHQAAAHgFAFQgFAFgHAAgAkHIgQgIAAgFgFQgFgFAAgHQAAgHAFgFQAFgFAIgBIA7AAQAIABAFAFQAFAFAAAHQAAAHgFAFQgFAFgIAAgAmAIgQgHAAgFgFQgFgFAAgHQAAgHAFgFQAFgFAHgBIA8AAQAIABAFAFQAFAFAAAHQAAAHgFAFQgFAFgIAAgAn4IgQgHAAgFgFQgFgFAAgHQAAgHAFgFQAFgFAHgBIA9AAQAHABAFAFQAFAFAAAHQAAAHgFAFQgFAFgHAAgApvIgQgIAAgFgFQgFgFAAgHQAAgHAFgFQAFgFAIgBIA7AAQAIABAFAFQAFAFAAAHQAAAHgFAFQgFAFgIAAgAroIgQgHAAgFgFQgFgFAAgHQAAgHAFgFQAFgFAHgBIA8AAQAIABAFAFQAFAFAAAHQAAAHgFAFQgFAFgIAAgAtgIgQgHAAgFgFQgFgFAAgHQAAgHAFgFQAFgFAHgBIA9AAQAHABAFAFQAFAFAAAHQAAAHgFAFQgFAFgHAAgAvXIgQgIAAgFgFQgFgFAAgHQAAgHAFgFQAFgFAIgBIA7AAQAIABAFAFQAFAFAAAHQAAAHgFAFQgFAFgIAAgAwkIgQgHAAgFgFQgFgFAAgHIAAgsQAAgHAFgFQAFgFAHgBQAIABAFAFQAFAFAAAHIAAAaQAGABAFAFQAFAFAAAHQAAAHgFAFQgFAFgIAAgAwwGzQgFgFAAgHIAAg8QAAgHAFgFQAFgFAHAAQAIAAAFAFQAFAFAAAHIAAA8QAAAHgFAFQgFAFgIABQgHgBgFgFgAQYGoQgFgFAAgHIAAg8QAAgHAFgFQAFgFAHAAQAIAAAFAFQAFAFAAAHIAAA8QAAAHgFAFQgFAFgIAAQgHAAgFgFgAwwE7QgFgFAAgHIAAg8QAAgHAFgFQAFgFAHAAQAIAAAFAFQAFAFAAAHIAAA8QAAAHgFAFQgFAFgIAAQgHAAgFgFgAQYEwQgFgFAAgHIAAg8QAAgHAFgFQAFgFAHgBQAIABAFAFQAFAFAAAHIAAA8QAAAHgFAFQgFAFgIAAQgHAAgFgFgAwwDDQgFgFAAgHIAAg8QAAgHAFgFQAFgFAHgBQAIABAFAFQAFAFAAAHIAAA8QAAAHgFAFQgFAFgIABQgHgBgFgFgAQYC4QgFgFAAgHIAAg8QAAgHAFgFQAFgFAHgBQAIABAFAFQAFAFAAAHIAAA8QAAAHgFAFQgFAFgIABQgHgBgFgFgAwwBLQgFgFAAgHIAAg8QAAgGAFgFQAFgFAHAAQAIAAAFAFQAFAFAAAGIAAA8QAAAHgFAFQgFAFgIABQgHgBgFgFgAQYBAQgFgFAAgHIAAg7QAAgHAFgFQAFgFAHAAQAIAAAFAFQAFAFAAAHIAAA7QAAAHgFAFQgFAFgIAAQgHAAgFgFgAwwgsQgFgFAAgHIAAg8QAAgHAFgFQAFgFAHAAQAIAAAFAFQAFAFAAAHIAAA8QAAAHgFAFQgFAFgIAAQgHAAgFgFgAQYg3QgFgFAAgHIAAg8QAAgHAFgFQAFgFAHgBQAIABAFAFQAFAFAAAHIAAA8QAAAHgFAFQgFAFgIAAQgHAAgFgFgAwwikQgFgFAAgHIAAg8QAAgHAFgFQAFgFAHgBQAIABAFAFQAFAFAAAHIAAA8QAAAHgFAFQgFAFgIABQgHgBgFgFgAQYivQgFgFAAgHIAAg8QAAgHAFgFQAFgFAHgBQAIABAFAFQAFAFAAAHIAAA8QAAAHgFAFQgFAFgIABQgHgBgFgFgAwwkcQgFgFAAgHIAAg8QAAgHAFgFQAFgFAHAAQAIAAAFAFQAFAFAAAHIAAA8QAAAHgFAFQgFAFgIABQgHgBgFgFgAQYknQgFgFAAgHIAAg8QAAgHAFgFQAFgFAHAAQAIAAAFAFQAFAFAAAHIAAA8QAAAHgFAFQgFAFgIAAQgHAAgFgFgAwwmUQgFgFAAgHIAAg8QAAgHAFgFQAFgFAHAAQAIAAAFAFQAFAFAAAHIAAA8QAAAHgFAFQgFAFgIAAQgHAAgFgFgAQYmfQgFgFAAgHIAAg8QAAgHAFgFQAFgFAHgBQAIABAFAFQAFAFAAAHIAAA8QAAAHgFAFQgFAFgIABQgHgBgFgFgAPTn8QgHgBgFgFQgFgFAAgHQAAgHAFgFQAFgFAHgBIA9AAQAHABAFAFQAFAFAAAHQAAAHgFAFQgFAFgHABgANcn8QgIgBgFgFQgFgFAAgHQAAgHAFgFQAFgFAIgBIA7AAQAIABAFAFQAFAFAAAHQAAAHgFAFQgFAFgIABgALjn8QgHgBgFgFQgFgFAAgHQAAgHAFgFQAFgFAHgBIA8AAQAIABAFAFQAFAFAAAHQAAAHgFAFQgFAFgIABgAJrn8QgHgBgFgFQgFgFAAgHQAAgHAFgFQAFgFAHgBIA9AAQAHABAFAFQAFAFAAAHQAAAHgFAFQgFAFgHABgAH0n8QgIgBgFgFQgFgFAAgHQAAgHAFgFQAFgFAIgBIA7AAQAIABAFAFQAFAFAAAHQAAAHgFAFQgFAFgIABgAF7n8QgHgBgFgFQgFgFAAgHQAAgHAFgFQAFgFAHgBIA8AAQAIABAFAFQAFAFAAAHQAAAHgFAFQgFAFgIABgAEDn8QgHgBgFgFQgFgFAAgHQAAgHAFgFQAFgFAHgBIA9AAQAHABAFAFQAFAFAAAHQAAAHgFAFQgFAFgHABgACMn8QgIgBgFgFQgFgFAAgHQAAgHAFgFQAFgFAIgBIA7AAQAIABAFAFQAFAFAAAHQAAAHgFAFQgFAFgIABgAATn8QgHgBgFgFQgFgFAAgHQAAgHAFgFQAFgFAHgBIA8AAQAIABAFAFQAFAFAAAHQAAAHgFAFQgFAFgIABgAhkn8QgHgBgFgFQgFgFAAgHQAAgHAFgFQAFgFAHgBIA9AAQAHABAFAFQAFAFAAAHQAAAHgFAFQgFAFgHABgAjbn8QgIgBgFgFQgFgFAAgHQAAgHAFgFQAFgFAIgBIA7AAQAIABAFAFQAFAFAAAHQAAAHgFAFQgFAFgIABgAlUn8QgHgBgFgFQgFgFAAgHQAAgHAFgFQAFgFAHgBIA8AAQAIABAFAFQAFAFAAAHQAAAHgFAFQgFAFgIABgAnMn8QgHgBgFgFQgFgFAAgHQAAgHAFgFQAFgFAHgBIA9AAQAHABAFAFQAFAFAAAHQAAAHgFAFQgFAFgHABgApDn8QgIgBgFgFQgFgFAAgHQAAgHAFgFQAFgFAIgBIA7AAQAIABAFAFQAFAFAAAHQAAAHgFAFQgFAFgIABgAq8n8QgHgBgFgFQgFgFAAgHQAAgHAFgFQAFgFAHgBIA9AAQAHABAFAFQAFAFAAAHQAAAHgFAFQgFAFgHABgAszn8QgIgBgFgFQgFgFAAgHQAAgHAFgFQAFgFAIgBIA8AAQAHABAFAFQAFAFAAAHQAAAHgFAFQgFAFgHABgAurn8QgIgBgFgFQgFgFAAgHQAAgHAFgFQAFgFAIgBIA7AAQAIABAFAFQAFAFAAAHQAAAHgFAFQgFAFgIABgAwkn8QgHgBgFgFQgFgFAAgHQAAgHAFgFQAFgFAHgBIA9AAQAHABAFAFQAFAFAAAHQAAAHgFAFQgFAFgHABg");
	this.shape.setTransform(311.1,154.5);

	this.text = new cjs.Text("Profesional \nexperto", "bold 22px 'Arial'");
	this.text.textAlign = "center";
	this.text.lineHeight = 24;
	this.text.lineWidth = 165;
	this.text.parent = this;
	this.text.setTransform(518.8,234.8);

	this.text_1 = new cjs.Text("Alto\nImpacto", "bold 22px 'Arial'");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 24;
	this.text_1.lineWidth = 165;
	this.text_1.parent = this;
	this.text_1.setTransform(518.8,131.4);

	this.text_2 = new cjs.Text("Futuro\nLíder", "bold 22px 'Arial'");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 24;
	this.text_2.lineWidth = 165;
	this.text_2.parent = this;
	this.text_2.setTransform(518.8,31.5);

	this.text_3 = new cjs.Text("Profesional \nefectivo", "bold 22px 'Arial'");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 24;
	this.text_3.lineWidth = 169;
	this.text_3.parent = this;
	this.text_3.setTransform(313,233);

	this.text_4 = new cjs.Text("Colaborador \nconsistente", "bold 22px 'Arial'");
	this.text_4.textAlign = "center";
	this.text_4.lineHeight = 24;
	this.text_4.lineWidth = 165;
	this.text_4.parent = this;
	this.text_4.setTransform(313,135);

	this.text_5 = new cjs.Text("Talento en \ncrecimiento", "bold 22px 'Arial'");
	this.text_5.textAlign = "center";
	this.text_5.lineHeight = 24;
	this.text_5.lineWidth = 165;
	this.text_5.parent = this;
	this.text_5.setTransform(313,31.5);

	this.text_6 = new cjs.Text("Bajo \ndesempeño", "bold 22px 'Arial'");
	this.text_6.textAlign = "center";
	this.text_6.lineHeight = 24;
	this.text_6.lineWidth = 165;
	this.text_6.parent = this;
	this.text_6.setTransform(104.7,242.1);

	this.text_7 = new cjs.Text("Desempeño inconsistente (Dilema)", "bold 22px 'Arial'");
	this.text_7.textAlign = "center";
	this.text_7.lineHeight = 24;
	this.text_7.lineWidth = 165;
	this.text_7.parent = this;
	this.text_7.setTransform(104.7,118.7);

	this.text_8 = new cjs.Text("Caso a revisar\n(Enigma)", "bold 22px 'Arial'");
	this.text_8.textAlign = "center";
	this.text_8.lineHeight = 24;
	this.text_8.lineWidth = 165;
	this.text_8.parent = this;
	this.text_8.setTransform(104.7,31.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#FFFFFF").p("AAE4BMAAAAwDIgHAAMAAAgwDg");
	this.shape_1.setTransform(207.8,155.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgDYBMAAAgwCIAHAAMAAAAwCg");
	this.shape_2.setTransform(207.8,155.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#FFFFFF").p("AAE4BMAAAAwDIgHAAMAAAgwDg");
	this.shape_3.setTransform(415.1,155.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgDYBMAAAgwCIAHAAMAAAAwCg");
	this.shape_4.setTransform(415.1,155.5);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#FFFFFF").p("EAwngADIAAAHMhhNAAAIAAgHg");
	this.shape_5.setTransform(311.5,104.2);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("EgwlAAEIAAgHMBhLAAAIAAAHg");
	this.shape_6.setTransform(311.5,104.2);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#FFFFFF").p("EAwngADIAAAHMhhNAAAIAAgHg");
	this.shape_7.setTransform(311.5,206.7);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("EgwlAAEIAAgHMBhLAAAIAAAHg");
	this.shape_8.setTransform(311.5,206.7);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#FFFFFF").p("AQJn8IAAP5MggRAAAIAAv5g");
	this.shape_9.setTransform(104.1,53);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#F1E2A8").s().p("AwIH9IAAv5MAgRAAAIAAP5g");
	this.shape_10.setTransform(104.1,53);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#FFFFFF").p("AQJn8IAAP5MggRAAAIAAv5g");
	this.shape_11.setTransform(311.5,258);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#F1E2A8").s().p("AwIH9IAAv5MAgRAAAIAAP5g");
	this.shape_12.setTransform(311.5,258);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#FFFFFF").p("AQJn8IAAP5MggRAAAIAAv5g");
	this.shape_13.setTransform(518.8,258);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#F1E2A8").s().p("AwIH9IAAv5MAgRAAAIAAP5g");
	this.shape_14.setTransform(518.8,258);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#FFFFFF").p("AQJn8IAAP5MggRAAAIAAv5g");
	this.shape_15.setTransform(104.1,155.5);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#E0878B").s().p("AwIH9IAAv5MAgRAAAIAAP5g");
	this.shape_16.setTransform(104.1,155.5);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#FFFFFF").p("AQJn8IAAP5MggRAAAIAAv5g");
	this.shape_17.setTransform(104.1,258);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#E0878B").s().p("AwIH9IAAv5MAgRAAAIAAP5g");
	this.shape_18.setTransform(104.1,258);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("#FFFFFF").p("AQJn8IAAP5MggRAAAIAAv5g");
	this.shape_19.setTransform(311.5,155.5);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#BED19D").s().p("AwIH9IAAv5MAgRAAAIAAP5g");
	this.shape_20.setTransform(311.5,155.5);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f().s("#FFFFFF").p("AQJn8IAAP5MggRAAAIAAv5g");
	this.shape_21.setTransform(311.5,53);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#A2D7E9").s().p("AwIH9IAAv5MAgRAAAIAAP5g");
	this.shape_22.setTransform(311.5,53);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f().s("#FFFFFF").p("AQJn8IAAP5MggRAAAIAAv5g");
	this.shape_23.setTransform(518.8,155.5);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#85C8DA").s().p("AwIH9IAAv5MAgRAAAIAAP5g");
	this.shape_24.setTransform(518.8,155.5);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f().s("#FFFFFF").p("AQJn8IAAP5MggRAAAIAAv5g");
	this.shape_25.setTransform(518.8,53);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#6CBACB").s().p("AwIH9IAAv5MAgRAAAIAAP5g");
	this.shape_26.setTransform(518.8,53);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f().s("#FFFFFF").p("EgwqgYEMAAAAwJMBhVAAAMAAAgwJgEAwjAX+MhhFAAAMAAAgv7MBhFAAAg");
	this.shape_27.setTransform(311.5,155.5);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#000000").s().p("EgwqAYFMAAAgwJMBhVAAAMAAAAwJgEgwiAX+MBhFAAAMAAAgv7MhhFAAAg");
	this.shape_28.setTransform(311.5,155.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.text_8},{t:this.text_7},{t:this.text_6},{t:this.text_5},{t:this.text_4},{t:this.text_3},{t:this.text_2},{t:this.text_1},{t:this.text},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.M03_TMR_TABLA4, new cjs.Rectangle(-1,0.4,624.9,318.5), null);


(lib.M03_TMR_TABanimultax = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#999999").s().p("AeqQQQgHgBgGgFQgFgFAAgHQAAgHAFgFQAGgFAHAAIA8AAQAHAAAFAFQAFAFAAAHQAAAHgFAFQgFAFgHABgAcyQQQgHgBgFgFQgGgFAAgHQAAgHAGgFQAFgFAHAAIA8AAQAHAAAFAFQAFAFAAAHQAAAHgFAFQgFAFgHABgAa6QQQgHgBgFgFQgGgFAAgHQAAgHAGgFQAFgFAHAAIA8AAQAHAAAFAFQAFAFAAAHQAAAHgFAFQgFAFgHABgAZCQQQgHgBgGgFQgFgFAAgHQAAgHAFgFQAGgFAHAAIA8AAQAHAAAFAFQAFAFAAAHQAAAHgFAFQgFAFgHABgAXKQQQgHgBgFgFQgGgFAAgHQAAgHAGgFQAFgFAHAAIA8AAQAHAAAFAFQAFAFAAAHQAAAHgFAFQgFAFgHABgAVSQQQgHgBgFgFQgGgFAAgHQAAgHAGgFQAFgFAHAAIA8AAQAHAAAFAFQAFAFAAAHQAAAHgFAFQgFAFgHABgATaQQQgHgBgGgFQgFgFAAgHQAAgHAFgFQAGgFAHAAIA8AAQAHAAAFAFQAFAFAAAHQAAAHgFAFQgFAFgHABgARiQQQgHgBgFgFQgGgFAAgHQAAgHAGgFQAFgFAHAAIA8AAQAHAAAFAFQAFAFAAAHQAAAHgFAFQgFAFgHABgAPqQQQgHgBgFgFQgGgFAAgHQAAgHAGgFQAFgFAHAAIA8AAQAHAAAFAFQAFAFAAAHQAAAHgFAFQgFAFgHABgANyQQQgHgBgGgFQgFgFAAgHQAAgHAFgFQAGgFAHAAIA8AAQAHAAAFAFQAFAFAAAHQAAAHgFAFQgFAFgHABgAL6QQQgHgBgFgFQgGgFAAgHQAAgHAGgFQAFgFAHAAIA8AAQAHAAAFAFQAFAFAAAHQAAAHgFAFQgFAFgHABgAKCQQQgHgBgFgFQgGgFAAgHQAAgHAGgFQAFgFAHAAIA8AAQAHAAAFAFQAFAFAAAHQAAAHgFAFQgFAFgHABgAIKQQQgHgBgGgFQgFgFAAgHQAAgHAFgFQAGgFAHAAIA8AAQAHAAAFAFQAFAFAAAHQAAAHgFAFQgFAFgHABgAGSQQQgHgBgFgFQgGgFAAgHQAAgHAGgFQAFgFAHAAIA8AAQAHAAAFAFQAFAFAAAHQAAAHgFAFQgFAFgHABgAEaQQQgHgBgFgFQgGgFAAgHQAAgHAGgFQAFgFAHAAIA8AAQAHAAAFAFQAFAFAAAHQAAAHgFAFQgFAFgHABgACiQQQgHgBgGgFQgFgFAAgHQAAgHAFgFQAGgFAHAAIA8AAQAHAAAFAFQAFAFAAAHQAAAHgFAFQgFAFgHABgAAqQQQgHgBgFgFQgGgFAAgHQAAgHAGgFQAFgFAHAAIA8AAQAHAAAFAFQAFAFAAAHQAAAHgFAFQgFAFgHABgEAgOAQCQgGgFAAgHIAAg8QAAgHAGgFQAFgFAHgBQAHABAFAFQAFAFAAAHIAAA8QAAAHgFAFQgFAFgHABQgHgBgFgFgAgVQBQgFgFAAgHIAAg8QAAgHAFgFQAFgFAHgBQAHABAFAFQAFAFAAAHIAAA8QAAAHgFAFQgFAFgHABQgHgBgFgFgEAgOAOKQgGgFAAgHIAAg8QAAgHAGgFQAFgFAHAAQAHAAAFAFQAFAFAAAHIAAA8QAAAHgFAFQgFAFgHAAQgHAAgFgFgAgVOJQgFgFAAgHIAAg8QAAgHAFgFQAFgFAHAAQAHAAAFAFQAFAFAAAHIAAA8QAAAHgFAFQgFAFgHAAQgHAAgFgFgEAgOAMSQgGgFAAgHIAAg8QAAgHAGgFQAFgFAHgBQAHABAFAFQAFAFAAAHIAAA8QAAAHgFAFQgFAFgHAAQgHAAgFgFgAgVMRQgFgFAAgHIAAg8QAAgHAFgFQAFgFAHgBQAHABAFAFQAFAFAAAHIAAA8QAAAHgFAFQgFAFgHABQgHgBgFgFgEAgOAKaQgGgFAAgHIAAg8QAAgHAGgFQAFgFAHgBQAHABAFAFQAFAFAAAHIAAA8QAAAHgFAFQgFAFgHABQgHgBgFgFgAgVKZQgFgFAAgHIAAg8QAAgHAFgFQAFgFAHgBQAHABAFAFQAFAFAAAHIAAA8QAAAHgFAFQgFAFgHABQgHgBgFgFgEAgOAIiQgGgFAAgHIAAg8QAAgHAGgFQAFgFAHAAQAHAAAFAFQAFAFAAAHIAAA8QAAAHgFAFQgFAFgHAAQgHAAgFgFgAgVIhQgFgFAAgHIAAg8QAAgHAFgFQAFgFAHAAQAHAAAFAFQAFAFAAAHIAAA8QAAAHgFAFQgFAFgHAAQgHAAgFgFgEAgOAGqQgGgFAAgHIAAg8QAAgHAGgFQAFgFAHgBQAHABAFAFQAFAFAAAHIAAA8QAAAHgFAFQgFAFgHAAQgHAAgFgFgAgVGpQgFgFAAgHIAAg8QAAgHAFgFQAFgFAHgBQAHABAFAFQAFAFAAAHIAAA8QAAAHgFAFQgFAFgHABQgHgBgFgFgEAgOAEyQgGgFAAgHIAAg8QAAgHAGgFIABgBIgBgBQgGgFAAgIIAAgeQAAgHAGgFQAFgFAHAAQAHAAAFAFQAFAFAAAHIAAAeQAAAIgFAFIgBABIABABQAFAFAAAHIAAA8QAAAHgFAFQgFAFgHABQgHgBgFgFgAgVExQgFgFAAgHIAAg7QAAgHAFgFIABgBIgBgBQgFgFAAgIIAAg8QAAgHAFgFQAFgFAHAAQAHAAAFAFQAFAFAAAHIAAA8QAAAIgFAFIgBABIABABQAFAFAAAHIAAA7QAAAHgFAFQgFAFgHABQgHgBgFgFgEAgOACBQgGgFAAgHIAAg8QAAgHAGgFQAFgFAHgBQAHABAFAFQAFAFAAAHIAAA8QAAAHgFAFQgFAFgHABQgHgBgFgFgAgVBkQgFgFAAgHIAAg9QAAgHAFgFQAFgFAHAAQAHAAAFAFQAFAFAAAHIAAA9QAAAHgFAFQgFAFgHAAQgHAAgFgFgAhvAbQgHAAgFgFQgFgFAAgHQAAgHAFgEQAFgFAHgBIA8AAQAHABAFAFQAGAEAAAHQAAAHgGAFQgFAFgHAAgAjnAbQgHAAgFgFQgFgFAAgHQAAgHAFgEQAFgFAHgBIA8AAQAHABAGAFQAFAEAAAHQAAAHgFAFQgGAFgHAAgAlfAbQgHAAgFgFQgFgFAAgHQAAgHAFgEQAFgFAHgBIA8AAQAHABAGAFQAFAEAAAHQAAAHgFAFQgGAFgHAAgAnXAbQgHAAgFgFQgFgFAAgHQAAgHAFgEQAFgFAHgBIA8AAQAHABAFAFQAGAEAAAHQAAAHgGAFQgFAFgHAAgApPAbQgHAAgFgFQgFgFAAgHQAAgHAFgEQAFgFAHgBIA8AAQAHABAGAFQAFAEAAAHQAAAHgFAFQgGAFgHAAgArHAbQgHAAgFgFQgFgFAAgHQAAgHAFgEQAFgFAHgBIA8AAQAHABAGAFQAFAEAAAHQAAAHgFAFQgGAFgHAAgAs/AbQgHAAgFgFQgFgFAAgHQAAgHAFgEQAFgFAHgBIA8AAQAHABAFAFQAGAEAAAHQAAAHgGAFQgFAFgHAAgAu3AbQgHAAgFgFQgFgFAAgHQAAgHAFgEQAFgFAHgBIA8AAQAHABAGAFQAFAEAAAHQAAAHgFAFQgGAFgHAAgAwvAbQgHAAgFgFQgFgFAAgHQAAgHAFgEQAFgFAHgBIA8AAQAHABAGAFQAFAEAAAHQAAAHgFAFQgGAFgHAAgAynAbQgHAAgFgFQgFgFAAgHQAAgHAFgEQAFgFAHgBIA8AAQAHABAFAFQAGAEAAAHQAAAHgGAFQgFAFgHAAgA0fAbQgHAAgFgFQgFgFAAgHQAAgHAFgEQAFgFAHgBIA8AAQAHABAGAFQAFAEAAAHQAAAHgFAFQgGAFgHAAgA2XAbQgHAAgFgFQgFgFAAgHQAAgHAFgEQAFgFAHgBIA8AAQAHABAGAFQAFAEAAAHQAAAHgFAFQgGAFgHAAgA4PAbQgHAAgFgFQgFgFAAgHQAAgHAFgEQAFgFAHgBIA8AAQAHABAFAFQAGAEAAAHQAAAHgGAFQgFAFgHAAgA6HAbQgHAAgFgFQgFgFAAgHQAAgHAFgEQAFgFAHgBIA8AAQAHABAGAFQAFAEAAAHQAAAHgFAFQgGAFgHAAgA7/AbQgHAAgFgFQgFgFAAgHQAAgHAFgEQAFgFAHgBIA8AAQAHABAGAFQAFAEAAAHQAAAHgFAFQgGAFgHAAgA93AbQgHAAgFgFQgFgFAAgHQAAgHAFgEQAFgFAHgBIA8AAQAHABAFAFQAGAEAAAHQAAAHgGAFQgFAFgHAAgA/vAbQgHAAgFgFQgFgFAAgHQAAgHAFgEQAFgFAHgBIA8AAQAHABAGAFQAFAEAAAHQAAAHgFAFQgGAFgHAAgEAgOAAJQgGgFAAgGIAAg8QAAgHAGgFQAFgFAHgBQAHABAFAFQAFAFAAAHIAAA8QAAAGgFAFQgFAFgHABQgHgBgFgFgEgglAADQgFgEAAgHIAAg8QAAgHAFgFQAFgFAHgBQAHABAGAFQAFAFAAAHIAAA8QAAAHgFAEQgGAFgHABQgHgBgFgFgEAgOgBuQgGgFAAgHIAAg8QAAgHAGgFQAFgFAHAAQAHAAAFAFQAFAFAAAHIAAA8QAAAHgFAFQgFAFgHAAQgHAAgFgFgEgglgB0QgFgFAAgHIAAg8QAAgHAFgFQAFgFAHgBQAHABAGAFQAFAFAAAHIAAA8QAAAHgFAFQgGAFgHABQgHgBgFgFgEAgOgDmQgGgFAAgHIAAg8QAAgHAGgFQAFgFAHgBQAHABAFAFQAFAFAAAHIAAA8QAAAHgFAFQgFAFgHABQgHgBgFgFgEgglgDsQgFgFAAgHIAAg8QAAgHAFgFQAFgFAHAAQAHAAAGAFQAFAFAAAHIAAA8QAAAHgFAFQgGAFgHAAQgHAAgFgFgEAgOgFeQgGgFAAgHIAAg8QAAgHAGgFQAFgFAHgBQAHABAFAFQAFAFAAAHIAAA8QAAAHgFAFQgFAFgHABQgHgBgFgFgEgglgFkQgFgFAAgHIAAg8QAAgHAFgFQAFgFAHgBQAHABAGAFQAFAFAAAHIAAA8QAAAHgFAFQgGAFgHABQgHgBgFgFgEAgOgHWQgGgFAAgHIAAg8QAAgHAGgFQAFgFAHAAQAHAAAFAFQAFAFAAAHIAAA8QAAAHgFAFQgFAFgHAAQgHAAgFgFgEgglgHcQgFgFAAgHIAAg8QAAgHAFgFQAFgFAHgBQAHABAGAFQAFAFAAAHIAAA8QAAAHgFAFQgGAFgHABQgHgBgFgFgEAgOgJOQgGgFAAgHIAAg8QAAgHAGgFQAFgFAHgBQAHABAFAFQAFAFAAAHIAAA8QAAAHgFAFQgFAFgHAAQgHAAgFgFgEgglgJUQgFgFAAgHIAAg8QAAgHAFgFQAFgFAHAAQAHAAAGAFQAFAFAAAHIAAA8QAAAHgFAFQgGAFgHAAQgHAAgFgFgEAgOgLGQgGgFAAgHIAAg8QAAgHAGgFQAFgFAHgBQAHABAFAFQAFAFAAAHIAAA8QAAAHgFAFQgFAFgHABQgHgBgFgFgEgglgLMQgFgFAAgHIAAg8QAAgHAFgFQAFgFAHgBQAHABAGAFQAFAFAAAHIAAA8QAAAHgFAFQgGAFgHAAQgHAAgFgFgEAgOgM+QgGgFAAgHIAAg8QAAgHAGgFQAFgFAHAAQAHAAAFAFQAFAFAAAHIAAA8QAAAHgFAFQgFAFgHAAQgHAAgFgFgEgglgNEQgFgFAAgHIAAg8QAAgHAFgFQAFgFAHgBQAHABAGAFQAFAFAAAHIAAA8QAAAHgFAFQgGAFgHABQgHgBgFgFgEAgOgO2QgGgFAAgHIAAg3IAAgEQAAgHAFgFQAFgFAHAAIABAAQAHAAAFAFQAFAFAAAHIAAA7QAAAHgFAFQgFAFgHAAQgHAAgFgFgEgglgO8QgFgFAAgHIAAg1QAAgHAFgFQAFgFAHAAIAHAAQAHAAAFAFQAGAFAAAHQAAAHgGAFIgBACIAAAnQAAAHgFAFQgGAFgHAAQgHAAgFgFgAehvsQgHAAgFgFQgFgFAAgHQAAgHAFgFQAFgFAHAAIA8AAQAHAAAGAFQAFAFAAAHQAAAHgFAFQgGAFgHAAgAcpvsQgHAAgFgFQgFgFAAgHQAAgHAFgFQAFgFAHAAIA8AAQAHAAAFAFQAGAFAAAHQAAAHgGAFQgFAFgHAAgAaxvsQgHAAgFgFQgFgFAAgHQAAgHAFgFQAFgFAHAAIA8AAQAHAAAFAFQAGAFAAAHQAAAHgGAFQgFAFgHAAgAY5vsQgHAAgFgFQgFgFAAgHQAAgHAFgFQAFgFAHAAIA8AAQAHAAAGAFQAFAFAAAHQAAAHgFAFQgGAFgHAAgAXBvsQgHAAgFgFQgFgFAAgHQAAgHAFgFQAFgFAHAAIA8AAQAHAAAFAFQAGAFAAAHQAAAHgGAFQgFAFgHAAgAVJvsQgHAAgFgFQgFgFAAgHQAAgHAFgFQAFgFAHAAIA8AAQAHAAAFAFQAGAFAAAHQAAAHgGAFQgFAFgHAAgATRvsQgHAAgFgFQgFgFAAgHQAAgHAFgFQAFgFAHAAIA8AAQAHAAAGAFQAFAFAAAHQAAAHgFAFQgGAFgHAAgARZvsQgHAAgFgFQgFgFAAgHQAAgHAFgFQAFgFAHAAIA8AAQAHAAAFAFQAGAFAAAHQAAAHgGAFQgFAFgHAAgAPhvsQgHAAgFgFQgFgFAAgHQAAgHAFgFQAFgFAHAAIA8AAQAHAAAFAFQAGAFAAAHQAAAHgGAFQgFAFgHAAgANpvsQgHAAgFgFQgFgFAAgHQAAgHAFgFQAFgFAHAAIA8AAQAHAAAGAFQAFAFAAAHQAAAHgFAFQgGAFgHAAgALxvsQgHAAgFgFQgFgFAAgHQAAgHAFgFQAFgFAHAAIA8AAQAHAAAFAFQAGAFAAAHQAAAHgGAFQgFAFgHAAgAJ5vsQgHAAgFgFQgFgFAAgHQAAgHAFgFQAFgFAHAAIA8AAQAHAAAFAFQAGAFAAAHQAAAHgGAFQgFAFgHAAgAIBvsQgHAAgFgFQgFgFAAgHQAAgHAFgFQAFgFAHAAIA8AAQAHAAAGAFQAFAFAAAHQAAAHgFAFQgGAFgHAAgAGJvsQgHAAgFgFQgFgFAAgHQAAgHAFgFQAFgFAHAAIA8AAQAHAAAFAFQAGAFAAAHQAAAHgGAFQgFAFgHAAgAERvsQgHAAgFgFQgFgFAAgHQAAgHAFgFQAFgFAHAAIA8AAQAHAAAFAFQAGAFAAAHQAAAHgGAFQgFAFgHAAgACZvsQgHAAgFgFQgFgFAAgHQAAgHAFgFQAFgFAHAAIA8AAQAHAAAGAFQAFAFAAAHQAAAHgFAFQgGAFgHAAgAAhvsQgHAAgFgFQgFgFAAgHQAAgHAFgFQAFgFAHAAIA8AAQAHAAAFAFQAGAFAAAHQAAAHgGAFQgFAFgHAAgAhWvsQgHAAgFgFQgFgFAAgHQAAgHAFgFQAFgFAHAAIA8AAQAHAAAFAFQAGAFAAAHQAAAHgGAFQgFAFgHAAgAjOvsQgHAAgFgFQgFgFAAgHQAAgHAFgFQAFgFAHAAIA8AAQAHAAAGAFQAFAFAAAHQAAAHgFAFQgGAFgHAAgAlGvsQgHAAgFgFQgFgFAAgHQAAgHAFgFQAFgFAHAAIA8AAQAHAAAFAFQAGAFAAAHQAAAHgGAFQgFAFgHAAgAm+vsQgHAAgFgFQgFgFAAgHQAAgHAFgFQAFgFAHAAIA8AAQAHAAAFAFQAGAFAAAHQAAAHgGAFQgFAFgHAAgAo2vsQgHAAgFgFQgFgFAAgHQAAgHAFgFQAFgFAHAAIA8AAQAHAAAGAFQAFAFAAAHQAAAHgFAFQgGAFgHAAgAquvsQgHAAgFgFQgFgFAAgHQAAgHAFgFQAFgFAHAAIA8AAQAHAAAFAFQAGAFAAAHQAAAHgGAFQgFAFgHAAgAsmvsQgHAAgFgFQgFgFAAgHQAAgHAFgFQAFgFAHAAIA8AAQAHAAAFAFQAGAFAAAHQAAAHgGAFQgFAFgHAAgAuevsQgHAAgFgFQgFgFAAgHQAAgHAFgFQAFgFAHAAIA8AAQAHAAAGAFQAFAFAAAHQAAAHgFAFQgGAFgHAAgAwWvsQgHAAgFgFQgFgFAAgHQAAgHAFgFQAFgFAHAAIA8AAQAHAAAFAFQAGAFAAAHQAAAHgGAFQgFAFgHAAgAyOvsQgHAAgFgFQgFgFAAgHQAAgHAFgFQAFgFAHAAIA8AAQAHAAAFAFQAGAFAAAHQAAAHgGAFQgFAFgHAAgA0GvsQgHAAgFgFQgFgFAAgHQAAgHAFgFQAFgFAHAAIA8AAQAHAAAGAFQAFAFAAAHQAAAHgFAFQgGAFgHAAgA1+vsQgHAAgFgFQgFgFAAgHQAAgHAFgFQAFgFAHAAIA8AAQAHAAAFAFQAGAFAAAHQAAAHgGAFQgFAFgHAAgA32vsQgHAAgFgFQgFgFAAgHQAAgHAFgFQAFgFAHAAIA8AAQAHAAAFAFQAGAFAAAHQAAAHgGAFQgFAFgHAAgA5uvsQgHAAgFgFQgFgFAAgHQAAgHAFgFQAFgFAHAAIA8AAQAHAAAGAFQAFAFAAAHQAAAHgFAFQgGAFgHAAgA7mvsQgHAAgFgFQgFgFAAgHQAAgHAFgFQAFgFAHAAIA8AAQAHAAAFAFQAGAFAAAHQAAAHgGAFQgFAFgHAAgA9evsQgHAAgFgFQgFgFAAgHQAAgHAFgFQAFgFAHAAIA8AAQAHAAAFAFQAGAFAAAHQAAAHgGAFQgFAFgHAAgA/WvsQgHAAgFgFQgFgFAAgHQAAgHAFgFQAFgFAHAAIA8AAQAHAAAGAFQAFAFAAAHQAAAHgFAFQgGAFgHAAg");
	this.shape.setTransform(416.6,105.8);

	this.text = new cjs.Text("Profesional \nexperto", "bold 22px 'Arial'");
	this.text.textAlign = "center";
	this.text.lineHeight = 24;
	this.text.lineWidth = 165;
	this.text.parent = this;
	this.text.setTransform(518.8,234.8);

	this.text_1 = new cjs.Text("Alto\nImpacto", "bold 22px 'Arial'");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 24;
	this.text_1.lineWidth = 165;
	this.text_1.parent = this;
	this.text_1.setTransform(518.8,131.4);

	this.text_2 = new cjs.Text("Futuro\nLíder", "bold 22px 'Arial'");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 24;
	this.text_2.lineWidth = 165;
	this.text_2.parent = this;
	this.text_2.setTransform(518.8,31.5);

	this.text_3 = new cjs.Text("Profesional \nefectivo", "bold 22px 'Arial'");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 24;
	this.text_3.lineWidth = 169;
	this.text_3.parent = this;
	this.text_3.setTransform(313,233);

	this.text_4 = new cjs.Text("Colaborador \nconsistente", "bold 22px 'Arial'");
	this.text_4.textAlign = "center";
	this.text_4.lineHeight = 24;
	this.text_4.lineWidth = 165;
	this.text_4.parent = this;
	this.text_4.setTransform(313,135);

	this.text_5 = new cjs.Text("Talento en \ncrecimiento", "bold 22px 'Arial'");
	this.text_5.textAlign = "center";
	this.text_5.lineHeight = 24;
	this.text_5.lineWidth = 165;
	this.text_5.parent = this;
	this.text_5.setTransform(313,31.5);

	this.text_6 = new cjs.Text("Bajo\nDesempeño ", "bold 22px 'Arial'");
	this.text_6.textAlign = "center";
	this.text_6.lineHeight = 24;
	this.text_6.lineWidth = 165;
	this.text_6.parent = this;
	this.text_6.setTransform(104.7,242.1);

	this.text_7 = new cjs.Text("Desempeño inconsistente (Dilema)", "bold 22px 'Arial'");
	this.text_7.textAlign = "center";
	this.text_7.lineHeight = 24;
	this.text_7.lineWidth = 165;
	this.text_7.parent = this;
	this.text_7.setTransform(104.7,118.7);

	this.text_8 = new cjs.Text("Caso a revisar\n(Enigma)", "bold 22px 'Arial'");
	this.text_8.textAlign = "center";
	this.text_8.lineHeight = 24;
	this.text_8.lineWidth = 165;
	this.text_8.parent = this;
	this.text_8.setTransform(104.7,31.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#FFFFFF").p("AAE4BMAAAAwDIgHAAMAAAgwDg");
	this.shape_1.setTransform(207.8,155.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgDYBMAAAgwCIAHAAMAAAAwCg");
	this.shape_2.setTransform(207.8,155.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#FFFFFF").p("AAE4BMAAAAwDIgHAAMAAAgwDg");
	this.shape_3.setTransform(415.1,155.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgDYBMAAAgwCIAHAAMAAAAwCg");
	this.shape_4.setTransform(415.1,155.5);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#FFFFFF").p("EAwngADIAAAHMhhNAAAIAAgHg");
	this.shape_5.setTransform(311.5,104.2);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("EgwlAAEIAAgHMBhLAAAIAAAHg");
	this.shape_6.setTransform(311.5,104.2);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#FFFFFF").p("EAwngADIAAAHMhhNAAAIAAgHg");
	this.shape_7.setTransform(311.5,206.7);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("EgwlAAEIAAgHMBhLAAAIAAAHg");
	this.shape_8.setTransform(311.5,206.7);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#FFFFFF").p("AQJn8IAAP5MggRAAAIAAv5g");
	this.shape_9.setTransform(104.1,53);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#F1E2A8").s().p("AwIH9IAAv5MAgRAAAIAAP5g");
	this.shape_10.setTransform(104.1,53);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#FFFFFF").p("AQJn8IAAP5MggRAAAIAAv5g");
	this.shape_11.setTransform(311.5,258);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#F1E2A8").s().p("AwIH9IAAv5MAgRAAAIAAP5g");
	this.shape_12.setTransform(311.5,258);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#FFFFFF").p("AQJn8IAAP5MggRAAAIAAv5g");
	this.shape_13.setTransform(518.8,258);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#F1E2A8").s().p("AwIH9IAAv5MAgRAAAIAAP5g");
	this.shape_14.setTransform(518.8,258);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#FFFFFF").p("AQJn8IAAP5MggRAAAIAAv5g");
	this.shape_15.setTransform(104.1,155.5);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#E0878B").s().p("AwIH9IAAv5MAgRAAAIAAP5g");
	this.shape_16.setTransform(104.1,155.5);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#FFFFFF").p("AQJn8IAAP5MggRAAAIAAv5g");
	this.shape_17.setTransform(104.1,258);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#E0878B").s().p("AwIH9IAAv5MAgRAAAIAAP5g");
	this.shape_18.setTransform(104.1,258);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("#FFFFFF").p("AQJn8IAAP5MggRAAAIAAv5g");
	this.shape_19.setTransform(311.5,155.5);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#BED19D").s().p("AwIH9IAAv5MAgRAAAIAAP5g");
	this.shape_20.setTransform(311.5,155.5);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f().s("#FFFFFF").p("AQJn8IAAP5MggRAAAIAAv5g");
	this.shape_21.setTransform(311.5,53);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#A2D7E9").s().p("AwIH9IAAv5MAgRAAAIAAP5g");
	this.shape_22.setTransform(311.5,53);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f().s("#FFFFFF").p("AQJn8IAAP5MggRAAAIAAv5g");
	this.shape_23.setTransform(518.8,155.5);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#85C8DA").s().p("AwIH9IAAv5MAgRAAAIAAP5g");
	this.shape_24.setTransform(518.8,155.5);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f().s("#FFFFFF").p("AQJn8IAAP5MggRAAAIAAv5g");
	this.shape_25.setTransform(518.8,53);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#6CBACB").s().p("AwIH9IAAv5MAgRAAAIAAP5g");
	this.shape_26.setTransform(518.8,53);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f().s("#FFFFFF").p("EgwqgYEMAAAAwJMBhVAAAMAAAgwJgEAwjAX+MhhFAAAMAAAgv7MBhFAAAg");
	this.shape_27.setTransform(311.5,155.5);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#000000").s().p("EgwqAYFMAAAgwJMBhVAAAMAAAAwJgEgwiAX+MBhFAAAMAAAgv7MhhFAAAg");
	this.shape_28.setTransform(311.5,155.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.text_8},{t:this.text_7},{t:this.text_6},{t:this.text_5},{t:this.text_4},{t:this.text_3},{t:this.text_2},{t:this.text_1},{t:this.text},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.M03_TMR_TABanimultax, new cjs.Rectangle(-1,0.4,626.7,318.5), null);


(lib.M03_TMR_BICI3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CFE1B5").s().p("EgENAhyQjtgWiWjXQiVjYAakaQAUjTBzikQBxigClg/QhChzgehCIiGkjQgqgig2hAQgigogkgjIgdgcQicgRi0gEQj2gGgUgCQiRgMhDgtQiDhYhLh6QgYgmgPgkIgKgdIghgqQglgbgVg9Qgqh8BRivIALgXIgcgMQAPg9AZg5QgigWgVgrQgYgvAFgwQABgEAGgKQAFgJABgHQABgHgThHQgQg6AUgWQgEgZAKgXIAWgpIAOgcQAIgSAFgIQAGgKAWgVQATgRAEgOQABgFgDgGQgDgFABgFIAfgdQASgQARgIQAGgBACAJQADALADABQAIgEAHgOQAHgPAGgEQAGAAATAHQANAFAKgJQgBgGgJgVQgHgPABgQQAHgTAYgEIAtgFQAOgDAUgOQAVgPAKgDQANAOAvgEQArgDAMAWIBLALQBYAFA/gfIAEANQAXgPAbgOQBmg1B/AIQA/AEArAPIBCAkQBLAqAuAkIAKgIIAJAPQAPgrAKgpIgDAEQgYgtgKhGQgViNBFiAQBJiHB1gwQBXgiBUASQAnAIBNA1IAKAFQAeADAVgCIgVATIALAIIAXASQAhAKAlACQAUABAMgCIgrAnIAUAQQAkAOArACQAWABAOgCIgsApQAmAcAvARQAOAFACADQADAEgGAJQgOAWiBA4QgDASgFANIhQCDIgGAJIABAJQAFADADgGQADgGgGgJQAOAOgDAHQgDAHgHALQgHAMgDAAQgCAAgFgCIgFgCIgCADQABAxgRBKQgBAGgFAGQgIAMgOgBQgMAAgPgJQgNgGgCACQgOAWgEALIgBADQgBAIgMAIIgGAEIAAAAQgGAIgFADQgMAKgLAGQAEABgHAFQgCACgKAZQgJAXgKAEQgRAHgKAAQgSAAgUgNIg8g7QgsgqgSAKQgUALgYBIQAgAuANAqQAHAagQBEQgKAogWBTQgTBWgCBEIA5gGQBCgGArgCQAvgDA6AiQA1AfAEAUQACAIgcgDQgvgFgLAAQgQABgQAJIgNAKIAcAUQAcAWgBANQgBAEgsgDQhOgGgVAAQglgBgyAPIgqAPIgFBJQgCBNANAaQAOAZCCgDQBBgCA/gHIAogSQArhMAagPIDniBIDMohIg9iaQgSgtAyjfQAhiYAahWQAIgWApgDQAqgDAMAXQAKAVgsCjQgWBRgYBOQAcBMAJgFQAIgFBKh4IA1gOIgtAcIhrEdIBaCLQBaCSAGAhQAGAhgMA7QgGAegHAXIAgAyICGBNIA5geQBCgbAvARQA8AWFVDFQA0AVA6AbQAVhTAUg/QAihoAQADQAtAHAdAkQAPAThsDaQD2B5CVCAQCVCBgfBDQgfBBjCgeQjAgej7hvQgkBGgTgEQgIgBgdADQgGAAgKgVQgHgOAfhIQjzh1iYh+QiYh/AQhHIg4gPIkFStIgBAOQAaAFAYARQAYARAQAaQAcAugGAxQgGAxglAXQgXAPgbgBQgGAFgHAFQglAXgtgPIgdAyQARgGALAAQAjACBXgQQBLgDAXA9QAVA0hKA7QhpBHg5AqQArBaARBkQASBogKBsQgaEbi6C4QilCkjQAAQgYAAgagCgAlJeeQBSAYBigEIg/m4gAiIeyQAsgDAhgHQAegGAEgGQAXgEAbgZIAYgYIgGAEIjvluIgDgBgAnucwIAUAZQAxA3BTAaIB2mkIgBAAgAA2djQA4g1AnhEIiyioIiUhBIAAAAgAn2clIEHkyIg1gLIkVDHIgDgEQAXA+AvA8gACabhQARgeAOgjIi7hTgApZY0QAEAaALAwQAEASAHATIEJi/IgcgFgAhgX1IBIBEIDVBdQANglAIgfIkohhgAhLXqIEgBeQAKgsAEgsIABgLIkTgjgAgzYtIg4g1QgWAFghAAIBvAwgApeXMQgCAwAGAuIEEhUQg6gUgrgWgAgwWwIEVArQADg4gGg0Ii/AXQgbAZgSAAIgngCgApcWjIgCAfICVgdQgagQgIgKQgIgKgBgOIhegTQgHAjgDAggABtUxQgrA2gTATICygVQgKhLgchGQgcAfgyA+gAhrV1QgKgjgKgaQgRgwAGghQhDBcACANQABAMAMAPIBTAKIAAAAgApQVWIBbARQABgSAIgPQAIgPAKgBQAUgCBvAhIi2iuQgvBQgUBfgAoISeIC3CvIACguIiBjNQgcAggcAsgAnJRKIB7DEQACgfAGg7Igoi2QgyAggpAsgAkPToIAJAcIBih4IhBhpgAlhP2IAkBrIASiFQgeAMgYAOgACDORQATAQAMAMIBOibIgDgDgAhYJwIgDAtQAFA8AnBJIAIARQA6ATA1AgIB+icQgKglAKgiQAKgiAbgSIAfiLQgNArghA8IgyBcQgXAvhbgjIhWgrgAgiE8QAaAZARATIANAFQARADAVgEQBBgNBHhVQA8hHBIgbIDEt5gAmLkhQhLAShVAMIhHAIIBqA+QBzBFAnAkQARAQAlBDQAVAlAnBKQAQAeAfAjQAlApAhATIARALQCfkgFwp6QgHAMgQAMQgfAWgtACQgvADhogEIhfgFIh/BTIgNAeQAbABADAVQAEAdgfBWQgOAmgeAUQgZASgoAGQgqBOgMAEQgWAHgXgGQgXgGgIgSQgEgIAQguQg7AAgkAIgAVVktQCSBBBqAiQBqAjAHgPQAGgPhhg5Qhig5iThDIgDAIQAxAYAeAWQAdAWgEAKQgEAJgjgIQgjgHgxgVgAPfoEQgHAOBWAzQBTAzCFA+IAJgRQgogVgXgTQgYgTAEgIQAEgJAfAGQAdAGAtARIAEgHQiJg8hfgeQhCgVgXAAQgLAAgCAEgAsNlxQgEgFgEgLQgHgUAAgZQALgqAIglQAPhKgOgzQgzACg8AGQh6ANgzAXQgTAJgJAUQgIATAEATQAJAzCYA5QBMAcBKASIAAAAgAL/q1QAggEAnACQgXgGgRgDIgMgBgACjrXIBVASQBaANAcgRQAlgXA0h2QA2h7gPguQgMgig+hUIg7hNgAthswIBNgCIAAg+g");
	this.shape.setTransform(197.6,216.4);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.M03_TMR_BICI3, new cjs.Rectangle(0,0,395.3,432.9), null);


(lib.indicador = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// Layer 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#00CC00").s().p("AgZBZQgGAAgEgDIgEgDIgpgvQgHgIgCgGQgDgGACgFQABgFACgCIABgDQAHgFAHABQAGAAAFADIAEADIAfAjIBhh1QAFgHAFgCQAEgBACABIACABQADADAAAEQAAAEgCADIgCADIhiCaQgIAFgGAAIgBAAg");
	this.shape.setTransform(16.1,16.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FF0000").s().p("AAAAdIhKBLIgdgeIBLhKIhLhJIAdgdIBKBKIBKhKIAdAdIhKBJIBKBKIgdAeg");
	this.shape_1.setTransform(15.5,15);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).wait(1));

	// Layer 1
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AhqBrQgsgsgBg/QABg+AsgsQAsgsA+gBQA/ABAsAsQAtAsAAA+QAAA/gtAsQgsAtg/AAQg+AAgsgtg");
	this.shape_2.setTransform(15.2,15.2);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,30.3,30.3);


(lib.imprimir = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgbA1IAAhmIAQAAIAAAPQAGgLAFgDQAEgEAGAAQAJAAAJAGIgGAQQgGgEgHAAQgGAAgDAEQgFADgCAGQgDAJAAALIAAA2g");
	this.shape.setTransform(92.5,17.8);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgIBIIAAhnIARAAIAABngAgIgyIAAgUIARAAIAAAUg");
	this.shape_1.setTransform(86.2,16);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AA1A1IAAhAQAAgLgCgFQgBgEgFgDQgEgDgGAAQgLAAgIAIQgHAGAAAQIAAA8IgQAAIAAhCQAAgMgFgGQgEgGgKAAQgHAAgGAEQgHAEgDAIQgCAHAAAOIAAA1IgSAAIAAhmIAQAAIAAAOQAFgIAIgEQAIgFAKAAQAMAAAHAFQAGAEADAJQANgSATAAQAQAAAIAIQAIAJAAASIAABGg");
	this.shape_2.setTransform(75.6,17.8);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgIBIIAAhnIARAAIAABngAgIgyIAAgUIARAAIAAAUg");
	this.shape_3.setTransform(65.1,16);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgbA1IAAhmIAQAAIAAAPQAGgLAFgDQAEgEAGAAQAJAAAJAGIgGAQQgGgEgHAAQgGAAgDAEQgFADgCAGQgDAJAAALIAAA2g");
	this.shape_4.setTransform(60.3,17.8);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgsBJIAAiOIAQAAIAAANQAGgIAHgEQAHgEAJAAQANAAALAHQAKAHAFAMQAFANAAAPQAAAQgGALQgFANgLAHQgLAHgMAAQgIAAgHgEQgGgEgFgFIAAAygAgTgvQgJAKAAAUQAAATAIAKQAJAJALAAQAKAAAJgKQAIgKAAgTQAAgUgIgKQgIgKgLAAQgLAAgIALg");
	this.shape_5.setTransform(50.9,19.8);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AA1A1IAAhAQAAgLgCgFQgBgEgFgDQgEgDgGAAQgLAAgIAIQgHAGAAAQIAAA8IgQAAIAAhCQAAgMgFgGQgEgGgKAAQgHAAgGAEQgHAEgDAIQgCAHAAAOIAAA1IgSAAIAAhmIAQAAIAAAOQAFgIAIgEQAIgFAKAAQAMAAAHAFQAGAEADAJQANgSATAAQAQAAAIAIQAIAJAAASIAABGg");
	this.shape_6.setTransform(36.8,17.8);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgIBIIAAiOIARAAIAACOg");
	this.shape_7.setTransform(25.7,16);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Layer 1
	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#FFFFFF").ss(1,1,1).p("AmyisINlAAQA+AAAsAsQAsAsAAA+IAAAtQAAA+gsAsQgsAsg+AAItlAAQg+AAgsgsQgsgsAAg+IAAgtQAAg+AsgsQAsgsA+AAg");
	this.shape_8.setTransform(58.5,17.3);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#D25558").s().p("AmyCsQg+ABgsgtQgsgsAAg9IAAgsQAAg/AsgrQAsgsA+gBINlAAQA+ABAsAsQAsArAAA/IAAAsQAAA9gsAsQgsAtg+gBg");
	this.shape_9.setTransform(58.5,17.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-4,-1,126,36.5);


(lib.iconoactividadesyretos = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgyEUIAAhpIBoAAIAABpgAgyCHIAAgZQAAguAPgeQAPgeAtgkQAuglAJgMQAOgSAAgWQAAgegYgWQgZgWgpAAQgnAAgbAXQgbAWgKAvIhggMQAEhDA1guQA1gvBVAAQBZAAA1AwQA2AvAAA+QAAAjgUAeQgTAfhBA1QggAcgJAQQgIARABArg");
	this.shape.setTransform(57.5,55.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#9AC9AC").s().p("Al/OEQivhKiHiIQiGiHhKiwQhMi2ABjIQAAjIBNi1QBKiwCJiGQCHiGCxhJQC3hMDJABQDHAACzBNQCvBLCFCIQCGCHBJCwQBMC2AADHQAADHhNC1QhKCviICHQiHCGiwBJQi3BMjHAAQjHAAi1hNg");
	this.shape_1.setTransform(56,55.2,0.49,0.49);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#EFEFEF").s().p("Am5QYQjMhXieidQididhWjNQhajTAAjnQAAjnBajTQBWjMCdidQCeieDMhWQDShZDnAAQDoAADSBZQDMBWCeCeQCeCdBVDMQBaDTAADnQAADnhaDTQhVDNieCdQieCdjMBXQjSBZjoAAQjnAAjShZg");
	this.shape_2.setTransform(55.7,55.7,0.49,0.49);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,111.4,111.4);


(lib.fondo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(227,239,185,0.698)").s().p("EhK3An3MAAAhPtMCVvAAAMAAABPtg");
	this.shape.setTransform(497.2,219.4);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(18,-35.6,958.3,510.2);


(lib.flechainstrucciones = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D73D45").s().p("ABFBsIhLhNIgYA4QgEAHgHAAQgIgBgCgHIg6i1QgCgHAEgFQAFgEAHACIC1A6QAHACABAIQAAAHgHAEIg3AYIBMBLQADADAAAFQAAAEgDAEIgXAXQgDADgFAAQgFAAgDgDg");
	this.shape.setTransform(8.1,9.1,0.784,0.784);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.5,0.5,17.4,17.4);


(lib.Group_17 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#6379B7").ss(0.5).p("AAAgTIABAn");
	this.shape.setTransform(0.4,2);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_17, new cjs.Rectangle(-0.7,-1,2.3,6.1), null);


(lib.Group_16 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#6379B7").ss(0.5).p("AAAgTIABAn");
	this.shape.setTransform(0.4,2);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_16, new cjs.Rectangle(-0.7,-1,2.3,5.9), null);


(lib.Group_15 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#6379B7").ss(0.5).p("AAAgRIABAj");
	this.shape.setTransform(0.4,1.8);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_15, new cjs.Rectangle(-0.7,-1,2.3,5.7), null);


(lib.Group_14 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#6379B7").ss(0.5).p("AAAgSIABAl");
	this.shape.setTransform(0.4,1.9);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_14, new cjs.Rectangle(-0.7,-0.9,2.2,5.8), null);


(lib.Group_13 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#6379B7").ss(0.5).p("AAAgSIABAl");
	this.shape.setTransform(0.4,1.9);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_13, new cjs.Rectangle(-0.7,-0.9,2.2,5.7), null);


(lib.Group_12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#6379B7").ss(0.5).p("AAAgRIABAj");
	this.shape.setTransform(0.4,1.8);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_12, new cjs.Rectangle(-0.7,-1,2.2,5.6), null);


(lib.Group_11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#6379B7").ss(0.5).p("AABgTIgBAn");
	this.shape.setTransform(0.4,2);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_11, new cjs.Rectangle(-0.7,-1,2.3,6.1), null);


(lib.Group_10 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#6379B7").ss(0.5).p("AABgTIgBAn");
	this.shape.setTransform(0.4,2);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_10, new cjs.Rectangle(-0.7,-1,2.3,5.9), null);


(lib.Group_9 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#6379B7").ss(0.5).p("AABgRIgBAj");
	this.shape.setTransform(0.4,1.8);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_9, new cjs.Rectangle(-0.7,-1,2.3,5.7), null);


(lib.Group_8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#6379B7").ss(0.5).p("AABgSIgBAl");
	this.shape.setTransform(0.4,1.9);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_8, new cjs.Rectangle(-0.7,-0.9,2.2,5.8), null);


(lib.Group_7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#6379B7").ss(0.5).p("AABgSIgBAl");
	this.shape.setTransform(0.4,1.9);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_7, new cjs.Rectangle(-0.7,-0.9,2.3,5.7), null);


(lib.Group_6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#6379B7").ss(0.5).p("AABgRIgBAj");
	this.shape.setTransform(0.4,1.8);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_6, new cjs.Rectangle(-0.7,-1,2.2,5.6), null);


(lib.Group_5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#6379B7").ss(0.5).p("AAFgOIgJAd");
	this.shape.setTransform(0.7,1.6);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_5, new cjs.Rectangle(-0.7,-0.9,3,5.1), null);


(lib.Group_4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#6379B7").ss(0.5).p("AgDALIAHgV");
	this.shape.setTransform(0.6,1.2);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_4, new cjs.Rectangle(-0.7,-0.9,2.8,4.3), null);


(lib.Group_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#6379B7").ss(0.5).p("AgHgNQAKAHADAY");
	this.shape.setTransform(0.9,1.6);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_3, new cjs.Rectangle(-0.9,-0.8,3.5,5.2), null);


(lib.Group_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#6379B7").ss(0.5).p("AAIgNQgIAGgFAZ");
	this.shape.setTransform(0.9,1.6);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_2, new cjs.Rectangle(-0.7,-0.8,3.5,5.2), null);


(lib.Group_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#6379B7").ss(0.5).p("AgCgHIAFAP");
	this.shape.setTransform(0.5,0.9);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_1, new cjs.Rectangle(-0.7,-0.9,2.6,3.7), null);


(lib.Group = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#6379B7").ss(0.5).p("AAFAOIgJgb");
	this.shape.setTransform(0.7,1.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group, new cjs.Rectangle(-0.8,-0.9,3.1,4.8), null);


(lib.ClipGroup_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AAiBHIAHgWQAEgMAAgKQABgOgFgLQgEgJgKgKQgEgDgQgKQgMgIgEgIIgYAZQgHALgCANQgBANACAOIAIAbIADAEQAAABAAAAQAAAAAAABQgBAAAAAAQAAAAAAAAIAAgBIgBAAIgBgCIgHgLQgEgHgBgGIgFgmQgDgRADgMQADgMAKgLIAJgIQAdgRAeAQQALAGAHAVQADAJAAAIQAAAHgBAGIgCAOIACAPQABAJgCAGIgQAiIAAAAIAAgBg");
	mask.setTransform(5.3,7.2);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CC8D61").s().p("AAiBHIAHgWQAEgMAAgKQABgOgFgLQgEgJgKgKQgEgDgQgKQgMgIgEgIIgYAZQgHALgCANQgBANACAOIAIAbIADAEQAAABAAAAQAAAAAAABQgBAAAAAAQAAAAAAAAIAAgBIgBAAIgBgCIgHgLQgEgHgBgGIgFgmQgDgRADgMQADgMAKgLIAJgIQAdgRAeAQQALAGAHAVQADAJAAAIQAAAHgBAGIgCAOIACAPQABAJgCAGIgQAiIAAAAIAAgBg");
	this.shape.setTransform(5.3,7.2);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FBEC3F").s().p("AAiBHIAHgWQAEgMAAgKQABgOgFgLQgEgJgKgKQgEgDgQgKQgMgIgEgIIgYAZQgHALgCANQgBANACAOIAIAbIADAEQAAABAAAAQAAAAAAABQgBAAAAAAQAAAAAAAAIAAgBIgBAAIgBgCIgHgLQgEgHgBgGIgFgmQgDgRADgMQADgMAKgLIAJgIQAdgRAeAQQALAGAHAVQADAJAAAIQAAAHgBAGIgCAOIACAPQABAJgCAGIgQAiIAAAAIAAgBg");
	this.shape_1.setTransform(5.3,7.2);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_2, new cjs.Rectangle(0.1,0,10.5,14.4), null);


(lib.ClipGroup_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AggAHQAAgHAGgHQAHgIANgDQAKgCALAEQANAGAEAKQADAIgEAKIg7ACQgEgDAAgKg");
	mask.setTransform(3.3,1.9);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#C8885F").s().p("AggAHQAAgHAGgHQAHgIANgDQAKgCALAEQANAGAEAKQADAIgEAKIg7ACQgEgDAAgKg");
	this.shape.setTransform(3.3,1.9);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_1, new cjs.Rectangle(0,0,6.7,4), null);


(lib.Path_15 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#C9C9C9").s().p("AhEAnImUgMIAIhBIOpAJIgDBEg");
	this.shape.setTransform(47.3,3.9);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Path_15, new cjs.Rectangle(0,0,94.5,7.8), null);


(lib.Group_17_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#6379B7").ss(0.5).p("AgFhXQAFBPAFBg");
	this.shape_1.setTransform(0.8,8.8);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_17_1, new cjs.Rectangle(-0.7,-1,3.1,19.7), null);


(lib.Group_16_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#6379B7").ss(0.5).p("AgFhUQAFBMAFBe");
	this.shape_1.setTransform(0.8,8.5);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_16_1, new cjs.Rectangle(-0.7,-1,3.1,19.1), null);


(lib.Group_15_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#6379B7").ss(0.5).p("AgEhPQAEA0AFBr");
	this.shape_1.setTransform(0.8,8);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_15_1, new cjs.Rectangle(-0.7,-1,3.1,18), null);


(lib.Group_14_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#6379B7").ss(0.5).p("AgEhRQAFBRAEBT");
	this.shape_1.setTransform(0.8,8.3);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_14_1, new cjs.Rectangle(-0.7,-0.9,3.1,18.5), null);


(lib.Group_13_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#6379B7").ss(0.5).p("AgEhQQAEA3AFBq");
	this.shape_1.setTransform(0.7,8.2);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_13_1, new cjs.Rectangle(-0.7,-0.9,3,18.3), null);


(lib.Group_12_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#6379B7").ss(0.5).p("AgEhNQAGBmADA2");
	this.shape_1.setTransform(0.7,7.9);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_12_1, new cjs.Rectangle(-0.7,-0.9,3,17.7), null);


(lib.Group_11_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#6379B7").ss(0.5).p("AAGhXQgGBPgEBg");
	this.shape_1.setTransform(0.8,8.8);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_11_1, new cjs.Rectangle(-0.7,-1,3.1,19.7), null);


(lib.Group_10_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#6379B7").ss(0.5).p("AAFhUQgFBUgEBW");
	this.shape_1.setTransform(0.8,8.5);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_10_1, new cjs.Rectangle(-0.7,-1,3.1,19.1), null);


(lib.Group_9_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#6379B7").ss(0.5).p("AAFhPQgFBOgEBR");
	this.shape_1.setTransform(0.8,8);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_9_1, new cjs.Rectangle(-0.7,-1,3.1,18), null);


(lib.Group_8_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#6379B7").ss(0.5).p("AAFhRQgEA3gFBt");
	this.shape_1.setTransform(0.8,8.3);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_8_1, new cjs.Rectangle(-0.7,-0.9,3,18.5), null);


(lib.Group_7_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#6379B7").ss(0.5).p("AAFhQQgEA3gFBq");
	this.shape_1.setTransform(0.8,8.2);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_7_1, new cjs.Rectangle(-0.7,-0.9,3,18.3), null);


(lib.Group_6_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#6379B7").ss(0.5).p("AAFhNQgEA0gFBo");
	this.shape_1.setTransform(0.8,7.9);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_6_1, new cjs.Rectangle(-0.7,-0.9,3,17.7), null);


(lib.Group_5_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#6379B7").ss(0.5).p("AAVhBIgpCD");
	this.shape_1.setTransform(2.4,6.7);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_5_1, new cjs.Rectangle(-0.7,-0.9,6.2,15.2), null);


(lib.Group_4_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#6379B7").ss(0.5).p("AgPAyIAfhj");
	this.shape_1.setTransform(1.8,5);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_4_1, new cjs.Rectangle(-0.7,-0.9,5.2,12), null);


(lib.Group_3_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#6379B7").ss(0.5).p("AgfhCQAbARAQAuQAKAbAIAw");
	this.shape_1.setTransform(3.4,6.9);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_3_1, new cjs.Rectangle(-0.8,-0.8,8.2,15.9), null);


(lib.Group_2_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#6379B7").ss(0.5).p("AAghCQgbARgQAuQgKAbgIAw");
	this.shape_1.setTransform(3.2,6.9);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_2_1, new cjs.Rectangle(-0.7,-0.8,8.2,15.9), null);


(lib.Group_1_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#6379B7").ss(0.5).p("AgMgkIAZBJ");
	this.shape_1.setTransform(1.5,3.8);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_1_1, new cjs.Rectangle(-0.7,-0.9,4.5,9.3), null);


(lib.Group_18 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#6379B7").ss(0.5).p("AAWA+Igrh7");
	this.shape_1.setTransform(2.5,6.3);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_18, new cjs.Rectangle(-0.7,-0.9,6.5,14.5), null);


(lib.Group_17_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#6379B7").ss(0.5).p("AgFhpQAFBHAHCN");
	this.shape_2.setTransform(0.9,10.6);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_17_2, new cjs.Rectangle(-0.7,-1,3.3,23.3), null);


(lib.Group_16_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#6379B7").ss(0.5).p("AgFhmQAFBcAGBx");
	this.shape_2.setTransform(0.9,10.3);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_16_2, new cjs.Rectangle(-0.7,-0.9,3.3,22.6), null);


(lib.Group_15_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#6379B7").ss(0.5).p("AgFhfQAFBWAGBp");
	this.shape_2.setTransform(0.9,9.6);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_15_2, new cjs.Rectangle(-0.7,-0.9,3.3,21.2), null);


(lib.Group_14_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#6379B7").ss(0.5).p("AgFhiQAFBXAGBv");
	this.shape_2.setTransform(0.9,10);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_14_2, new cjs.Rectangle(-0.7,-0.9,3.3,21.9), null);


(lib.Group_13_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#6379B7").ss(0.5).p("AgFhhQAFBDAGCA");
	this.shape_2.setTransform(0.8,9.8);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_13_2, new cjs.Rectangle(-0.7,-1,3.2,21.6), null);


(lib.Group_12_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#6379B7").ss(0.5).p("AgFhdQAHBoAEBU");
	this.shape_2.setTransform(0.8,9.4);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_12_2, new cjs.Rectangle(-0.7,-1,3.2,20.9), null);


(lib.Group_11_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#6379B7").ss(0.5).p("AAHhpQgIB1gEBf");
	this.shape_2.setTransform(0.9,10.6);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_11_2, new cjs.Rectangle(-0.7,-1,3.3,23.3), null);


(lib.Group_10_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#6379B7").ss(0.5).p("AAGhmQgGBcgFBx");
	this.shape_2.setTransform(0.9,10.3);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_10_2, new cjs.Rectangle(-0.7,-0.9,3.3,22.6), null);


(lib.Group_9_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#6379B7").ss(0.5).p("AAGhfQgGBWgFBp");
	this.shape_2.setTransform(0.9,9.6);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_9_2, new cjs.Rectangle(-0.7,-0.9,3.3,21.2), null);


(lib.Group_8_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#6379B7").ss(0.5).p("AAGhiQgGBXgFBv");
	this.shape_2.setTransform(0.9,10);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_8_2, new cjs.Rectangle(-0.7,-0.9,3.3,21.9), null);


(lib.Group_7_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#6379B7").ss(0.5).p("AAGhhQgGBZgFBq");
	this.shape_2.setTransform(0.9,9.8);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_7_2, new cjs.Rectangle(-0.7,-1,3.3,21.6), null);


(lib.Group_6_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#6379B7").ss(0.5).p("AAGhdQgHBogEBU");
	this.shape_2.setTransform(0.8,9.4);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_6_2, new cjs.Rectangle(-0.7,-1,3.2,20.9), null);


(lib.Group_5_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#6379B7").ss(0.5).p("AAZhPIgxCf");
	this.shape_2.setTransform(2.8,8);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_5_2, new cjs.Rectangle(-0.7,-0.9,7.1,17.9), null);


(lib.Group_4_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#6379B7").ss(0.5).p("AgSA8IAlh3");
	this.shape_2.setTransform(2.1,6.1);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_4_2, new cjs.Rectangle(-0.7,-0.9,5.8,14), null);


(lib.Group_3_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#6379B7").ss(0.5).p("AglhRQAhAVATA3QAMAhAJA6");
	this.shape_2.setTransform(4,8.4);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_3_2, new cjs.Rectangle(-0.8,-0.8,9.5,18.8), null);


(lib.Group_2_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#6379B7").ss(0.5).p("AAmhRQghAVgTA3QgMAhgJA6");
	this.shape_2.setTransform(3.9,8.4);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_2_2, new cjs.Rectangle(-0.7,-0.8,9.5,18.8), null);


(lib.Group_1_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#6379B7").ss(0.5).p("AgOgrIAdBX");
	this.shape_2.setTransform(1.7,4.5);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_1_2, new cjs.Rectangle(-0.8,-0.9,5.1,10.8), null);


(lib.Group_19 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#6379B7").ss(0.5).p("AAbBLIg1iV");
	this.shape_2.setTransform(2.9,7.6);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_19, new cjs.Rectangle(-0.7,-0.9,7.4,17), null);


(lib.Path_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgKASQgIgEgCgJQgCgIAFgHQAEgJAJgBQAIgDAIAGQAHAEACAJQADAIgFAHQgFAJgJABIgFABQgFAAgFgEg");
	this.shape.setTransform(2.2,2.2);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Path_0, new cjs.Rectangle(0,0,4.4,4.4), null);


(lib.Path = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#C9E7F4").s().p("Ah9DKQhUg0gWhgQgWhfA0hUQA0hUBggWQBfgWBUA0QBUA0AWBgQAWBfg0BUQg1BUhfAWQgdAHgaAAQhBAAg7glg");
	this.shape.setTransform(23.8,23.8);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Path, new cjs.Rectangle(0,0,47.7,47.7), null);


(lib.Group_20 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AirBvQgRgBAAgQIABgZQAIhAAqgvQAsgxA+gOQBAgNA8AaQA8AbAhA5QAIANgPAHQgOAIgIgOQgdgwg2gWQg2gVg2APQg2AQgiAvQgiAtABA5QAAAQgPAAIgBAAg");
	this.shape_3.setTransform(18.9,11);

	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_20, new cjs.Rectangle(0,0,37.8,22.1), null);


(lib.Group_17_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#6379B7").ss(0.5).p("AgCgyIAFBl");
	this.shape_3.setTransform(0.6,5.1);

	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_17_3, new cjs.Rectangle(-0.7,-1,2.7,12.1), null);


(lib.Group_16_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#6379B7").ss(0.5).p("AgCgwIAFBh");
	this.shape_3.setTransform(0.6,5);

	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_16_3, new cjs.Rectangle(-0.7,-0.9,2.6,11.8), null);


(lib.Group_15_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#6379B7").ss(0.5).p("AgCgvQADAuACAs");
	this.shape_3.setTransform(0.6,4.8);

	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_15_3, new cjs.Rectangle(-0.7,-1,2.6,11.2), null);


(lib.Group_14_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#6379B7").ss(0.5).p("AgCgxQADAwACAu");
	this.shape_3.setTransform(0.6,5);

	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_14_3, new cjs.Rectangle(-0.7,-0.9,2.6,11.5), null);


(lib.Group_13_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#6379B7").ss(0.5).p("AgCguIAFBd");
	this.shape_3.setTransform(0.5,4.7);

	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_13_3, new cjs.Rectangle(-0.7,-1,2.6,11.3), null);


(lib.Group_12_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#6379B7").ss(0.5).p("AgCgsIAFBZ");
	this.shape_3.setTransform(0.6,4.5);

	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_12_3, new cjs.Rectangle(-0.7,-1,2.6,11), null);


(lib.Group_11_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#6379B7").ss(0.5).p("AADgvQgDAwgCA0");
	this.shape_3.setTransform(0.5,4.8);

	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_11_3, new cjs.Rectangle(-0.7,-1,2.6,12.1), null);


(lib.Group_10_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#6379B7").ss(0.5).p("AADgwQgDAwgCAx");
	this.shape_3.setTransform(0.5,4.9);

	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_10_3, new cjs.Rectangle(-0.7,-0.9,2.6,11.8), null);


(lib.Group_9_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#6379B7").ss(0.5).p("AADgvQgDAugCAs");
	this.shape_3.setTransform(0.5,4.8);

	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_9_3, new cjs.Rectangle(-0.7,-1,2.6,11.2), null);


(lib.Group_8_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#6379B7").ss(0.5).p("AADguIgFBd");
	this.shape_3.setTransform(0.6,4.8);

	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_8_3, new cjs.Rectangle(-0.7,-0.9,2.6,11.5), null);


(lib.Group_7_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#6379B7").ss(0.5).p("AADgtQgDAtgCAv");
	this.shape_3.setTransform(0.5,4.6);

	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_7_3, new cjs.Rectangle(-0.7,-1,2.6,11.3), null);


(lib.Group_6_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#6379B7").ss(0.5).p("AADgqQgDAegCA7");
	this.shape_3.setTransform(0.5,4.3);

	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_6_3, new cjs.Rectangle(-0.7,-1,2.6,11), null);


(lib.Group_5_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#6379B7").ss(0.5).p("AAMglIgXBL");
	this.shape_3.setTransform(1.4,3.9);

	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_5_3, new cjs.Rectangle(-0.7,-0.9,4.4,9.6), null);


(lib.Group_4_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#6379B7").ss(0.5).p("AgIAcIARg3");
	this.shape_3.setTransform(1.1,2.9);

	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_4_3, new cjs.Rectangle(-0.8,-0.9,3.8,7.7), null);


(lib.Group_3_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#6379B7").ss(0.5).p("AgSglQAZARAKA+");
	this.shape_3.setTransform(2,4);

	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_3_3, new cjs.Rectangle(-0.8,-0.8,5.6,10), null);


(lib.Group_2_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#6379B7").ss(0.5).p("AATglQgZARgKA+");
	this.shape_3.setTransform(1.9,4);

	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_2_3, new cjs.Rectangle(-0.7,-0.8,5.6,10), null);


(lib.Group_1_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#6379B7").ss(0.5).p("AgGgUIANAp");
	this.shape_3.setTransform(0.9,2.2);

	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_1_3, new cjs.Rectangle(-0.8,-0.9,3.5,6.2), null);


(lib.Group_21 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#6379B7").ss(0.5).p("AANAkIgZhH");
	this.shape_4.setTransform(1.5,3.6);

	this.timeline.addTween(cjs.Tween.get(this.shape_4).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_21, new cjs.Rectangle(-0.8,-0.9,4.6,9.1), null);


(lib.ClipGroup_10 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AgOAiIgjAEIArhjIA4AYIgrBjg");
	mask.setTransform(5,6.2);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#A7DAC8").ss(2).p("AgTAuIAnhb");
	this.shape.setTransform(3.3,5.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#A7DAC8").ss(2).p("AgSAvIAlhc");
	this.shape_1.setTransform(6.8,7);

	var maskedShapeInstanceList = [this.shape,this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_10, new cjs.Rectangle(0.3,0,9.5,12.5), null);


(lib.ClipGroup_9 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AgxglIA4gYIArBjIgjgEIgWAcg");
	mask.setTransform(5,6.2);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#A7DAC8").ss(2).p("AAUAuIgnhb");
	this.shape.setTransform(6.7,5.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#A7DAC8").ss(2).p("AATAvIglhc");
	this.shape_1.setTransform(3.1,7);

	var maskedShapeInstanceList = [this.shape,this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_9, new cjs.Rectangle(0.2,0,9.5,12.5), null);


(lib.ClipGroup_8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AgOAiIgjAEIArhjIA4AYIgrBjg");
	mask.setTransform(5,6.2);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#A7DAC8").ss(2).p("AgTAuIAnhb");
	this.shape.setTransform(3.3,5.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#A7DAC8").ss(2).p("AgSAvIAlhc");
	this.shape_1.setTransform(6.8,7);

	var maskedShapeInstanceList = [this.shape,this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_8, new cjs.Rectangle(0.3,0,9.5,12.5), null);


(lib.ClipGroup_7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AgxglIA4gYIArBjIgjgEIgWAcg");
	mask.setTransform(5,6.2);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#A7DAC8").ss(2).p("AAUAuIgnhb");
	this.shape.setTransform(6.7,5.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#A7DAC8").ss(2).p("AATAvIglhc");
	this.shape_1.setTransform(3.1,7);

	var maskedShapeInstanceList = [this.shape,this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_7, new cjs.Rectangle(0.2,0,9.5,12.5), null);


(lib.ClipGroup_6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AgOAiIgjAEIArhjIA4AYIgrBjg");
	mask.setTransform(5,6.2);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#A7DAC8").ss(2).p("AgTAuIAnhb");
	this.shape.setTransform(3.3,5.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#A7DAC8").ss(2).p("AgSAvIAlhc");
	this.shape_1.setTransform(6.8,7);

	var maskedShapeInstanceList = [this.shape,this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_6, new cjs.Rectangle(0.3,0,9.5,12.5), null);


(lib.ClipGroup_5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AgxglIA4gYIArBjIgjgEIgVAcg");
	mask.setTransform(5,6.2);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#A7DAC8").ss(2).p("AAUAuIgnhb");
	this.shape.setTransform(6.7,5.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#A7DAC8").ss(2).p("AATAvIglhc");
	this.shape_1.setTransform(3.1,7);

	var maskedShapeInstanceList = [this.shape,this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_5, new cjs.Rectangle(0.2,0,9.5,12.5), null);


(lib.ClipGroup_26 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhFAGIAAgLICLAAIAAALg");
	mask.setTransform(7.1,0.8);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#6278B9").ss(0.5).p("AhFgFICLAL");
	this.shape.setTransform(7.1,0.8);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_26, new cjs.Rectangle(0.1,0.2,14.1,1.2), null);


(lib.ClipGroup_25 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhUACIAAgDICpAAIAAADg");
	mask.setTransform(8.5,0.4);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#6278B9").ss(0.5).p("AhUABICpgB");
	this.shape.setTransform(8.5,0.4);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_25, new cjs.Rectangle(0,0.2,17.1,0.4), null);


(lib.ClipGroup_24 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhTAJIAAgRICnAAIAAARg");
	mask.setTransform(8.4,1.1);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#6278B9").ss(0.5).p("AhTAIICngQ");
	this.shape.setTransform(8.4,1.1);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_24, new cjs.Rectangle(0.1,0.2,16.8,1.8), null);


(lib.ClipGroup_23 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhPBlIAAjJICfAAIAADJg");
	mask.setTransform(8.1,10.1);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#6278B9").ss(0.5).p("AhSBjICfgUIhBi0");
	this.shape.setTransform(8.4,10.3);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_23, new cjs.Rectangle(0.1,0.1,16.1,20.2), null);


(lib.ClipGroup_22 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AgbBPIAAidIA2AAIAACdg");
	mask.setTransform(3,8);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#6278B9").ss(0.5).p("AgahOIA1Cd");
	this.shape.setTransform(3,8);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_22, new cjs.Rectangle(0.2,0.1,5.5,15.8), null);


(lib.ClipGroup_21 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AgZBCIAAiDIAzAAIAACDg");
	mask.setTransform(2.8,6.7);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#6278B9").ss(0.5).p("AgYhBIAxCD");
	this.shape.setTransform(2.8,6.7);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_21, new cjs.Rectangle(0.2,0.1,5.1,13.2), null);


(lib.ClipGroup_20 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AgTAxIAAhhIAnAAIAABhg");
	mask.setTransform(2.1,5);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#6278B9").ss(0.5).p("AgSgwIAlBh");
	this.shape.setTransform(2.1,5);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_20, new cjs.Rectangle(0.2,0.1,4,9.8), null);


(lib.ClipGroup_19 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AgNAjIAAhFIAbAAIAABFg");
	mask.setTransform(1.5,3.6);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#6278B9").ss(0.5).p("AgMgiIAZBF");
	this.shape.setTransform(1.5,3.6);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_19, new cjs.Rectangle(0.2,0.1,2.8,7.1), null);


(lib.ClipGroup_18 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AgOBIIAAiQIAdAAIAACQg");
	mask.setTransform(1.7,7.5);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#6278B9").ss(0.5).p("AAQhFQgJAFgHAUQgRApAGBO");
	this.shape.setTransform(1.6,7.2);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_18, new cjs.Rectangle(0.2,0.2,3.1,14.5), null);


(lib.ClipGroup_17 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AgOBIIAAiQIAdAAIAACQg");
	mask.setTransform(1.6,7.5);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#6278B9").ss(0.5).p("AgPhFQAJAFAHAUQARApgGBO");
	this.shape.setTransform(1.7,7.2);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_17, new cjs.Rectangle(0.1,0.2,3,14.5), null);


(lib.ClipGroup_16 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Ag0CXIAAktIBpAAIAAEtg");
	mask.setTransform(5.5,15.2);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#6278B9").ss(0.5).p("Ag0CXIBpkt");
	this.shape.setTransform(5.6,15.1);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_16, new cjs.Rectangle(0.2,0.1,10.7,30.2), null);


(lib.ClipGroup_15 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AgyCGIAAkLIBlAAIAAELg");
	mask.setTransform(5.3,13.5);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#6278B9").ss(0.5).p("AgyCGIBlkL");
	this.shape.setTransform(5.3,13.5);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_15, new cjs.Rectangle(0.2,0.1,10.3,26.9), null);


(lib.ClipGroup_14 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AgwB1IAAjqIBgAAIAADqg");
	mask.setTransform(5.1,11.9);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#6278B9").ss(0.5).p("AgvB1IBfjp");
	this.shape.setTransform(5.1,11.8);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_14, new cjs.Rectangle(0.2,0.1,9.7,23.5), null);


(lib.ClipGroup_13 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Ag1CnIAAlOIBqAAIAAFOg");
	mask.setTransform(5.6,16.9);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#6278B9").ss(0.5).p("Ag0CnIBplN");
	this.shape.setTransform(5.6,16.8);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_13, new cjs.Rectangle(0.2,0.1,10.7,33.5), null);


(lib.ClipGroup_12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Ag2CrIAAlVIBsAAIAAFVg");
	mask.setTransform(5.7,17.2);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#6278B9").ss(0.5).p("AA2iqIhrFV");
	this.shape.setTransform(5.6,17.2);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_12, new cjs.Rectangle(0.2,0.1,10.9,34.1), null);


(lib.ClipGroup_11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AgEDBIAAmBIAJAAIAAGBg");
	mask.setTransform(0.7,19.4);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#6278B9").ss(0.5).p("AAFjAQgFBDgCBRQgGCiALBL");
	this.shape.setTransform(0.7,19.4);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_11, new cjs.Rectangle(0.2,0.1,1.1,38.6), null);


(lib.ClipGroup_10_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("AgEDBIAAmBIAJAAIAAGBg");
	mask_1.setTransform(0.7,19.4);

	// Layer_3
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#6278B9").ss(0.5).p("AAFjAQgFBDgCBRQgFCiALBL");
	this.shape_2.setTransform(0.7,19.4);

	var maskedShapeInstanceList = [this.shape_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_10_1, new cjs.Rectangle(0.2,0.1,1.1,38.6), null);


(lib.ClipGroup_9_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("AgEDBIAAmBIAJAAIAAGBg");
	mask_1.setTransform(0.7,19.3);

	// Layer_3
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#6278B9").ss(0.5).p("AAFjAQgFBDgCBRQgFCiALBL");
	this.shape_2.setTransform(0.7,19.3);

	var maskedShapeInstanceList = [this.shape_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_9_1, new cjs.Rectangle(0.2,0,1,38.6), null);


(lib.ClipGroup_8_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("AgEC8IAAl3IAJAAIAAF3g");
	mask_1.setTransform(0.7,18.8);

	// Layer_3
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#6278B9").ss(0.5).p("AAFi7QgFBAgCBPQgGCdALBL");
	this.shape_2.setTransform(0.7,18.8);

	var maskedShapeInstanceList = [this.shape_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_8_1, new cjs.Rectangle(0.2,0,1.1,37.6), null);


(lib.ClipGroup_7_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("AgEDBIAAmBIAJAAIAAGBg");
	mask_1.setTransform(0.8,19.3);

	// Layer_3
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#6278B9").ss(0.5).p("AAFjAQgFBDgCBRQgFCiALBL");
	this.shape_2.setTransform(0.7,19.4);

	var maskedShapeInstanceList = [this.shape_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_7_1, new cjs.Rectangle(0.3,0,1,38.7), null);


(lib.ClipGroup_6_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("AgEDBIAAmBIAJAAIAAGBg");
	mask_1.setTransform(0.7,19.3);

	// Layer_3
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#6278B9").ss(0.5).p("AAFjAQgFBDgCBRQgFCjAKBK");
	this.shape_2.setTransform(0.7,19.3);

	var maskedShapeInstanceList = [this.shape_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_6_1, new cjs.Rectangle(0.2,0,1.1,38.7), null);


(lib.ClipGroup_5_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("AgEDBIAAmBIAJAAIAAGBg");
	mask_1.setTransform(0.7,19.4);

	// Layer_3
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#6278B9").ss(0.5).p("AgEjAQAEBDADBRQAFCigLBL");
	this.shape_2.setTransform(0.7,19.4);

	var maskedShapeInstanceList = [this.shape_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_5_1, new cjs.Rectangle(0.2,0.1,1,38.6), null);


(lib.ClipGroup_4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AgEDBIAAmBIAJAAIAAGBg");
	mask.setTransform(0.7,19.4);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#6278B9").ss(0.5).p("AgEjAQAEBDADBRQAGCigLBL");
	this.shape.setTransform(0.7,19.4);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_4, new cjs.Rectangle(0.2,0.1,1.1,38.6), null);


(lib.ClipGroup_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AgEDBIAAmBIAJAAIAAGBg");
	mask.setTransform(0.7,19.3);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#6278B9").ss(0.5).p("AgEjAQAEBDADBRQAFCigLBL");
	this.shape.setTransform(0.7,19.3);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_3, new cjs.Rectangle(0.2,0,1,38.6), null);


(lib.ClipGroup_2_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("AgEC8IAAl3IAJAAIAAF3g");
	mask_1.setTransform(0.7,18.8);

	// Layer_3
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#6278B9").ss(0.5).p("AgEi7QAEBAADBPQAGCdgLBL");
	this.shape_2.setTransform(0.7,18.8);

	var maskedShapeInstanceList = [this.shape_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_2_1, new cjs.Rectangle(0.2,0,1.1,37.6), null);


(lib.ClipGroup_1_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("AgEDBIAAmBIAJAAIAAGBg");
	mask_1.setTransform(0.7,19.3);

	// Layer_3
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#6278B9").ss(0.5).p("AgEjAQAEBDADBRQAGCigLBL");
	this.shape_1.setTransform(0.7,19.4);

	var maskedShapeInstanceList = [this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_1_1, new cjs.Rectangle(0.2,0,1.1,38.7), null);


(lib.ClipGroup_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AgEDBIAAmBIAJAAIAAGBg");
	mask.setTransform(0.7,19.3);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#6278B9").ss(0.5).p("AgEjAQAEBDADBRQAGCjgLBK");
	this.shape.setTransform(0.7,19.3);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_0, new cjs.Rectangle(0.2,0,1.1,38.7), null);


(lib.ClipGroup = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Ag6ARQgSgSgEgYQgGgcABgOQABgGACgCIAuAaQAQAKAhAaQAcAVACAAQAFgBAEhKIAfgBQADAhAAAiQgBBDgRAJIgCABQgPAAhtg7g");
	mask.setTransform(13.4,9.7);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFE5EE").s().p("AgcAwIAvhjIAKAEIgvBjg");
	this.shape.setTransform(2.9,5.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFE5EE").s().p("Ag6ARQgSgSgEgYQgGgcABgOQABgGACgCIAuAaQAQAKAhAaQAcAVACAAQAFgBAEhKIAfgBQADAhAAAiQgBBDgRAJIgCABQgPAAhtg7g");
	this.shape_1.setTransform(13.4,9.7);

	var maskedShapeInstanceList = [this.shape,this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Layer_1
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFE5EE").s().p("Ag6ARQgSgSgEgYQgGgcABgOQABgGACgCIAuAaQAQAKAhAaQAcAVACAAQAFgBAEhKIAfgBQADAhAAAiQgBBDgRAJIgCABQgPAAhtg7g");
	this.shape_2.setTransform(13.4,9.7);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup, new cjs.Rectangle(4.8,2.2,17.2,15.2), null);


(lib.ClipGroup_1_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	mask_2.graphics.p("AjYBcQgHgXABgWQACg3AngtQAzg5BRgPQBMgPBIAdQAmAQAdAZQAhAcAOAjQALAdgBAjQgCAhgNAgImQAJQgPgLgJgcg");
	mask_2.setTransform(22.3,13.1);

	// Layer_3
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#C9885B").s().p("AjYBcQgHgXABgWQACg3AngtQAzg5BRgPQBMgPBIAdQAmAQAdAZQAhAcAOAjQALAdgBAjQgCAhgNAgImQAJQgPgLgJgcg");
	this.shape_2.setTransform(22.3,13.1);

	var maskedShapeInstanceList = [this.shape_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_1_2, new cjs.Rectangle(0,0,44.6,26.3), null);


(lib.ClipGroup_27 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("ADiHfQAAgBAAAAQAAgBAAgBQgBAAABgBQAAAAAAAAQAHgbASgvQAUg0AGgVQAZhQAChHQAChdgehFQgdhFhEhBQgYgXhshBQhTgzggg4IgNANQgkAjgnArIgjAmQgVAXgMARQgwBEgLBfQgKBYAPBdQAJA0AUA5QAIAZATAwQAKAPAFALQACADgCAGQgCAFgDgFIgBgCQAAAAgBAAQAAAAAAAAQgBAAAAAAQAAAAgBgBIgHgPQgjgxgQgaQgcgtgFgoQgDgYgDgoIgGhBIgUh/QgTh1AThOQAWhTA/hFQAVgYAJgIQARgRARgJQDMhuDDBqQBIAnAtCLQAVBCACAyQABAlgKAxIgKAwQgFAdAAAWQABATAGAgIAIA0QAFA4gMArQgLAlgbAxQgTAigOAeQgNAhgUAqIgBABIgCgBg");
	mask_1.setTransform(35,48.1);

	// Layer_3
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#CD8D5D").s().p("ADiHfQAAgBAAAAQAAgBAAgBQgBAAABgBQAAAAAAAAQAHgbASgvQAUg0AGgVQAZhQAChHQAChdgehFQgdhFhEhBQgYgXhshBQhTgzggg4IgNANQgkAjgnArIgjAmQgVAXgMARQgwBEgLBfQgKBYAPBdQAJA0AUA5QAIAZATAwQAKAPAFALQACADgCAGQgCAFgDgFIgBgCQAAAAgBAAQAAAAAAAAQgBAAAAAAQAAAAgBgBIgHgPQgjgxgQgaQgcgtgFgoQgDgYgDgoIgGhBQgCgagHgmIgLg/QgTh1AThOQAWhTA/hFQAVgYAJgIQARgRARgJQDMhuDDBqQBIAnAtCLQAVBCACAyQABAlgKAxIgKAwQgFAdAAAWQABATAGAgIAIA0QAFA4gMArQgLAlgbAxQgTAigOAeQgNAhgUAqIgBABIgCgBg");
	this.shape_3.setTransform(35,48.1);

	var maskedShapeInstanceList = [this.shape_3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(1));

	// Layer_1
	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FCEE21").s().p("ADiHfQAAgBAAAAQAAgBAAgBQgBAAABgBQAAAAAAAAQAHgbASgvQAUg0AGgVQAZhQAChHQAChdgehFQgdhFhEhBQgYgXhshBQhTgzggg4IgNANQgkAjgnArIgjAmQgVAXgMARQgwBEgLBfQgKBYAPBdQAJA0AUA5QAIAZATAwQAKAPAFALQACADgCAGQgCAFgDgFIgBgCQAAAAgBAAQAAAAAAAAQgBAAAAAAQAAAAgBgBIgHgPQgjgxgQgaQgcgtgFgoQgDgYgDgoIgGhBIgUh/QgTh1AThOQAWhTA/hFQAVgYAJgIQARgRARgJQDMhuDDBqQBIAnAtCLQAVBCACAyQABAlgKAxIgKAwQgFAdAAAWQABATAGAgIAIA0QAFA4gMArQgLAlgbAxQgTAigOAeQgNAhgUAqIgBABIgCgBg");
	this.shape_4.setTransform(35,48.1);

	this.timeline.addTween(cjs.Tween.get(this.shape_4).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_27, new cjs.Rectangle(0.1,0.1,69.9,96.1), null);


(lib.circulo4g = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#8DC449").s().p("AAABVIgZAcIAAiQIglANIA+heIA/BeIglgOIAACRg");
	this.shape.setTransform(38.1,41.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FDC12D").s().p("AgWBHIAAhiIgeARIAAgdIA0gfIA1AfIAAAdIgegRIAABig");
	this.shape_1.setTransform(49.3,46.9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#996600").s().p("AgTB4IgHihIgmAAIBAhOIBBBOIgmAAIgHChg");
	this.shape_2.setTransform(54.7,34.7);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#6699FF").s().p("AgeBeIAAhnIgLARIgZAAIBChlIBDBlIgZAAIgLgRIAABng");
	this.shape_3.setTransform(66.4,41.3);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#637C14").s().p("Ag0ApQgHgLgBgNIAAgDQAAgWASgQQASgQAYAAQASAAAQAJIAGAEQAVARAAAYQAAAPgJAMg");
	this.shape_4.setTransform(32,74.7);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#637C14").s().p("AgnAkQgFgJgBgMIAAgDQAAgTANgOQAOgOASAAQAOAAAMAJIAEADQAQAPAAAUQAAAMgGAMg");
	this.shape_5.setTransform(76.3,75.2);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#598415").s().p("AgaBNQgIgZgBgkIAAgBQAAgdAHgYQAHgYAKgKQAFgEAGAAQAPAAALAbQAKAbAAAlQAAAkgJAag");
	this.shape_6.setTransform(27.3,71.1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#598415").s().p("AgVBMQgHgaAAgiIAAAAQAAgdAFgYQAFgYAJgJQAFgFAEAAQAMAAAJAbQAJAagBAmQABAkgIAYg");
	this.shape_7.setTransform(82.3,71.2);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#F5B22D").s().p("AgHAVIAAgVIgJAAIAQgUIASAUIgJAAIAAAVg");
	this.shape_8.setTransform(28.3,60.6);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#F5B22D").s().p("AgHAVIAAgVIgJAAIAQgUIASAUIgJAAIAAAVg");
	this.shape_9.setTransform(79.7,61.4);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#D25558").s().p("AgeAuQgGAAgDgEQgEgEgBgFIAAhAQABgGAEgEQADgFAGAAIA9AAQAGAAAEAFQADAEAAAGIAABAQAAAFgDAEQgEAEgGAAgAglgfIAABAQAAAGAHAAIA9AAQAHAAAAgGIAAhAQAAgHgHAAIg9AAQgHAAAAAHg");
	this.shape_10.setTransform(79.4,61.4);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgeArQgEAAgDgDQgDgDAAgFIAAhAQAAgEADgDQADgDAEAAIA9AAQAEAAADADQADADAAAEIAABAQAAAFgDADQgDADgEAAg");
	this.shape_11.setTransform(79.4,61.4);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#4A7186").s().p("AgeAvQgGgBgEgEQgDgEAAgGIAAg/QAAgGADgEQAEgFAGAAIA9AAQAGAAADAFQAEAEABAGIAAA/QgBAGgEAEQgDAEgGABgAglgfIAAA/QAAAHAHAAIA9AAQAGAAABgHIAAg/QgBgHgGAAIg9AAQgHAAAAAHg");
	this.shape_12.setTransform(28.3,60.6);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgeArQgEAAgDgDQgDgEAAgEIAAhAQAAgEADgDQADgDAEAAIA9AAQAEAAADADQADADAAAEIAABAQAAAEgDAEQgDADgEAAg");
	this.shape_13.setTransform(28.3,60.6);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgDBPIAAidIAIAAIAACdg");
	this.shape_14.setTransform(58.1,71.9);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgDBPIAAidIAHAAIAACdg");
	this.shape_15.setTransform(49.3,71.9);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#D25558").s().p("AjWBXQgJAAgHgHQgGgGgBgKIAAh/QABgJAGgHQAHgHAJAAIGsAAQAKAAAGAHQAIAHgBAJIAAB/QABAKgIAGQgGAHgKAAgAjchFQgCADAAADIAAB/QAAAEACACQACADAEAAIGsAAQAEAAACgDQADgCAAgEIAAh/QAAgDgDgDQgCgCgEAAImsAAQgEAAgCACg");
	this.shape_16.setTransform(53.5,47.3);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AjWBPQgGABgFgFQgEgEAAgHIAAh/QAAgGAEgFQAFgFAGABIGtAAQAGgBAFAFQAEAFAAAGIAAB/QAAAHgEAEQgFAFgGgBg");
	this.shape_17.setTransform(53.4,47.3);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("Ah+AFIAAgJID9AAIAAAJg");
	this.shape_18.setTransform(53.7,64);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("Ah8CkQgHAAAAgIIAAk4QAAgHAHAAID5AAQAHAAAAAHIAAE4QAAADgCADQgCACgDAAgAh8CcID5AAIAAk4Ij5AAg");
	this.shape_19.setTransform(53.7,64);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#66C2B0").s().p("Ah8CgQgBAAgBAAQAAAAgBgBQAAAAAAgBQAAgBAAAAIAAk4QAAgBAAgBQAAgBAAAAQABgBAAAAQABAAABAAID5AAQABAAABAAQAAAAABABQAAAAAAABQAAABAAABIAAE4QAAAAAAABQAAABAAAAQgBABAAAAQgBAAgBAAg");
	this.shape_20.setTransform(53.7,64);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#D5E5E6").s().p("AiQC+IAAl7IEhAAIAAF7g");
	this.shape_21.setTransform(53.5,63);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AhpAFIAAgJIDTAAIAAAJg");
	this.shape_22.setTransform(68.1,64);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AhqCNQgHAAAAgHIAAkLQAAgHAHAAIDVAAQADAAACACQACACAAADIAAELQAAAHgHAAgAhqCGIDVAAIAAkLIjVAAg");
	this.shape_23.setTransform(68.2,63.3);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#469F8E").s().p("AhqCKQgBAAgBgBQAAAAgBAAQAAgBgBAAQAAgBAAgBIAAkLQAAgBAAgBQABAAAAgBQABAAAAAAQABgBABAAIDVAAQABAAABABQAAAAABAAQAAABABAAQAAABAAABIAAELQAAABAAABQgBAAAAABQgBAAAAAAQgBABgBAAg");
	this.shape_24.setTransform(68.2,63.3);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#B73A3C").s().p("AiEAZQgEAAgEgDQgCgDAAgEIAAgdQAAgFACgCQAEgDAEAAIEKAAQAEAAACADQADADAAAEIAAAdQAAAEgDADQgCADgEAAg");
	this.shape_25.setTransform(68,44.4);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#C5D5D6").s().p("AiECuIAAlbIEJAAIAAFbg");
	this.shape_26.setTransform(68,61.4);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AhvAFIAAgJIDfAAIAAAJg");
	this.shape_27.setTransform(39.5,64);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AhqCNQgHAAAAgHIAAkLQgBgDADgCQACgCADAAIDVAAQADAAACACQACACAAADIAAELQAAAHgHAAgAhqCGIDVAAIAAkLIjVAAg");
	this.shape_28.setTransform(39,63.3);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#469F8E").s().p("AhqCKQgBAAgBgBQAAAAgBAAQAAgBAAAAQgBgBAAgBIAAkLQAAgBABgBQAAAAAAgBQABAAAAAAQABgBABAAIDVAAQABAAABABQAAAAABAAQAAABAAAAQABABAAABIAAELQAAABgBABQAAAAAAABQgBAAAAAAQgBABgBAAg");
	this.shape_29.setTransform(39,63.3);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#B73A3C").s().p("AiFAZQgDAAgDgDQgDgDAAgEIAAgdQAAgEADgDQADgDADAAIELAAQAEAAACADQADADAAAEIAAAdQAAAEgDADQgCADgEAAg");
	this.shape_30.setTransform(38.7,44.4);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#C5D5D6").s().p("AiFCuIAAlbIEKAAIAAFbg");
	this.shape_31.setTransform(38.8,61.4);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#637C14").s().p("AgnAkQgFgJgBgMIAAgDQAAgTANgOQAOgOASAAQAOAAAMAJIAEADQAQAPAAAUQAAAMgGAMg");
	this.shape_32.setTransform(25.4,75.2);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#B6E9B7").s().p("AmVBFQgPgegKghQCvg9C6gLQEBgPDzBZQgLAhgOAcg");
	this.shape_33.setTransform(53,66.1);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#B6E9B7").s().p("AjxA4QhrhDg5hyIMrAAQg5ByhrBDQhvBGiDAAQiCAAhvhGg");
	this.shape_34.setTransform(53,85.6);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#C1EAF8").s().p("AhFDdQi6ALivA/QgWhDAAhHQAAi7CFiEQCFiFC6AAQC8AACECFQCFCEAAC7QAABHgWBEQjzhakBAPg");
	this.shape_35.setTransform(53,37.3);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#FFFFFF").s().p("Al1F2QibibAAjbQAAjaCbibQCcibDZAAQDaAACcCbQCbCbAADaQAADbibCbQicCbjaAAQjZAAicibgAkJkJQhuBvAACaQAACcBuBuQBuBvCbAAQCbAABvhvQBuhuAAicQAAiahuhvQhvhuibAAQibAAhuBug");
	this.shape_36.setTransform(52.9,52.9);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#FFFFFF").s().p("Ak/FAQiFiEAAi8QAAi6CFiFQCEiFC7AAQC7AACFCFQCFCFAAC6QAAC8iFCEQiFCFi7AAQi7AAiEiFg");
	this.shape_37.setTransform(52.9,52.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.circulo4g, new cjs.Rectangle(0,0,105.8,105.8), null);


(lib.circulo3g = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(242,106,118,0.698)").s().p("AjSGrQiHhHABgdIAwhXIAOAMQAAgSgCgiIgCgfQgkgjgfg/Qg9h9AaiNQAciWBhhQQBGg6BVgJQAngEBYAbIALACQAdgGATgJIgOAYIANAEIAbALQAiAAAlgLQASgFALgFIgcAyIAXAJQAmACApgLQAVgFANgGIgdAzQAtAPAxACQAOABADACQAEADgCAKQgEAOgpApQgbAbgoAjIACAfIglCUIgDAKIADAIIADAAQADgBABgEQABgHgIgGQAFACAEAEQAIAFAAAFQgBAIgDAMQgEANgCABIgIAAIgFAAIgBADQAQAwAGBIIgBANQgFAOgNAEQgMADgRgDQgOgDgBADIgEAPQgCAMgBAJIAAAEQABAHgJALIgEAGQgDAKgEAEQgHANgKAJIABABQABABgDAFQgBACgCAaQgCAZgIAGQgNAMgLADQgQAGgXgHQgJgDgXgMIgqgWQg1gagOAOQgNANgDA1QgBAdgBA0IAGAFIgDA0QhEgfhDgkg");
	this.shape.setTransform(102.2,76.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AjSGrQiHhHABgdIAwhXIAOAMQAAgSgCgiIgCgfQgkgjgfg/Qg9h9AaiNQAciWBhhQQBGg6BVgJQAngEBYAbIALACQAdgGATgJIgOAYIANAEIAbALQAiAAAlgLQASgFALgFIgcAyIAXAJQAmACApgLQAVgFANgGIgdAzQAtAPAxACQAOABADACQAEADgCAKQgEAOgpApQgbAbgoAjIACAfIglCUIgDAKIADAIIADAAQADgBABgEQABgHgIgGQAFACAEAEQAIAFAAAFQgBAIgDAMQgEANgCABIgIAAIgFAAIgBADQAQAwAGBIIgBANQgFAOgNAEQgMADgRgDQgOgDgBADIgEAPQgCAMgBAJIAAAEQABAHgJALIgEAGQgDAKgEAEQgHANgKAJIABABQABABgDAFQgBACgCAaQgCAZgIAGQgNAMgLADQgQAGgXgHQgJgDgXgMIgqgWQg1gagOAOQgNANgDA1QgBAdgBA0IAGAFIgDA0QhEgfhDgkg");
	this.shape_1.setTransform(102.2,76.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#9AC9AC").s().p("AH2LmIvqgBQg4AAgOgOQgNgPAAg6IAA0dQAAg6ANgOQAOgOA5AAIPkAAQA6AAAOAOQAOAOAAA4IABUkQAAAtgSATQgSATgrAAIgDAAgAkaGIQgmAAgcAcQgbAcAAAlQABAjAaAcQAbAbAjACQAmABAdgbQAdgbABgmQABgmgcgcQgbgcglAAIgCAAgAgqG/IgJACQgWAJABAZQABAZAXAIIAJACQAkACBIAAIEPgBQAbAAAbgBIAKgCQAWgIABgZQABgZgVgJQgDgBgHgBQhugDhuAAQhuAAhtADgAm4ChQgJALADAOIAEAHQAyA+AgAZQAJAGAUgCQAUgCAJgIQBWhQBThdQADgDACgFQAHgUgRgOQgQgOgSALIgEADQgjAehvBqQgJAIgMgBQgMAAgHgJQgVgagSgOQgEgDgLAAQgOAAgKALgAgsCDQgFAAgHADQgUAMADAYQAEAZAXAFIAEAAQAsACBAAAIBsAAIAAgBIBzABQBDAAAwgCQAHgBAHgFQAQgLABgUQAAgUgRgLQgFgEgGAAIilgBQiUAAiKAEgAmwiaQgPAOAIASIACAEQAMAQAVAXIAkAlQARAUASgBQAQgBASgUIBVhXQAyg0AhglQACgBACgFQAIgTgQgOQgQgNgSAJIgGAEQgcAah3BzQgIAIgMgBQgMAAgHgKQgRgYgOgLIgGgEQgHgDgGAAQgLAAgKAJgAAOi8Ig3ACQgHABgFADQgUAKgBAXQAAAXAVAIQAFACADAAQDeAEDfgEIAJgCQAVgIAAgXQAAgYgVgJQgGgDgFAAIg3gDIiiABIhygBIg1AAgAmynUQgNARAMARQALAOAVAWIAhAjQATAWASgBQAQgCAUgVIBQhSQAyg0AdggIABAAQAOgSgOgSQgPgSgVAKIgJAGQggAchsBuQgIAIgLgBQgLgBgGgJQgUgdgNgKQgDgDgHgCQgFgCgFAAQgNAAgKAMgAgln4IgFAAQgYAEgDAbQgDAaAXAKQAHADAFAAIAzADQA1ABBpgCIBwABQBBAAAugDQAFAAAGgCQAWgKAAgYQAAgYgWgIIgKgCQhsgDhsAAQhtAAhsADg");
	this.shape_2.setTransform(57.2,43.3,0.383,0.383);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("An7NNQhZgBgsgrQgrgrAAhZIAA0+QAAhUAqgrQArgsBUAAQHggCIkACQCqABAACvIAAU3QAABagqAsQgsArhZABIn8ABIn8gBgAo5rXQgNAOAAA6IAAUdQAAA6ANAPQAOAOA4AAIPqABQAtAAATgTQASgTAAgtIgB0kQAAg4gOgOQgOgOg6AAIvlAAQg4AAgOAOg");
	this.shape_3.setTransform(57.2,43.3,0.383,0.383);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#9AC9AC").s().p("AnrSAQjghfisiuQisithejhQhhjpABkAQAAkABjjoQBfjhCuirQCuisDihdQDrhhEBABQD+AADnBjQDeBgCrCtQCrCtBeDhQBhDqAAD+QgBD/hiDoQhfDgitCsQitCrjiBeQjpBhkAABQj/gBjohigAoCtMQhUAAgrAsQgqArAABUIAAU+QAABZArAsQAsAqBZABQH7ACH9gCQBZgBArgrQArgsAAhaIAA03QAAiviqgBInLgBIo5ABg");
	this.shape_4.setTransform(57.2,43.3,0.383,0.383);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#E6E6E6").s().p("ACDZSQnQjkADhQIBzjFIBaiRQABgngbgcQikAoiqAAQkaAAkBhtQj5hpjAjAQjAjAhpj4QhtkAAAkbQAAkaBtkBQBpj4DAjAQDAjAD5hpQEBhtEaAAQG9AAFnEDQFhD8CSGXQAlgKA3ACQAcACAUADIgeBSQAfAAAIACQADABAUgDQBoAAB3gcQA8gPAmgOIg+CcIAbAJQBzAHB9ggQA/gPAngRIhYCSQCGAqCTAHQAsACAJAGQANAJgIAdQgMArh3B9QhtB0hcBMIACAeIAAAeIhxGlQAPAGAOAJQAYAQgBAPQgDAXgLApQgMAwgIACQgHADgQgEIgOgFQAvCJASDMIgEAkQgMAogoALQgjAJg1gJQgpgHgCAIIgNAqQgIAhgBAcIgCALQAFASgbAiIgNAQIAAABQg7BjgQAVQgEAGgGBLQgFBGgYASQgoAigfAKQgzAPhDgSQgfgJg8goQhHgxgjgXQiBhUgcA0QgRAdACBDQADB4gBAeIAkAxIAFEjQjphhjphzg");
	this.shape_5.setTransform(75.3,60.3,0.383,0.383);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.circulo3g, new cjs.Rectangle(3.6,-9.8,143.5,140.3), null);


(lib.circulo2instrucciones = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#ACAFA1").p("AB9AAQAAAzgkAlQglAlg0AAQgzAAgkglQglglAAgzQAAgzAlglQAkgkAzAAQA0AAAlAkQAkAlAAAzg");
	this.shape.setTransform(14,14);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.5,0.5,27,27);


(lib.circulo1instrucciones = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#B9BDAD").s().p("Ag/BAQgagbgBglQABglAagaQAbgbAkAAQAlAAAbAbQAbAagBAlQABAlgbAbQgbAbglgBQgkABgbgbg");
	this.shape.setTransform(104.6,9.1,0.895,0.895);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(96.5,1,16.2,16.2);


(lib.chpag2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#DDDDDD").ss(3,1,1).p("ABnAAQAAArgeAeQgeAegrAAQgqAAgegeQgegeAAgrQAAgqAegeQAegeAqAAQArAAAeAeQAeAeAAAqg");
	this.shape.setTransform(3.1,19);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AhIBJQgegeAAgrQAAgqAegeQAegeAqAAQArAAAeAeQAeAeAAAqQAAArgeAeQgeAegrAAQgqAAgegeg");
	this.shape_1.setTransform(3.1,19);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#DDDDDD").s().p("AhUBYQglgBgYgZQgZgZgBglQABgkAZgZQAYgZAlgBICoAAQAmABAZAZQAZAZAAAkQAAAlgZAZQgZAZgmABg");
	this.shape_2.setTransform(12.3,19.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#C7E0A3").ss(3,1,1).p("AhgAkQgGgRAAgTQAAgqAegeQAegeAqAAQArAAAeAeQAeAeAAAqQAAArgeAeQgeAegrAAQgqAAgegeQgKgKgHgMQgEgHgDgIg");
	this.shape_3.setTransform(17.1,19);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#339900").s().p("AhIBJQgKgKgHgMQgEgHgDgHQgGgSAAgTQAAgqAegeQAegeAqAAQArAAAeAeQAeAeAAAqQAAArgeAeQgeAegrAAQgqAAgegeg");
	this.shape_4.setTransform(17.1,19);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#C7E0A3").s().p("AhUBYQglgBgYgZQgZgZgBglQABgkAZgZQAYgZAlgBICoAAQAmABAZAZQAZAZAAAkQAAAlgZAZQgZAZgmABg");
	this.shape_5.setTransform(8.8,19.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-8.7,7.2,38.3,23.6);


(lib.ch14 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#DDDDDD").ss(3,1,1).p("ABnAAQAAArgeAeQgeAegrAAQgqAAgegeQgegeAAgrQAAgqAegeQAegeAqAAQArAAAeAeQAeAeAAAqg");
	this.shape.setTransform(3.1,19);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AhIBJQgegeAAgrQAAgqAegeQAegeAqAAQArAAAeAeQAeAeAAAqQAAArgeAeQgeAegrAAQgqAAgegeg");
	this.shape_1.setTransform(3.1,19);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#DDDDDD").s().p("AhUBYQglgBgYgZQgZgZgBglQABgkAZgZQAYgZAlgBICoAAQAmABAZAZQAZAZAAAkQAAAlgZAZQgZAZgmABg");
	this.shape_2.setTransform(12.3,19.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#C7E0A3").ss(3,1,1).p("AhgAkQgGgRAAgTQAAgqAegeQAegeAqAAQArAAAeAeQAeAeAAAqQAAArgeAeQgeAegrAAQgqAAgegeQgKgKgHgMQgEgHgDgIg");
	this.shape_3.setTransform(17.1,19);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#339900").s().p("AhIBJQgKgKgHgMQgEgHgDgHQgGgSAAgTQAAgqAegeQAegeAqAAQArAAAeAeQAeAeAAAqQAAArgeAeQgeAegrAAQgqAAgegeg");
	this.shape_4.setTransform(17.1,19);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#C7E0A3").s().p("AhUBYQglgBgYgZQgZgZgBglQABgkAZgZQAYgZAlgBICoAAQAmABAZAZQAZAZAAAkQAAAlgZAZQgZAZgmABg");
	this.shape_5.setTransform(8.8,19.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-8.7,7.2,38.3,23.6);


(lib.ch3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#DDDDDD").ss(3,1,1).p("ABnAAQAAArgeAeQgeAegrAAQgqAAgegeQgegeAAgrQAAgqAegeQAegeAqAAQArAAAeAeQAeAeAAAqg");
	this.shape.setTransform(3.1,19);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AhIBJQgegeAAgrQAAgqAegeQAegeAqAAQArAAAeAeQAeAeAAAqQAAArgeAeQgeAegrAAQgqAAgegeg");
	this.shape_1.setTransform(3.1,19);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#DDDDDD").s().p("AhUBYQglgBgYgZQgZgZgBglQABgkAZgZQAYgZAlgBICoAAQAmABAZAZQAZAZAAAkQAAAlgZAZQgZAZgmABg");
	this.shape_2.setTransform(12.3,19.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#C7E0A3").ss(3,1,1).p("AhgAkQgGgRAAgTQAAgqAegeQAegeAqAAQArAAAeAeQAeAeAAAqQAAArgeAeQgeAegrAAQgqAAgegeQgKgKgHgMQgEgHgDgIg");
	this.shape_3.setTransform(17.1,19);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#339900").s().p("AhIBJQgKgKgHgMQgEgHgDgHQgGgSAAgTQAAgqAegeQAegeAqAAQArAAAeAeQAeAeAAAqQAAArgeAeQgeAegrAAQgqAAgegeg");
	this.shape_4.setTransform(17.1,19);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#C7E0A3").s().p("AhUBYQglgBgYgZQgZgZgBglQABgkAZgZQAYgZAlgBICoAAQAmABAZAZQAZAZAAAkQAAAlgZAZQgZAZgmABg");
	this.shape_5.setTransform(8.8,19.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-8.7,7.2,38.3,23.6);


(lib.cajaatraslistoahora = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E6E6E6").s().p("AjeFUQh4AAAAh4IAAmdIKtAAIAAGdQAAB4h4AAgAlWjCIAAiRIKtAAIAACRg");
	this.shape.setTransform(34.3,34);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,68.6,68);


(lib.btn_terminar = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 2
	this.text = new cjs.Text("Terminar", "43px 'Arial'", "#FFFFFF");
	this.text.lineHeight = 50;
	this.text.parent = this;
	this.text.setTransform(56.9,5.7);

	this.timeline.addTween(cjs.Tween.get(this.text).wait(1));

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#009900").s().rr(-143.05,-30.45,286.1,60.9,14.3);
	this.shape.setTransform(143.1,30.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.btn_terminar, new cjs.Rectangle(0,0,286.1,60.9), null);


(lib.btn_reintentar = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 2
	this.text = new cjs.Text("Reintentar", "43px 'Arial'", "#FFFFFF");
	this.text.lineHeight = 50;
	this.text.parent = this;
	this.text.setTransform(49.6,5.7);

	this.timeline.addTween(cjs.Tween.get(this.text).wait(1));

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#990000").s().rr(-143.05,-30.45,286.1,60.9,14.3);
	this.shape.setTransform(143.1,30.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.btn_reintentar, new cjs.Rectangle(0,0,286.1,60.9), null);


(lib.area_respuesta8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// texto
	this.txt_pregunta = new cjs.Text("", "bold 12px 'Arial'");
	this.txt_pregunta.name = "txt_pregunta";
	this.txt_pregunta.lineHeight = 16;
	this.txt_pregunta.lineWidth = 255;
	this.txt_pregunta.parent = this;
	this.txt_pregunta.setTransform(-559.1,-10.9);

	this.txt_respuesta = new cjs.Text("", "12px 'Arial'", "#333333");
	this.txt_respuesta.name = "txt_respuesta";
	this.txt_respuesta.lineHeight = 15;
	this.txt_respuesta.lineWidth = 254;
	this.txt_respuesta.parent = this;
	this.txt_respuesta.setTransform(-558.2,69.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.txt_respuesta},{t:this.txt_pregunta}]},1).wait(1));

	// fondo
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFCC00").s().p("A0QOrQiiAAAAiiIAA4RQAAiiCiAAMAogAAAQCiAAAACiIAAYRQAACiiiAAg");
	this.shape.setTransform(-431.8,91.5,1,1.272);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1).to({_off:false},0).wait(1));

	// pestaña
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(69,69,69,0)").s().p("AjugLIAPjVIHPDdIngDkg");
	this.shape_1.setTransform(-271.1,35.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFCC00").s().p("AjugLIAPjVIHPDdInfDkg");
	this.shape_2.setTransform(-269.2,35.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1}]}).to({state:[{t:this.shape_2}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-295.2,13.2,48.1,45);


(lib.area_respuesta7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// texto
	this.txt_pregunta = new cjs.Text("", "bold 12px 'Arial'");
	this.txt_pregunta.name = "txt_pregunta";
	this.txt_pregunta.lineHeight = 16;
	this.txt_pregunta.lineWidth = 255;
	this.txt_pregunta.parent = this;
	this.txt_pregunta.setTransform(-563.8,-92.1);

	this.txt_respuesta = new cjs.Text("", "12px 'Arial'", "#333333");
	this.txt_respuesta.name = "txt_respuesta";
	this.txt_respuesta.lineHeight = 15;
	this.txt_respuesta.lineWidth = 254;
	this.txt_respuesta.parent = this;
	this.txt_respuesta.setTransform(-562.9,-26.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.txt_respuesta},{t:this.txt_pregunta}]},1).wait(1));

	// fondo
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFCC00").s().p("A0PODQiiAAAAiiIAA3CQAAiiCiAAMAogAAAQCiAAAACiIAAXCQAACiiiAAg");
	this.shape.setTransform(-436.1,9.9,1,1.328);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1).to({_off:false},0).wait(1));

	// pestaña
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(255,51,204,0)").s().p("AjugLIAPjVIHPDdIngDkg");
	this.shape_1.setTransform(-271.1,35.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFCC00").s().p("AjugLIAPjVIHQDdInhDkg");
	this.shape_2.setTransform(-272.3,35.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1}]}).to({state:[{t:this.shape_2}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-295.2,13.2,48.1,45);


(lib.area_respuesta6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// texto
	this.txt_pregunta = new cjs.Text("", "bold 12px 'Arial'");
	this.txt_pregunta.name = "txt_pregunta";
	this.txt_pregunta.lineHeight = 16;
	this.txt_pregunta.lineWidth = 255;
	this.txt_pregunta.parent = this;
	this.txt_pregunta.setTransform(-556.7,2);

	this.txt_respuesta = new cjs.Text("", "12px 'Arial'", "#333333");
	this.txt_respuesta.name = "txt_respuesta";
	this.txt_respuesta.lineHeight = 15;
	this.txt_respuesta.lineWidth = 254;
	this.txt_respuesta.parent = this;
	this.txt_respuesta.setTransform(-556.7,85.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.txt_respuesta},{t:this.txt_pregunta}]},1).wait(1));

	// fondo
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFCC00").s().p("A0QOsQiiAAAAiiIAA4TQAAiiCiAAMAogAAAQCiAAAACiIAAYTQAACiiiAAg");
	this.shape.setTransform(-431.8,111.2,1,1.272);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1).to({_off:false},0).wait(1));

	// pestaña
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(255,255,255,0)").s().p("AjugLIAPjVIHPDdInfDkg");
	this.shape_1.setTransform(-271.1,35.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFCC00").s().p("AjugLIAPjVIHPDdInfDkg");
	this.shape_2.setTransform(-269.2,35.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1}]}).to({state:[{t:this.shape_2}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-295.1,13.2,48.1,45);


(lib.area_respuesta4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// texto
	this.txt_respuesta = new cjs.Text("", "12px 'Arial'", "#333333");
	this.txt_respuesta.name = "txt_respuesta";
	this.txt_respuesta.lineHeight = 15;
	this.txt_respuesta.lineWidth = 254;
	this.txt_respuesta.parent = this;
	this.txt_respuesta.setTransform(19.1,-24.8);
	this.txt_respuesta._off = true;

	this.timeline.addTween(cjs.Tween.get(this.txt_respuesta).wait(1).to({_off:false},0).wait(1));

	// fondo
	this.txt_pregunta = new cjs.Text("", "bold 12px 'Arial'");
	this.txt_pregunta.name = "txt_pregunta";
	this.txt_pregunta.lineHeight = 16;
	this.txt_pregunta.lineWidth = 255;
	this.txt_pregunta.parent = this;
	this.txt_pregunta.setTransform(19.1,-116.1);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFCC00").s().p("A0PQQQihAAgBigIgBAAIAA7dQAAiiCiAAMAogAAAQCiAAAACiIAAWTIABAAIAAFIQAACiiiAAg");
	this.shape.setTransform(145.9,-23.5,1,1.149);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape},{t:this.txt_pregunta}]},1).wait(1));

	// pestaña
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(66,66,66,0)").s().p("AjwgDIHQjdIAPDVIACDsg");
	this.shape_1.setTransform(-16.8,35.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFCC00").s().p("AjwgDIHQjdIAPDVIACDsg");
	this.shape_2.setTransform(-16.8,34.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1}]}).to({state:[{t:this.shape_2}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-40.8,13.2,48.1,45);


(lib.area_respuesta3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// texto
	this.txt_respuesta = new cjs.Text("", "12px 'Arial'", "#333333");
	this.txt_respuesta.name = "txt_respuesta";
	this.txt_respuesta.lineHeight = 15;
	this.txt_respuesta.lineWidth = 254;
	this.txt_respuesta.parent = this;
	this.txt_respuesta.setTransform(19.1,34.7);
	this.txt_respuesta._off = true;

	this.timeline.addTween(cjs.Tween.get(this.txt_respuesta).wait(1).to({_off:false},0).wait(1));

	// fondo
	this.txt_pregunta = new cjs.Text("", "bold 12px 'Arial'");
	this.txt_pregunta.name = "txt_pregunta";
	this.txt_pregunta.lineHeight = 16;
	this.txt_pregunta.lineWidth = 255;
	this.txt_pregunta.parent = this;
	this.txt_pregunta.setTransform(19.1,-47);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFCC00").s().p("A0QOrQihAAgBiiIAA4RQABiiChAAMAogAAAQCiAAAACiIAAYRQAACiiiAAg");
	this.shape.setTransform(145.9,61.5,1,1.272);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape},{t:this.txt_pregunta}]},1).wait(1));

	// pestaña
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(255,255,255,0)").s().p("AjwgDIHQjdIAPDVIACDsg");
	this.shape_1.setTransform(-16.8,35.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFCC00").s().p("AjwgDIHQjdIAPDVIACDsg");
	this.shape_2.setTransform(-16.8,35.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1}]}).to({state:[{t:this.shape_2}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-40.8,13.2,48.1,45);


(lib.area_respuesta = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// texto
	this.txt_pregunta = new cjs.Text("", "bold 12px 'Arial'");
	this.txt_pregunta.name = "txt_pregunta";
	this.txt_pregunta.lineHeight = 16;
	this.txt_pregunta.lineWidth = 255;
	this.txt_pregunta.parent = this;
	this.txt_pregunta.setTransform(17.3,9.7);

	this.txt_respuesta = new cjs.Text("", "12px 'Arial'", "#333333");
	this.txt_respuesta.name = "txt_respuesta";
	this.txt_respuesta.lineHeight = 15;
	this.txt_respuesta.lineWidth = 254;
	this.txt_respuesta.parent = this;
	this.txt_respuesta.setTransform(19.1,92.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.txt_respuesta},{t:this.txt_pregunta}]},1).wait(1));

	// fondo
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFCC00").s().p("A0QN6QihAAgBiiIAA2vQABihChgBMAogAAAQCiABAAChIAAWvQAACiiiAAg");
	this.shape.setTransform(145.9,119.5,1,1.343);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1).to({_off:false},0).wait(1));

	// pestaña
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(255,255,255,0)").s().p("AjwgDIHQjdIAPDVIACDsg");
	this.shape_1.setTransform(-16.8,35.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFCC00").s().p("AjwgDIHQjdIAPDVIACDsg");
	this.shape_2.setTransform(-16.8,35.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1}]}).to({state:[{t:this.shape_2}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-40.8,13.2,48.1,45);


(lib.unodosanios = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.text = new cjs.Text("Aún necesita desarrollar algunas de las competencias requeridas en el siguiente nivel.", "8px 'Arial'", "#333333");
	this.text.textAlign = "center";
	this.text.lineHeight = 8;
	this.text.lineWidth = 53;
	this.text.parent = this;
	this.text.setTransform(70.6,56.2,2.067,2.067);

	this.text_1 = new cjs.Text("1 o 2 años", "bold 8px 'Arial'", "#FFFFFF");
	this.text_1.lineHeight = 10;
	this.text_1.lineWidth = 50;
	this.text_1.parent = this;
	this.text_1.setTransform(30.5,12.5,2.067,2.067);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FBB03B").s().p("ArDDUIAAiwQAAj3D3AAIOYAAQD5AAgBD3IAACwg");
	this.shape.setTransform(71.2,21.2);

	this.instance = new lib.cajaatraslistoahora("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(72.6,114.5,2.067,2.067,0,0,0,35.1,35);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance},{t:this.shape},{t:this.text_1},{t:this.text}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,142.1,201.5);


(lib.perfoles1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#87AE65").s().p("AACAkIAAgzQgGAHgLAEIAAgNQAFgBAHgGQAFgEADgHIALAAIAABHg");
	this.shape.setTransform(136.7,97.8,0.911,0.911);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#F9AF48").s().p("AgcAdQgMgMAAgRQAAgQAMgMQAMgMAQAAQARAAAMAMQAMAMAAAQQAAARgMAMQgMAMgRAAQgQAAgMgMg");
	this.shape_1.setTransform(137.4,97.8,0.911,0.911);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#EED264").s().p("AALBDQgIgDgDAAQgCAAgIADQgIADgDgBQgEgBgEgHQgFgIgDgBIgLgEQgHgCgCgDQgDgEABgHQAAgKgBgCIgGgKQgFgGAAgEQAAgDAFgGIAGgKQABgCAAgKQgBgHADgDQACgEAHgCQAJgCACgCQADgBAFgIQAEgGAEgCQADgBAIADQAIADACAAQADAAAIgDQAIgDADABQAEACAEAGQAFAIADABQACACAJACQAHACACAEQADADgBAHIABAMIAGAKQAFAGAAADQAAAEgFAGIgGAKIgBAMQABAHgDAEQgCADgHACIgLAEQgDABgFAIQgEAHgEABIgCAAIgJgCg");
	this.shape_2.setTransform(137.4,97.8,0.911,0.911);

	this.instance = new lib.ClipGroup_10();
	this.instance.parent = this;
	this.instance.setTransform(134,104.7,0.911,0.911,0,0,0,5.5,6.7);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#6CC1A4").s().p("AgNAiIgkAEIArhjIA4AYIgrBjg");
	this.shape_3.setTransform(133.7,105.2,0.911,0.911);

	this.instance_1 = new lib.ClipGroup_9();
	this.instance_1.parent = this;
	this.instance_1.setTransform(141.6,104.7,0.911,0.911,0,0,0,5.4,6.7);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#6CC1A4").s().p("AgxglIA4gYIArBjIgkgEIgUAcg");
	this.shape_4.setTransform(141.3,105.2,0.911,0.911);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#87AE65").s().p("AACAkIAAgzQgGAHgLAEIAAgNQAFgBAHgGQAFgEADgHIALAAIAABHg");
	this.shape_5.setTransform(90.3,97.8,0.911,0.911);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#F9AF48").s().p("AgcAdQgMgMAAgRQAAgQAMgMQAMgMAQAAQARAAAMAMQAMAMAAAQQAAARgMAMQgMAMgRAAQgQAAgMgMg");
	this.shape_6.setTransform(90.9,97.8,0.911,0.911);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#EED264").s().p("AALBDQgIgDgDAAQgCAAgIADQgIADgDgBQgEgBgEgHQgFgIgDgBIgLgEQgHgCgCgDQgDgEABgHQAAgKgBgCIgGgKQgFgGAAgEQAAgDAFgGIAGgKQABgCAAgKQgBgHADgDQACgEAHgCQAJgCACgCQADgBAFgIQAEgGAEgCQADgBAIADQAIADACAAQADAAAIgDQAIgDADABQAEACAEAGQAFAIADABQACACAJACQAHACACAEQADADgBAHIABAMIAGAKQAFAGAAADQAAAEgFAGIgGAKIgBAMQABAHgDAEQgCADgHACIgLAEQgDABgFAIQgEAHgEABIgCAAIgJgCg");
	this.shape_7.setTransform(90.9,97.8,0.911,0.911);

	this.instance_2 = new lib.ClipGroup_8();
	this.instance_2.parent = this;
	this.instance_2.setTransform(87.7,104.7,0.911,0.911,0,0,0,5.4,6.7);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#6CC1A4").s().p("AgOAiIgjAEIArhjIA4AYIgrBjg");
	this.shape_8.setTransform(87.2,105.2,0.911,0.911);

	this.instance_3 = new lib.ClipGroup_7();
	this.instance_3.parent = this;
	this.instance_3.setTransform(95.4,104.7,0.911,0.911,0,0,0,5.4,6.7);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#6CC1A4").s().p("AgxglIA4gYIArBjIgjgEIgWAcg");
	this.shape_9.setTransform(94.8,105.2,0.911,0.911);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#87AE65").s().p("AACAkIAAgzQgGAHgLAEIAAgNQAFgBAHgGQAFgEADgHIALAAIAABHg");
	this.shape_10.setTransform(44.7,97.8,0.911,0.911);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#F9AF48").s().p("AgcAdQgMgMAAgRQAAgQAMgMQAMgMAQAAQARAAAMAMQAMAMAAAQQAAARgMAMQgMAMgRAAQgQAAgMgMg");
	this.shape_11.setTransform(45.4,97.8,0.911,0.911);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#EED264").s().p("AALBDQgIgDgDAAQgCAAgIADQgIADgDgBQgEgBgEgHQgFgIgDgBIgLgEQgHgCgCgDQgDgEABgHQAAgKgBgCIgGgKQgFgGAAgEQAAgDAFgGIAGgKQABgCAAgKQgBgHADgDQACgEAHgCQAJgCACgCQADgBAFgIQAEgGAEgCQADgBAIADQAIADACAAQADAAAIgDQAIgDADABQAEACAEAGQAFAIADABQACACAJACQAHACACAEQADADgBAHIABAMIAGAKQAFAGAAADQAAAEgFAGIgGAKIgBAMQABAHgDAEQgCADgHACIgLAEQgDABgFAIQgEAHgEABIgCAAIgJgCg");
	this.shape_12.setTransform(45.4,97.8,0.911,0.911);

	this.instance_4 = new lib.ClipGroup_6();
	this.instance_4.parent = this;
	this.instance_4.setTransform(42,104.7,0.911,0.911,0,0,0,5.4,6.7);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#6CC1A4").s().p("AgOAiIgjAEIArhjIA4AYIgrBjg");
	this.shape_13.setTransform(41.6,105.2,0.911,0.911);

	this.instance_5 = new lib.ClipGroup_5();
	this.instance_5.parent = this;
	this.instance_5.setTransform(49.7,104.7,0.911,0.911,0,0,0,5.4,6.7);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#6CC1A4").s().p("AgxglIA4gYIArBjIgjgEIgVAcg");
	this.shape_14.setTransform(49.3,105.2,0.911,0.911);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#3F3231").s().p("Ah9BcIgJgCQgBAAgDgHQgFgQgHgrQgFgiAdgXQgDguAogTIgGAKQgHAMgCAJQAAAAAAAAQAAAAAAABQAAAAAAAAQAAAAAAAAIACAAQAPgRAagMQApgUA7gBQgWADgPAJQgBAAAAABQAAAAAAAAQAAAAAAABQAAAAAAABQAAAAAAAAQAAABABAAQAAAAABAAQAAAAAAAAQAZgDAZADQAmADAYAQQgHgCgKABIgBABQAAAAAAAAQAAAAAAABQAAAAABAAQAAAAAAAAQASAHAOAOQAVAUAAAdIgNgPIgBAAIAAABQAHAWgFAWQgBgGgIgHQgBAjgKAuQgKgBgGALIgFAMQABgQgBgUQgCgmgKgPQgagohIACIhDAJQgNAfgRASQgBAGgCAkIgCAiQgBgTgKgGg");
	this.shape_15.setTransform(137.8,65.1,0.911,0.911);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#3F3231").s().p("AAgAVQgGgBgEgEQgHgFAAgHIAAgCQgHgFgFABIgBAAQgEgBgIAFIAAACQAAAHgGAFQgFAEgGABIg1AAIgBAAQgJgEgEgFQgDgFABgEIAAgDIgQABIgCgJIATgDQAEgIAMgBIAAAAIAxAAQAOAAAFAKQAHgDAGAAQAIAAAGADQAHgKANAAIAwAAIABAAQALABAFAIIAOACIgBAGIgMADIAAADQAAAMgPAGIgBAAgAAXgKIAAAQIABAEQACADAFADIA5AAQAGgBAAgJIAAgPQgDgFgEAAIg5AAQgHABAAADgAhYgKIAAAQIABAEQACADAEADIA5AAQAGgBAAgJIAAgPQgBgFgGAAIg5AAQgGABAAADg");
	this.shape_16.setTransform(136.8,73.3,0.911,0.911);

	this.instance_6 = new lib.Group_21();
	this.instance_6.parent = this;
	this.instance_6.setTransform(155.1,97.1,0.911,0.911,0,0,0,1.8,4);
	this.instance_6.alpha = 0.391;

	this.instance_7 = new lib.Group_1_3();
	this.instance_7.parent = this;
	this.instance_7.setTransform(153.1,98.3,0.911,0.911,0,0,0,1.1,2.6);
	this.instance_7.alpha = 0.391;

	this.instance_8 = new lib.Group_2_3();
	this.instance_8.parent = this;
	this.instance_8.setTransform(152.9,96.8,0.911,0.911,0,0,0,2.2,4.8);
	this.instance_8.alpha = 0.391;

	this.instance_9 = new lib.Group_3_3();
	this.instance_9.parent = this;
	this.instance_9.setTransform(123.2,96.8,0.911,0.911,0,0,0,2.1,4.8);
	this.instance_9.alpha = 0.391;

	this.instance_10 = new lib.Group_4_3();
	this.instance_10.parent = this;
	this.instance_10.setTransform(122.3,97.8,0.911,0.911,0,0,0,1.2,3.2);
	this.instance_10.alpha = 0.391;

	this.instance_11 = new lib.Group_5_3();
	this.instance_11.parent = this;
	this.instance_11.setTransform(121.1,96.9,0.911,0.911,0,0,0,2,4.4);
	this.instance_11.alpha = 0.391;

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#A9B3BC").s().p("AgnAJIBAglIAOAcQgBALgUAKIgUAIg");
	this.shape_17.setTransform(141.1,92.2,0.911,0.911);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#A9B3BC").s().p("AgNAVQgZgOgBgKIAOgdIBBAuIgeATQgLgFgMgHg");
	this.shape_18.setTransform(133.8,91.7,0.911,0.911);

	this.instance_12 = new lib.Group_6_3();
	this.instance_12.parent = this;
	this.instance_12.setTransform(139.6,96.3,0.911,0.911,0,0,0,0.9,4.9);
	this.instance_12.alpha = 0.391;

	this.instance_13 = new lib.Group_7_3();
	this.instance_13.parent = this;
	this.instance_13.setTransform(142.3,96.3,0.911,0.911,0,0,0,1,5.4);
	this.instance_13.alpha = 0.391;

	this.instance_14 = new lib.Group_8_3();
	this.instance_14.parent = this;
	this.instance_14.setTransform(144.3,95.9,0.911,0.911,0,0,0,1,5);
	this.instance_14.alpha = 0.391;

	this.instance_15 = new lib.Group_9_3();
	this.instance_15.parent = this;
	this.instance_15.setTransform(150.9,96.3,0.911,0.911,0,0,0,0.9,5);
	this.instance_15.alpha = 0.391;

	this.instance_16 = new lib.Group_10_3();
	this.instance_16.parent = this;
	this.instance_16.setTransform(148.9,95.9,0.911,0.911,0,0,0,1,5.5);
	this.instance_16.alpha = 0.391;

	this.instance_17 = new lib.Group_11_3();
	this.instance_17.parent = this;
	this.instance_17.setTransform(146.4,95.8,0.911,0.911,0,0,0,1,5.5);
	this.instance_17.alpha = 0.391;

	this.instance_18 = new lib.Group_12_3();
	this.instance_18.parent = this;
	this.instance_18.setTransform(136.7,96.3,0.911,0.911,0,0,0,1.1,4.9);
	this.instance_18.alpha = 0.391;

	this.instance_19 = new lib.Group_13_3();
	this.instance_19.parent = this;
	this.instance_19.setTransform(134,96.3,0.911,0.911,0,0,0,1,5.4);
	this.instance_19.alpha = 0.391;

	this.instance_20 = new lib.Group_14_3();
	this.instance_20.parent = this;
	this.instance_20.setTransform(131.9,95.9,0.911,0.911,0,0,0,0.9,5);
	this.instance_20.alpha = 0.391;

	this.instance_21 = new lib.Group_15_3();
	this.instance_21.parent = this;
	this.instance_21.setTransform(125.4,96.3,0.911,0.911,0,0,0,0.7,5);
	this.instance_21.alpha = 0.391;

	this.instance_22 = new lib.Group_16_3();
	this.instance_22.parent = this;
	this.instance_22.setTransform(127.3,95.9,0.911,0.911,0,0,0,0.9,5.5);
	this.instance_22.alpha = 0.391;

	this.instance_23 = new lib.Group_17_3();
	this.instance_23.parent = this;
	this.instance_23.setTransform(129.8,95.8,0.911,0.911,0,0,0,0.9,5.5);
	this.instance_23.alpha = 0.391;

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#BBCACB").s().p("Ah0A+QAdhXAMgHQATgNApgHQATgEARgBQAkgMAhAUQAQAKAJAMIACBZg");
	this.shape_19.setTransform(128.3,96.6,0.911,0.911);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#CCD0D0").s().p("Ah4A+IAEhZIAZgWQAhgUAkAMIAlAFQApAHATANQAQAJAeBVg");
	this.shape_20.setTransform(147.2,96.6,0.911,0.911);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#E8AF93").s().p("AAQAAIgLgCIgDAAIgHABIgWAEQAEgDAJgDIAPgCIAFAAIAMACQAIAEACAFQgEgFgIgBg");
	this.shape_21.setTransform(131.9,72.2,0.911,0.911);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#E1BB93").s().p("AgUCbQgOgFgRgNQgjgYgUgiIgBgEIgBgWIgBAAQgDAAgDgCIgDgDIAAAAQgCgFgDgQIgEgbQgCgJAAgIQAAgHACgCQADgBAEAEQADACAAADIACgBQgEgSAAgVQAAgvAZgNIAbgUQAfgTAfAAIADAAIAAAAIABAAIABAAIAAAAIABAAIAAAAQAfgBAhAUQARAKAKAKIABAAQAYANAAAvQAAAVgEASIgBAEIADgDIAGgFQAEgDADABQAFADgEAUIgFAcQgDATgCACIAAABQgDAFgGAAIgBAAIgDAaQAAABAAAAQAAABAAAAQgBABAAAAQAAABAAAAQgKAPgQAQQgaAagcAPIgCAAQgGACgKABIgHAAQgKAAgKgDg");
	this.shape_22.setTransform(137.1,73.1,0.911,0.911);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#D6AE89").s().p("AgKA7QhVgDAVgVQATgTAJghIAFgfIApgJQAogGABAPQABAZAlBRQgdACgcAAIgggBg");
	this.shape_23.setTransform(137.4,87.5,0.911,0.911);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#C9C9C9").s().p("AgmBMIAWiXIAeApQAeAtgFAbIgHAmg");
	this.shape_24.setTransform(105.4,94.5,0.911,0.911);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#C9C9C9").s().p("AgdBGQgEgXgEgLQgMgoAgglQARgSARgKIAIAiQAHAlADAXIAGAtg");
	this.shape_25.setTransform(76.6,95.1,0.911,0.911);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#BBCACB").s().p("AgOAUQgXgOgCgKIAOgaIBBAoIggAVQgKgEgMgHg");
	this.shape_26.setTransform(87.3,87.1,0.911,0.911);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#BBCACB").s().p("AglAIIA9giIAOAaQgCAKgUAJIgSAIg");
	this.shape_27.setTransform(94.1,87.5,0.911,0.911);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#9D9393").s().p("AAdAaQgGgBgEgEQgHgHAAgJIAAgDQgGgFgFABIgBAAQgGgCgFAHIAAACQAAAJgGAHQgFAEgFABIgzAAIgBgBQgPgHAAgOIAAgFIgOACIgDgMIASgDQAFgJAKgCIAvAAQANAAAGAMQAGgEAGABQAHgBAGAEQAGgMAMAAIAvAAQAMACADAJIASADIgCAMIgOgCIAAAFQAAAOgOAHIgCABgAAagIIAAANQAAAGAFACIAsAAQAHgEAAgFIAAgNQAAgBgGgBIgtAAQgDgBgCAEgAhQgJIAAAOIABACQABADAEADIAsAAQAGgCAAgGIAAgNQgBgDgGAAIgsAAQgFABAAABg");
	this.shape_28.setTransform(90.2,68.7,0.911,0.911);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#71706F").s().p("ABqBBIgGgwQgCgIgGgJQgMgQgWABQgJAAgOAGQgpATgdgWIgBAAQgRgGgNABQgcADgFAdIgGAxQAAABAAAAQgBABAAAAQAAAAgBABQAAAAgBAAQAAAAgBAAQAAgBgBAAQAAAAAAgBQAAAAgBgBQgLhhAdgDQABAAAAAAQABAAAAAAQAAgBAAAAQAAgBAAAAIAHgIQAKgHAVgCQASgBAPgFQAOgGAKAAQBEgBAVAdIABACQAIAEAFAKQAJASgCAfIgCAnQAAABAAAAQgBABAAAAQAAAAgBABQAAAAgBAAQAAAAgBAAQAAgBgBAAQAAAAAAgBQAAAAgBgBg");
	this.shape_29.setTransform(90,60.6,0.911,0.911);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#EDAB86").s().p("AhEADIAjgEIARgBIAQAAQASAAARABIAiAEg");
	this.shape_30.setTransform(90.4,61.9,0.911,0.911);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#EDAB86").s().p("AhEADQARgDARgBIASAAIAQgBQARAAARABQASABARADg");
	this.shape_31.setTransform(90.3,63.4,0.911,0.911);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#F9BD9C").s().p("AgTCTQgNgFgRgMQghgXgTghIgBgDIAAgVIgBAAQgEAAgDgDIgCgCIAAAAIgFgUIgEgZQgCgJAAgHQAAgHADgCQACgBAEAEQABABAAAAQABAAAAABQABAAAAABQAAABAAAAIACAAIgCgMQgCgNAAgNQAAgtAYgLIAAAAIAZgTQAegSAdAAIAGAAQAdgBAfATQAQAJAKAKIABAAQAXALAAAtQAAAUgEASIgBAEIADgDQAIgIAEABQAEACgDAUIgEAbQgDASgCACIgBAAQgDAFgFAAIgBAAIgDAZIgBAEQgfAsgsAXIgCABQgLADgKAAQgKAAgKgDg");
	this.shape_32.setTransform(90.3,69.5,0.911,0.911);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#EDAB86").s().p("AgJA4QhSgDAVgUQASgSAIgfIAFgeIAngIQAmgFABANQABAYAjBNQgcACgaAAIgegBg");
	this.shape_33.setTransform(90.6,83.1,0.911,0.911);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#D6D8D8").s().p("Ai1BUIgBgYIAAg7QADgfAVgRQAVgQAigJQASgEANgBQA3gFA5gBQBAAAAQAGQAYAJAUAzQATAuAAApIgBAOg");
	this.shape_34.setTransform(91.5,93.9,0.911,0.911);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#7F795E").s().p("AgiAIIA4ggIANAYQgBAKgTAJIgRAGg");
	this.shape_35.setTransform(48.6,87.2,0.911,0.911);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#7F795E").s().p("AgMASQgVgNgCgIIANgZIA6AoIgbARIgVgLg");
	this.shape_36.setTransform(42.2,86.8,0.911,0.911);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#DAA675").s().p("ABmAiQgDgUgjAAQgtAEgVgBQgagBgYgSIgSgTQgLAogGAEQgEADgFAbIgFAaIgLgRQgMgRABgDQACgEACgLQACgPgDgLQgCgKAAgNQABgQAGgGIAAAAQgCgEAjgOQAngRAkgDQAmgDAvAbQAtAaABAVQABAWgEAaQgDAcgGABQgEABgGAJIgDAHQAIgSgFgfg");
	this.shape_37.setTransform(45,62,0.911,0.911);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#C4B98C").s().p("AhvBRQAnh+ANgJQAbgSA6gDQAggLAdARQAPAJAIALIACCCg");
	this.shape_38.setTransform(36.7,93.4,0.911,0.911);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#C4B98C").s().p("AhzBRIAFiCIAXgUQAdgRAgALIAgAEQAkAGARALQAJAGAQAlQAQAmAQA2g");
	this.shape_39.setTransform(54.6,93.4,0.911,0.911);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#F9BD9C").s().p("AgRCJQgMgFgQgLQgfgWgRgeIgBgDIgBgUIgBAAQgDAAgFgEIAAgBQgCgDgDgPIgDgXIgCgPQAAgHACgBQACgBAFADQAAABAAAAQABABAAAAQAAABAAAAQABABAAAAIACAAQgEgQAAgTQAAgqAWgKIABgBIAXgRQAcgRAbAAIAFAAQAcgBAdARQAPAJAJAJIAAABQAWAKAAAqQAAAMgCAMIgCALIAAAEIACgDQAIgIADACQAEACgDASIAAACIgEAXQgCAOgCAEIgBABQgDAEgFAAIgBAAIgCAYIgBADQgcApgrAWIgBABQgLADgKAAQgJAAgIgDg");
	this.shape_40.setTransform(45,70.4,0.911,0.911);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#EDAB86").s().p("AgIA0QhMgCATgTQAQgQAIgeIAFgcIAkgHQAkgFABAMQABAXAgBHQgaACgYAAIgcgBg");
	this.shape_41.setTransform(45.4,83.1,0.911,0.911);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#87AE65").s().p("AggA2QgIgFgJgQQgGgKgGgPQgDgIAEgEQAEgFAIgBQAFAAADAEIAHAKIAEAHIAVgYQAYgcAegMQAKgEAGABIABABIgEAEQgcAWgTAbQgOATgNAeIgCAEQgDAGgFAAQgDAAgEgDg");
	this.shape_42.setTransform(137.9,119,0.911,0.911);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#87AE65").s().p("AggA2QgIgFgJgQQgGgKgGgPQgDgIAEgEQAEgFAIgBQAFAAADAEIAHAKIAEAHIAVgYQAYgcAegMQAKgEAGABIABABIgEAEQgcAWgTAbQgOATgNAeIgCAEQgDAGgFAAQgDAAgEgDg");
	this.shape_43.setTransform(91.4,119,0.911,0.911);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#87AE65").s().p("AggA2QgIgFgJgQQgGgKgGgPQgDgIAEgEQAEgFAIgBQAEAAAEAEIAHAKIAEAHIAVgYQAYgcAegMQAKgEAGABIABABIgEAEQgcAWgTAbQgOATgNAeIgCAEQgDAGgFAAQgDAAgEgDg");
	this.shape_44.setTransform(46.8,119,0.911,0.911);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#DFE5DF").s().p("AlZM0QighEh8h7Qh6h7hEifQhGimAAi1QAAi0BGilQBEigB6h8QB8h6CghEQClhGC0AAQC1AACmBGQCfBEB7B6QB7B8BECgQBGClAAC0QAAC1hGCmQhECfh7B7Qh7B7ifBEQimBGi1AAQi0AAilhGg");
	this.shape_45.setTransform(91.8,90.3,0.911,0.911);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#EFEFEF").s().p("AmGOcQizhMiLiKQiLiMhMi0QhPi6AAjMQAAjLBPi6QBMi1CLiKQCLiLCzhMQC7hPDLAAQDMAAC6BPQC0BMCMCLQCKCKBMC1QBPC6AADLQAADMhPC6QhMC0iKCMQiMCKi0BMQi6BPjMAAQjLAAi7hPg");
	this.shape_46.setTransform(91.4,91.4,0.911,0.911);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.instance_23},{t:this.instance_22},{t:this.instance_21},{t:this.instance_20},{t:this.instance_19},{t:this.instance_18},{t:this.instance_17},{t:this.instance_16},{t:this.instance_15},{t:this.instance_14},{t:this.instance_13},{t:this.instance_12},{t:this.shape_18},{t:this.shape_17},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.instance_5},{t:this.shape_13},{t:this.instance_4},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.instance_3},{t:this.shape_8},{t:this.instance_2},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.instance_1},{t:this.shape_3},{t:this.instance},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,182.8,182.8);


(lib.nohaysucesor = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.text = new cjs.Text("No es factible que pueda desarrollar las competencias requeridas del puesto destino.", "8px 'Arial'", "#333333");
	this.text.textAlign = "center";
	this.text.lineHeight = 8;
	this.text.lineWidth = 53;
	this.text.parent = this;
	this.text.setTransform(70.7,56.2,2.067,2.067);

	this.text_1 = new cjs.Text("No hay sucesor", "bold 8px 'Arial'", "#FFFFFF");
	this.text_1.lineHeight = 10;
	this.text_1.lineWidth = 63;
	this.text_1.parent = this;
	this.text_1.setTransform(11.3,12.5,2.067,2.067);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF1D25").s().p("ArEDUIAAiwQAAj3D5AAIOYAAQD3AAABD3IAACwg");
	this.shape.setTransform(71,21.2);

	this.instance = new lib.cajaatraslistoahora("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(73,114.5,2.067,2.067,0,0,0,35.3,35);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance},{t:this.shape},{t:this.text_1},{t:this.text}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,146.6,201.5);


(lib.mc_retro_eval = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		var root = this;
		var preguntas = 7;
		
		root.txt_cal.text = root.parent.res/10;
		
		function activarReintentar() {
			root.reintentar.addEventListener("click", reintentar);
			root.reintentar.cursor = "pointer";
		}
		
		function reintentar() {
			root.parent.reiniciar();
		}
		
		for (var i = 1; i <= preguntas; i++) {
			//inicializar botones
			root['b' + i].n = i;
			root['b' + i].cursor = "pointer";
			root['b' + i].addEventListener("rollover", mostrar);
			root['b' + i].addEventListener("rollout", ocultar);
		
			//inicializar indicadores
			console.log(root.parent.resultados[i - 1]);
			if (root.parent.resultados[i - 1] == 0) {
				root['i' + i].gotoAndStop(2);
			}
		
		}
		
		function mostrar(m) { //listo
			var n = m.currentTarget.n;
			root["a" + n].gotoAndStop(1);
			root["a" + n].txt_pregunta.text = root.parent.preguntas[n - 1];
			root["a" + n].txt_respuesta.text = "La respuesta correcta es:\n " + root.parent.correctas[n - 1];
		}
		
		function ocultar(m) { //listo
			root["a" + m.currentTarget.n].gotoAndStop(0);
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 4
	this.terminar = new lib.btn_terminar();
	this.terminar.parent = this;
	this.terminar.setTransform(-193.6,102.3,0.521,0.521);

	this.reintentar = new lib.btn_reintentar();
	this.reintentar.parent = this;
	this.reintentar.setTransform(-193.6,162.2,0.521,0.521);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.reintentar},{t:this.terminar}]}).wait(1));

	// areas amarillas
	this.a5 = new lib.area_respuesta8();
	this.a5.parent = this;
	this.a5.setTransform(801.4,-8.1,1,1,0,0,0,145.8,119);

	this.a7 = new lib.area_respuesta7();
	this.a7.parent = this;
	this.a7.setTransform(800,192.4,1,1,0,0,0,145.8,119);

	this.a6 = new lib.area_respuesta6();
	this.a6.parent = this;
	this.a6.setTransform(804.8,88.9,1,1,0,0,0,145.8,119);

	this.a4 = new lib.area_respuesta4();
	this.a4.parent = this;
	this.a4.setTransform(437.4,237.9,1,1,0,0,0,145.8,119);

	this.a3 = new lib.area_respuesta3();
	this.a3.parent = this;
	this.a3.setTransform(437.4,137.8,1,1,0,0,0,145.8,119);

	this.a2 = new lib.area_respuesta();
	this.a2.parent = this;
	this.a2.setTransform(437.4,42.3,1,1,0,0,0,145.8,119);

	this.a1 = new lib.area_respuesta();
	this.a1.parent = this;
	this.a1.setTransform(436,-39.9,1,1,0,0,0,145.8,119);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.a1},{t:this.a2},{t:this.a3},{t:this.a4},{t:this.a6},{t:this.a7},{t:this.a5}]}).wait(1));

	// Botones
	this.i7 = new lib.indicador();
	this.i7.parent = this;
	this.i7.setTransform(586.1,108.5,1.139,1.139,0,0,0,15.2,15.2);

	this.i6 = new lib.indicador();
	this.i6.parent = this;
	this.i6.setTransform(592.4,3.9,1.139,1.139,0,0,0,15.2,15.1);

	this.i5 = new lib.indicador();
	this.i5.parent = this;
	this.i5.setTransform(592,-86.2,1.139,1.139,0,0,0,15.2,15.2);

	this.i4 = new lib.indicador();
	this.i4.parent = this;
	this.i4.setTransform(221.3,155.9,1.139,1.139,0,0,0,15.2,15.2);

	this.i3 = new lib.indicador();
	this.i3.parent = this;
	this.i3.setTransform(221.3,54,1.139,1.139,0,0,0,15.2,15.2);

	this.i2 = new lib.indicador();
	this.i2.parent = this;
	this.i2.setTransform(221.3,-41.6,1.139,1.139,0,0,0,15.2,15.2);

	this.i1 = new lib.indicador();
	this.i1.parent = this;
	this.i1.setTransform(221.3,-124.8,1.139,1.139,0,0,0,15.2,15.1);

	this.p7 = new cjs.Text("Pregunta 7", "bold 19px 'Arial'", "#333333");
	this.p7.name = "p7";
	this.p7.textAlign = "center";
	this.p7.lineHeight = 23;
	this.p7.lineWidth = 100;
	this.p7.parent = this;
	this.p7.setTransform(490.3,96.1,1.139,1.139);

	this.p6 = new cjs.Text("Pregunta 6", "bold 19px 'Arial'", "#333333");
	this.p6.name = "p6";
	this.p6.textAlign = "center";
	this.p6.lineHeight = 23;
	this.p6.lineWidth = 100;
	this.p6.parent = this;
	this.p6.setTransform(496.6,-8.5,1.139,1.139);

	this.p5 = new cjs.Text("Pregunta 5", "bold 19px 'Arial'", "#333333");
	this.p5.name = "p5";
	this.p5.textAlign = "center";
	this.p5.lineHeight = 23;
	this.p5.lineWidth = 100;
	this.p5.parent = this;
	this.p5.setTransform(492.8,-99.5,1.139,1.139);

	this.p4 = new cjs.Text("Pregunta 4", "bold 19px 'Arial'", "#333333");
	this.p4.name = "p4";
	this.p4.textAlign = "center";
	this.p4.lineHeight = 23;
	this.p4.lineWidth = 100;
	this.p4.parent = this;
	this.p4.setTransform(122.1,141.6,1.139,1.139);

	this.p3 = new cjs.Text("Pregunta 3", "bold 19px 'Arial'", "#333333");
	this.p3.name = "p3";
	this.p3.textAlign = "center";
	this.p3.lineHeight = 23;
	this.p3.lineWidth = 100;
	this.p3.parent = this;
	this.p3.setTransform(122.1,41.5,1.139,1.139);

	this.p2 = new cjs.Text("Pregunta 2", "bold 19px 'Arial'", "#333333");
	this.p2.name = "p2";
	this.p2.textAlign = "center";
	this.p2.lineHeight = 23;
	this.p2.lineWidth = 100;
	this.p2.parent = this;
	this.p2.setTransform(122.1,-54,1.139,1.139);

	this.p1 = new cjs.Text("Pregunta 1", "bold 19px 'Arial'", "#333333");
	this.p1.name = "p1";
	this.p1.textAlign = "center";
	this.p1.lineHeight = 23;
	this.p1.lineWidth = 100;
	this.p1.parent = this;
	this.p1.setTransform(122.1,-137.3,1.139,1.139);

	this.b7 = new lib.mc_boton();
	this.b7.parent = this;
	this.b7.setTransform(509.1,108.7,1.139,1.139,0,0,0,88.3,19.9);

	this.b6 = new lib.mc_boton();
	this.b6.parent = this;
	this.b6.setTransform(515.4,4.1,1.139,1.139,0,0,0,88.3,19.9);

	this.b5 = new lib.mc_boton();
	this.b5.parent = this;
	this.b5.setTransform(515.4,-86.8,1.139,1.139,0,0,0,88.3,20);

	this.b4 = new lib.mc_boton();
	this.b4.parent = this;
	this.b4.setTransform(144.7,154.2,1.139,1.139,0,0,0,88.3,19.9);

	this.b3 = new lib.mc_boton();
	this.b3.parent = this;
	this.b3.setTransform(144.7,54.1,1.139,1.139,0,0,0,88.3,19.9);

	this.b2 = new lib.mc_boton();
	this.b2.parent = this;
	this.b2.setTransform(144.7,-41.4,1.139,1.139,0,0,0,88.3,19.9);

	this.b1 = new lib.mc_boton();
	this.b1.parent = this;
	this.b1.setTransform(144.7,-124.6,1.139,1.139,0,0,0,88.3,19.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.b1},{t:this.b2},{t:this.b3},{t:this.b4},{t:this.b5},{t:this.b6},{t:this.b7},{t:this.p1},{t:this.p2},{t:this.p3},{t:this.p4},{t:this.p5},{t:this.p6},{t:this.p7},{t:this.i1},{t:this.i2},{t:this.i3},{t:this.i4},{t:this.i5},{t:this.i6},{t:this.i7}]}).wait(1));

	// Layer 2
	this.text = new cjs.Text("de 7 respuestas correctas", "40px 'Arial'", "#FFFFFF");
	this.text.lineHeight = 47;
	this.text.lineWidth = 485;
	this.text.parent = this;
	this.text.setTransform(196,-238);

	this.txt_cal = new cjs.Text("0", "bold 40px 'Arial'", "#FFFFFF");
	this.txt_cal.name = "txt_cal";
	this.txt_cal.lineHeight = 47;
	this.txt_cal.lineWidth = 42;
	this.txt_cal.parent = this;
	this.txt_cal.setTransform(169,-235);

	this.text_1 = new cjs.Text("Obtuviste", "40px 'Arial'", "#FFFFFF");
	this.text_1.lineHeight = 47;
	this.text_1.lineWidth = 184;
	this.text_1.parent = this;
	this.text_1.setTransform(-3,-238);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text_1},{t:this.txt_cal},{t:this.text}]}).wait(1));

	// Fondo
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D25558").s().p("Eg5AAHAIAAqPQAAhkA+hGQBAhGBZAAMBrTAAAQBZAAA/BGQA/BGAABkIAAKPg");
	this.shape.setTransform(343.7,-211.8);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#EEEFEF").s().p("Eg1pAjtQhZAAhAhHQg+hGAAhjMAAAg/5QAAhjA+hHQBAhGBZAAMBrTAAAQBZAAA/BGQA/BHAABjMAAAA/5QAABjg/BGQg/BHhZAAg");
	this.shape_1.setTransform(343.7,-28.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.mc_retro_eval, new cjs.Rectangle(-193.6,-256.6,902.3,457), null);


(lib.mc_portada = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		///* alert(String(window.eval.rojo));*/
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E3EFB9").s().p("AiwlhIFhFhIlhFig");
	this.shape.setTransform(223,170.1);

	this.text = new cjs.Text("En esta sección evaluaremos los conocimientos adquiridos en el curso de Talent Management Review.", "20px 'Arial'");
	this.text.textAlign = "center";
	this.text.lineHeight = 24;
	this.text.lineWidth = 261;
	this.text.parent = this;
	this.text.setTransform(37.4,207.5);

	this.text_1 = new cjs.Text("Sigue las instrucciones que se te presentan en cada pregunta para responderlas.\n\nAsegúrate de elegir bien tu respuesta, ya que al avanzar a la siguiente pregunta no podrás regresar a la anterior.\n\n¡Buena suerte!", "16px 'Arial'");
	this.text_1.lineHeight = 20;
	this.text_1.lineWidth = 434;
	this.text_1.parent = this;
	this.text_1.setTransform(253,97.1);

	this.instance = new lib.circulo3g();
	this.instance.parent = this;
	this.instance.setTransform(3.2,99,1.22,1.22,0,0,0,52.9,52.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#E3EFB9").s().p("A4nb5QhoAAhJhJQhJhJAAhoMAAAgv9QAAhoBJhJQBJhJBoAAMA1JAAAMAAAA3xg");
	this.shape_1.setTransform(37,164.2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#EEEFEF").s().p("Eg/BAb5QhnAAhKhJQhIhJgBhoMAAAgv9QABhoBIhJQBKhJBnAAMB+CAAAQBoAABJBJQBKBJgBBoMAAAAv9QAAA1gSAtQgTArgkAkQhJBJhoAAg");
	this.shape_2.setTransform(282.8,164.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.instance},{t:this.text_1},{t:this.text},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.mc_portada, new cjs.Rectangle(-145.6,-14.3,856.7,409.9), null);


(lib.mc_p5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		/*NOTA IMPROTANTE:
		EN CADA ACTIVIDAD CON MC IGUALES, SE TIENEN QUE DUPLICAR
		NO BASTA CON CAMBIARLES LA INSTANCIA, A NIVEL CÓDIGO NO HAY DIFERENCIA
		ADEMAS DE QUE TIENEN QUE TENER INSTANCIAS DIFERENTES A LAS ANTERIORES
		*/
		this.stop();
		var root = this;
		var resp = 2;
		var correcta = 1;
		root.p5.text=("¿Cómo definimos el “Potencial” de nuestros colaboradores en Arca Continental?");
		root.c5_op0.text=("Se entiende como la capacidad de cumplir un objetivo en el corto plazo.");
		root.c5_op1.text=("Es la cantidad máxima de contribución que el colaborador es capaz de entregar en el largo plazo.");
		root.c5_op2.text=("Es el conjunto de acciones que nos ayudan a lograr el acatamiento a las políticas y reglamentos de la empresa por parte de todos sus integrantes.");
		iniciar();
		
		function iniciar() {
			root.parent.parent.btn_siguiente.visible = false;
			for (var i = 0; i <= resp; i++) {
				root['c5_' + i].cursor = "pointer";
				root['c5_' + i].n = i;
				root['c5_' + i].addEventListener("click", cambios);
				root['c5_' + i].gotoAndStop(1);
			}
		}
		
		function cambios(r) {
			//Cambia el estatus de la opcion seleccionada
			for (var i = 0; i <= resp; i++) {
				if (root['c5_' + i].n != r.currentTarget.n) {
					root['c5_' + i].gotoAndStop(0);
				} else {
					root['c5_' + i].gotoAndStop(1);
				}
			}
		
			//Valida la respuesta
			if (r.currentTarget.n == correcta) {
				root.parent.parent.resultados[root.parent.parent.cont] = 10;
				console.log("Respuesta Correcta " + root.parent.parent.resultados[root.parent.parent.cont]);
			} else {
				root.parent.parent.resultados[root.parent.parent.cont] = 0;
				console.log("Respuesta Incorrecta " + root.parent.parent.resultados[root.parent.parent.cont]);
			}
			root.parent.parent.activarSiguiente();
			root.parent.parent.registrar_pregunta(root.p5.text, root['c5_op'+r.currentTarget.n].text, root['c5_op'+correcta].text);
		
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#ACDBD1").s().p("AgEAnQgVgIgHgFQgEgDgBgCIABgCIABAAIAAgFQAAAAAAAAQAAgBABAAQAAAAAAAAQABAAAAAAIADAAIAAgIIgDAAQAAAAgBAAQAAAAAAAAQgBgBAAAAQAAgBAAAAIAAgDQAAgBAAAAQAAAAABAAQAAgBAAAAQABAAAAAAIADAAIAAgIIgDAAQAAAAgBAAQAAAAAAgBQgBAAAAAAQAAAAAAgBIAAgEQAAAAAAgBQAAAAABAAQAAgBAAAAQABAAAAAAIADAAIAAgHIgHAAQAAAAgBAAQAAAAgBgBQAAAAAAgBQAAAAAAgBIAAgJQAAgBAAAAQAAgBAAAAQABgBAAAAQABAAAAAAIBLAAQABAAAAAAQABAAAAABQAAAAAAABQABAAAAABIAAAJQAAABgBAAQAAABAAAAQAAABgBAAQAAAAgBAAIgEAAIAAAHIAAAAQABAAAAAAQABAAAAABQAAAAAAAAQAAABAAAAIAAAEQAAABAAAAQAAAAAAAAQAAABgBAAQAAAAgBAAIAAAAIAAAIIAAAAQABAAAAAAQABAAAAABQAAAAAAAAQAAAAAAABIAAADQAAAAAAABQAAAAAAABQAAAAgBAAQAAAAgBAAIAAAAIAAAIIAAAAQABAAAAAAQABAAAAAAQAAAAAAABQAAAAAAAAIAAAGIACAAQADABgHAFQgDADgMAFIgMAFIgGACg");
	this.shape.setTransform(250.3,222.8,0.839,0.839);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#ACDBD1").s().p("AgmCGQgBgLgEgOQgJgegOgUQgKgQgKgVQgTgnADgXQAAgLAFgPQAKgdAZgSIAQgKQAVgKAZAAQAZAAAVAKQALAFAGAFQAZASAKAdQAFAPAAALQADAXgUAnQgJAVgLAQQgNAUgJAeQgEAOgBALg");
	this.shape_1.setTransform(250.4,207.6,0.839,0.839);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#F8DB94").s().p("AgKBXQgDgGgMgFQgJgEgHABIgFABIgNANIgWgVIAMgNQACgFgDgLIgCgGQgEgHgFgDIgEgDIgSABIgBgeIARAAQAHgDAFgLIACgDQACgIgBgGIgBgFIgNgMIAVgXIANAMIAFABQAGAAAHgDIADgBQAMgGABgGIAAgSIAdgBIABARIADAEQADAFAIADIAAAAIADABQAMAEAHgDIAMgNIAWAVIgLANIgBAFQAAAGACAHIABADQAHALAGACIASAAIABAdIgSABIgEACQgEAEgDAHIgDAHQgCALACAFIAOAMIgWAXIgMgMQgHgDgLAEIAAAAQgJAEgEAGIgDAEIAAASIgdABgAgBgvQgTABgOAOQgNAPABASQAAAUAOAOQAPANASgBQAVgBANgOQANgOgBgTQgBgUgNgNQgOgNgTAAIgBAAg");
	this.shape_2.setTransform(266.5,229.5,0.839,0.839);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#E5989B").s().p("AAhCpQgJgLgYgCIAAABQgSgBgNAFIgKAFIgOAgIg2gZIAOgfQABgNgNgRIgIgIQgLgLgMgEIgJgCIggAMIgVg4IAggMQALgIACgXIAAgHQAAgQgFgLIgFgIIgggOIAZg3IAfAPIAKgBQAMgEAMgLIAEgDQARgSAAgOIgMggIA3gVIAMAhIAHAFQALAFANACIAIAAQAZAAAKgKIAOgfIA2AYIgOAgIABAJQAEAMAKAMIAEAEQASARANAAIAhgMIAVA4IghALIgFAIQgGAKgBANIgBANQABAWAJAJIAgAOIgZA2IgfgOQgNgBgTAPIABAAQgOAMgFAOQgDAGAAAEIAMAgIg3AVgAgghWQgjAOgQAiQgQAkANAiQAOAlAjAPQAjAQAigOQAkgNAQgjQAQgigNgkQgOgkgjgQQgTgIgTAAQgPAAgRAGg");
	this.shape_3.setTransform(247.3,246.3,0.839,0.839);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#6AB5C6").s().p("Aq+Q8QCohMAdACQAkADAug4QBdhxA1gzQA0hyBGiGQAkhDAZgtIAqgMIANg+IAKgFQAUhOAJgrQAQhPgOgYQgPgbhYASQhiAZgbAAQgjABgXgPQgOgJgPgWQgIgNAHglQAHgngBgEQgDgIACgBIACAAQgKgSgGgXQgDgEgBgJIgBgIIAAAAIgEgKQgIgWAEgIIABgGQADgOABgTIAAgXQAAgFgVgBQgbgCgQgKQgSgLgBgVIADgUQAmhnAqhBIAAgFQgOgCgEgDQgEgDAAgVQAAgTACgLQACgIAOgFQAKgEAGAAQgPAFgBAKQgCALAKgBIAHgKIABgPIADjpQAIgaAHgTQh1iyAAglQAAgQAHgDQAGgCAVAFQBJAQBHgFIgXhXIAuAfQA6AgA5ALIAjgDIgWhVIAoAbQAxAeAyANQAkgFAYAAIADAAIgLgqIASANQAXAQAZANIASABQCLgFA4AWQB6AvBQBxQBvCcgSDnQgRDZiNChQgsAygzAmIgqAdIgBgHQgUA5gRBGIAZgNIAiCHIAbASQAiAZAgAjIgDgVIAKAcQBfBoA0CTQBGDKgVEGg");
	this.shape_4.setTransform(234.9,270.7,0.839,0.839);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#DFE5DF").s().p("AoVTwQj2hoi+i+Qi+i+hoj2Qhsj/AAkXQAAkWBsj/QBoj2C+i+QC+i+D2hoQD/hsEWAAQEXAAD/BsQD2BoC+C+QC+C+BoD2QBsD/AAEWQAAEXhsD/QhoD2i+C+Qi+C+j2BoQj/BskXAAQkWAAj/hsg");
	this.shape_5.setTransform(242,280.8,0.839,0.839);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#EFEFEF").s().p("ApeWcQkXh2jYjYQjYjYh2kXQh7kiAAk9QAAk8B7kiQB2kXDYjYQDYjYEXh2QEih7E8AAQE9AAEiB7QEXB2DYDYQDYDYB2EXQB7EiAAE8QAAE9h7EiQh2EXjYDYQjYDYkXB2QkiB7k9AAQk8AAkih7g");
	this.shape_6.setTransform(240.9,281.4,0.839,0.839);

	this.c5_2 = new lib.mc_radioButton5();
	this.c5_2.parent = this;
	this.c5_2.setTransform(501.9,358.2,1,1,0,0,0,18,18.1);

	this.c5_1 = new lib.mc_radioButton5();
	this.c5_1.parent = this;
	this.c5_1.setTransform(501.9,262.5,1,1,0,0,0,18,18.1);

	this.c5_op0 = new cjs.Text("Se entiende como la capacidad de cumplir un objetivo en el corto plazo.", "16px 'Arial'");
	this.c5_op0.name = "c5_op0";
	this.c5_op0.lineHeight = 18;
	this.c5_op0.lineWidth = 369;
	this.c5_op0.parent = this;
	this.c5_op0.setTransform(527.3,169.3);

	this.c5_op2 = new cjs.Text("Es el conjunto de acciones que nos ayudan a lograr el acatamiento a las políticas y reglamentos de la empresa por parte de todos sus integrantes.", "16px 'Arial'");
	this.c5_op2.name = "c5_op2";
	this.c5_op2.lineHeight = 18;
	this.c5_op2.lineWidth = 401;
	this.c5_op2.parent = this;
	this.c5_op2.setTransform(523.3,349.4);

	this.c5_op1 = new cjs.Text("Es la cantidad máxima de contribución que el colaborador es capaz de entregar en el largo plazo.", "16px 'Arial'");
	this.c5_op1.name = "c5_op1";
	this.c5_op1.lineHeight = 18;
	this.c5_op1.lineWidth = 359;
	this.c5_op1.parent = this;
	this.c5_op1.setTransform(523.3,253.6);

	this.c5_0 = new lib.mc_radioButton5();
	this.c5_0.parent = this;
	this.c5_0.setTransform(501.9,176.7,1,1,0,0,0,18,18.1);

	this.p5 = new cjs.Text("¿Cómo definimos el “Potencial” de nuestros colaboradores en Arca Continental?", "20px 'Arial'");
	this.p5.name = "p5";
	this.p5.lineHeight = 24;
	this.p5.lineWidth = 335;
	this.p5.parent = this;
	this.p5.setTransform(135,15.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.p5},{t:this.c5_0},{t:this.c5_op1},{t:this.c5_op2},{t:this.c5_op0},{t:this.c5_1},{t:this.c5_2},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// fondo y encabezado
	this.instance = new lib.iconoactividadesyretos("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(477.7,95.1,0.551,0.551,0,0,0,55.7,55.7);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("rgba(230,149,122,0.498)").s().p("EgiSAJ5QjsAAAAjsIAAsZQAAjsDsAAMBElAAAQDsAAAADsIAAMZQAADsjsAAg");
	this.shape_7.setTransform(256.4,49.7);

	this.instance_1 = new lib.fondo("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(469.6,267.3,1,1,0,0,0,485.2,268.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.shape_7},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.mc_p5, new cjs.Rectangle(2.4,-36.5,958.3,510.2), null);


(lib.mc_p4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		/*NOTA IMPROTANTE:
		EN CADA ACTIVIDAD CON MC IGUALES, SE TIENEN QUE DUPLICAR
		NO BASTA CON CAMBIARLES LA INSTANCIA, A NIVEL CÓDIGO NO HAY DIFERENCIA
		ADEMAS DE QUE TIENEN QUE TENER INSTANCIAS DIFERENTES A LAS ANTERIORES
		*/
		this.stop();
		var root = this;
		var resp = 5;
		var correcta = 3;
		root.p4.text=("Esta etapa inicia con la evaluación de potencial del colaborador por parte del líder y finaliza con la integración de las mediciones de potencial y desempeño en el formato de evaluación llamado “9-BOX”.");
		root.c4_op0.text=("Estrategia del Negocio.");
		root.c4_op1.text=("Identificación de puestos críticos.");
		root.c4_op2.text=("Perfil de Éxito.");
		root.c4_op3.text=("Evaluación de Potencial y Desempeño.");
		root.c4_op4.text=("Sesión de Calibración.");
		root.c4_op5.text=("Sesión de Sucesión.");
		iniciar();
		
		function iniciar() {
			root.parent.parent.btn_siguiente.visible = false;
			for (var i = 0; i <= resp; i++) {
				root['c4_' + i].cursor = "pointer";
				root['c4_' + i].n = i;
				root['c4_' + i].addEventListener("click", cambios);
				root['c4_' + i].gotoAndStop(1);
			}
		}
		
		function cambios(r) {
			//Cambia el estatus de la opcion seleccionada
			for (var i = 0; i <= resp; i++) {
				if (root['c4_' + i].n != r.currentTarget.n) {
					root['c4_' + i].gotoAndStop(0);
				} else {
					root['c4_' + i].gotoAndStop(1);
				}
			}
		
			//Valida la respuesta
			if (r.currentTarget.n == correcta) {
				root.parent.parent.resultados[root.parent.parent.cont] = 10;
				console.log("Respuesta Correcta " + root.parent.parent.resultados[root.parent.parent.cont]);
			} else {
				root.parent.parent.resultados[root.parent.parent.cont] = 0;
				console.log("Respuesta Incorrecta " + root.parent.parent.resultados[root.parent.parent.cont]);
			}
			root.parent.parent.activarSiguiente();
			root.parent.parent.registrar_pregunta(root.p4.text, root['c4_op'+r.currentTarget.n].text, root['c4_op'+correcta].text);
		
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.text = new cjs.Text("%", "bold 25px 'Arial'");
	this.text.lineHeight = 8;
	this.text.lineWidth = 33;
	this.text.parent = this;
	this.text.setTransform(185.4,307.6,0.685,0.685);

	this.text_1 = new cjs.Text("10", "bold 35px 'Arial'");
	this.text_1.lineHeight = 14;
	this.text_1.lineWidth = 53;
	this.text_1.parent = this;
	this.text_1.setTransform(157.4,302,0.685,0.685);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("ACJFTQgFgBgDgEQgDgFACgFIAAAAQAAgFAFgDQAEgDAFABQAfAHAbgBQAFgBAEAEQADADABAFIAAABQAAAFgDAEQgEADgFABIgIAAQgbAAgdgGgAD9FNQgFgCgCgFIAAgBQgCgEACgFQACgEAFgCQAQgHANgLIAAAAQAHgGAGgHQADgEAFgBQAFAAAEADIAAAAQAEADABAFQABAFgDAEQgIAKgJAIIAAAAQgQAMgTAJIgFABIgFgBgABMFCQgcgKgcgPQgEgCgCgFQgCgFADgFIAAAAQACgEAFgCQAFgBAFACQAaAOAbAJQAEACADAFQACAEgCAFIAAAAQgCAFgEACIgGACIgEgBgAgiEJIgNgJIglgaQgEgDgBgFQgBgFADgEQADgEAGgBQAFgBAEADIAkAaIANAJQAEADABAFQABAFgCAEIgBAAQgDAEgFABIgCABQgEAAgDgDgAFHD0QgFgBgCgEQgDgFABgFIACgIIAAABQADgXgCgZQgBgFAEgEQADgEAFgBIAAAAQAFAAAEADQAEADABAFQACAdgDAZIAAABIgCAJQgCAFgEADQgDACgDAAIgEgBgAiDDAQgXgUgWgXIABAAIgBgBQgEgEAAgFQAAgFAEgEIAAAAQADgDAFAAQAFAAAEADIABABIAAAAQAVAXAXATQADAEABAFQAAAFgDAEIAAAAQgEAEgFAAIgBAAQgEAAgEgDgAE8B9QgFgCgBgFQgIgcgMgcQgCgFACgEQACgFAFgCIAAAAQAEgCAFACQAFACACAEQANAeAIAdQABAFgCAFQgDAEgFACIgDAAQgEAAgCgCgAjQBsQgFgBgDgEQgUgXgQgZQgDgEABgFQAAgFAFgDIAAAAQAEgDAFABQAFABADAEQAQAYATAWQADAEAAAFQgBAFgEAEIAAAAQgDADgFAAIgBAAgAEQAQQgFgBgDgFIgJgOIAAAAIgXgkQgDgEABgFQABgFAEgDIAAAAQAEgDAGABQAFABADAEIAYAlIgBAAIAKAQQADADgCAFQgBAGgFACQgDACgCAAIgEgBgAkVAKQgFgBgDgFQgQgagMgaQgCgFACgFQACgFAFgCIAAAAQAFgCAEACQAFACACAFQALAZAQAaQACAEgBAEQgCAFgEADQgDACgDAAIgDgBgADNhSQgFAAgEgEQgTgWgVgWIgBgCIAAAAQgEgEAAgFQAAgFAEgEIAAAAQADgDAFAAQAFAAAEADIABABIABABQAWAXATAXQAEAEgBAFQAAAFgEADIAAAAQgEADgEAAIgBAAgAlHhfQgEgDgCgFIgCgHQgJgfgCgcQAAgGADgEQAEgDAFgBQAFAAAEADQAEAEAAAFQACAZAIAdIACAHQACAFgDAFQgCAEgFACIAAAAIgEAAQgDAAgDgBgAByisQgXgTgXgTQgEgDgBgFQAAgFADgEIAAAAQADgEAFgBQAFAAAFADQAXATAXAUQAEADAAAFQABAGgEADQgDAEgFABIgBAAQgFAAgDgEgAlMjbIgBAAQgFgBgDgEQgDgEACgFQAHgiATgZQADgEAFgBQAFAAAFADIAAAAQAEADAAAFQABAFgDAEQgQAVgGAcQgBAFgEADQgEACgDAAIgCgBgAAUjzQgZgRgbgOQgEgCgCgFQgCgFADgEQACgFAFgCQAFgBAEACQAbAOAcASQAEADABAFQABAFgDAEQgDAEgFABIgCABQgEAAgDgCgAhWkpIgGgCIAAAAQgZgJgYgFQgFgBgDgFQgDgEACgFIAAAAQABgFAEgDQAEgDAFABQAaAGAbAJIgBAAIAGACQAFACADAFQACAEgCAFIAAABQgCAEgEACIgGACIgEgBgAkIk0QgEgCgCgEIAAgBQgCgFACgFQACgEAFgCQAagLAigCIABAAIADAAQAFAAAEAEQADADAAAFIAAABQAAAFgDADQgEAEgFAAIgDAAQgdACgXAJIgFABIgFgBg");
	this.shape.setTransform(176.8,314.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(255,255,255,0.8)").s().p("ADTFEQgEgEgFAAQgcABgegGQgFgBgEADQgFADgBAFIAAAAQgRgEgSgGQABgFgCgEQgCgFgFgCQgagKgbgNQgEgDgFACQgFABgDAFIgfgTQADgEgBgFQgBgFgEgDIgNgJIgkgZQgFgDgFAAQgFABgDAEIgagWQADgEAAgFQgBgFgEgDQgWgUgVgWIAAAAIgBgBQgEgEgFAAQgFAAgDAEIgXgZIAAgBQAEgDABgFQAAgFgDgEQgTgXgQgXQgDgFgFgBQgFAAgEACIgBABIgQgbIgCgCQAEgDACgFQABgEgDgFQgPgZgLgaQgCgFgFgBQgFgCgEACIgLgeQAFgBACgFQADgEgCgFIgCgHQgIgdgCgaQAAgFgEgDQgEgEgFABQgBgTADgRQAEABAEgDQAFgDABgFQAGgcAPgUQAEgEgBgFQgBgFgDgDIAIgHQAJgIALgGQACAEAEACQAFACAFgCQAXgJAdgBIADAAQAFAAADgEQAEgEAAgFIAAAAQASAAASADIAAABQgBAFADAEQADAEAFABQAYAFAZAKIAAAAIAGACQAFABAFgCQAEgCACgFIAgAOQgCAFACAFQABAFAFACQAaANAaARQAEADAFgBQAFgBADgFIADACIAaATQgDAEAAAFQABAFAEADQAXASAWAUQAEADAFAAQAFAAAEgEIAYAXIgBAAQgDAEAAAFQAAAFADADIABABIABABQAVAWATAWQADAEAGABQAEAAAEgDIAWAcQgEADgBAEQgBAGADAEIAXAjIAAAAIAJAPQADAEAFACQAFABAEgCIAPAeQgEACgCAFQgCAFACAFQAMAcAIAbQABAFAEADQAFADAFgCQAEASADAQQgFAAgDAEQgEAEABAFQACAagDAXIAAgBIgCAIQgBAFACAEQADAFAFABQgGASgJAOQgEgDgFABQgFABgDAEQgGAHgHAGIAAAAQgNAKgQAHQgFACgCAFQgCAEACAFQgQAEgRACQgBgFgDgDg");
	this.shape_1.setTransform(176.6,314.3);

	this.text_2 = new cjs.Text("%", "bold 25px 'Arial'");
	this.text_2.lineHeight = 8;
	this.text_2.lineWidth = 33;
	this.text_2.parent = this;
	this.text_2.setTransform(379.8,254.5,0.685,0.685);

	this.text_3 = new cjs.Text("15", "bold 35px 'Arial'");
	this.text_3.lineHeight = 14;
	this.text_3.lineWidth = 53;
	this.text_3.parent = this;
	this.text_3.setTransform(351.7,249.7,0.685,0.685);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#333333").s().p("ACtGTQgFAAgDgFQgDgEABgFIAAAAQABgFAEgDQAEgDAFABQAeAFAbAAQAFAAAEADQAEAEAAAFQAAAFgEAEQgDAEgFAAIgFAAQgcAAgdgGgAEfGPQgEgCgCgFIAAgBQgBgFACgEQADgEAFgCQAbgIAVgSQAFgDAFABQAEAAADAEIABAAQADAEAAAFQgBAGgEADQgYAUghAKIgEABQgDAAgDgCgABwGEIgLgEIAAAAQgYgIgYgKQgFgDgCgEQgCgFACgFIABAAQACgFAEgCQAFgCAFADQAXAKAXAIIAAAAIALAEQAFACACAEQACAFgBAEIAAABQgCAFgFACIgFABIgEgBgAgBFRQgagPgbgSIgBgBIgBgBQgEgEAAgFQAAgEACgDIACgCQADgDAFAAQAGAAADADQAZARAZAPQAEACABAFQACAFgDAFIAAAAQgCAEgFACIgEAAQgDAAgCgCgAF5FFIgBAAQgEgDgBgEQgCgFACgFQAKgTAEgZIABgKQAAgFAEgDQAEgDAFAAQAGABADAEQADAEAAAFIgCAMQgFAcgKAWQgCAFgFABIgEABIgGgBgAhoEMIgvgnQgEgDgBgGQAAgFADgEIABAAQADgEAFAAQAFAAAEADIAuAmQAEAEABAFQAAAFgDAEIAAAAQgDAEgFABIgBAAQgFAAgDgDgAGGDOQgEgDgBgFQgDgbgJgeQgBgFADgFQACgEAFgBQAFgCAFADQAEACABAFQAJAgAEAdQABAFgEAEQgDAEgFABIgBAAQgFAAgDgDgAjCC8IgMgMIgBAAIgeghQgDgEAAgFQABgFAEgDQAEgEAFABQAFAAADAEIAdAfIAAAAIAMAMQAEAEAAAFQAAAFgEAEQgDAEgGAAQgFAAgDgEgAkLBlQgFgBgDgEQgTgZgRgZQgDgEABgFQABgFAFgDIAAAAQAEgDAFABQAFABADAEQAQAZATAYQADAEgBAFQAAAFgEADIgBABQgDACgEAAIgCAAgAFqBcQgFgCgCgFQgLgagOgaQgCgFABgFQABgFAFgCQAFgDAFACQAFABACAFQAPAbALAbQACAFgCAFQgCAFgFACIAAAAIgEABIgFgBgAlPAAQgEAAgDgFQgPgbgNgbQgCgFACgFQACgFAFgCIAAAAQAFgCAEACQAFACACAEQAMAaAPAbQACAFgBAFQgBAFgFACQgDABgDAAIgEgBgAE1gMQgFgBgDgEQgQgZgSgYQgDgEABgFQABgFAEgDQAEgDAFAAQAFABADAEQATAZAQAZQADAFgBAFQgBAFgFADIAAAAQgDACgEAAIgCgBgAmChuQgEgDgCgFIgEgOIAAAAQgGgXgDgVQgBgFADgEQADgEAFgBQAFgBAEADQAEADABAFQAEAUAFAVIAAAAIAEAOQACAFgDAFQgCAEgFACIAAAAIgEAAQgDAAgDgBgADuhtQgFAAgDgEQgTgWgWgWIgBgCIgUgUQgEgEAAgFQAAgFAEgDIAAgBQADgDAFAAQAGAAADADIAVAVIABABQAWAXAUAWQADAEAAAGQAAAFgEADIgBAAQgDADgEAAIgCAAgAB7jbQgWgUgYgSQgEgDgBgFQgBgFADgEIAAAAQAEgEAFgBQAFgBAEADQAYASAYAVQAEADAAAFQAAAFgDAEIAAAAQgEAEgFABIgBAAQgEAAgEgDgAmOjhIAAAAQgFAAgEgEQgDgEAAgFQABgPACgOQACgSAGgPQABgFAFgDQAFgCAEACIABAAQAFACACAEQACAFgCAFQgEANgDAPIgCAbQAAAFgEAEQgEADgFAAIAAAAgAAdkjQgbgRgagOQgEgDgCgFQgBgFACgEIAAAAQADgFAFgBQAFgCAEADQAbAOAbASQAFADABAFQABAFgDAEIAAABQgDAEgFABIgDAAQgDAAgDgCgAlslTIgBAAQgDgEgBgFQAAgFAEgEIAMgLQASgQAXgJQAEgCAFACQAFACACAFIAAAAQACAFgCAEQgCAFgFACQgTAIgPANIgKAJQgDAEgGAAIAAAAQgFAAgDgDgAhMlbIgggMIAAAAIgXgIQgFgBgDgFQgCgEABgFQACgFAEgDQAFgCAFABIAZAIIgBAAIAhANQAFACACAEQACAFgCAFIAAAAQgCAFgFACIgFABIgEgBgAi+l8QgagDgYABIgBAAIgGAAQgFABgEgEQgEgDgBgFIAAAAQAAgFADgEQADgEAFgBIAJAAIAAAAQAagBAcADQAGABADAEQADAEgBAFIAAABQAAAEgFAEQgDACgEAAIgCAAg");
	this.shape_2.setTransform(370.3,261.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("rgba(255,255,255,0.8)").s().p("ADzGCQgEgDgFAAQgcAAgdgFQgFgBgFADQgEADgBAFIAAAAQgRgDgSgGQACgEgCgEQgCgFgFgCIgLgEIgBAAQgXgIgXgKQgEgCgFABQgFACgCAFIgfgQQACgFgBgFQgBgEgFgDQgYgPgZgQQgEgEgFAAQgFAAgEAEIgCABIgcgUQADgEgBgFQAAgFgEgDIgugnQgEgDgFAAQgFABgEADIgYgXQADgEAAgFQAAgFgDgEIgMgLIAAAAIgdggQgEgEgFAAQgFgBgEAEIgWgbIAAgBQAEgDABgFQABgFgEgEQgSgYgRgZQgCgEgGgBQgEgBgFADIgJgPIgJgOQAFgCABgFQACgFgDgFQgOgagMgbQgCgEgFgCQgFgCgFACIgMghQAFgCACgEQACgFgBgFIgEgOIAAABQgGgWgDgUQgBgFgEgDQgEgDgGABQgCgSAAgRQAFAAADgDQAEgEAAgFIADgaQACgQAFgNQABgFgCgFQgCgEgEgCQAHgRALgOQAEADAFAAQAFAAAEgEIAJgJQAQgNATgIQAEgCACgFQACgEgBgFQAQgFASgCIAAAAQABAFAEADQAEAEAFgBIAHAAIAAAAQAZgBAaADQAFABAEgDQAEgDABgFQASADASAFQgCAFADAEQACAFAFABIAXAIIABAAIAfAMQAFACAFgCQAEgCACgFIAgAPQgCAFABAFQABAEAFADQAaAOAaARQAFADAEgBQAFgBADgEIADACIAaASQgDAEABAFQAAAFAEADQAYASAXAUQAEADAFAAQAFgBADgDIAAgBIAbAZQgDADgBAFQABAFADAEIAVAVIABABQAVAWATAWQAEAEAFAAQAFABAEgDIAWAcQgEADAAAFQgBAFADAEQASAYAPAZQADAEAFACQAFABAEgDIAAAAIARAdQgEACgCAFQgBAFACAFQAPAaAKAaQACAFAFACQAFACAEgCIAMAiQgFABgDAFQgCAEABAFQAIAeADAbQABAFAEADQAEAEAFgBQACASgBAQQgFAAgEADQgEADgBAGIgBAKQgEAYgJAUQgDAEACAFQACAEAEADQgJAPgMAMQgDgEgFAAQgFgBgEADQgVASgcAIQgFACgCAEQgCAFABAEQgQAEgTABQAAgFgDgEg");
	this.shape_3.setTransform(370.3,262);

	this.text_4 = new cjs.Text("%", "bold 25px 'Arial'");
	this.text_4.lineHeight = 8;
	this.text_4.lineWidth = 33;
	this.text_4.parent = this;
	this.text_4.setTransform(287.1,274.4,0.685,0.685);

	this.text_5 = new cjs.Text("75", "bold 40px 'Arial'");
	this.text_5.lineHeight = 19;
	this.text_5.lineWidth = 53;
	this.text_5.parent = this;
	this.text_5.setTransform(257.4,266.4,0.685,0.685);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AEgJAQgGAAgEgEQgFgFABgGIAAgBQAAgGAEgEQAFgEAGAAIAeAAIAagCQAHgBAFAEQAEADABAGIAAABQABAGgDAFQgEAFgGABQgOACgQAAIgQABIgQgBgADiI5QgegGgggKQgFgCgDgGQgDgFACgGIAAgBQACgFAFgDQAGgDAGACQAdAKAcAFQAGABAEAFQADAFgBAGIAAABQgBAGgFADQgEADgEAAIgDAAgAGSIsQgGgCgDgGIAAAAQgCgFACgGQACgGAGgCQAagMAVgSQAEgFAHABQAFAAAEAEIABABQAEAFAAAGQgBAGgEAEQgZAWgeANIgGABIgFgBgABrITQgcgMgcgOQgFgDgCgGQgCgGADgFQADgGAFgCQAGgCAGADQAbAOAbALQAFADADAFQACAGgDAGQgCAFgGADIgFABIgGgBgAHoHdIgBgBQgFgDgBgFQgCgGADgGQAOgXAIgcQABgGAGgDQAFgDAFABIABAAQAGACADAGQADAFgBAGQgJAggQAaQgDAGgGABIgEABQgEAAgDgCgAgCHbIgyghQgFgEgCgGQgBgGAEgFIAAAAQADgFAGgBQAGgCAGAEIAwAgQAFADACAGQABAGgDAGIAAAAQgDAFgGABIgEABQgEAAgDgCgAhnGVQgYgSgXgUQgFgEAAgGQgBgHAEgEIAAgBQAEgEAGgBQAHAAAEAEIAuAlQAFAEABAGQABAGgEAFQgEAFgGABIgCAAQgFAAgEgDgAIPFsIgBAAQgGAAgEgFQgEgEABgGQABgcgCgeQgBgGAEgFQAEgEAGgBIAAAAQAHgBAEAEQAFAEABAHQACAggBAdQgBAGgEAFQgFADgFAAIgBAAgAjDFGIgsgrQgEgEAAgGQAAgHAEgEIAAAAQAFgEAGAAQAGAAAEAEIArAqQAFAFAAAGQAAAGgEAFQgEAEgGAAIgBAAQgGAAgEgEgAH9DyQgFgDgBgGIgIgkIAAAAIgEgPQgCgGADgGQADgFAGgBIAAgBQAGgBAGADQAFADACAGIAEAQIAAgBIAIAmQACAGgEAFQgDAFgGACIgBAAIgDAAQgEAAgEgDgAkOD0QgGAAgFgFIgnguQgDgFAAgGQABgGAFgEIAAAAQAFgEAGABQAGAAAEAFIAmAtQAEAFAAAGQgBAGgEAEIAAABQgFADgFAAIgBAAgAlaCYQgGgBgEgFQgSgZgQgYQgEgGABgGQACgGAFgDIAAAAQAFgEAGACQAGABAEAFQAPAYASAYQAEAFgBAGQgBAGgFAEQgEADgEAAIgDAAgAHfCEQgFgCgDgGQgJgcgNgbQgDgGADgGQACgGAFgCIAAAAQAGgDAGACQAGACACAGQAOAdAKAdQACAGgDAFQgCAGgGACIAAAAIgGABIgGgCgAmeAyQgGgBgDgGIgJgQIAAAAIgWglQgCgGABgGQACgGAGgCIAAgBQAFgCAGACQAGABADAGIAVAkIAAABIAJAQQADAFgCAGQgCAGgFADIAAAAQgEACgDAAIgEgBgAGwAXQgGgCgDgGIgPgaIAAAAIgPgYQgDgFACgGQABgHAFgDQAFgDAGABQAHACADAFIAPAZIAAAAIAPAbQADAGgCAGQgBAGgGADIAAAAQgDABgEAAIgEAAgAnXg5QgGgCgDgGQgMgcgKgcQgCgGADgFQACgGAGgCIAAAAQAGgCAFACQAGADACAGQAKAbAMAbQACAGgCAGQgCAFgGADIAAAAIgGABIgFgBgAFzhPQgGgBgEgFQgQgYgSgYQgEgFABgGQABgGAFgEIAAAAQAFgEAGABQAGABAEAFQASAYARAZQAEAFgCAGQgBAGgFAEQgEACgEAAIgDAAgAoBipQgFgDgCgGIgDgKIAAgBQgGgYgFgXQgBgGAEgFQADgFAGgBQAHgBAFADQAFAEABAGQAEAWAGAXIgBgBIADAKQACAGgDAFQgDAGgGACIAAAAIgEAAQgDAAgEgBgAEsivQgGAAgEgFIgngtQgEgFAAgGQABgGAEgEQAFgEAGAAQAGAAAEAFIAoAuQAEAFAAAGQgBAGgFAEIAAAAQgEADgFAAIgCAAgADpj8QgGAAgFgEIgpgpQgEgFAAgGQAAgGAEgEIAAAAQAEgFAGAAQAHAAAEAEIAqAqQAEAFAAAGQAAAGgFAEIAAAAQgEAEgGAAIAAAAgAoYkeQgFgFAAgGQgCggACgdQABgHAFgEQAEgEAGABIABAAQAGABAEAEQAEAFgBAGQgCAcACAdQAAAHgEAEQgEAFgGAAIgBAAQgGAAgEgDgACJlRIgugmQgFgEAAgGQgBgGAEgFIAAAAQAEgFAGgBQAGgBAFAEIAvAnQAFAEAAAGQABAGgFAFIAAAAQgEAFgGAAIgBAAQgFAAgFgDgAoGmTIgBAAQgGgCgDgGQgCgFABgGQALggARgZQADgGAGgBQAGgBAFADQAGAEABAGQABAGgDAFQgPAWgJAcQgCAGgGADQgDABgDAAIgEAAgAAtmZQgYgSgYgQQgFgDgCgGQgBgGADgFIABgBQADgFAFgBQAGgCAFAEQAaAQAZASQAFAEABAGQABAGgEAFQgDAFgGABIgDAAQgFAAgEgCgAg2nYQgbgOgbgMQgGgCgCgGQgCgGACgFIAAgBQADgFAGgDQAFgCAGADQAcAMAcAPQAGACABAGQACAGgDAGIAAAAQgDAFgFACIgFABQgDAAgEgCgAnCn1QgGgBgEgEIAAgBQgEgFABgGQAAgGAFgEQAagUAegLQAGgCAGACQAGADACAGIAAAAQACAGgDAFQgCAGgGACQgaAKgWARQgEADgFAAIgCAAgAijoHQgdgKgcgGQgGgCgEgFQgDgFACgGQABgHAFgDQAFgDAGABQAeAHAfAKQAGACACAGQADAFgCAGIAAABQgCAFgFADQgDABgEAAIgFAAgAlZojQgFgEgBgGQAAgGADgFQAEgFAGgBIASgBIAAAAQAVgBAXABQAGABAEAFQAFAEgBAGIAAABQgBAGgEAEQgFAEgGgBQgVgBgTABIgQABIgCAAQgFAAgEgDg");
	this.shape_4.setTransform(277.8,278.7);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("rgba(255,255,255,0.698)").s().p("ADzIsQACgGgEgFQgDgFgGgBQgdgGgdgJQgGgCgGADQgFACgCAGIgQgGIgMgFQACgFgCgGQgDgGgFgCQgbgMgbgNQgGgDgFACQgGACgDAFIgbgPQADgFgBgGQgCgGgFgDIgwghQgFgDgGABQgHABgDAFIgHgFIgTgOQAEgFgBgGQgBgGgFgEIguglQgEgEgHABQgGAAgEAFIgWgUQAEgEAAgHQAAgGgFgEIgqgqQgFgFgGAAQgGAAgFAEIgUgVQAEgEABgGQAAgGgEgFIgmgtQgEgFgGgBQgGAAgFADIgSgXQAFgDABgHQABgGgEgFQgRgXgQgYQgEgGgGgBQgGgBgFADIgRgbQAGgDABgGQACgGgDgFIgJgQIAAAAIgVglQgDgFgGgCQgFgCgGADIgMgbQAFgCACgGQADgFgDgGQgMgcgKgbQgCgGgGgCQgFgDgGACIAAAAIgJgcIAAAAQAGgCADgFQADgGgCgFIgCgKIAAAAQgGgXgEgWQgBgGgFgDQgFgEgGABIgEgdQAGAAAEgFQAEgFAAgGQgCgeACgbQABgGgEgFQgEgFgGgBIABgEIAFgbQAFACAFgDQAGgDACgGQAJgbAPgWQADgGgBgGQgBgGgGgDQAKgMALgLQAEAFAGAAQAGABAFgEQAWgRAagKQAGgCACgFQADgGgCgFQAPgFARgCQAAAGAFAEQAFAEAGgBIAQgCQATgBAVACQAGAAAFgEQAFgEAAgGIAfAFQgCAGADAFQAEAGAGABQAcAGAeAKQAFACAGgDQAFgCACgGIAGACIAWAJQgCAGACAFQADAGAFADQAbALAbAPQAGACAGgBQAFgCADgFIAaAPQgDAFACAFQABAGAFAEQAYAPAZASQAFAEAGgBQAGgBADgFIAXAQQgEAFABAGQABAGAEAEIAuAmQAFAEAGAAQAGgBAEgEIAXAUQgEAFAAAGQAAAGAEAEIAqApQAEAFAGAAQAGAAAEgEIAJAJQgEAFgBAGQAAAGAEAEIAnAtQAEAFAGABQAGAAAFgDIATAYQgFADgBAGQAAAGADAFQASAYAQAYQAEAFAGACQAGABAFgEIAQAaQgFADgBAGQgCAGAEAFIAOAYIAAAAIAPAbQADAFAGACQAGACAFgDIANAbQgFADgCAGQgDAFADAGQANAcAJAbQADAGAFADQAGADAGgDIAAAAIAKAfQgGACgCAFQgEAFACAGIAEAQIAAAAIAIAjQABAGAGAEQAFADAGgBIAEAeQgGABgEAFQgEAEABAHQACAegBAbQgBAGAEAFQAFAEAFABIgBANIgDARQgGgCgFADQgFADgCAGQgIAcgOAYQgDAFACAGQABAGAFADQgIAMgLALQgDgEgGgBQgHAAgEAEQgVATgaALQgFADgDAGQgCAFACAFQgOAGgRADQAAgGgFgEQgFgDgHABIgaACIgeAAQgGAAgEAEQgFAEAAAGIgfgEg");
	this.shape_5.setTransform(277.8,278.8);

	this.instance = new lib.M03_TMR_TABanimultax();
	this.instance.parent = this;
	this.instance.setTransform(274.1,286.3,0.47,0.47,0,0,0,313.1,159);

	this.text_6 = new cjs.Text("Potencial básico\n", "18px 'Arial'", "#333333");
	this.text_6.textAlign = "center";
	this.text_6.lineHeight = 19;
	this.text_6.lineWidth = 97;
	this.text_6.parent = this;
	this.text_6.setTransform(98.7,321.3,0.585,0.585);

	this.text_7 = new cjs.Text("Potencial medio", "18px 'Arial'", "#333333");
	this.text_7.textAlign = "center";
	this.text_7.lineHeight = 19;
	this.text_7.lineWidth = 97;
	this.text_7.parent = this;
	this.text_7.setTransform(98.7,275.8,0.585,0.585);

	this.text_8 = new cjs.Text("Alto Potencial ", "18px 'Arial'", "#333333");
	this.text_8.textAlign = "center";
	this.text_8.lineHeight = 19;
	this.text_8.lineWidth = 97;
	this.text_8.parent = this;
	this.text_8.setTransform(98.7,226.3,0.585,0.585);

	this.text_9 = new cjs.Text("Desempeño alto\n", "18px 'Arial'", "#333333");
	this.text_9.lineHeight = 22;
	this.text_9.lineWidth = 159;
	this.text_9.parent = this;
	this.text_9.setTransform(334.3,193.5,0.585,0.585);

	this.text_10 = new cjs.Text("Desempeño medio", "18px 'Arial'", "#333333");
	this.text_10.lineHeight = 22;
	this.text_10.lineWidth = 159;
	this.text_10.parent = this;
	this.text_10.setTransform(229.6,193.5,0.585,0.585);

	this.text_11 = new cjs.Text("Desempeño bajo", "18px 'Arial'", "#333333");
	this.text_11.lineHeight = 22;
	this.text_11.lineWidth = 276;
	this.text_11.parent = this;
	this.text_11.setTransform(135.1,193.5,0.585,0.585);

	this.c4_5 = new lib.mc_radioButton4();
	this.c4_5.parent = this;
	this.c4_5.setTransform(574.9,407.8,1,1,0,0,0,18,18.1);

	this.c4_op5 = new cjs.Text("Sesión de Sucesión.", "16px 'Arial'", "#333333");
	this.c4_op5.name = "c4_op5";
	this.c4_op5.lineHeight = 20;
	this.c4_op5.lineWidth = 212;
	this.c4_op5.parent = this;
	this.c4_op5.setTransform(603.8,402.4);

	this.c4_4 = new lib.mc_radioButton4();
	this.c4_4.parent = this;
	this.c4_4.setTransform(574.9,356.2,1,1,0,0,0,18,18.1);

	this.c4_op4 = new cjs.Text("Sesión de Calibración.", "16px 'Arial'", "#333333");
	this.c4_op4.name = "c4_op4";
	this.c4_op4.lineHeight = 20;
	this.c4_op4.lineWidth = 243;
	this.c4_op4.parent = this;
	this.c4_op4.setTransform(603.8,349.9);

	this.c4_3 = new lib.mc_radioButton4();
	this.c4_3.parent = this;
	this.c4_3.setTransform(574.9,304.7,1,1,0,0,0,18,18.1);

	this.c4_2 = new lib.mc_radioButton4();
	this.c4_2.parent = this;
	this.c4_2.setTransform(574.9,253.2,1,1,0,0,0,18,18.1);

	this.c4_1 = new lib.mc_radioButton4();
	this.c4_1.parent = this;
	this.c4_1.setTransform(574.9,201.7,1,1,0,0,0,18,18.1);

	this.c4_op3 = new cjs.Text("Evaluación de Potencial y Desempeño.", "16px 'Arial'", "#333333");
	this.c4_op3.name = "c4_op3";
	this.c4_op3.lineHeight = 20;
	this.c4_op3.lineWidth = 283;
	this.c4_op3.parent = this;
	this.c4_op3.setTransform(603.8,299);

	this.c4_op0 = new cjs.Text("Estrategia del Negocio.", "16px 'Arial'", "#333333");
	this.c4_op0.name = "c4_op0";
	this.c4_op0.lineHeight = 20;
	this.c4_op0.lineWidth = 211;
	this.c4_op0.parent = this;
	this.c4_op0.setTransform(603.8,141.8);

	this.c4_op2 = new cjs.Text("Perfil de Éxito.", "16px 'Arial'", "#333333");
	this.c4_op2.name = "c4_op2";
	this.c4_op2.lineHeight = 20;
	this.c4_op2.lineWidth = 154;
	this.c4_op2.parent = this;
	this.c4_op2.setTransform(603.8,247.6);

	this.c4_op1 = new cjs.Text("Identificación de puestos críticos.", "16px 'Arial'", "#333333");
	this.c4_op1.name = "c4_op1";
	this.c4_op1.lineHeight = 20;
	this.c4_op1.lineWidth = 245;
	this.c4_op1.parent = this;
	this.c4_op1.setTransform(603.8,196.4);

	this.c4_0 = new lib.mc_radioButton4();
	this.c4_0.parent = this;
	this.c4_0.setTransform(574.9,150.2,1,1,0,0,0,18,18.1);

	this.p4 = new cjs.Text("Esta etapa inicia con la evaluación de potencial del colaborador por parte del líder y finaliza con la integración de las mediciones de potencial y desempeño en el formato de evaluación llamado “9-BOX”.", "20px 'Arial'");
	this.p4.name = "p4";
	this.p4.lineHeight = 21;
	this.p4.lineWidth = 392;
	this.p4.parent = this;
	this.p4.setTransform(113.4,-11.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.p4},{t:this.c4_0},{t:this.c4_op1},{t:this.c4_op2},{t:this.c4_op0},{t:this.c4_op3},{t:this.c4_1},{t:this.c4_2},{t:this.c4_3},{t:this.c4_op4},{t:this.c4_4},{t:this.c4_op5},{t:this.c4_5},{t:this.text_11},{t:this.text_10},{t:this.text_9},{t:this.text_8},{t:this.text_7},{t:this.text_6},{t:this.instance},{t:this.shape_5},{t:this.shape_4},{t:this.text_5},{t:this.text_4},{t:this.shape_3},{t:this.shape_2},{t:this.text_3},{t:this.text_2},{t:this.shape_1},{t:this.shape},{t:this.text_1},{t:this.text}]}).wait(1));

	// fondo y encabezado
	this.instance_1 = new lib.iconoactividadesyretos("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(502.7,104.7,0.551,0.551,0,0,0,55.7,55.7);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("rgba(230,149,122,0.498)").s().p("EgjDAJ5QjiAAAAjsIAAsZQAAjsDiAAMBGHAAAQDiAAAADsIAAMZQAADsjiAAg");
	this.shape_6.setTransform(257.8,47.7);

	this.instance_2 = new lib.fondo("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(469.6,267.3,1,1,0,0,0,485.2,268.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.shape_6},{t:this.instance_1}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.mc_p4, new cjs.Rectangle(2.4,-36.5,958.3,510.2), null);


(lib.mc_p1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		var root = this;
		var resp = 2;//numero de respuestas desde 0
		var correcta = 0; // cual es la respuesta correcta
		
		//console.log(root.p1.text, root.parent.cont, root.parent.preguntas);
		//root.parent.preguntas[root.parent.cont]=root.p1.text;
		//console.log(root.parent.preguntas[root.parent.cont], root.parent.preguntas);
		root.op0.text="Es el proceso mediante el que los líderes de negocio aseguran contar con el talento adecuado, disponible en el lugar y el momento para satisfacer sus objetivos de negocio de corto y largo plazo.";
		root.op1.text="El proceso de atraer individuos oportunamente en suficiente número y con los debidos atributos y estimularlos para que soliciten empleo en la organización.";
		root.op2.text="Es el proceso de elaboración de las políticas y objetivos de contratación y desarrollo de colaboradores en una empresa.";
		root.p1.text="¿En qué consiste la gestión de talento?";
		iniciar();
		
		function iniciar() {
			root.parent.parent.btn_siguiente.visible = false;
			for (var i = 0; i <= resp; i++) {
				root['r' + i].cursor = "pointer";
				root['r' + i].n = i;
				root['r' + i].addEventListener("click", cambios);
				root['r' + i].gotoAndStop(1);
			}
		}
		
		function cambios(r) {
			//Cambia el estatus de la opcion seleccionada
			for (var i = 0; i <= resp; i++) {
				if (root['r' + i].n != r.currentTarget.n) {
					root['r' + i].gotoAndStop(0);
				} else {
					root['r' + i].gotoAndStop(1);
				}
			}
		
			//Valida la respuesta
			if (r.currentTarget.n == correcta) {
				root.parent.parent.resultados[root.parent.parent.cont] = 10;
				console.log("Respuesta Correcta " + root.parent.parent.resultados[root.parent.parent.cont]);
			} else {
				root.parent.parent.resultados[root.parent.parent.cont] = 0;
				console.log("Respuesta Incorrecta " + root.parent.parent.resultados[root.parent.parent.cont]);
			}
			root.parent.parent.activarSiguiente();
			root.parent.parent.registrar_pregunta(root.p1.text, root['op'+r.currentTarget.n].text, root['op'+correcta].text);
			
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// txt y radio butons
	this.p1 = new cjs.Text("¿En qué consiste la gestión de talento?", "20px 'Arial'");
	this.p1.name = "p1";
	this.p1.lineHeight = 24;
	this.p1.lineWidth = 309;
	this.p1.parent = this;
	this.p1.setTransform(126.4,24.6);

	this.op2 = new cjs.Text("Es el proceso de elaboración de las políticas y objetivos de contratación y desarrollo de colaboradores en una empresa.", "16px 'Arial'");
	this.op2.name = "op2";
	this.op2.lineHeight = 20;
	this.op2.lineWidth = 400;
	this.op2.parent = this;
	this.op2.setTransform(522.1,341.9);

	this.op1 = new cjs.Text("El proceso de atraer individuos oportunamente en suficiente número y con los debidos atributos y estimularlos para que soliciten empleo en la organización.", "16px 'Arial'");
	this.op1.name = "op1";
	this.op1.lineHeight = 20;
	this.op1.lineWidth = 374;
	this.op1.parent = this;
	this.op1.setTransform(522.1,242.3);

	this.op0 = new cjs.Text("Es el proceso mediante el que los líderes de negocio aseguran contar con el talento adecuado, disponible en el lugar y el momento para satisfacer sus objetivos de negocio de corto y largo plazo.", "16px 'Arial'");
	this.op0.name = "op0";
	this.op0.lineHeight = 20;
	this.op0.lineWidth = 364;
	this.op0.parent = this;
	this.op0.setTransform(522.1,140.7);

	this.r2 = new lib.mc_radioButton();
	this.r2.parent = this;
	this.r2.setTransform(474,335.3);

	this.r1 = new lib.mc_radioButton();
	this.r1.parent = this;
	this.r1.setTransform(492,251.4,1,1,0,0,0,18,18.1);

	this.r0 = new lib.mc_radioButton();
	this.r0.parent = this;
	this.r0.setTransform(474,131.4);

	this.instance = new lib.perfoles1("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(229.1,284.9,1.477,1.477,0,0,0,91.3,91.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance},{t:this.r0},{t:this.r1},{t:this.r2},{t:this.op0},{t:this.op1},{t:this.op2},{t:this.p1}]}).wait(1));

	// fondo y encabezado
	this.instance_1 = new lib.iconoactividadesyretos("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(473.7,95.1,0.551,0.551,0,0,0,55.7,55.7);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(230,149,122,0.498)").s().p("EgiSAJ5QjsAAAAjsIAAsZQAAjsDsAAMBElAAAQDsAAAADsIAAMZQAADsjsAAg");
	this.shape.setTransform(252.4,49.7);

	this.instance_2 = new lib.fondo("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(469.6,267.3,1,1,0,0,0,485.2,268.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.shape},{t:this.instance_1}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.mc_p1, new cjs.Rectangle(2.4,-36.5,958.3,510.2), null);


(lib.M03_TMR_DESEMPEÑO = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CCCCCC").s().p("AgJAmIgLhBQgBgIAIgCQAIgCADAHIASAxQADAHACAOg");
	this.shape.setTransform(93.3,109.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#4D4D4D").s().p("AgMAAIAFgIIAUALIgMAGQgMgDgBgGg");
	this.shape_1.setTransform(100.3,104.9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#4D4D4D").s().p("AgMAFIAVgPIAEAKQAAAFgPAGg");
	this.shape_2.setTransform(102.9,104.7);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#744C28").s().p("AAmANQgBgIgNAAQgRACgHgBQgKAAgJgGIgGgHQgEAOgDACIgDALIgCAJIgIgNQADgJgCgHQgBgDABgFQAAgGACgBIAAgBQAAgBAMgFQAPgGANgCQANgBASAKQAQAKABAIQAAAHgBAKQgCAKgCABIgDADIgCADQADgGgBgMg");
	this.shape_3.setTransform(101.7,94.7);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#CCCCCC").s().p("AANAuQgHgQAAgDQAAgEgCAXIgxAAIAAhPIAJgIQALgGAMAEIAMABQANADAFAEQAIAEAVBNg");
	this.shape_4.setTransform(105.6,109);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#CCCCCC").s().p("AgDAuQgCgXgBAEQABADgHAQIgiAAQAGgdAJgZQAKgYAEgDQAKgHAVgBQAMgEAKAGQAGAEADAEIACBPg");
	this.shape_5.setTransform(97.5,109);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#F9BD9C").s().p("AgHAzIAAgBQgRgIgJgPIgBgBIgBgJIgDgBIAAgBQgBAAgBgGIgBgJIAAAAQgBgHABAAIAAgBQABAAAAAAQABAAAAAAQABABAAAAQABABAAABIABABIAAgCIgBgMQAAgQAIgEQAAgBAJgGQAKgGAKAAIACAAQAQAAANANIAAAAQAIAEAAAQQAAAGgBAGIABABIAAgCIADgBQAAAAAAAAQAAABAAAAQABAAAAABQAAAAAAABIgCAOIgCAGIAAABQgBAAAAAAQAAABgBAAQAAAAAAAAQgBAAAAAAIgBAJQgGALgMAIIgKAGIgHABIgHgBg");
	this.shape_6.setTransform(101.7,98.1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#EDAB86").s().p("AgZATQAMgaAAgIQABgFAMACIANADIACAKQADAKAGAGQAJAJghAAIgZgBg");
	this.shape_7.setTransform(101.6,103.2);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#F9BD9C").s().p("AAAATIgFgOQgRgKAFgPQADgGAJgDQABAAgCgHIAAgCQgCgFABgCQABgBAAAAQAAgBABAAQAAAAAAAAQABAAAAAAQADAAABAEIATBVIgMAGQgDgOgEgPg");
	this.shape_8.setTransform(91.7,105.9);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#9D9D9E").s().p("ABMDiQhTgZh1gqIAikTIAThtIDFAkIgrGfg");
	this.shape_9.setTransform(67.7,194.5);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AhNgLIAAgOICbAdIgGAWg");
	this.shape_10.setTransform(71.8,173.7);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FDB17B").s().p("AhMBTQgUgEgKgSQgKgQAEgTQAFgTAQgJIAAgBIAYgNQAKgFADgBIAPgEQAUgFAOgFIAHgDIABgBIADgBIADgCIAdgNIAkgWQAIgGAKAAQAJABAHAIQAHAHgBAKQgBAKgIAHIgGAEIgHADQgEACgNAJIgkAbIgDADIgCABIgBABIgHAGQgHAGgQAUIgJAMIgbAVIgHAEQgLAHgNAAQgGAAgGgCg");
	this.shape_11.setTransform(86.3,164.6);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FDB17B").s().p("AhPAnIAnh1IB4AoIgnB1g");
	this.shape_12.setTransform(71,176.3);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FDB17B").s().p("AAABrIg/gWQgXgHgDgRQgEgPAMgdQAHgRAdgrIAcgpIAPgPQAUgOAbAJQAuAPAAA6QABAQgGAcQgIAkgMAQQgTAbgJAHQgMAKgNAAQgGAAgHgCg");
	this.shape_13.setTransform(75.7,162.8);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#9D9D9E").s().p("Ah8gqIghhDIhfi0ICthlIBnC8IAjBGIBKCXIAkBOIBUDCIgWANQhfA3hJAgg");
	this.shape_14.setTransform(151.5,173.7);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AhIAjICOhQIADAMIiMBQg");
	this.shape_15.setTransform(134.7,139.1);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FDB17B").s().p("AATCOQgJgEgVgVQgOgMgWglQgTgegGgNQgEgLgCgJIhNh7QgEgGABgHQABgHAFgEQAGgFAIABQAHABAFAFIBHBTQABABAAAAQABABAAAAQABAAAAAAQABAAABAAQADgBABgCQADgIAPgGQAwgSAmAKQASAEAaASQAVAPAPAvIABAEIAJASQAMAbgBAOQgBARgSAKIhWAwQgJAFgJAAQgIAAgJgFg");
	this.shape_16.setTransform(124.9,127.3);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FDB17B").s().p("AhZgOIB8hFIA3BhIh8BGg");
	this.shape_17.setTransform(136.8,142.2);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#E39A9B").s().p("Ag3A8IAAh3IBvAAIAAB3g");
	this.shape_18.setTransform(140.7,163.3);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#E39A9B").s().p("Ag3A8IAAh3IBvAAIAAB3g");
	this.shape_19.setTransform(128,163.3);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#E39A9B").s().p("Ag3A8IAAh3IBvAAIAAB3g");
	this.shape_20.setTransform(115.2,163.3);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#CCCCCC").s().p("AhfA8IAAh4IC/AAIAAB4g");
	this.shape_21.setTransform(98.5,163.4);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#CCCCCC").s().p("AkeANIAAgZII9AAIAAAZg");
	this.shape_22.setTransform(117.6,153.8);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#CCCCCC").s().p("AkeANIAAgZII9AAIAAAZg");
	this.shape_23.setTransform(117.6,149.1);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#A6CDDA").s().p("AkcAWIAAgrII5AAIAAArg");
	this.shape_24.setTransform(117.4,143);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#CCCCCC").s().p("AkeANIAAgZII9AAIAAAZg");
	this.shape_25.setTransform(117.6,135.7);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#CCCCCC").s().p("AkeAMIAAgYII9AAIAAAYg");
	this.shape_26.setTransform(117.6,131);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#A6CDDA").s().p("AkcAWIAAgrII5AAIAAArg");
	this.shape_27.setTransform(117.4,124.8);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#CCCCCC").s().p("AkeAMIAAgYII9AAIAAAYg");
	this.shape_28.setTransform(117.6,117.6);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#CCCCCC").s().p("AiaAMIAAgXIE1AAIAAAXg");
	this.shape_29.setTransform(130.8,112.8);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#A6CDDA").s().p("AiZAWIAAgqIEzAAIAAAqg");
	this.shape_30.setTransform(130.7,106.7);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#5A6E75").s().p("Ah3AGIAAgLIDvAAIAAALg");
	this.shape_31.setTransform(127.3,94.8);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#E39A9B").s().p("Ag3AKIAAgTIBvAAIAAATg");
	this.shape_32.setTransform(120.8,97.7);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#E6E6E6").s().p("Ah3AQIAAgfIDvAAIAAAfg");
	this.shape_33.setTransform(127.3,91.2);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FFFFFF").s().p("AgEAFIACAAQAAAFACAAQABAAABgBQAAAAABAAQAAgBAAAAQAAgBAAgBQAAgCgDgCIgCgDQAAAAgBgBQAAAAAAgBQAAgBgBAAQAAgBAAAAQAAgFAEAAQAEAAABAFIAAABIgCAAIAAAAQAAgBAAgBQgBgBAAAAQgBgBAAAAQgBAAAAAAQAAAAgBAAQAAAAgBABQAAAAAAABQAAAAAAABIACADIACADQADACAAADQAAAFgFAAQgEgBAAgFg");
	this.shape_34.setTransform(117.5,148.8);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#FFFFFF").s().p("AgEAKIAAgTIAEAAQAFAAAAAGIAAAHQAAAGgFAAgAgCAJIACAAQADAAAAgEIAAgJQAAgEgDAAIgCAAg");
	this.shape_35.setTransform(116.3,148.8);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#FFFFFF").s().p("AADAKIgDgKIgCAAIAAAKIgCAAIAAgTIAEAAQAEAAAAAFQAAAEgCAAIADAKgAgCAAIACAAQABAAABAAQAAgBAAAAQABgBAAgBQAAAAAAgBQAAgBAAgBQAAAAgBgBQAAAAAAgBQgBAAgBAAIgCAAg");
	this.shape_36.setTransform(115,148.8);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#FFFFFF").s().p("AADAKIgBgFIgDAAIgBAFIgCAAIAEgTIABAAIAEATgAACAEIgCgLIgBALIADAAg");
	this.shape_37.setTransform(113.7,148.8);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#FFFFFF").s().p("AADAKIgDgRIgCARIgCAAIgDgTIACAAIACAQIADgQIABAAIADAQIACgQIACAAIgEATg");
	this.shape_38.setTransform(112.4,148.8);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#FFFFFF").s().p("AAEAKIgBgFIgEAAIgBAFIgCAAIAEgTIABAAIAEATgAACAEIgCgLIgBALIADAAg");
	this.shape_39.setTransform(110.9,148.8);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#FFFFFF").s().p("AhxB6IAAj0IDjAAIAAD0g");
	this.shape_40.setTransform(100.3,101.8);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#1FB4FB").s().p("Ak4AEIAAgHIJxAAIAAAHg");
	this.shape_41.setTransform(117.5,172.6);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#515D60").s().p("Ak4BIIAAiPIJxAAIAACPg");
	this.shape_42.setTransform(117.5,93.9);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#FFFFFF").s().p("Ak4GwIAAteIJxAAIAANeg");
	this.shape_43.setTransform(117.5,129.8);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#FDB17B").s().p("AgJgDIATAFIgKACg");
	this.shape_44.setTransform(86.3,155.5);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#FDB17B").s().p("ABGAxIg+gzIAKgBIgTgGIAJAHIhSALQgMABgJgHQgKgGgBgMQgCgLAHgKQAHgJAMgBIACgBIBdgGIABAAQAKgBAIAGIBEA/QAHAHAAAJQABAKgHAGQgGAHgJAAIgBABQgIAAgHgGg");
	this.shape_45.setTransform(85.5,156.2);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#F5A064").s().p("ABIBHQgJAAgGgGIg6g9IAFACIgKgGIAFAEIhJgSQgLgEgGgKQgGgKADgLQADgLAKgGQALgGALADIACABIBMAaIACABQAFACAEAFIA8BEQAGAHAAAKQgBAJgHAGQgGAFgIAAIgCAAg");
	this.shape_46.setTransform(85.1,158.4);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#F5A064").s().p("AAAACIgFgEIALAFg");
	this.shape_47.setTransform(85,158.6);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#D78C57").s().p("ABDBCQgHgBgEgGIgBAAIgRgVIgmgsIgLgKIADgBIAGgEIADgEIgDADQgEACgEAAIgEgBIgBAAIgBAAIgBAAIABAAIAFAEIAAABIgLACQgGABgNgBQgKgCgNgDIgIgDQgJgDgEgJQgEgIAEgJQADgIAJgEQAIgEAJAEIAGACIAQAFIAIABIABAAIAEgDQAEgDAFAAIAHABIAFACIAIAFIAHAHIANANQALANAcAjIARAWQAFAGgBAIQgCAHgGAFQgEADgGAAIgDAAg");
	this.shape_48.setTransform(81.7,160.8);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#D78C57").s().p("AgDAEIgEgEIgCAAIACAAIAAAAIACAAIADABQAEgBADgBIAFgDIgFAEIgFAEIgDAAg");
	this.shape_49.setTransform(80.9,158.7);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#FFFFFF").s().p("AgTATQgHgIgBgLQABgKAHgIQAJgIAKAAQAMAAAHAIQAIAIAAAKQAAALgIAIQgHAIgMAAQgKAAgJgIg");
	this.shape_50.setTransform(120.3,173.7);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#94B9C3").s().p("AioCYIAAkvIFRAAIAAEvg");
	this.shape_51.setTransform(142.5,147.4);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#DFE4E6").s().p("AhmCYIAAkvIDNAAIAAEvg");
	this.shape_52.setTransform(112.6,147.4);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#94B9C3").s().p("AhmCYIAAkvIDNAAIAAEvg");
	this.shape_53.setTransform(89.3,147.4);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#A6CDDA").s().p("AmRA9IAAh5IMjAAIAAB5g");
	this.shape_54.setTransform(119.2,123.7);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#DBDBDB").s().p("AjZA8IAAh3IGzAAIAAA7QAAAZgTASQgUARgbAAg");
	this.shape_55.setTransform(142.1,174.2);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#DBDBDB").s().p("AilA8QgbAAgTgRQgUgSAAgZIAAg7IHPAAIAAB3g");
	this.shape_56.setTransform(97.1,174.2);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#BDEBF8").s().p("AmmEHIAAoNINOAAIAAINg");
	this.shape_57.setTransform(118.9,139.2);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#969696").s().p("AiqAUIAAgmIFVAAIAAAmg");
	this.shape_58.setTransform(120.2,188.6);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#C7C7C7").s().p("AiqA+IBdh7ICbAAIBdB7g");
	this.shape_59.setTransform(120.2,180.4);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#000000").s().p("AnBEhIAApBIODAAIAAJBg");
	this.shape_60.setTransform(118.9,139.2);

	this.instance = new lib.Path_15();
	this.instance.parent = this;
	this.instance.setTransform(110.1,187.5,1,1,0,0,0,47.3,3.9);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#CCCCCC").s().p("Ag0C/IgzlJQgDgRAKgPQAKgOASgEQAQgEAPAHQAPAHAGAPIBfD6QAFANAHAaQAKAjAEAeg");
	this.shape_61.setTransform(73.6,96.5);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#4D4D4D").s().p("AgbAiQgigQgDgSIAYguIBpA9Ig8AgQgPgFgRgIg");
	this.shape_62.setTransform(108.5,71.5);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#4D4D4D").s().p("AhCAWIBthLIAXAuQgCASgpAYIgnATg");
	this.shape_63.setTransform(121.7,70.8);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#744C28").s().p("AC9CDQAGgggGglQgFglhCAAQhUAHgmgBQgygCgsgjIgigkQgUBMgLAIQgHAGgKAxIgJAwIgVgfQgVgfACgGQAMgugHgeQgFgVACgYQABgeALgJIABgCQgEgHBAgaQBJgfBCgFQBIgGBXAyQBUAwACAoQACAogHAyQgHA0gKACQgJABgJARIgIAQQAEgJADgQg");
	this.shape_64.setTransform(115.8,20.3);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#CCCCCC").s().p("AA/DoQghhUgBgLQgBgNgDAfQgEAdgDAwIj4AAQgBiBACiWIACh+IALgNQAOgOARgKQA2ghA7AUIA+AIQBCAMAgAUQAhAWBvGJg");
	this.shape_65.setTransform(135.3,92.4);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#CCCCCC").s().p("AgUDoQgJh/gCAgQgBAUgdBLIixAAQAiiWAvh/QAsh7AXgPQAggUBDgMQAigGAbgCQA7gUA2AhQAbAQAPAVIAGB+QAFCWADCBg");
	this.shape_66.setTransform(94.3,92.4);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#F9BD9C").s().p("AglD/IgDgBQgugZgrgqQgYgZgSgZIgCgHIgFgrIgBAAQgGgBgFgEIgEgEIAAgBQgDgDgGgfIgHgrIgBgEQgGgiAIgEIABAAQAHgDANAPIAFAFIgCgHQgHgeAAgjQAAhNApgUIABgBIAsghQA2ghA0ACIAAAAIAFAAIAAAAIAGAAQAxAAA1AgQAaAQARAQIAAABQApATAABOQAAAjgHAeIAEABQABgFAEgDQAIgHADACQAFADAAANQAAAKgEASIgGAsQgGAdgDAFIAAAAIgFAFQgEADgGABIgCAAIgBAkIgCAGQggA4g6AoIg0AeQgPAFgTAAQgRAAgUgFg");
	this.shape_67.setTransform(115.8,37.2);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#EDAB86").s().p("AiBBgQA8iHACgpQACgXBCAJQAiAFAiAJIAJAzQAPA4AeAeQAkAjiNAGg");
	this.shape_68.setTransform(115.2,63.1);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#F9BD9C").s().p("AgIBdIgXhDIAAAAQgvgfgMgnQgLgfAMgeQAJgUAXgNQAMgGAPgFQAGgEgLgiIgCgIQgJgWAIgPQAFgKAJABQANADAGAPIBlGxIhAAgQgQhGgYhPg");
	this.shape_69.setTransform(65.4,76.5);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#1C140B").s().p("AgFAAQAAgGACgGQACgEABAAQAGAAAAAQQAAARgGAAQgFAAAAgRg");
	this.shape_70.setTransform(52.9,51.6);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#927954").s().p("AgHAZQgDgLAAgOQAAgNADgLQADgKAEAAQAFAAADAKQADALAAANQAAAOgDALQgDAKgFAAQgEAAgDgKg");
	this.shape_71.setTransform(52.9,51.1);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#1C140B").s().p("AgFAAQABgGABgGQACgEABAAQAGAAgBAQQABARgGAAQgEAAgBgRg");
	this.shape_72.setTransform(16.4,51.6);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#927954").s().p("AgHAZQgDgLAAgOQAAgNADgLQADgKAEAAQAFAAADAKQADALAAANQAAAOgDALQgDAKgFAAQgEAAgDgKg");
	this.shape_73.setTransform(16.4,51.1);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#1C140B").s().p("AkuDhQgWgWAAgeQAAgdAUgVQgOgJgJgOQgIgPAAgRQAAgfAXgTQgHgLAAgNQAAgPAJgMQAJgMAOgFQgDgKAAgLQAAgfAWgWQAVgWAfAAIAFAAQAHgTARgLQARgMAUAAQAQAAAPAIQAGgZAUgQQAUgQAaAAQAVAAARAKQARgSAbAAQAhAAAUAbIAHAAQAPAAAKAKQALAKABAOQAMgEANAAQAiAAAZAYQAYAYAAAjIAAABIALgBQAbAAATATQAUATAAAcQAAAUgLAPQAWAWAAAdQAAAigaAWQAQALAJAQQAJARAAATQAAAfgWAWQgVAVgfAAQgXAAgTgNQgTgMgIgVQgSgEgLgOQgLgOAAgSIAAgIQgKACgJAAQgjAAgZgZQgZgYAAgkIAAgHQgKAFgOAAQgTAAgPgMQgQgMgFgSIgCAAQgSAAgNgKQgNgLgEgRIgEgCIABAHQAAAQgIANQgIANgNAIQAKASAAASQAAAZgPATQgQASgXAGQACAGAAAIQAAAMgGALQgHAKgLAFQgEAbgUATQgVASgbAAQgfAAgVgVg");
	this.shape_74.setTransform(33.6,24.6);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#A25F37").s().p("AgKgbQAKgRAJACQAFABADAEQAEAigTAaIgTAUg");
	this.shape_75.setTransform(53.2,46.5);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#A25F37").s().p("AgBAXQgTgaAEgiIAIgFQAJgCAKARIAHBGQgLgGgIgOg");
	this.shape_76.setTransform(15.2,46.5);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#A25F37").s().p("Ag+D5QhGgtgnhUQgLgGgJgNQgUgbAFgjIAIgFQALgBAJARQgOgngGgwQgMhhAngwIApgsQA2gtBCgHIAUAAQBDAHA3AtQAbAXANAVQAoAwgNBhQgHAwgOAnQAKgRALABQAFABADAEQAFAjgUAbIgUATQgnBUhHAtQgVAPgYAJIgRAGQgbgHgjgXg");
	this.shape_77.setTransform(34.3,38.6);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#1C140B").s().p("AgHB+QgOgJgKgOQgGADgEAAQgPAAgLgMQgLgKAAgQIABgIIgNABQgZAAgSgSQgTgSAAgZQAAgTAKgPQAKgPARgHQgPgOAAgTQAAgSANgNQAMgNASAAQAYAAANATQAOgFAQAAQAggBAXAXQAWAXAAAgQAAAXgMATQAcAGAOAbQAKgEAIAAQAUAAANAOQAOAOAAAUQAAATgOAOQgNAOgUABQgRgBgNgKQgVAUgcAAQgSAAgPgIg");
	this.shape_78.setTransform(18.4,52.4);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#1C140B").s().p("AhzBZQgPgPAAgUQAAgVAPgPQAPgPAVAAIAAAAQAAgUAPgPQAOgOAVgBQADgWARgPQARgPAWAAQASAAAPAJQAMgNARAAQAQAAALALQALAMAAAQQAAAQgLALQgLAMgQAAIgBgBQgEASgNAMQgMAOgSAEIAAAEQAAAagSASQgSASgZAAQgLAAgKgEQgRAUgYAAQgVAAgPgPg");
	this.shape_79.setTransform(51.1,55.8);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#9D9D9E").s().p("AgiBcIgpg6QgHgTAFgYQAJgzA2gfIAfA8QAlBGAaA1g");
	this.shape_80.setTransform(53.8,87.1);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#9D9D9E").s().p("Ag3BeQAFhhAPg3IANgjIBOA9IgUB+g");
	this.shape_81.setTransform(17.4,86.9);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#FFFFFF").s().p("AgugZIAsgQIAxAsIgkAng");
	this.shape_82.setTransform(29.1,75.9);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#FFFFFF").s().p("AguAEIAzgvIAqAQIg6BHg");
	this.shape_83.setTransform(38.5,75.8);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#CCCBCB").s().p("AALAfIg3g9IAggLIA5AnIgeAsg");
	this.shape_84.setTransform(29.3,76.6);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#CCCBCB").s().p("AgqAAIA8gnIAZALIg3A2IgEAOg");
	this.shape_85.setTransform(38.1,76.4);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#9F5733").s().p("AhVAMIAkgQQAHgGACgFQAFgNgDgtIBLgCIgBAeQgBAfADAGIAHADIAoAQIg+A7IgcgaIgBAAIgBAAIghAgg");
	this.shape_86.setTransform(34.5,72);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#FFFFFF").s().p("AgngFIgthAIBSghIBXAfIg9A8IgdByg");
	this.shape_87.setTransform(34.4,80.2);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#626568").s().p("AgNCDIhDh2IAfgOIgzgMIgphFICNgwICOA0IhDBNIgpgBIAaATIg3Byg");
	this.shape_88.setTransform(34.6,83.2);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#606060").s().p("AgMCBIhHhxIAhgQIg3gKIgqhCQAPgEAJgFIA3gUIAFgCIBCgVIA3ATIAJAEIBRAlIhABEIgtAAIAcATIg8Bug");
	this.shape_89.setTransform(34.4,83.5);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#9D9D9E").s().p("AiKCDQgHgOgBgHQgEgSADgTIAJglQADgPgKgRIgRgbQgVgjgCABQAMgFAWgIQAZgIAKgFIA2gUIBKgbIA+AbIA3AaQAiAPAXAKIgNAPQgIALgFAMQgEANACAJIAEALQAUAygTArQgDAHgHAMg");
	this.shape_90.setTransform(33.8,83.3);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#3F3231").s().p("AjaChIgQgFQgDABgEgNQgKgcgLhKQgGgiAPgcQALgWAVgRQgCgeAKgaQAQgmApgSQgFAGgGALQgMAUgEAQQAAAAAAAAQAAABAAAAQABAAAAABQAAAAAAAAQABAAAAAAQABAAAAAAQABAAAAAAQABAAAAAAQAYgeAugVQBIgiBogCQgmAFgbAQQgBAAAAABQgBAAAAABQAAAAAAABQAAABAAAAQABADADAAQAsgGArAFQBCAGAqAbQgMgCgRABQAAAAAAAAQgBAAAAAAQAAAAAAAAQAAABgBAAQAAAAAAABQAAAAABABQAAAAAAAAQAAAAABAAQAhAOAXAWQAlAkAAAyQgNgQgKgKQAAAAAAAAQAAgBgBAAQAAAAAAABQAAAAgBAAQAAAAAAAAQAAAAgBABQAAAAAAAAQAAABAAAAQAPAmgLAoQgCgKgMgNQgCA9gRBQQgSgCgMAUIgJAUQACgcgCgiQgDhCgSgbQgthFh9ACQgoABgqAHIgjAIQgXA3geAgQgCAKgDA+IgDA8QgDghgQgKg");
	this.shape_91.setTransform(190,25.4);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#3F3231").s().p("AA4AlQgKgCgIgGQgLgJAAgOIAAgDQgJgIgMABIgDAAQgLgBgKAIIAAADQABAOgLAJQgJAGgKACIhdAAIgDgBQgOgGgHgKQgFgIAAgHIAAgGIgbADIgEgSIAhgEQAHgMAVgEIBWAAQAYAAAKARQAMgFALABQAMgBANAFQADgGAIgFQAJgGANAAIBXAAQAUAEAIAMIAYACIgDAMIgUAFIAAAGQABAHgGAIQgGAKgPAGIgCABgAApgSIAAAcIACAGQADAHAIAFIBjAAQALgDAAgOIAAgcQgCgIgLAAIhjAAQgLADAAAEgAibgSIAAAcIACAGQADAHAIAFIBjAAQALgDAAgOIAAgcQgCgIgLAAIhjAAQgLACAAAFg");
	this.shape_92.setTransform(188.1,41);

	this.instance_1 = new lib.Group_18();
	this.instance_1.parent = this;
	this.instance_1.setTransform(222.3,87.5,1,1,0,0,0,2.5,6.3);
	this.instance_1.alpha = 0.391;

	this.instance_2 = new lib.Group_1_1();
	this.instance_2.parent = this;
	this.instance_2.setTransform(218.6,90.1,1,1,0,0,0,1.5,3.8);
	this.instance_2.alpha = 0.391;

	this.instance_3 = new lib.Group_2_1();
	this.instance_3.parent = this;
	this.instance_3.setTransform(218.4,86.8,1,1,0,0,0,3.4,7.2);
	this.instance_3.alpha = 0.391;

	this.instance_4 = new lib.Group_3_1();
	this.instance_4.parent = this;
	this.instance_4.setTransform(161.4,86.8,1,1,0,0,0,3.3,7.2);
	this.instance_4.alpha = 0.391;

	this.instance_5 = new lib.Group_4_1();
	this.instance_5.parent = this;
	this.instance_5.setTransform(159.7,88.8,1,1,0,0,0,1.8,5);
	this.instance_5.alpha = 0.391;

	this.instance_6 = new lib.Group_5_1();
	this.instance_6.parent = this;
	this.instance_6.setTransform(157,87.2,1,1,0,0,0,2.4,6.7);
	this.instance_6.alpha = 0.391;

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#A9B3BC").s().p("AhEAQIBwhBIAZAxQgDATgkARIgiAOg");
	this.shape_93.setTransform(196.3,77.2);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#A9B3BC").s().p("AgYAlQgrgZgDgTIAZgyIBzBQIg1AiQgTgIgWgMg");
	this.shape_94.setTransform(182.4,76.4);

	this.instance_7 = new lib.Group_6_1();
	this.instance_7.parent = this;
	this.instance_7.setTransform(192.7,86,1,1,0,0,0,0.8,7.9);
	this.instance_7.alpha = 0.391;

	this.instance_8 = new lib.Group_7_1();
	this.instance_8.parent = this;
	this.instance_8.setTransform(197.7,85.7,1,1,0,0,0,0.8,8.2);
	this.instance_8.alpha = 0.391;

	this.instance_9 = new lib.Group_8_1();
	this.instance_9.parent = this;
	this.instance_9.setTransform(201.9,85.4,1,1,0,0,0,0.8,8.3);
	this.instance_9.alpha = 0.391;

	this.instance_10 = new lib.Group_9_1();
	this.instance_10.parent = this;
	this.instance_10.setTransform(214.2,85.7,1,1,0,0,0,0.8,8);
	this.instance_10.alpha = 0.391;

	this.instance_11 = new lib.Group_10_1();
	this.instance_11.parent = this;
	this.instance_11.setTransform(210.7,85.2,1,1,0,0,0,0.8,8.6);
	this.instance_11.alpha = 0.391;

	this.instance_12 = new lib.Group_11_1();
	this.instance_12.parent = this;
	this.instance_12.setTransform(205.6,84.8,1,1,0,0,0,0.8,8.8);
	this.instance_12.alpha = 0.391;

	this.instance_13 = new lib.Group_12_1();
	this.instance_13.parent = this;
	this.instance_13.setTransform(187,86,1,1,0,0,0,0.7,7.9);
	this.instance_13.alpha = 0.391;

	this.instance_14 = new lib.Group_13_1();
	this.instance_14.parent = this;
	this.instance_14.setTransform(182.1,85.7,1,1,0,0,0,0.8,8.2);
	this.instance_14.alpha = 0.391;

	this.instance_15 = new lib.Group_14_1();
	this.instance_15.parent = this;
	this.instance_15.setTransform(177.8,85.4,1,1,0,0,0,0.8,8.3);
	this.instance_15.alpha = 0.391;

	this.instance_16 = new lib.Group_15_1();
	this.instance_16.parent = this;
	this.instance_16.setTransform(165.5,85.7,1,1,0,0,0,0.8,8);
	this.instance_16.alpha = 0.391;

	this.instance_17 = new lib.Group_16_1();
	this.instance_17.parent = this;
	this.instance_17.setTransform(169,85.2,1,1,0,0,0,0.8,8.6);
	this.instance_17.alpha = 0.391;

	this.instance_18 = new lib.Group_17_1();
	this.instance_18.parent = this;
	this.instance_18.setTransform(174.1,84.8,1,1,0,0,0,0.8,8.8);
	this.instance_18.alpha = 0.391;

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#BBCACB").s().p("AjLBtQAyiZAUgNQAigWBIgNQAjgGAdgCQA/gVA5AjQAdARAQAWIACCcg");
	this.shape_95.setTransform(171.8,85.7);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#CCD0D0").s().p("AjSBtIAHicIALgNQAQgPASgLQA5gjA/AVIBAAIQBIANAiAWQAMAIAWAtQAUArAZBGg");
	this.shape_96.setTransform(207.9,85.7);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#E8AF93").s().p("AAcAAQgGgDgHAAIgMgBIgZAEQgPACgMAFQALgHAOgFQAKgDAQgCIAPABQAGABAIADQAOAGAEAKQgIgIgNgDg");
	this.shape_97.setTransform(178.6,39);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#E1BB93").s().p("AgjEOQgYgJgfgWQg9gqgjg8QgCgCAAgEIgBgnIgCAAQgLAAgEgJIgBAAQgDgFgGggIgHguQgEgSAAgMQAAgPAFgBQAEgCAJAHQAEAEAAAEIAEgBQgHggAAglQAAhSArgVIABgBIAugiQA3giA1AAIAMAAQA2gCA6AiQAdASASASIABABQArAVAABSQAAAlgHAgIgCAHIAGgFIAJgJQAIgFAEACIAAAAQAJAEgHAkIgIAyQgGAggDAEIgBABQgFAJgKAAIgCAAIgFAuQAAAEgCADQgSAagbAbQgtAugxAaIgDABQgWAFgTAAQgTAAgQgGg");
	this.shape_98.setTransform(188.5,40.8);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#D6AE89").s().p("AgSBnQiWgFAmglQAhghAPg7IAKg2IBIgPQBHgLABAaQABAbAhBSIAhBNQg2ADgxAAIg2gBg");
	this.shape_99.setTransform(189.2,68.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_99},{t:this.shape_98},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.instance_18},{t:this.instance_17},{t:this.instance_16},{t:this.instance_15},{t:this.instance_14},{t:this.instance_13},{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.shape_94},{t:this.shape_93},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.instance},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.M03_TMR_DESEMPEÑO, new cjs.Rectangle(0,0,229,217.1), null);


(lib.listoahora = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.text = new cjs.Text("Ya listo para asumir la posición destino.", "8px 'Arial'", "#333333");
	this.text.textAlign = "center";
	this.text.lineHeight = 9;
	this.text.lineWidth = 53;
	this.text.parent = this;
	this.text.setTransform(69.4,73.9,2.067,2.067);

	this.text_1 = new cjs.Text("Listo ahora", "bold 8px 'Arial'", "#FFFFFF");
	this.text_1.lineHeight = 10;
	this.text_1.lineWidth = 53;
	this.text_1.parent = this;
	this.text_1.setTransform(23,12.8,2.067,2.067);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#39B54A").s().p("ArEDUIAAiwQAAj3D5AAIOYAAQD3AAAAD3IAACwg");
	this.shape.setTransform(70.9,21.2);

	this.instance = new lib.cajaatraslistoahora("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(69.4,114.5,2.067,2.067,0,0,0,33.4,35);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance},{t:this.shape},{t:this.text_1},{t:this.text}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,142,182.7);


(lib.graficatoda = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.circulo4g();
	this.instance.parent = this;
	this.instance.setTransform(249.3,308.9,0.944,0.944,0,0,0,53,53);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhIACIAmhBIBrA+IgmBBg");
	this.shape.setTransform(84.6,81.9,0.937,0.937);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AhJgCIAohAIBrBFIgoBAg");
	this.shape_1.setTransform(410.3,269.5,0.937,0.937);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AhLAAIByhAIAlBBIhyBAg");
	this.shape_2.setTransform(86.4,271.1,0.937,0.937);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AhOACIB3hFIAmBCIh3BFg");
	this.shape_3.setTransform(410.9,80.6,0.937,0.937);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#F6C1A5").s().p("AgEAAIAEgDIAFACIgBADIgFACg");
	this.shape_4.setTransform(132.4,115.2,0.937,0.937);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#F6C1A5").s().p("AgDACIgBgDIAEgCIAFADIgDAEg");
	this.shape_5.setTransform(127.1,115.2,0.937,0.937);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#CCCC00").s().p("AgTAZQgJgKAAgPQAAgNAIgKQAJgKALAAQALAAAKAKQAIAKAAANQAAAOgJALQgJAJgLAAQgKAAgJgJg");
	this.shape_6.setTransform(128.7,105.9);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#CCCC00").s().p("AgvAgQgGABAAgHIAAgNQAAgOAIgMQAIgMANgHIAAABQAKANAOAAQAPAAAKgNIAAgBQANAHAIAMQAIAMAAAOIAAANQAAAHgGgBg");
	this.shape_7.setTransform(128.7,111.9);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgyBHQgFAAgDgDQgDgEAAgEIAAgOQAAgRAJgOQAJgOAQgGIABAAQgHgLgBgOQAAgRAKgLQAKgMAOAAQAPAAAKAMQAJALABARQAAAOgIALIABAAQAQAGAJAOQAJAOAAARIAAAOQAAAEgDAEQgEADgEAAg");
	this.shape_8.setTransform(130,108.7,0.937,0.937);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#3A332D").s().p("AAKAJQAAgBAAgBQAAgBAAAAQAAgBAAAAQgBAAAAAAQgCgDgHACIgHADQgIABgBgJQgBgFACgDQACgDADABQAFACADgBQACgBAEABIAJADIADACQAEAGgEAGIgCACIgFAEIABgEg");
	this.shape_9.setTransform(129.6,109.5,0.937,0.937);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#DAC6AC").s().p("AAAAKIgBgDIgDgBQAAgBgBAAQAAAAAAgBQAAAAgBgBQAAAAAAgBIgBgCIAAgFIABgCQAEgDAFABIAEACIAAACIABAFIAAACQAAABAAAAQAAAAgBABQAAAAgBABQAAAAgBAAIAAAEIgBABIgDABIgBgBg");
	this.shape_10.setTransform(129.8,110.3,0.937,0.937);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#344359").s().p("AAZAmIgHgFQgEgCgFgBIgaAAQgIACgBgBIAAgBIABgLQABgKAGgYIACgIIABgFIAHgHQAEgDAEABQALACADACIAFAIQAEAIABAIIADAmQAAAJgBAAg");
	this.shape_11.setTransform(129.8,114.6,0.937,0.937);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#2F3D50").s().p("AgEAAIAEgCIAFAAIAAACIgFADg");
	this.shape_12.setTransform(128.7,125.4,0.937,0.937);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#D3D3D3").s().p("AgEAzIgIg2IAAgrIAZgEIgLBlg");
	this.shape_13.setTransform(129,120.4,0.937,0.937);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#344359").s().p("AgNAMIAOgaIANgDIgLAYIgJALg");
	this.shape_14.setTransform(128,112.8,0.937,0.937);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#D3D3D3").s().p("AgIAHIgFgpIABgRIAZABIABAKIgFAvIAEArIgGACg");
	this.shape_15.setTransform(130.8,120.4,0.937,0.937);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#2F3D50").s().p("AgEACIADgCIAFgFIABAHIgGADg");
	this.shape_16.setTransform(131.6,125.3,0.937,0.937);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#F6C1A5").s().p("AgDAAIADgFIACADIACAFIgEADg");
	this.shape_17.setTransform(124.7,113.2,0.937,0.937);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#F6C1A5").s().p("AgDADIACgGIADgCIACAFIgDAFg");
	this.shape_18.setTransform(116.1,113.4,0.937,0.937);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#6699CC").s().p("AgQAVQgIgJAAgMQAAgLAIgIQAHgJAJAAQAKAAAIAJQAGAHABAMQAAAMgIAJQgIAIgJAAQgIAAgIgIg");
	this.shape_19.setTransform(119.1,109);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#6699CC").s().p("AgoAcIgEgCQAAAAgBgBQAAAAAAAAQgBgBAAgBQAAAAAAgBIAAgLQAAgMAIgKQAHgKALgGIAAABQAJAKALAAQANAAAIgKIABgBQALAGAHAKQAHAKAAAMIAAALQAAAGgGAAg");
	this.shape_20.setTransform(119.1,114.1);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AgrA9QgEgBgDgCQgCgDAAgEIAAgLQAAgPAIgMQAHgMAOgFIABAAQgGgKgBgMQAAgOAJgJQAIgKAMAAQAMAAAJAKQAJAJAAAOQgBAMgGAKIABAAQAOAFAHAMQAIANAAAOIAAALQAAAEgDADQgDACgEABg");
	this.shape_21.setTransform(120.5,111.3,0.937,0.937);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#3A332D").s().p("AgLAKIgBgBIACgEIABgCIACgEQAAgEABgBIAFgCIAGgFQAEgBACADQADAEgCADQgBACgGABQgFABAAADQAAABAAAAQAAABAAAAQAAABAAAAQAAABAAAAIAAABQgBAAAAABQgBAAAAABQAAAAAAABQAAAAAAABIAAAAQAAAAAAABQAAAAAAAAQAAAAgBABQAAAAgBAAQgHAAAAgEg");
	this.shape_22.setTransform(119.9,110.7,0.937,0.937);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#DAC6AC").s().p("AAAACIgBAAIAAgCIAAgBIADgBIAAAEIAAABg");
	this.shape_23.setTransform(120.4,111.9,0.937,0.937);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#DAC6AC").s().p("AgFAFQgDgFACgEQADgEAEAAQAGAAABAGIgBAGQgCAFgDAAIgCAAQgDAAgCgEg");
	this.shape_24.setTransform(120.4,111.1,0.937,0.937);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#3A332D").s().p("AAAALQAAAAAAAAQgBgBAAAAQAAgBAAAAQAAgBABgBQABgFgBgCIgCgEIgDgDIABgBIABgCQABgBAAAAQABAAAAAAQABAAAAAAQAAABAAAAIADAEIABAEIgBAGIAAABIACACQAAAAAAABQABABAAAAQAAABgBAAQAAABAAAAIgCABIgDgBg");
	this.shape_25.setTransform(121.1,111.1,0.937,0.937);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#8B6656").s().p("AgHAAIACgEIAMADIAAgBIABAHg");
	this.shape_26.setTransform(122.1,114.3,0.937,0.937);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#F6C1A5").s().p("AAAACIgDgCIABgCIADACIAAgCIADADIgBACg");
	this.shape_27.setTransform(121.3,113.9,0.937,0.937);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#8B6656").s().p("AAHANIgQgSIgDgJIAHACIASAVIgFAGg");
	this.shape_28.setTransform(122.1,113.4,0.937,0.937);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#5FB6DA").s().p("AgSAuIAFgbIACgYIACgdQAAgIADgDQABAAAAAAQAAgBABAAQAAAAABAAQAAAAAAAAQADAAACADIAFAMQAFAMgBAqQABAJAHANIgTACg");
	this.shape_29.setTransform(120.7,116.3,0.937,0.937);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#5FB6DA").s().p("AgWAuIgGgDIgFgCIAEgGIACgHIAKhAIAFgFIACgCQAHgEAIACIABAAQAEABAHALIACACIAFAPQAEAMABALIAEAVIABAKQAAABAAABQAAABgBAAQAAABAAAAQAAABgBAAQgDACgHAAIgeABIgOAAg");
	this.shape_30.setTransform(120.4,116.3,0.937,0.937);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#344359").s().p("AgFACIABgEIAEAAIAFADIAAACg");
	this.shape_31.setTransform(121.8,125.5,0.937,0.937);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#344359").s().p("AABAlIgMhJIAXAFIgHBEg");
	this.shape_32.setTransform(121.3,121.6,0.937,0.937);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#344359").s().p("AACAEIgHgEIABgEIAEAAIAFAEIABABIgBADg");
	this.shape_33.setTransform(119.4,125.4,0.937,0.937);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#344359").s().p("AgIAlIACgjIgEgnIAVAJIgBADIgEAgIgKAfg");
	this.shape_34.setTransform(119.9,121.3,0.937,0.937);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#BC6756").s().p("AgDAAIADgFIACADIACAFIgEADg");
	this.shape_35.setTransform(143.6,113.2,0.937,0.937);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#BC6756").s().p("AgDADIACgGIACgCIADAFIgDAFg");
	this.shape_36.setTransform(135,113.4,0.937,0.937);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#6699CC").s().p("AgQAVQgIgIAAgNQAAgMAHgHQAIgJAJAAQAKAAAHAJQAIAIAAALQAAANgIAIQgHAIgKAAQgJAAgHgIg");
	this.shape_37.setTransform(138,109);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#6699CC").s().p("AgoAcQgGAAAAgGIAAgLQAAgMAHgKQAHgKALgGIABABQAJAKALAAQANAAAIgKIAAgBQAMAGAHAKQAHAKAAAMIAAALQAAABAAAAQAAABgBABQAAAAAAAAQgBABAAAAQgBABAAAAQAAAAgBAAQAAABgBAAQAAAAgBAAg");
	this.shape_38.setTransform(138,114.1);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#FFFFFF").s().p("AgqA9QgFgBgCgCQgDgDAAgEIAAgLQAAgOAIgNQAHgMAOgFIABAAQgGgKgBgMQAAgOAJgJQAJgKALAAQANAAAIAKQAJAJAAAOQgBAMgFAKIAAAAQAOAFAHAMQAIAMAAAPIAAALQAAAEgDADQgCACgEABg");
	this.shape_39.setTransform(139.2,111.3,0.937,0.937);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#A5B4BA").s().p("AgOAIIABgIIAWgWIAGgCIgEAEIgKAVIgGAFIAFANIgDAGg");
	this.shape_40.setTransform(137.6,113.8,0.937,0.937);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#504A45").s().p("AABAAQgDAAgDACIgCACIgBADQgDACAAgIIgCgFIAAgBIACgBIALgEIABAAIAGAEIAFADQACACAAAFQAAABgFAGQAAgKgIgBg");
	this.shape_41.setTransform(139.5,109.7,0.937,0.937);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#BC6756").s().p("AgEAKIABgDIgDgBIgCgCQgCgDACgJIABgBIACgBQAFgBAGACIABAAIADABIAAADIgDAGQgCAEgCABIgBABIAAADQAAABAAAAQgBAAAAAAQAAAAgBAAQAAAAAAAAIgEgBg");
	this.shape_42.setTransform(139.6,110.7,0.937,0.937);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#E2E2E2").s().p("AgVAjQgDgDAAgDQAAgdAFgPQAEgOAGgGIAFgDIAQACIAKAmIACAUQADAPgHgCQgDgBgdAFIgCAAQgEAAgDgEg");
	this.shape_43.setTransform(139.4,115.1,0.937,0.937);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#233040").s().p("AgEAAIAEgCIAEAAIAAACIgEADg");
	this.shape_44.setTransform(137.9,125.5,0.937,0.937);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#457EC9").s().p("AgHAqIgEg9IACgVIAVgCIgOBVg");
	this.shape_45.setTransform(138.6,121.3,0.937,0.937);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#233040").s().p("AgDAAIAAgCIAEAAIADACIgCADg");
	this.shape_46.setTransform(140.8,125.7,0.937,0.937);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#457EC9").s().p("AgLgnIAWAEIABAcIgEAuIgEABg");
	this.shape_47.setTransform(140.1,121.8,0.937,0.937);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#5C2C14").s().p("AjUAaQgFAAgEgDQgEgFAAgGIAAgXQAAgGAEgEQAEgFAFAAIGoAAQAGAAAEAFQAEAEAAAGIAAAXQAAAGgEAFQgEADgGAAg");
	this.shape_48.setTransform(129.4,87.3,0.937,0.937);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#785548").s().p("AguAMQgEAAgDgDQgCgDAAgFIAAgBQAAgFACgDQADgEAEABIBcAAQAFgBACAEQADADAAAFIAAABQAAAFgDADQgCADgFAAg");
	this.shape_49.setTransform(149.6,119.2,0.937,0.937);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#598415").s().p("AgmAeQgHgIAAgJQAAgNAKgHIAAgCQAAgFADgDQACgDAFAAQADAAAEADQAJgMANAAQAMAAAJAJQAIAIABAMQAMAEAAANQAAAIgEAFg");
	this.shape_50.setTransform(149.6,116.9,0.937,0.937);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#785548").s().p("AgbANQgFAAgDgEQgEgEABgFQgBgEAEgEQADgEAFAAIA3AAQAFAAADAEQAEAEAAAEQAAAFgEAEQgDAEgFAAg");
	this.shape_51.setTransform(129.9,83.9,0.937,0.937);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#785548").s().p("Ag4ANQgEAAgEgEQgEgEABgFQgBgEAEgEQAEgEAEAAIBxAAQAFAAADAEQADAEABAEQgBAFgDAEQgDAEgFAAg");
	this.shape_52.setTransform(141.7,83.9,0.937,0.937);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#785548").s().p("Ag4ANQgEAAgEgEQgDgEAAgFQAAgEADgEQAEgEAEAAIBxAAQAFAAADAEQADAEAAAEQAAAFgDAEQgDAEgFAAg");
	this.shape_53.setTransform(118.3,83.9,0.937,0.937);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#785548").s().p("AguAMQgDAAgEgDQgDgDAAgFIAAgBQAAgFADgDQAEgEADABIBcAAQAEgBADAEQAEADAAAFIAAABQAAAFgEADQgDADgEAAg");
	this.shape_54.setTransform(160.8,119.2,0.937,0.937);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#598415").s().p("AAVAUIgHABQgKAAgFgGQgEALgLAAQgFAAgFgEQgEAHgIAAQgFAAgEgEQgDgEAAgGQAAgGADgEQAEgFAFAAQAEAAACACQAEgMAMAAQADAAAEACQACgIAGgGQAGgGAJAAQAIAAAHAGQAHAGAAAKQAHABAEAFQAEAEAAAHQAAAHgEAGQgGAFgHAAQgJAAgEgJg");
	this.shape_55.setTransform(160.8,117.2,0.937,0.937);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#785548").s().p("AgtAMQgFAAgDgDQgCgDAAgFIAAgBQAAgFACgDQADgEAFABIBbAAQAFgBACAEQADADAAAFIAAABQAAAFgDADQgCADgFAAg");
	this.shape_56.setTransform(99.4,119.2,0.937,0.937);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#598415").s().p("AAbAWQgFAEgFAAQgLAAgEgLQgGAGgIAAIgHgBQgGAJgJAAQgHAAgEgFQgFgGgBgHQAAgHAFgEQAEgFAGgBQABgKAHgGQAHgGAJAAQAIAAAFAGQAHAGABAIQAFgCADAAQAMAAAEAMQADgCACAAQAGAAADAFQAFAEAAAGQAAAGgFAEQgDAEgGAAQgHAAgEgHg");
	this.shape_57.setTransform(99.4,117.2,0.937,0.937);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#785548").s().p("AgtAMQgEAAgDgDQgEgDAAgFIAAgBQAAgFAEgDQADgEAEABIBcAAQADgBADAEQAEADAAAFIAAABQAAAFgEADQgDADgDAAg");
	this.shape_58.setTransform(110.7,119.2,0.937,0.937);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#598415").s().p("AgpAeQgEgFAAgIQAAgNAMgEQABgMAJgIQAIgJAMAAQANAAAJAMQADgDAEAAQAEAAADADQADADAAAFIAAACQAKAHAAANQAAAKgHAHg");
	this.shape_59.setTransform(110.7,116.9,0.937,0.937);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#D25558").s().p("AiXArQgHgBgEgFQgGgGAAgHIAAgvQAAgIAGgFQAEgGAHAAIEvAAQAHAAAEAGQAFAFABAIIAAAvQgBAHgFAGQgEAFgHABgAidgXIAAAvQAAAHAGAAIEvAAQAGAAAAgHIAAgvQAAgHgGAAIkvAAQgGAAAAAHg");
	this.shape_60.setTransform(129.5,94.4,0.937,0.937);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#FFFFFF").s().p("AiXAlQgFAAgDgEQgDgDAAgGIAAgvQAAgFADgEQADgEAFAAIEvAAQAEAAAEAEQADAEAAAFIAAAvQAAAFgDAEQgEAEgEAAg");
	this.shape_61.setTransform(129.5,94.4,0.937,0.937);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#FFFFFF").s().p("AA7ArIAAhBQAAgDgCgCQgDgCgDgBIh5AAIAAgMIB5AAQAIAAAGAFQAGAGAAAJIAABBg");
	this.shape_62.setTransform(155.3,116.3,0.937,0.937);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#FFFFFF").s().p("AhGArIAAhBQAAgJAGgGQAFgFAJAAIB5AAIAAAMIh5AAQgIABAAAHIAABBg");
	this.shape_63.setTransform(103.6,116.3,0.937,0.937);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#7F8C8D").s().p("AgnBAQgHAAgFgFQgEgFAAgIIAAhbQAAgIAEgFQAFgFAHAAIBPAAQAHAAAFAFQAEAFAAAIIAABbQAAAIgEAFQgFAFgHAAgAgug1QgEADAAAFIAABbQAAAFAEADQADAEAEAAIBPAAQAEAAADgEQADgDAAgFIAAhbQAAgFgDgDQgDgDgEAAIhPAAQgEAAgDADg");
	this.shape_64.setTransform(156.9,104.1,0.937,0.937);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#FFFFFF").s().p("AgnA9QgGAAgEgEQgDgFAAgGIAAhbQAAgGADgEQAEgFAGAAIBPAAQAFAAAEAFQAFAEAAAGIAABbQAAAGgFAFQgEAEgFAAg");
	this.shape_65.setTransform(156.9,104.1,0.937,0.937);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#4A7186").s().p("AgnBAQgHAAgFgFQgEgFAAgIIAAhbQAAgIAEgFQAFgFAHAAIBPAAQAHAAAFAFQAEAFAAAIIAABbQAAAIgEAFQgFAFgHAAgAgug1QgDADAAAFIAABbQAAAFADADQADAEAEAAIBPAAQAEAAADgEQADgDAAgFIAAhbQAAgFgDgDQgDgDgEAAIhPAAQgEAAgDADg");
	this.shape_66.setTransform(102.7,104.1,0.937,0.937);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#FFFFFF").s().p("AgnA9QgGAAgDgEQgEgFAAgGIAAhbQAAgGAEgEQADgFAGAAIBPAAQAGAAAEAFQADAEAAAGIAABbQAAAGgDAFQgEAEgGAAg");
	this.shape_67.setTransform(102.7,104.1,0.937,0.937);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#FFFFFF").s().p("AgDBlIAAjJIAIAAIAADJg");
	this.shape_68.setTransform(130.4,110.9,0.937,0.937);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#FFFFFF").s().p("AgDBlIAAjJIAHAAIAADJg");
	this.shape_69.setTransform(128.7,110.9,0.937,0.937);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#66B2D6").s().p("AizBfIAAi8IFnAAIAAC8g");
	this.shape_70.setTransform(128.3,111);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#EE852F").s().p("AjNCwIAAlfIGaAAIAAFfg");
	this.shape_71.setTransform(129.5,103.8,0.937,0.937);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#6C3C22").s().p("AjTAaQgGAAgEgDQgEgFAAgGIAAgXQAAgGAEgEQAEgEAGgBIGoAAQAFABAEAEQAEAEAAAGIAAAXQAAAGgEAFQgEADgFAAg");
	this.shape_72.setTransform(144.9,93,0.937,0.937);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#6C3C22").s().p("AjUAaQgFAAgEgDQgEgFAAgGIAAgXQAAgGAEgEQAEgEAFgBIGoAAQAGABAEAEQAEAEAAAGIAAAXQAAAGgEAFQgEADgGAAg");
	this.shape_73.setTransform(114.3,93,0.937,0.937);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#EECC67").s().p("AiKCPIAAkdIEVAAIAAEdg");
	this.shape_74.setTransform(151.5,107,0.937,0.937);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#EECC67").s().p("AiKCPIAAkdIEVAAIAAEdg");
	this.shape_75.setTransform(108,107,0.937,0.937);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#181C23").s().p("AgLAIQgCgDAAgFQAAgIAIgDQAIgCAGAIIAFAEIgDACIgKABQgBAAAAAAQAAAAAAABQgBAAAAAAQAAABAAAAQAAABgBAAQAAABgBAAQAAABAAAAQgBAAAAAAIgBgDIgBgBIgBABQAAABAAAAQAAABAAAAQAAAAABABQAAAAABAAIAAAFIgGgEg");
	this.shape_76.setTransform(121.6,232.1,0.937,0.937);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#1C3355").s().p("AgDADQgLgCAAgDQABgCAEgBIADAAIAVAHIAAAEg");
	this.shape_77.setTransform(121.4,236.4,0.937,0.937);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#202B41").s().p("AgBAAIABgCIABAAIABABIgBAEg");
	this.shape_78.setTransform(121.7,234.5,0.937,0.937);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#D79E73").s().p("AAAALQgEAAgDgDQgEgEAAgEQAAgFAEgDQADgEAEAAQAFAAAEAEQADADAAAFQAAAFgDAFQgCADgDAAIgEgCg");
	this.shape_79.setTransform(121.5,232.3,0.937,0.937);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#FFFFFF").s().p("AgEAAIgBgCIACgBIADACQABAAABAAQAAAAABAAQAAgBAAAAQAAAAABgBIAAAAIABAAIABAGIgEgDIgCAEIgEgEg");
	this.shape_80.setTransform(121.4,233.7,0.937,0.937);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#1C3355").s().p("AAAANIgBgCQgFgKABgHQABgEACgCIACgCQACABACAMIACALQABAEgDABIgBAAIgDgCg");
	this.shape_81.setTransform(120.2,235.2,0.937,0.937);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#172C48").s().p("AgFAHIgBgTIAEAJIADAJIAGADIAAAEQgLgDgBgDg");
	this.shape_82.setTransform(120.4,235.7,0.937,0.937);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#1C3355").s().p("AgHAUIAAghIACgEQADgEAGgCIACAGIACAOQAAAKgCAQIgEABQgIAAgBgEg");
	this.shape_83.setTransform(120.4,235.7,0.937,0.937);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#202B41").s().p("AgBAAIABgCIACABIAAADIgCABg");
	this.shape_84.setTransform(121.6,234,0.937,0.937);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#202B41").s().p("AgEAJIACgWIAHAAIgGAbg");
	this.shape_85.setTransform(120.6,238.4,0.937,0.937);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#202B41").s().p("AAAANQgBgBgCgVIAHgEIAAAaIgDABIgBgBg");
	this.shape_86.setTransform(121.7,240.1,0.937,0.937);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#1C3355").s().p("AABAEQABgJgCgJIgDgHIABAAIABAAIADABIACARQgBATgBADQAAAAAAAAQAAABgBAAQAAABAAAAQgBABAAAAg");
	this.shape_87.setTransform(122.1,235.5,0.937,0.937);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#202B41").s().p("AgHAHIAHgQIAIABIgLASQgBAAgBgBQAAAAgBAAQAAgBAAAAQgBAAAAgBg");
	this.shape_88.setTransform(119.7,240.5,0.937,0.937);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#D79E73").s().p("AgDACIACgCIAEgCIACACQgCAEgEAAQgBAAgBgBQAAAAgBAAQAAAAAAgBQAAAAABAAg");
	this.shape_89.setTransform(123,236.7,0.937,0.937);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#DFE7F2").s().p("AgDgDIAIgCIgBALg");
	this.shape_90.setTransform(121.4,234.2,0.937,0.937);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#D79E73").s().p("AgDAEIAAgJIAHAAIAAAJQgBABAAAAQAAAAgBABQAAAAAAAAQgBAAAAAAQgBAAAAAAQAAAAAAAAQgBgBgBAAQAAAAgBgBg");
	this.shape_91.setTransform(121.3,233.2,0.937,0.937);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#243B67").s().p("AgIARIgFgDIAAgRQAAgGAFgEIAFgDQAGgDAGACIAFADIAAAaQgBAEgKACIgDABQgEAAgEgCg");
	this.shape_92.setTransform(120.9,235.2,0.937,0.937);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#1C3355").s().p("AgDAKIABgXIACABIACAKIACALQAAAEgCABIgBAAQgCAAgCgEg");
	this.shape_93.setTransform(122.4,234.8,0.937,0.937);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#202B41").s().p("AgMAUIgBgoIAbAFIgCAaIgFADIgDABIgCgTIgEABIgDAYg");
	this.shape_94.setTransform(121,237.8,0.937,0.937);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#F0C136").s().p("AgDgEIAPgHIgJAQIgOAHg");
	this.shape_95.setTransform(123.7,235.9,0.937,0.937);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#1C3355").s().p("AgDADQgGgBgDgCQgBAAAAAAQgBAAAAAAQAAgBAAAAQAAAAAAgBQACgDADAAIADAAIAVAHIAAAEg");
	this.shape_96.setTransform(122.6,235.8,0.937,0.937);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#1A1E26").s().p("AgFABIAAgCIAFgBIAFACQABABAAAAQAAAAAAABQAAAAgBAAQAAABgBAAIgCAAIgHgCg");
	this.shape_97.setTransform(122.1,241.6,0.937,0.937);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#1A1E26").s().p("AAAADIgDgDIABgDIACgBQAAAAAAABQABAAAAAAQAAAAAAABQABAAAAAAIACAEQAAAAAAABQAAAAAAABQAAAAAAAAQAAAAAAAAIgBABIgDgCg");
	this.shape_98.setTransform(119.2,241.6,0.937,0.937);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#FC0D1B").s().p("AjCAIIAAgPIGFAAIAAAPg");
	this.shape_99.setTransform(130.9,230.9,0.937,0.937);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#D79E73").s().p("AgDAEIgBgHIABgBIACAEIADgHIADAHIgFAIg");
	this.shape_100.setTransform(150,232.5,0.937,0.937);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#243B67").s().p("AgQAXQgFgCgDgEQgCgFABgFQACgFAEgCIAFgBIAVgCIAHgPQACgGAGADQAFACgBAGIgIATIgDADIgBABIgVALQgDACgDAAIgDAAg");
	this.shape_101.setTransform(148.2,234.2,0.937,0.937);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("#243B67").s().p("AgDgEIABgCIACgBQABAAADAHIgEAIg");
	this.shape_102.setTransform(145.3,234.9,0.937,0.937);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("#243B67").s().p("AgCAHIAAgSIAFAIIgBANIgCACg");
	this.shape_103.setTransform(145.5,235.2,0.937,0.937);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f("#243B67").s().p("AgCAJQgGgBgDgDIgCgCIAAgNIAXAAIAEATQgEACgFAAIgHgCg");
	this.shape_104.setTransform(146.5,236.9,0.937,0.937);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f("#243B67").s().p("AAAANIgLgNIgBgMIAIABQAJACAGAGIAAABIAAAAIACAOIgDABg");
	this.shape_105.setTransform(146.3,235.3,0.937,0.937);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f("#243B67").s().p("AgMAOIAAggIAUAIIAFAdg");
	this.shape_106.setTransform(146.4,235.9,0.937,0.937);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f("#FFFFFF").s().p("AgGgBQABgDAJAEIADADIgGABQgHgDAAgCg");
	this.shape_107.setTransform(146.3,234.3,0.937,0.937);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f("#202B41").s().p("AgOAfIgBAAIAHgWIgDglIATgCIAEAEIACACIAAAAQAAABAAAAQABAAAAABQAAAAABAAQAAAAAAAAIAAAeIgEAWIgDABIgBAAIgCguIgFgCIgCAdIgLAUg");
	this.shape_108.setTransform(146.3,239.9,0.937,0.937);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f("#1E2128").s().p("AgEABIABgBIADgBQACAAACABQABAAgGACIAAAAIgDgBg");
	this.shape_109.setTransform(145.2,242.8,0.937,0.937);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f("#1E2128").s().p("AgEABIABgBIADgBQADAAACABIgDABIgDABIAAAAIgDgBg");
	this.shape_110.setTransform(147.4,242.8,0.937,0.937);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f("#D79E73").s().p("AgCAAQAAAAAAAAQAAgBABAAQAAgBABAAQAAAAAAAAQABAAAAAAQABAAAAAAQAAABAAAAQAAABAAAAQABAAAAABQAAAAgBABQAAAAgBABQAAAAgBAAQAAAAAAAAQgBAAAAAAQAAgBAAAAQgBgBAAgBg");
	this.shape_111.setTransform(147.1,233.1,0.937,0.937);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.f("#181C23").s().p("AgFAHQgDgDAAgEQgBgCADgDQACgDAEgBQAJAAAAAJQABADgDADQgCADgEAAQgDAAgDgCg");
	this.shape_112.setTransform(145.5,232.2,0.937,0.937);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.f("#243B67").s().p("AgIABQgBgDADgDQADgDADAAQAJAAAAAIQAAAEgCACQgDADgDAAIgBAAQgHAAgBgIg");
	this.shape_113.setTransform(145.6,232.2,0.937,0.937);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.f("#181C23").s().p("AABANIgFgBQgDgBgCgDIgCgFIAGgNIAIgCQANgCgFAIIgCABQgCACABAEQAAAFgCAEQgBABAAABQgBAAAAABQgBAAAAAAQAAAAgBAAIgBAAg");
	this.shape_114.setTransform(146.4,232.7,0.937,0.937);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.f("#D79E73").s().p("AgCADIgBgHIAHAAIAAAJg");
	this.shape_115.setTransform(146.3,234,0.937,0.937);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.f("#D79E73").s().p("AgHAKQgEgEgBgFQAAgEADgEQAEgEAFgBQAEAAAEADQAEAEABAFQAAAGgCACQgCAEgIABIgBAAQgEAAgDgDg");
	this.shape_116.setTransform(146.4,232.8,0.937,0.937);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.f("#D79E73").s().p("AgCAAIACgCQABAAABgBQAAAAABAAQAAAAAAAAQAAAAAAAAIAAAGIgDABg");
	this.shape_117.setTransform(147.5,230.7,0.937,0.937);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.f("#243B67").s().p("AgQAcQgEgEAAgFIABgDIAKgfIAAgBQABgDACgBIARgKQAGgDADAGQACAFgFAEIgNAIIAAAdQAAAGgEADQgCAEgGAAQgFAAgDgEg");
	this.shape_118.setTransform(146.1,233.2,0.937,0.937);

	this.shape_119 = new cjs.Shape();
	this.shape_119.graphics.f("#FFFFFF").s().p("AjbAPQgFAAgFgDQgEgFAAgGIAAgCQAAgFAEgFQAFgDAFAAIG2AAQAHAAAEADQAEAFAAAFIAAACQAAAGgEAFQgEADgHAAg");
	this.shape_119.setTransform(127.6,271.6,0.937,0.937);

	this.shape_120 = new cjs.Shape();
	this.shape_120.graphics.f("#F2F2F2").s().p("AjbAYQgFAAgFgEQgEgFAAgGIAAgSQAAgGAEgEQAFgEAFAAIG2AAQAHAAAEAEQAEAEAAAGIAAASQAAAGgEAFQgEAEgHAAg");
	this.shape_120.setTransform(127.6,270.8,0.937,0.937);

	this.shape_121 = new cjs.Shape();
	this.shape_121.graphics.f("#39A2A5").s().p("AjdBCQgGAAgEgDQgEgFgBgGIAAhoQABgFAEgFQAEgDAGAAIG7BAQAGgBAEAEQAEAEABAGIAAAoQgBAGgEAFQgEADgGAAg");
	this.shape_121.setTransform(127.3,239.2,0.937,0.937);

	this.shape_122 = new cjs.Shape();
	this.shape_122.graphics.f("#364F5D").s().p("AjdBNQgGAAgEgEQgEgFgBgGIAAh8QABgGAEgEQAEgEAGAAIG7BAQAGAAAEAFQAEAEABAFIAAA8QgBAGgEAFQgEAEgGAAg");
	this.shape_122.setTransform(127.3,240.2,0.937,0.937);

	this.shape_123 = new cjs.Shape();
	this.shape_123.graphics.f("#66C2B0").s().p("Ai5B0IAAjnIFyAAIAADng");
	this.shape_123.setTransform(127.6,260.6,0.937,0.937);

	this.shape_124 = new cjs.Shape();
	this.shape_124.graphics.f("#EAECE1").s().p("AjfCHIAAkMIG/AAIAAEMg");
	this.shape_124.setTransform(127.6,258.9,0.937,0.937);

	this.shape_125 = new cjs.Shape();
	this.shape_125.graphics.f("#637C14").s().p("AgTBhQgPggAAg4QAAgrAKgeQAKggAOAAQAOAAALAgQALAeAAArQAAA4gQAgg");
	this.shape_125.setTransform(105,263.8,0.937,0.937);

	this.shape_126 = new cjs.Shape();
	this.shape_126.graphics.f("#57585A").s().p("AgMADIAAgFIAWAAQABAAABAAQAAAAABABQAAAAAAABQABAAAAAAQAAABgBAAQAAABAAAAQAAABgBAAQAAAAgBAAg");
	this.shape_126.setTransform(149.2,265.7,0.937,0.937);

	this.shape_127 = new cjs.Shape();
	this.shape_127.graphics.f("#57585A").s().p("AgUgCIAnAAQAAAAABAAQAAAAABABQAAAAAAAAQAAABAAAAQAAAAAAABQAAABAAAAQgBAAAAABQgBAAAAAAIgnAAg");
	this.shape_127.setTransform(149.9,263.4,0.937,0.937);

	this.shape_128 = new cjs.Shape();
	this.shape_128.graphics.f("#57585A").s().p("AgNADIAAgFIAYAAQAAAAABAAQAAAAABABQAAAAAAABQAAAAAAAAQAAABAAAAQAAABAAAAQgBABAAAAQgBAAAAAAg");
	this.shape_128.setTransform(149.2,270.3,0.937,0.937);

	this.shape_129 = new cjs.Shape();
	this.shape_129.graphics.f("#57585A").s().p("AgNgCIAYAAQAAAAABAAQAAAAABABQAAAAAAAAQAAABAAAAQAAAAAAABQAAAAAAABQgBAAAAAAQgBAAAAAAIgYABg");
	this.shape_129.setTransform(149.2,268,0.937,0.937);

	this.shape_130 = new cjs.Shape();
	this.shape_130.graphics.f("#57585A").s().p("AgNgCIAYAAQAAAAABAAQABAAAAAAQAAABABAAQAAABAAAAQAAABAAAAQgBABAAAAQAAAAgBABQgBAAAAAAIgXAAg");
	this.shape_130.setTransform(149.2,261.1,0.937,0.937);

	this.shape_131 = new cjs.Shape();
	this.shape_131.graphics.f("#57585A").s().p("AgNADIAAgEIAYgBQAAAAABAAQAAAAABABQAAAAAAABQAAAAAAAAQAAABAAAAQAAABAAAAQgBABAAAAQgBAAAAAAg");
	this.shape_131.setTransform(149.1,258.7,0.937,0.937);

	this.shape_132 = new cjs.Shape();
	this.shape_132.graphics.f("#57585A").s().p("AgNgCIAYAAQAAAAABAAQAAAAABAAQAAABAAAAQAAABAAAAQAAABAAAAQAAABAAAAQgBAAAAABQgBAAAAAAIgYAAg");
	this.shape_132.setTransform(149.1,256.4,0.937,0.937);

	this.shape_133 = new cjs.Shape();
	this.shape_133.graphics.f("#57585A").s().p("AgUADIAAgEIAmgBQABAAABAAQAAAAABABQAAAAAAABQAAAAAAAAQAAABAAAAQAAABAAAAQgBABAAAAQgBAAgBAAg");
	this.shape_133.setTransform(149.8,254.1,0.937,0.937);

	this.shape_134 = new cjs.Shape();
	this.shape_134.graphics.f("#57585A").s().p("AgMADIAAgFIAWAAQABAAABAAQAAAAABABQAAAAAAABQABAAAAAAQAAABgBAAQAAABAAAAQgBABAAAAQgBAAgBAAg");
	this.shape_134.setTransform(149.1,251.8,0.937,0.937);

	this.shape_135 = new cjs.Shape();
	this.shape_135.graphics.f("#57585A").s().p("AgMgCIAXAAQAAAAABAAQAAAAABABQAAAAAAAAQAAABAAAAQAAAAAAABQAAAAAAABQAAAAgBAAQAAABgBAAIgXAAg");
	this.shape_135.setTransform(149,249.5,0.937,0.937);

	this.shape_136 = new cjs.Shape();
	this.shape_136.graphics.f("#57585A").s().p("AgMgCIAXAAQAAAAABAAQAAAAABAAQAAABAAAAQAAABAAAAQAAAAAAABQAAABAAAAQgBAAAAABQgBAAAAAAIgXAAg");
	this.shape_136.setTransform(149,247.2,0.937,0.937);

	this.shape_137 = new cjs.Shape();
	this.shape_137.graphics.f("#57585A").s().p("AgUADIgBgFIAoAAQAAAAABAAQAAAAABABQAAAAAAABQAAAAAAAAQAAABAAAAQAAABAAAAQgBABAAAAQgBAAAAAAg");
	this.shape_137.setTransform(149.7,244.9,0.937,0.937);

	this.shape_138 = new cjs.Shape();
	this.shape_138.graphics.f("#57585A").s().p("AgNADIAAgFIAXAAQABAAABAAQAAAAABABQAAAAAAABQAAAAAAAAQAAABAAAAQAAABAAAAQgBABAAAAQgBAAgBAAg");
	this.shape_138.setTransform(149,242.6,0.937,0.937);

	this.shape_139 = new cjs.Shape();
	this.shape_139.graphics.f("#57585A").s().p("AgNgCIAXAAQABAAABAAQAAAAABAAQAAABAAAAQAAABAAAAQAAAAAAABQAAAAAAABQgBAAAAAAQgBABgBAAIgXAAg");
	this.shape_139.setTransform(149,240.3,0.937,0.937);

	this.shape_140 = new cjs.Shape();
	this.shape_140.graphics.f("#57585A").s().p("AgMADIAAgFIAXAAQAAAAABAAQAAAAABABQAAAAAAABQABAAAAAAQAAABgBAAQAAABAAAAQgBABAAAAQgBAAAAAAg");
	this.shape_140.setTransform(148.9,237.9,0.937,0.937);

	this.shape_141 = new cjs.Shape();
	this.shape_141.graphics.f("#57585A").s().p("AgUgCIAmAAQABAAABAAQAAAAAAABQABAAAAABQAAAAAAAAQAAABAAAAQAAABgBAAQAAAAAAAAQgBAAgBAAIgmABg");
	this.shape_141.setTransform(149.7,235.6,0.937,0.937);

	this.shape_142 = new cjs.Shape();
	this.shape_142.graphics.f("#57585A").s().p("AgNgCIAYAAQAAAAABAAQAAAAABABQAAAAAAABQAAAAAAAAQAAABAAAAQAAABAAAAQAAAAgBAAQAAAAgBAAIgYABg");
	this.shape_142.setTransform(148.9,233.3,0.937,0.937);

	this.shape_143 = new cjs.Shape();
	this.shape_143.graphics.f("#57585A").s().p("AgNgCIAYAAQAAAAABAAQAAAAABAAQAAABAAAAQAAABAAAAQAAABAAAAQAAABAAAAQgBAAAAABQgBAAAAAAIgYAAg");
	this.shape_143.setTransform(148.9,231,0.937,0.937);

	this.shape_144 = new cjs.Shape();
	this.shape_144.graphics.f("#57585A").s().p("AgMADIgBgEIAYgBQAAAAABAAQABAAAAABQAAAAABABQAAAAAAAAQAAABAAAAQgBABAAAAQAAABgBAAQgBAAAAAAg");
	this.shape_144.setTransform(148.9,228.7,0.937,0.937);

	this.shape_145 = new cjs.Shape();
	this.shape_145.graphics.f("#57585A").s().p("AgUgCIAmAAQABAAABAAQAAAAABABQAAAAAAAAQABABAAAAQAAAAgBABQAAAAAAABQgBAAAAAAQgBAAgBAAIgmABg");
	this.shape_145.setTransform(149.6,226.4,0.937,0.937);

	this.shape_146 = new cjs.Shape();
	this.shape_146.graphics.f("#FBC94A").s().p("AgqkmIBQgBIAFJPIhPAAgAgIkOQgDADAAAEQAAAEADADQADADAEAAQAJgBAAgJQAAgEgEgDQgDgDgCAAQgFAAgCADg");
	this.shape_146.setTransform(151.5,245.4,0.937,0.937);

	this.shape_147 = new cjs.Shape();
	this.shape_147.graphics.f("#D79E73").s().p("AgDACIADgGQAAAAAAAAQAAAAABAAQAAAAAAABQAAABABABIACADIgEADg");
	this.shape_147.setTransform(386,210.4,0.937,0.937);

	this.shape_148 = new cjs.Shape();
	this.shape_148.graphics.f("#D79E73").s().p("AgFAAIADgHIAEAHIACgEIACAAIgCAIIgEAEg");
	this.shape_148.setTransform(380.8,212.7,0.937,0.937);

	this.shape_149 = new cjs.Shape();
	this.shape_149.graphics.f("#243B67").s().p("AAOAYIgFgBIgXgNIgBgBIgDgDIgJgUQgCgHAGgCQAGgCADAFIAIASIAXACQAFAAADAEQADAEAAAFQgBAFgEAEQgDADgEAAIgCgBg");
	this.shape_149.setTransform(382.8,214.5,0.937,0.937);

	this.shape_150 = new cjs.Shape();
	this.shape_150.graphics.f("#243B67").s().p("AgDAAIACgEQABgEABAAQABAAABAAQAAAAAAABQABAAAAABQAAAAABABIgEAOg");
	this.shape_150.setTransform(386.1,215.3,0.937,0.937);

	this.shape_151 = new cjs.Shape();
	this.shape_151.graphics.f("#243B67").s().p("AgBALIgCgOIAGgKIAAAVIgDAGg");
	this.shape_151.setTransform(385.9,215.7,0.937,0.937);

	this.shape_152 = new cjs.Shape();
	this.shape_152.graphics.f("#243B67").s().p("AgJALIgFgBIADgVIAaAAIAAAOQgBAFgKACIgIACIgFgBg");
	this.shape_152.setTransform(384.8,217.6,0.937,0.937);

	this.shape_153 = new cjs.Shape();
	this.shape_153.graphics.f("#243B67").s().p("AgKAOIgDgBIACgPIAAgBIAAAAQALgMAOACIgBANIgMAOIgDAAIgIAAg");
	this.shape_153.setTransform(384.9,215.7,0.937,0.937);

	this.shape_154 = new cjs.Shape();
	this.shape_154.graphics.f("#243B67").s().p("AgMAIIAEgTIAWgKIAAAkIgbAHIABgOg");
	this.shape_154.setTransform(384.9,216.4,0.937,0.937);

	this.shape_155 = new cjs.Shape();
	this.shape_155.graphics.f("#FFFFFF").s().p("AgHADIABgCIADgBIAFgDQAFgBAAACQABADgJADg");
	this.shape_155.setTransform(384.9,214.7,0.937,0.937);

	this.shape_156 = new cjs.Shape();
	this.shape_156.graphics.f("#202B41").s().p("AAPAjIgMgWIgDggIgFADIgDAyIgEAAIgFgZIAAghQABAAAAgBQAAAAABAAQAAAAAAgBQAAAAABAAIAAgBQAAAAABAAQAAAAAAAAQAAgBABAAQAAAAAAgBIAEgFIAVADIgDAqIAIAXIgBABg");
	this.shape_156.setTransform(385,220.8,0.937,0.937);

	this.shape_157 = new cjs.Shape();
	this.shape_157.graphics.f("#1E2128").s().p("AACACIgEgBIgCgBQACgCADAAIAEABIAAADIgCABIgBgBg");
	this.shape_157.setTransform(386.2,224.2,0.937,0.937);

	this.shape_158 = new cjs.Shape();
	this.shape_158.graphics.f("#1E2128").s().p("AACACIgEgBQgBAAAAAAQgBgBAAAAQAAAAAAAAQAAAAAAAAQACgCADAAIAEABIAAADIgCABIgBgBg");
	this.shape_158.setTransform(383.7,224.2,0.937,0.937);

	this.shape_159 = new cjs.Shape();
	this.shape_159.graphics.f("#D79E73").s().p("AgCAAQAAAAAAgBQABAAAAgBQABAAAAAAQAAgBAAAAQABAAABABQAAAAABAAQAAABAAAAQAAABAAAAQAAABAAABQgBAAAAABQgBAAAAAAQgBAAAAAAQAAAAgBAAQAAAAAAAAQgBgBAAAAQAAgBAAgBg");
	this.shape_159.setTransform(384,213.3,0.937,0.937);

	this.shape_160 = new cjs.Shape();
	this.shape_160.graphics.f("#181C23").s().p("AAAAKQgEAAgDgDQgDgEABgDQAAgEADgDQAEgDADAAQAKABAAAKQgBAEgDADQgDADgEAAIAAgBg");
	this.shape_160.setTransform(385.8,212.3,0.937,0.937);

	this.shape_161 = new cjs.Shape();
	this.shape_161.graphics.f("#243B67").s().p("AAAAKQgKgBABgJQAAgEADgDQAEgDADABQAEAAADADQADADgBAEQAAAEgDADQgDACgDAAIgBAAg");
	this.shape_161.setTransform(385.7,212.4,0.937,0.937);

	this.shape_162 = new cjs.Shape();
	this.shape_162.graphics.f("#181C23").s().p("AgFALQgDgEAAgGQABgFgDgCIgCAAIgBgFQABgEAJABQANACgEAAIAHAPQAAADgCADIgGAFQgEgBgCABIgBABQgBAAgCgEg");
	this.shape_162.setTransform(384.9,212.9,0.937,0.937);

	this.shape_163 = new cjs.Shape();
	this.shape_163.graphics.f("#D79E73").s().p("AgCgFIAHABIgBAHIgHADg");
	this.shape_163.setTransform(384.9,214.3,0.937,0.937);

	this.shape_164 = new cjs.Shape();
	this.shape_164.graphics.f("#D79E73").s().p("AAAAOQgJgBgDgEQgCgDABgGQAAgGAFgEQAEgEAFABQAGAAAEAEQAEAFgBAFQAAAGgEAEQgEADgFAAIgBAAg");
	this.shape_164.setTransform(384.8,213,0.937,0.937);

	this.shape_165 = new cjs.Shape();
	this.shape_165.graphics.f("#243B67").s().p("AgJAmQgFgBgCgFQgDgEACgFIABgDIATgeIgJgSQgCgGAFgDQAEgDAEAFIANAVQABAEAAACIgBABIgNAlQgBAFgEACQgDACgDAAIgDgBg");
	this.shape_165.setTransform(386.1,213.6,0.937,0.937);

	this.shape_166 = new cjs.Shape();
	this.shape_166.graphics.f("#1A1E26").s().p("AgCADIgBgHIAGAAQAAAAAAAAQAAAAAAABQAAAAAAABQABAAAAABIAAACIAAADIgEABg");
	this.shape_166.setTransform(356.8,221.1,0.937,0.937);

	this.shape_167 = new cjs.Shape();
	this.shape_167.graphics.f("#1A1E26").s().p("AgEADIADgHQAFAEAAgBQABAAAAAAQAAAAAAABQAAAAAAAAQAAAAgBAAIgCAEIgCABg");
	this.shape_167.setTransform(353.9,221,0.937,0.937);

	this.shape_168 = new cjs.Shape();
	this.shape_168.graphics.f("#181C23").s().p("AgEAFQgCgCgBgDQABgCACgCQACgCACAAQAIgBAAAHQAAAHgIAAQgCAAgCgCg");
	this.shape_168.setTransform(355.6,209.7,0.937,0.937);

	this.shape_169 = new cjs.Shape();
	this.shape_169.graphics.f("#181C23").s().p("AgHAFIABgCIgBgDIAFgDQAFgCACACQAEADgBADQAAABgFABg");
	this.shape_169.setTransform(357.1,210.9,0.937,0.937);

	this.shape_170 = new cjs.Shape();
	this.shape_170.graphics.f("#181C23").s().p("AgLAIQgCgCAAgGQAAgKAJgCQAKgDAGAJQACADAAAEQgGACgFgDQgBAAgBAAQAAAAgBAAQAAAAAAAAQAAAAAAAAIgDAHIgBgDIgBgBQgBAAAAAAQAAAAAAAAQAAAAAAABQgBAAAAAAQAAABAAAAQAAABABAAQAAABAAAAQABABABAAIAAAGIgHgGg");
	this.shape_170.setTransform(356.3,210.9,0.937,0.937);

	this.shape_171 = new cjs.Shape();
	this.shape_171.graphics.f("#1C3355").s().p("AgEADQgHgBgDgCQgBAAAAAAQgBgBAAAAQAAAAAAAAQAAgBAAAAQACgDAEgBIADAAIAYAIIgBAFg");
	this.shape_171.setTransform(356.3,215.7,0.937,0.937);

	this.shape_172 = new cjs.Shape();
	this.shape_172.graphics.f("#D79E73").s().p("AAAANQgFgBgEgDQgEgEAAgFQAAgGAEgEQAEgEAFAAQAGAAAEAEQAEAEAAAGQAAAGgEAFQgCAEgDAAIgFgCg");
	this.shape_172.setTransform(356.3,211,0.937,0.937);

	this.shape_173 = new cjs.Shape();
	this.shape_173.graphics.f("#FFFFFF").s().p("AgEAAIgCgCIADgBIACABQAAAAABAAQAAABAAAAQAAAAAAAAQABAAAAAAIADgCIAAAAIACAAIABAFIgEgCIgCAEg");
	this.shape_173.setTransform(356.2,212.7,0.937,0.937);

	this.shape_174 = new cjs.Shape();
	this.shape_174.graphics.f("#1C3355").s().p("AAAAPIgBgDQgFgLABgHQAAgFADgDIACgCQAAAAAAABQAAAAABAAQAAABAAABQABAAAAABIADALIACAMQAAAEgCABIgCABQAAAAgBAAQAAgBgBAAQAAAAgBAAQAAgBAAAAg");
	this.shape_174.setTransform(355,214.2,0.937,0.937);

	this.shape_175 = new cjs.Shape();
	this.shape_175.graphics.f("#172C48").s().p("AgGAHIgBgVIAFAJIACAKIAIAGIAAADQgMgDgCgEg");
	this.shape_175.setTransform(355.2,214.9,0.937,0.937);

	this.shape_176 = new cjs.Shape();
	this.shape_176.graphics.f("#1C3355").s().p("AgIAWIAAgkIACgFQADgEAHgCIADAGQACAIAAAIQAAALgCASIgFAAQgJAAgBgEg");
	this.shape_176.setTransform(355.2,214.9,0.937,0.937);

	this.shape_177 = new cjs.Shape();
	this.shape_177.graphics.f("#1C3355").s().p("AABAFQAAgLgCgKIgCgHIABgBIAAABIAFABIACATIgCAYQgBACgCACg");
	this.shape_177.setTransform(357.2,214.6,0.937,0.937);

	this.shape_178 = new cjs.Shape();
	this.shape_178.graphics.f("#DFE7F2").s().p("AABACIgFgGIAJgCIgBANg");
	this.shape_178.setTransform(356.4,213.2,0.937,0.937);

	this.shape_179 = new cjs.Shape();
	this.shape_179.graphics.f("#DFE7F2").s().p("AgJASIgFgDIAAgUQgBgHAGgEIAFgDQAKAAAKACIAAAdQgCAEgKADIgFABQgEAAgEgCg");
	this.shape_179.setTransform(355.8,214.4,0.937,0.937);

	this.shape_180 = new cjs.Shape();
	this.shape_180.graphics.f("#1C3355").s().p("AAAAOIgCgDIgEgZIADAAQACADACAIIAFALQABAFgCABIgCABIgDgBg");
	this.shape_180.setTransform(357.8,213.9,0.937,0.937);

	this.shape_181 = new cjs.Shape();
	this.shape_181.graphics.f("#172C48").s().p("AACAdIgUgBIAHgbIAAgXIAegGIgCA5IgPAAg");
	this.shape_181.setTransform(355.5,217.9,0.937,0.937);

	this.shape_182 = new cjs.Shape();
	this.shape_182.graphics.f("#D79E73").s().p("AAAAPIgDgZIAIgEIAAAdg");
	this.shape_182.setTransform(356.6,219.7,0.937,0.937);

	this.shape_183 = new cjs.Shape();
	this.shape_183.graphics.f("#D79E73").s().p("AgFAJIADgYIAIABIgHAeg");
	this.shape_183.setTransform(355.4,217.9,0.937,0.937);

	this.shape_184 = new cjs.Shape();
	this.shape_184.graphics.f("#D79E73").s().p("AgIAIIAIgSIAJABIgNAUQgDgBgBgCg");
	this.shape_184.setTransform(354.4,220.2,0.937,0.937);

	this.shape_185 = new cjs.Shape();
	this.shape_185.graphics.f("#D79E73").s().p("AgEABIADgBIAFgDIABADQgBAEgGAAQgBAAAAAAQgBgBAAAAQAAAAAAgBQAAAAAAgBg");
	this.shape_185.setTransform(358.1,216,0.937,0.937);

	this.shape_186 = new cjs.Shape();
	this.shape_186.graphics.f("#D79E73").s().p("AgDAFIAAgLIAHAAIAAALQAAAAgBABQAAAAAAAAQgBAAAAABQgBAAAAAAIgEgCg");
	this.shape_186.setTransform(356.2,212,0.937,0.937);

	this.shape_187 = new cjs.Shape();
	this.shape_187.graphics.f("#D79E73").s().p("AgOAWIgBgsIAeAFIgCAdIgFADIgEABIgCgVIgFACIgDAag");
	this.shape_187.setTransform(355.8,217.2,0.937,0.937);

	this.shape_188 = new cjs.Shape();
	this.shape_188.graphics.f("#1C3355").s().p("AgCADQgFgCgCgBIgBgCQABgDADAAIACAAIAQAGIAAAFg");
	this.shape_188.setTransform(358.5,215.1,0.937,0.937);

	this.shape_189 = new cjs.Shape();
	this.shape_189.graphics.f("#1A1E26").s().p("AgBADIgEgCIAAgDIAFgBIAGADQAAABAAAAQAAABAAAAQAAAAAAABQgBAAAAAAIgCABIgEgBg");
	this.shape_189.setTransform(357.2,221.4,0.937,0.937);

	this.shape_190 = new cjs.Shape();
	this.shape_190.graphics.f("#1A1E26").s().p("AAAADIgEgDIACgEIACAAQAAAAAAAAQABAAAAAAQABAAAAABQAAAAAAABIACAEQABAAAAABQAAAAAAABQAAAAAAAAQAAABgBAAIgBAAIgDgCg");
	this.shape_190.setTransform(353.9,221.4,0.937,0.937);

	this.shape_191 = new cjs.Shape();
	this.shape_191.graphics.f("#D79E73").s().p("AgEACIADgCIAFgDIABADQgBAEgGAAQgEAAACgCg");
	this.shape_191.setTransform(359.7,215.3,0.937,0.937);

	this.shape_192 = new cjs.Shape();
	this.shape_192.graphics.f("#1C3355").s().p("AACAFIgQgHIAEgFIAWAFIACACQACACgCADQAAABAAAAQAAAAgBABQAAAAgBAAQAAAAgBAAIgBABQgEAAgEgDg");
	this.shape_192.setTransform(366.4,210,0.937,0.937);

	this.shape_193 = new cjs.Shape();
	this.shape_193.graphics.f("#D79E73").s().p("AACAFQgDAAgDgDIgBgCIACgEIAFAEQAHAFgGAAIgBAAg");
	this.shape_193.setTransform(365.1,209.4,0.937,0.937);

	this.shape_194 = new cjs.Shape();
	this.shape_194.graphics.f("#181C23").s().p("AAIAKQABgBABAAQABAAAAgBQAAAAAAgBQAAgBAAAAQAAgBAAAAQAAgBgBAAQAAAAAAAAQAAAAAAAAIgCABIgBAEQgDABgBgFQgBgCgDAAQgHAAgGgBIgFgEIAHgFQAIgLALADQANADAAAMQgCAIgCACIgIAHg");
	this.shape_194.setTransform(369.6,205.4,0.937,0.937);

	this.shape_195 = new cjs.Shape();
	this.shape_195.graphics.f("#1C3355").s().p("AADAHIgVgNIADgFIAdALIADADQADADgBAFQAAAAgBAAQAAAAAAABQgBAAAAAAQgBAAAAAAQgFAAgIgFg");
	this.shape_195.setTransform(369.7,210.5,0.937,0.937);

	this.shape_196 = new cjs.Shape();
	this.shape_196.graphics.f("#202B41").s().p("AgBgCIABgCIACABIAAADIgDAEg");
	this.shape_196.setTransform(369.4,208.6,0.937,0.937);

	this.shape_197 = new cjs.Shape();
	this.shape_197.graphics.f("#D79E73").s().p("AgLANQgEgGAAgHQAAgHAFgFQAEgEAGAAQAHAAAFAEQAEAFAAAHQAAAGgEAEQgFAFgHAAQgCACgCAAQgEAAgDgEg");
	this.shape_197.setTransform(369.6,205.7,0.937,0.937);

	this.shape_198 = new cjs.Shape();
	this.shape_198.graphics.f("#FFFFFF").s().p("AgCAAIgFADIABgHIACAAIAAAAIAEACQACABADgDIADACIgBACIgHAFg");
	this.shape_198.setTransform(369.9,207.6,0.937,0.937);

	this.shape_199 = new cjs.Shape();
	this.shape_199.graphics.f("#1C3355").s().p("AgEAUQgEgBABgGIADgPIACgNQACgDABgBIADACQADADABAGQABAJgGAOQgDAFgDAAIgBAAg");
	this.shape_199.setTransform(371.4,209.5,0.937,0.937);

	this.shape_200 = new cjs.Shape();
	this.shape_200.graphics.f("#172C48").s().p("AgJANIAJgGIAKgYQAAATgCAGQgCAGgPAEg");
	this.shape_200.setTransform(371.2,210.4,0.937,0.937);

	this.shape_201 = new cjs.Shape();
	this.shape_201.graphics.f("#1C3355").s().p("AgHAgQgDgWABgOQAAgKACgJIADgIQAOAEABAKIAAAsQgBAFgKAAIgHAAg");
	this.shape_201.setTransform(371.1,210.3,0.937,0.937);

	this.shape_202 = new cjs.Shape();
	this.shape_202.graphics.f("#202B41").s().p("AgBADIAAgFIACgBIABADIgCAEg");
	this.shape_202.setTransform(369.5,207.9,0.937,0.937);

	this.shape_203 = new cjs.Shape();
	this.shape_203.graphics.f("#202B41").s().p("AgGgRIAJgBIAEAdIgFAIg");
	this.shape_203.setTransform(370.9,213.9,0.937,0.937);

	this.shape_204 = new cjs.Shape();
	this.shape_204.graphics.f("#202B41").s().p("AgCATIgDgBIAAgkIALAFQgDAegBABIgCABIgCAAg");
	this.shape_204.setTransform(369.4,216.3,0.937,0.937);

	this.shape_205 = new cjs.Shape();
	this.shape_205.graphics.f("#1C3355").s().p("AgCAZIgDgdIADgXIAEgCIABAAIADABIgFAIQgCAMABAOIAAAYQgBgCgBgDg");
	this.shape_205.setTransform(368.8,210,0.937,0.937);

	this.shape_206 = new cjs.Shape();
	this.shape_206.graphics.f("#202B41").s().p("AgKgLIAKgCQALAUgBADQgBACgEACg");
	this.shape_206.setTransform(372.1,216.9,0.937,0.937);

	this.shape_207 = new cjs.Shape();
	this.shape_207.graphics.f("#D79E73").s().p("AAAAGQgDgDAAgDIAAgEIADgCIADAHQACAGgCAAIgDgBg");
	this.shape_207.setTransform(367.9,209.3,0.937,0.937);

	this.shape_208 = new cjs.Shape();
	this.shape_208.graphics.f("#DFE7F2").s().p("AgFgHIALACIgKANg");
	this.shape_208.setTransform(369.7,208.3,0.937,0.937);

	this.shape_209 = new cjs.Shape();
	this.shape_209.graphics.f("#D79E73").s().p("AgEAGIAAgNIAJAAIAAANQgDACgCAAQgBAAAAAAQgBAAAAAAQgBAAAAgBQgBAAAAgBg");
	this.shape_209.setTransform(369.9,206.9,0.937,0.937);

	this.shape_210 = new cjs.Shape();
	this.shape_210.graphics.f("#243B67").s().p("AgDAYQgIgCgFgDIgCgDIAAgkIAGgDQAJgDAIAEIAHADQAHAGAAAIIAAAYQgHAGgJAAIgGgBg");
	this.shape_210.setTransform(370.4,209.6,0.937,0.937);

	this.shape_211 = new cjs.Shape();
	this.shape_211.graphics.f("#1C3355").s().p("AgHARQgDgCACgGIAIgNQAEgKACgDIAEAAIgJAfQgCAEgDAAIgDgBg");
	this.shape_211.setTransform(367.9,209,0.937,0.937);

	this.shape_212 = new cjs.Shape();
	this.shape_212.graphics.f("#202B41").s().p("AAIAcIgEggIgFgCIgDAaIgFgBIgHgEIgCgkIAlgGIAAA2IgJABIgCAAg");
	this.shape_212.setTransform(370.4,213.1,0.937,0.937);

	this.shape_213 = new cjs.Shape();
	this.shape_213.graphics.f("#1A1E26").s().p("AgFAEQgBAAAAgBQgBAAAAgBQAAAAAAAAQAAgBABAAIAIgEIAGABIAAAEQgHACgDAAIgDAAg");
	this.shape_213.setTransform(368.8,218.3,0.937,0.937);

	this.shape_214 = new cjs.Shape();
	this.shape_214.graphics.f("#1A1E26").s().p("AgEAGQAAAAgBAAQAAgBAAAAQAAgBAAAAQABgBAAAAQACgDAAgCQABgBAAgBQAAAAABgBQAAAAAAAAQAAAAABAAIADABQACADgBACQAAACgEACIgEABIgBAAg");
	this.shape_214.setTransform(372.7,218.3,0.937,0.937);

	this.shape_215 = new cjs.Shape();
	this.shape_215.graphics.f("#A8A8A8").s().p("Ag3ADQgYgBAAgCQAAgBAYgBQAYgCAfAAQAgAAAYACQAYABAAABQAAACgYABQgXACghAAQggAAgXgCg");
	this.shape_215.setTransform(370.4,218.7,0.937,0.937);

	this.shape_216 = new cjs.Shape();
	this.shape_216.graphics.f("#CCCCCC").s().p("AhZAIIAKgPICfAAIAKAPg");
	this.shape_216.setTransform(370.4,218.7,0.937,0.937);

	this.shape_217 = new cjs.Shape();
	this.shape_217.graphics.f("#CCCCCC").s().p("AhBAHIAAgNIB6AAIAJANg");
	this.shape_217.setTransform(385,224.3,0.937,0.937);

	this.shape_218 = new cjs.Shape();
	this.shape_218.graphics.f("#CCCCCC").s().p("AhBAHIAJgNIB6AAIAAANg");
	this.shape_218.setTransform(355.7,221.6,0.937,0.937);

	this.shape_219 = new cjs.Shape();
	this.shape_219.graphics.f("#FD7E2B").s().p("AgPARIAFgHQAEAFAGAAQAFgBABgFQAAgGgLAAIAAgGQAJAAAAgGQAAgFgEAAQgEAAgEAEIgGgGQAHgGAHAAQAPAAAAANQAAAGgIADIAAAAQAJACAAAIQAAANgQAAQgKAAgFgGg");
	this.shape_219.setTransform(384.7,228.8,0.937,0.937);

	this.shape_220 = new cjs.Shape();
	this.shape_220.graphics.f("#2F74FB").s().p("AgOAXIAAgHQASgRAAgGQAAgHgGABQgEgBgDAFIgGgGQAGgGAJAAQAFAAAEADQAEAEAAAGQAAAIgNAPIAQgBIAAAJg");
	this.shape_220.setTransform(356.1,226.8,0.937,0.937);

	this.shape_221 = new cjs.Shape();
	this.shape_221.graphics.f("#FC4448").s().p("AgNAWIAAgIIAKAAIAAgZIgJAAIAAgGQAGgBAFgDIAHAAIAAAjIAIAAIAAAIg");
	this.shape_221.setTransform(370.4,223.2,0.937,0.937);

	this.shape_222 = new cjs.Shape();
	this.shape_222.graphics.f("#F2F2F2").s().p("AjeBCIAAhlICFAAIAAgfICzAAIAAA7ICFAAIAABJg");
	this.shape_222.setTransform(370.4,225.7,0.937,0.937);

	this.shape_223 = new cjs.Shape();
	this.shape_223.graphics.f("#7C4C31").s().p("AhaAoQgIAAgFgFQgFgGAAgIIAAgqQAAgHAFgGQAFgFAIAAIC1AAQAHAAAGAFQAFAGAAAHIAAAqQAAAIgFAGQgGAFgHAAg");
	this.shape_223.setTransform(387.2,264,0.937,0.937);

	this.shape_224 = new cjs.Shape();
	this.shape_224.graphics.f("#7C4C31").s().p("AhaAoQgIAAgFgFQgFgGAAgIIAAgqQAAgHAFgGQAFgFAIAAIC1AAQAHAAAGAFQAFAGAAAHIAAAqQAAAIgFAGQgGAFgHAAg");
	this.shape_224.setTransform(353.8,264,0.937,0.937);

	this.shape_225 = new cjs.Shape();
	this.shape_225.graphics.f("#39A2A5").s().p("AghB7QgHAAgGgEQgFgGAAgHIAAjTQAAgIAFgFQAGgEAHAAIBDAAQAIAAAFAEQAFAFAAAIIAADTQAAAHgFAGQgFAEgIAAg");
	this.shape_225.setTransform(370.5,254.6,0.937,0.937);

	this.shape_226 = new cjs.Shape();
	this.shape_226.graphics.f("#D25558").s().p("AkfBPIBIieIG0AAIBDCeg");
	this.shape_226.setTransform(370.3,228.6,0.937,0.937);

	this.shape_227 = new cjs.Shape();
	this.shape_227.graphics.f("#66C2B0").s().p("AiuB7QgJAAgGgFQgGgHAAgIIAAjNQAAgJAGgFQAGgHAJABIFdAAQAJgBAGAHQAGAFAAAJIAADNQAAAIgGAHQgGAFgJAAg");
	this.shape_227.setTransform(370.5,254.6,0.937,0.937);

	this.shape_228 = new cjs.Shape();
	this.shape_228.graphics.f("#B73A3C").s().p("AgMAcQgGgFAAgIIAAgdQAAgHAGgGQAFgFAHAAQAIAAAFAFQAGAGAAAHIAAAdQAAAIgGAFQgFAFgIAAQgHAAgFgFg");
	this.shape_228.setTransform(395.6,237.8,0.937,0.937);

	this.shape_229 = new cjs.Shape();
	this.shape_229.graphics.f("#B73A3C").s().p("AgMAcQgGgFABgIIAAgdQgBgHAGgGQAFgFAHAAQAHAAAGAFQAFAGABAHIAAAdQgBAIgFAFQgGAFgHAAQgHAAgFgFg");
	this.shape_229.setTransform(390.5,237.8,0.937,0.937);

	this.shape_230 = new cjs.Shape();
	this.shape_230.graphics.f("#B73A3C").s().p("AgMAcQgGgFABgIIAAgdQgBgHAGgGQAFgFAHAAQAHAAAGAFQAFAGABAHIAAAdQgBAIgFAFQgGAFgHAAQgHAAgFgFg");
	this.shape_230.setTransform(385.5,237.8,0.937,0.937);

	this.shape_231 = new cjs.Shape();
	this.shape_231.graphics.f("#B73A3C").s().p("AgMAcQgGgFABgIIAAgdQgBgHAGgGQAFgFAHAAQAIAAAFAFQAFAGABAHIAAAdQgBAIgFAFQgFAFgIAAQgHAAgFgFg");
	this.shape_231.setTransform(380.4,237.8,0.937,0.937);

	this.shape_232 = new cjs.Shape();
	this.shape_232.graphics.f("#B73A3C").s().p("AgMAcQgGgFABgIIAAgdQgBgHAGgGQAFgFAHAAQAIAAAFAFQAFAGABAHIAAAdQgBAIgFAFQgFAFgIAAQgHAAgFgFg");
	this.shape_232.setTransform(375.3,237.8,0.937,0.937);

	this.shape_233 = new cjs.Shape();
	this.shape_233.graphics.f("#B73A3C").s().p("AgMAcQgGgFAAgIIAAgdQAAgHAGgGQAFgFAHAAQAIAAAFAFQAGAGAAAHIAAAdQAAAIgGAFQgFAFgIAAQgHAAgFgFg");
	this.shape_233.setTransform(370.3,237.8,0.937,0.937);

	this.shape_234 = new cjs.Shape();
	this.shape_234.graphics.f("#B73A3C").s().p("AgMAcQgGgFAAgIIAAgdQAAgHAGgGQAFgFAHAAQAIAAAFAFQAGAGAAAHIAAAdQAAAIgGAFQgFAFgIAAQgHAAgFgFg");
	this.shape_234.setTransform(365.2,237.8,0.937,0.937);

	this.shape_235 = new cjs.Shape();
	this.shape_235.graphics.f("#B73A3C").s().p("AgMAcQgGgFAAgIIAAgdQAAgHAGgGQAFgFAHAAQAIAAAFAFQAGAGAAAHIAAAdQAAAIgGAFQgFAFgIAAQgHAAgFgFg");
	this.shape_235.setTransform(360.2,237.8,0.937,0.937);

	this.shape_236 = new cjs.Shape();
	this.shape_236.graphics.f("#B73A3C").s().p("AgMAcQgGgFAAgIIAAgdQAAgHAGgGQAFgFAHAAQAHAAAGAFQAGAGgBAHIAAAdQABAIgGAFQgGAFgHAAQgHAAgFgFg");
	this.shape_236.setTransform(355.1,237.8,0.937,0.937);

	this.shape_237 = new cjs.Shape();
	this.shape_237.graphics.f("#B73A3C").s().p("AgMAcQgGgFAAgIIAAgdQAAgHAGgGQAFgFAHAAQAIAAAFAFQAGAGgBAHIAAAdQABAIgGAFQgFAFgIAAQgHAAgFgFg");
	this.shape_237.setTransform(350.1,237.8,0.937,0.937);

	this.shape_238 = new cjs.Shape();
	this.shape_238.graphics.f("#B73A3C").s().p("AgMAcQgGgFAAgIIAAgdQAAgHAGgGQAFgFAHAAQAIAAAFAFQAGAGgBAHIAAAdQABAIgGAFQgFAFgIAAQgHAAgFgFg");
	this.shape_238.setTransform(345,237.8,0.937,0.937);

	this.shape_239 = new cjs.Shape();
	this.shape_239.graphics.f("#EAECE1").s().p("Aj8CuIAAlbIH5AAIAAFbg");
	this.shape_239.setTransform(370.5,251.5,0.937,0.937);

	this.shape_240 = new cjs.Shape();
	this.shape_240.graphics.f("#598415").s().p("AidCAQgQgYAAgdQgBgbANgWQANgUAUgHQAFg1AgglQAhgkArAAQAaAAAXAOQAXANAPAZQAMgOAPgBQAQABALAOQALANAAATIgBALQASAOAKAWQALAXAAAbQAAAsgZAeg");
	this.shape_240.setTransform(352.4,255.6,0.937,0.937);

	this.shape_241 = new cjs.Shape();
	this.shape_241.graphics.f("#598415").s().p("AidCAQgRgYAAgdQAAgbANgVQANgVAUgIQAFg1AggkQAhgkArAAQAZAAAYAOQAWANAQAYQAMgNAPAAQAQAAALANQALAOAAAUIgBAKQASAOAKAWQALAXAAAbQAAAqgZAgg");
	this.shape_241.setTransform(387.4,255.8,0.937,0.937);

	this.shape_242 = new cjs.Shape();
	this.shape_242.graphics.f("#B6E9B7").s().p("AmVBFQgOgcgLgjQCvg+C6gKQECgPDyBZQgMAkgNAZg");
	this.shape_242.setTransform(129.6,116,0.937,0.937);

	this.shape_243 = new cjs.Shape();
	this.shape_243.graphics.f("#B6E9B7").s().p("AjxA4QhrhDg5hyIMrAAQg5ByhrBDQhvBGiDAAQiCAAhvhGg");
	this.shape_243.setTransform(129.6,134.3,0.937,0.937);

	this.shape_244 = new cjs.Shape();
	this.shape_244.graphics.f("#C1EAF8").s().p("AhFDdQi6ALiwA/QgVhEAAhGQAAi6CFiFQCEiFC7AAQC7AACFCFQCFCFAAC6QAABGgWBFQjzhakBAPg");
	this.shape_244.setTransform(129.6,89,0.937,0.937);

	this.shape_245 = new cjs.Shape();
	this.shape_245.graphics.f("#B6E9B7").s().p("AmVBGQgPgfgKghQCwg9C5gLQECgPDyBZQgJAegQAgg");
	this.shape_245.setTransform(128.4,257.9,0.937,0.937);

	this.shape_246 = new cjs.Shape();
	this.shape_246.graphics.f("#B6E9B7").s().p("AjxA4QhshEg4hxIMrAAQg4BxhsBEQhuBGiEAAQiDAAhuhGg");
	this.shape_246.setTransform(128.5,276.2,0.937,0.937);

	this.shape_247 = new cjs.Shape();
	this.shape_247.graphics.f("#C1EAF8").s().p("AhFDdQi5ALiwA+QgWhBAAhIQAAi7CFiEQCEiFC7AAQC8AACECFQCECEABC7QAABHgWBEQjzhakBAPg");
	this.shape_247.setTransform(128.5,230.9,0.937,0.937);

	this.shape_248 = new cjs.Shape();
	this.shape_248.graphics.f("#B6E9B7").s().p("AmVBFQgOgcgLgjQCvg+C6gKQECgPDyBZQgMAkgNAZg");
	this.shape_248.setTransform(369,256.2,0.937,0.937);

	this.shape_249 = new cjs.Shape();
	this.shape_249.graphics.f("#B6E9B7").s().p("AjxA4QhshDg4hyIMrAAQg5ByhrBDQhuBGiEAAQiCAAhvhGg");
	this.shape_249.setTransform(369,274.5,0.937,0.937);

	this.shape_250 = new cjs.Shape();
	this.shape_250.graphics.f("#C1EAF8").s().p("AhFDdQi6AKiwA/QgVhDAAhGQAAi6CFiFQCEiFC7AAQC7AACFCFQCFCFAAC6QAABGgWBFQjzhakBAPg");
	this.shape_250.setTransform(369,229.2,0.937,0.937);

	this.shape_251 = new cjs.Shape();
	this.shape_251.graphics.f("#990000").s().p("AglEKQhugPhDhZQhDhZAQhuQAPhuBZhDQBZhDBuAQQBuAPBDBZQBDBZgQBtQgPBvhZBDQhJA2hWAAQgTAAgVgDgAiIi0QhLA4gNBdQgNBdA5BLQA4BLBdANQBcANBLg5QBLg4AOhdQANhcg5hMQg4hKhegOQgRgDgQAAQhIAAg+Avg");
	this.shape_251.setTransform(354.2,104.2);

	this.shape_252 = new cjs.Shape();
	this.shape_252.graphics.f("#C44327").s().p("AANBvIhqibIBYhCIAmAwIgsAiIBpCLg");
	this.shape_252.setTransform(374.9,130.8,0.937,0.937);

	this.shape_253 = new cjs.Shape();
	this.shape_253.graphics.f("#EE5B34").s().p("AgdBvIhqibIBXhCIC4Ddg");
	this.shape_253.setTransform(378.8,130.8,0.937,0.937);

	this.shape_254 = new cjs.Shape();
	this.shape_254.graphics.f("#83951B").s().p("AghAiQgOgOAAgUQAAgTAOgOQAOgOATAAQAUAAAOAOQAOAOAAATQAAAUgOAOQgOAOgUAAQgTAAgOgOg");
	this.shape_254.setTransform(351.7,105.7,0.937,0.937);

	this.shape_255 = new cjs.Shape();
	this.shape_255.graphics.f("#653F31").s().p("AgQAjQgFAAAAgFIgFg6QAAgGAFAAIAqAAQAGAAAAAGIgGA6QAAAFgFAAg");
	this.shape_255.setTransform(351.7,116.5,0.937,0.937);

	this.shape_256 = new cjs.Shape();
	this.shape_256.graphics.f("#88695F").s().p("AgEAsQgDgCAAgDIAAhNQAAgDADgCQACgCACAAQADAAADACQABACAAADIAABNQAAADgBACQgDACgDAAQgCAAgCgCg");
	this.shape_256.setTransform(351.7,111.9,0.937,0.937);

	this.shape_257 = new cjs.Shape();
	this.shape_257.graphics.f("#5C2C14").s().p("AhCAyQgHAAgFgGQgGgFAAgHIAAg+QAAgIAGgFQAFgFAHAAIAuAAIAJAGIg3AAQgEAAgEAEQgDADAAAFIAAA+QAAAFADADQAEADAEAAICSAAIAFAHg");
	this.shape_257.setTransform(367.7,87,0.937,0.937);

	this.shape_258 = new cjs.Shape();
	this.shape_258.graphics.f("#9C6C50").s().p("AhCAvQgGAAgEgFQgFgFAAgFIAAg+QAAgGAFgFQAEgEAGgBIAyAAIAiAZQAUAPAMAMQAQARAQAYg");
	this.shape_258.setTransform(367.8,87,0.937,0.937);

	this.shape_259 = new cjs.Shape();
	this.shape_259.graphics.f("#F2F2F2").s().p("AgDBmIAAjLIAGAAIAADLg");
	this.shape_259.setTransform(358,104.4,0.937,0.937);

	this.shape_260 = new cjs.Shape();
	this.shape_260.graphics.f("#572A1C").s().p("AgJAFQgFAAAAgFQAAgEAFAAIATAAQAFAAAAAEQAAAFgFAAg");
	this.shape_260.setTransform(379.2,107.4,0.937,0.937);

	this.shape_261 = new cjs.Shape();
	this.shape_261.graphics.f("#7086BD").s().p("AgHBIIAAiPIAHALIAAANQgDADgBAEQgBAEAEAFIABABIAABfIAHAAIAAAHg");
	this.shape_261.setTransform(381.5,107.4,0.937,0.937);

	this.shape_262 = new cjs.Shape();
	this.shape_262.graphics.f("#66C2B0").s().p("AgEgKIAJAPQgFAAgEAGg");
	this.shape_262.setTransform(381.6,102.3,0.937,0.937);

	this.shape_263 = new cjs.Shape();
	this.shape_263.graphics.f("#66C2B0").s().p("AgGA0IAAhnIACADQAEAFADAKIADARQACAYgCARIgCAbg");
	this.shape_263.setTransform(381.8,109,0.937,0.937);

	this.shape_264 = new cjs.Shape();
	this.shape_264.graphics.f("#F2F2F2").s().p("AgCBmIAAjLIAFAAIAADLg");
	this.shape_264.setTransform(371.7,104.4,0.937,0.937);

	this.shape_265 = new cjs.Shape();
	this.shape_265.graphics.f("#785548").s().p("AiJAYQgGAAgEgEQgFgFAAgGIAAgRQAAgGAFgEQAEgFAGAAIEAAAQASAVAQAag");
	this.shape_265.setTransform(362,90.6,0.937,0.937);

	this.shape_266 = new cjs.Shape();
	this.shape_266.graphics.f("#653F31").s().p("Ah6AUQgHABgEgFQgEgEgBgGIAAgLQABgGAEgEQAEgFAHABIDhAAIAJAIQANANAOASg");
	this.shape_266.setTransform(362,88.7,0.937,0.937);

	this.shape_267 = new cjs.Shape();
	this.shape_267.graphics.f("#653F31").s().p("AgKB1IAAjpIAHANIAADVIANAAIgCAHg");
	this.shape_267.setTransform(380.3,108.9,0.937,0.937);

	this.shape_268 = new cjs.Shape();
	this.shape_268.graphics.f("#785548").s().p("AgOBwIAAjfIAWAnIADAGQgGAAgDAFQgDAHAFAGQAFAEACAKIADARQACAZgBARQgDAwgKAng");
	this.shape_268.setTransform(381,109,0.937,0.937);

	this.shape_269 = new cjs.Shape();
	this.shape_269.graphics.f("#181C23").s().p("AgPAKQgCgDAAgHQAAgLALgDQAKgDAIAKQADADADACIgEADQgGACgHAAQgBAAAAAAQAAAAgBAAQAAABgBAAQAAAAAAABQAAABgBABQAAABgBAAQAAAAgBABQAAAAgBgBIgBgDIgBgBQAAAAgBAAQAAAAAAAAQAAAAAAAAQgBAAAAABQAAABAAAAQAAABABAAQAAABAAAAQABABABAAIAAAHIgIgGg");
	this.shape_269.setTransform(370,106.8,0.937,0.937);

	this.shape_270 = new cjs.Shape();
	this.shape_270.graphics.f("#1C3355").s().p("AgEAEQgJgBgDgDQgBAAAAAAQgBgBAAAAQAAgBAAAAQAAAAAAgBQACgDAEgBIAEAAIAbAKIAAAFg");
	this.shape_270.setTransform(369.8,112.3,0.937,0.937);

	this.shape_271 = new cjs.Shape();
	this.shape_271.graphics.f("#202B41").s().p("AgBAAIAAgCIACgBIABACIAAAFg");
	this.shape_271.setTransform(370.2,109.8,0.937,0.937);

	this.shape_272 = new cjs.Shape();
	this.shape_272.graphics.f("#D79E73").s().p("AAAAOQgFAAgFgEQgEgEAAgGQAAgGAEgFQAFgEAFAAQAHAAAEAEQAEAFAAAGQAAAHgDAGQgDADgDAAQgDAAgDgCg");
	this.shape_272.setTransform(369.9,107,0.937,0.937);

	this.shape_273 = new cjs.Shape();
	this.shape_273.graphics.f("#FFFFFF").s().p("AgFAAIgCgCIADgCIACACQAAAAABAAQABAAAAABQAAAAAAAAQABAAAAAAIAEgCIAAgBIACAAIABAHIgFgDIgCAFg");
	this.shape_273.setTransform(369.7,108.8,0.937,0.937);

	this.shape_274 = new cjs.Shape();
	this.shape_274.graphics.f("#1C3355").s().p("AAAARIgCgDQgFgNABgJQAAgFADgDIADgCQADABACAPIADAOQAAAGgDABIgBAAQgBAAAAAAQgBAAgBAAQAAgBgBAAQAAgBAAAAg");
	this.shape_274.setTransform(368.3,110.6,0.937,0.937);

	this.shape_275 = new cjs.Shape();
	this.shape_275.graphics.f("#172C48").s().p("AgGAIIgCgNIAAgLIAFALIAEAMIAJAFIgBAFQgOgDgBgGg");
	this.shape_275.setTransform(368.5,111.4,0.937,0.937);

	this.shape_276 = new cjs.Shape();
	this.shape_276.graphics.f("#1C3355").s().p("AgJAcIAAgqIACgFQAEgFAIgDIACAIQADAJAAAIQAAAOgCAQg");
	this.shape_276.setTransform(368.5,111.1,0.937,0.937);

	this.shape_277 = new cjs.Shape();
	this.shape_277.graphics.f("#202B41").s().p("AgBAAIABgDIACABIAAAFIgCABg");
	this.shape_277.setTransform(370.1,109.1,0.937,0.937);

	this.shape_278 = new cjs.Shape();
	this.shape_278.graphics.f("#202B41").s().p("AgEADIAAgFIAJAAIgBAFg");
	this.shape_278.setTransform(368.9,113.4,0.937,0.937);

	this.shape_279 = new cjs.Shape();
	this.shape_279.graphics.f("#1C3355").s().p("AAAAcIABgWQABgNgCgLIgEgIIACgBIAAAAIAFACIACAVQgBAZgBADIgCAEg");
	this.shape_279.setTransform(370.7,111.1,0.937,0.937);

	this.shape_280 = new cjs.Shape();
	this.shape_280.graphics.f("#D79E73").s().p("AgFACIADgCIAGgDIACADQgCAFgGAAQgFgBACgCg");
	this.shape_280.setTransform(371.9,112.6,0.937,0.937);

	this.shape_281 = new cjs.Shape();
	this.shape_281.graphics.f("#DFE7F2").s().p("AgFgFIALgCIgBAPg");
	this.shape_281.setTransform(369.9,109.5,0.937,0.937);

	this.shape_282 = new cjs.Shape();
	this.shape_282.graphics.f("#D79E73").s().p("AgEAFIAAgMIAJAAIAAANQAAAAgBABQAAAAgBAAQAAAAgBABQAAAAgBAAQgBAAgEgDg");
	this.shape_282.setTransform(369.7,108.1,0.937,0.937);

	this.shape_283 = new cjs.Shape();
	this.shape_283.graphics.f("#243B67").s().p("AgKAWIgHgEIAAgWQAAgIAGgFIAGgEQAOgGAJAIIAAAiQgCAFgMADIgFABQgEAAgFgCg");
	this.shape_283.setTransform(369.3,110.6,0.937,0.937);

	this.shape_284 = new cjs.Shape();
	this.shape_284.graphics.f("#1C3355").s().p("AgCAQIgCgDIABgeIADABIADANIACAOQABAGgDABIgCAAQAAAAgBAAQAAAAAAAAQAAgBgBAAQAAgBgBAAg");
	this.shape_284.setTransform(371.1,110.2,0.937,0.937);

	this.shape_285 = new cjs.Shape();
	this.shape_285.graphics.f("#202B41").s().p("AADAMIgBgEIgGACIAAACIgMAAIgBgWIAjAFIgCARg");
	this.shape_285.setTransform(369.2,112.6,0.937,0.937);

	this.shape_286 = new cjs.Shape();
	this.shape_286.graphics.f("#F0C136").s().p("AgEgFIATgJIgLAVIgSAIg");
	this.shape_286.setTransform(372.8,111.6,0.937,0.937);

	this.shape_287 = new cjs.Shape();
	this.shape_287.graphics.f("#1C3355").s().p("AgEAEQgJgBgDgDQgBAAAAAAQgBgBAAAAQAAgBAAAAQAAAAAAgBQACgDAEgBIAEAAIAbAKIAAAFg");
	this.shape_287.setTransform(371.4,111.5,0.937,0.937);

	this.shape_288 = new cjs.Shape();
	this.shape_288.graphics.f("#F2F2F2").s().p("Ag0BqIAAjTIBpAAIAADTgAgtBjIBcAAIAAjGIhcAAg");
	this.shape_288.setTransform(371.7,104.4,0.937,0.937);

	this.shape_289 = new cjs.Shape();
	this.shape_289.graphics.f("#F2F2F2").s().p("Ag0BqIAAjTIBpAAIAADTgAgtBjIBcAAIAAjGIhcAAg");
	this.shape_289.setTransform(357.9,104.4,0.937,0.937);

	this.shape_290 = new cjs.Shape();
	this.shape_290.graphics.f("#66C2B0").s().p("AgxBnIAAjNIBjAAIAADNg");
	this.shape_290.setTransform(358,104.3,0.937,0.937);

	this.shape_291 = new cjs.Shape();
	this.shape_291.graphics.f("#D25558").s().p("AitCWIAAkrIESAAIAUAiIAXAoQANAZAKAPIADAGQgGAAgDAGQgEAGAGAGQAFAFACAJIADARQACAZgBARQgDAxgLAng");
	this.shape_291.setTransform(366.1,105.6,0.937,0.937);

	this.shape_292 = new cjs.Shape();
	this.shape_292.graphics.f("#83951B").s().p("AgaAbQgLgLABgQQgBgOALgLQALgLAPAAQAPAAALALQAMALgBAOQABAPgMAMQgLAKgPABQgPgBgLgKg");
	this.shape_292.setTransform(366.7,108.8,0.937,0.937);

	this.shape_293 = new cjs.Shape();
	this.shape_293.graphics.f("#653F31").s().p("AgMAbQgEAAAAgEIgEgtQAAgEAEAAIAhAAQAEAAAAAEIgEAtQAAAEgEAAg");
	this.shape_293.setTransform(366.7,117.2,0.937,0.937);

	this.shape_294 = new cjs.Shape();
	this.shape_294.graphics.f("#88695F").s().p("AgFAfIAAg8QAAgGAFAAQAGAAAAAGIAAA8QAAAFgGAAQgFAAAAgFg");
	this.shape_294.setTransform(366.6,113.6,0.937,0.937);

	this.shape_295 = new cjs.Shape();
	this.shape_295.graphics.f("#5C2C14").s().p("AhHAnQgHAAgDgEQgFgFAAgFIAAgxQAAgGAFgEQADgEAHAAICQAAQAFAAAFAEQAEAEAAAGIAAAxQAAAFgEAFQgFAEgFAAgAhOgeQgCADAAADIAAAxQAAAEACACQADADAEAAICQAAQADAAADgDQACgCABgEIAAgxQgBgDgCgDQgDgDgDAAIiQAAQgEAAgDADg");
	this.shape_295.setTransform(381.1,94.1,0.937,0.937);

	this.shape_296 = new cjs.Shape();
	this.shape_296.graphics.f("#9C6C50").s().p("AhHAkQgFAAgEgDQgDgEAAgEIAAgxQAAgFADgDQAEgDAFAAICQAAQAFAAADADQADADAAAFIAAAxQAAAEgDAEQgDADgFAAg");
	this.shape_296.setTransform(381.1,94.1,0.937,0.937);

	this.shape_297 = new cjs.Shape();
	this.shape_297.graphics.f("#F2F2F2").s().p("AgCBQIAAifIAFAAIAACfg");
	this.shape_297.setTransform(371.6,107.8,0.937,0.937);

	this.shape_298 = new cjs.Shape();
	this.shape_298.graphics.f("#572A1C").s().p("AgHAEQgEAAAAgEQAAgDAEAAIAPAAQAEAAAAADQAAAEgEAAg");
	this.shape_298.setTransform(388.2,110.1,0.937,0.937);

	this.shape_299 = new cjs.Shape();
	this.shape_299.graphics.f("#7086BD").s().p("AggBIIAAiQIBBAAIAACQgAgbBDIA3AAIAAiFIg3AAg");
	this.shape_299.setTransform(392.6,108.6,0.937,0.937);

	this.shape_300 = new cjs.Shape();
	this.shape_300.graphics.f("#66C2B0").s().p("AgeBGIAAiLIA9AAIAACLg");
	this.shape_300.setTransform(392.6,108.6,0.937,0.937);

	this.shape_301 = new cjs.Shape();
	this.shape_301.graphics.f("#F2F2F2").s().p("AgCBQIAAifIAFAAIAACfg");
	this.shape_301.setTransform(382.3,107.8,0.937,0.937);

	this.shape_302 = new cjs.Shape();
	this.shape_302.graphics.f("#785548").s().p("Ai7ATQgFAAgDgEQgEgDAAgFIAAgNQAAgFAEgDQADgEAFAAIF3AAQAFAAADAEQAEADAAAFIAAANQAAAFgEADQgDAEgFAAg");
	this.shape_302.setTransform(382.3,96.9,0.937,0.937);

	this.shape_303 = new cjs.Shape();
	this.shape_303.graphics.f("#653F31").s().p("AiwAQQgFAAgDgEQgDgCAAgGIAAgIQAAgEADgDQADgEAFAAIFhAAQAFAAADAEQADADAAAEIAAAIQAAAGgDACQgDAEgFAAg");
	this.shape_303.setTransform(382.2,95.5,0.937,0.937);

	this.shape_304 = new cjs.Shape();
	this.shape_304.graphics.f("#653F31").s().p("AgtBqIAAjTIBbAAIAADTgAgpBlIBSAAIAAjJIhSAAg");
	this.shape_304.setTransform(392.6,109.9,0.937,0.937);

	this.shape_305 = new cjs.Shape();
	this.shape_305.graphics.f("#785548").s().p("AgrBoIAAjPIBXAAIAADPg");
	this.shape_305.setTransform(392.6,109.9,0.937,0.937);

	this.shape_306 = new cjs.Shape();
	this.shape_306.graphics.f("#F2F2F2").s().p("AgpBTIAAilIBTAAIAAClgAgjBOIBIAAIAAibIhIAAg");
	this.shape_306.setTransform(382.3,107.7,0.937,0.937);

	this.shape_307 = new cjs.Shape();
	this.shape_307.graphics.f("#66C2B0").s().p("AgmBQIAAifIBNAAIAACfg");
	this.shape_307.setTransform(382.3,107.7,0.937,0.937);

	this.shape_308 = new cjs.Shape();
	this.shape_308.graphics.f("#F2F2F2").s().p("AgpBTIAAilIBTAAIAAClgAgjBOIBHAAIAAibIhHAAg");
	this.shape_308.setTransform(371.6,107.7,0.937,0.937);

	this.shape_309 = new cjs.Shape();
	this.shape_309.graphics.f("#66C2B0").s().p("AgmBQIAAifIBNAAIAACfg");
	this.shape_309.setTransform(371.6,107.7,0.937,0.937);

	this.shape_310 = new cjs.Shape();
	this.shape_310.graphics.f("#D25558").s().p("Ai4B2IAAjqIFxAAIAADqg");
	this.shape_310.setTransform(382.5,108.7,0.937,0.937);

	this.shape_311 = new cjs.Shape();
	this.shape_311.graphics.f("#B6E9B7").s().p("AmVBFQgPgegKghQCwg9C5gLQEBgPDzBZQgKAegPAfg");
	this.shape_311.setTransform(368.6,117.3,0.937,0.937);

	this.shape_312 = new cjs.Shape();
	this.shape_312.graphics.f("#B6E9B7").s().p("AjxA4QhshDg4hyIMrAAQg4ByhsBDQhuBGiEAAQiDAAhuhGg");
	this.shape_312.setTransform(368.6,135.6,0.937,0.937);

	this.shape_313 = new cjs.Shape();
	this.shape_313.graphics.f("#C1EAF8").s().p("AhFDdQi5ALiwA/QgWhDAAhHQAAi6CFiFQCFiFC6AAQC8AACECFQCFCFAAC6QAABHgWBEQjzhZkBAOg");
	this.shape_313.setTransform(368.6,90.3,0.937,0.937);

	this.shape_314 = new cjs.Shape();
	this.shape_314.graphics.f("#F0C136").s().p("AARAcIgsgsQgFgFAFgGQAGgFAEAFIAtAsQADADAAADQAAADgDACQgCACgDAAQgEAAgCgCg");
	this.shape_314.setTransform(240.4,0.6,0.937,0.937);

	this.shape_315 = new cjs.Shape();
	this.shape_315.graphics.f("#F0C136").s().p("AgfAIQgIAAABgIQgBgGAIgBIA/AAQADABACACQACACAAACQAAADgCACQgCADgDAAg");
	this.shape_315.setTransform(263.4,8.9,0.937,0.937);

	this.shape_316 = new cjs.Shape();
	this.shape_316.graphics.f("#F0C136").s().p("AgfAIQgDAAgCgDQgDgCAAgDQAAgCADgCQACgCADgBIA/AAQADABADACQACACAAACQAAADgCACQgDADgDAAg");
	this.shape_316.setTransform(236.5,8.9,0.937,0.937);

	this.shape_317 = new cjs.Shape();
	this.shape_317.graphics.f("#F0C136").s().p("AgEAmQgCgDgBgDIAAg/QABgDACgCQACgDACAAQAHAAABAIIAAA/QgBAIgHAAQgCAAgCgCg");
	this.shape_317.setTransform(249.4,-2.4,0.937,0.937);

	this.shape_318 = new cjs.Shape();
	this.shape_318.graphics.f("#D79E73").s().p("AgCABIACgEIADAFIgCACg");
	this.shape_318.setTransform(244.7,14.4,0.937,0.937);

	this.shape_319 = new cjs.Shape();
	this.shape_319.graphics.f("#D79E73").s().p("AgCADIgBgGIABAAIABADIADgGIACAGIgEAHg");
	this.shape_319.setTransform(248.7,16.1,0.937,0.937);

	this.shape_320 = new cjs.Shape();
	this.shape_320.graphics.f("#243B67").s().p("AgOAVQgFgBgDgFQgCgEABgFQABgGAFgBIAGgCIARgBIAGgNQADgFAGACQAFADgCAGIgGAPQAAABgBAAQAAABAAAAQAAAAgBABQAAAAgBAAIgCABIgRALQgEADgDAAIgDgBg");
	this.shape_320.setTransform(247,17.7,0.937,0.937);

	this.shape_321 = new cjs.Shape();
	this.shape_321.graphics.f("#243B67").s().p("AgCgDIAAgBIACgCQABAAACAGIgDAHg");
	this.shape_321.setTransform(244.6,18.1,0.937,0.937);

	this.shape_322 = new cjs.Shape();
	this.shape_322.graphics.f("#243B67").s().p("AgCAGIAAgQIAFAIIgBAKIgCADg");
	this.shape_322.setTransform(244.8,18.5,0.937,0.937);

	this.shape_323 = new cjs.Shape();
	this.shape_323.graphics.f("#243B67").s().p("AgCAIQgFgBgCgCIgCgCIAAgLIAUAAIADAQIgIABIgGgBg");
	this.shape_323.setTransform(245.6,19.9,0.937,0.937);

	this.shape_324 = new cjs.Shape();
	this.shape_324.graphics.f("#243B67").s().p("AAAALIgJgKIgBgLIAHABQAHABAFAGIABAAIABANIgDAAg");
	this.shape_324.setTransform(245.5,18.5,0.937,0.937);

	this.shape_325 = new cjs.Shape();
	this.shape_325.graphics.f("#243B67").s().p("AgKAMIAAgcIARAHIADAPIABALg");
	this.shape_325.setTransform(245.5,19.1,0.937,0.937);

	this.shape_326 = new cjs.Shape();
	this.shape_326.graphics.f("#FFFFFF").s().p("AgCACQgBgBAAAAQgBgBAAAAQgBAAAAAAQAAAAAAgBQABgDAHAEQABAAAAAAQABAAAAABQAAAAAAAAQABABAAABIgFAAIgDgBg");
	this.shape_326.setTransform(245.5,17.7,0.937,0.937);

	this.shape_327 = new cjs.Shape();
	this.shape_327.graphics.f("#202B41").s().p("AgNAbIAAAAIAGgTIgCggIAQgCQACABABADIABABIABABQAAAAAAAAQAAAAABABQAAAAAAAAQABAAAAAAIgBAaIgDAUIgDAAIgDgoIgDgBIgCAYIgJASg");
	this.shape_327.setTransform(245.5,22.5,0.937,0.937);

	this.shape_328 = new cjs.Shape();
	this.shape_328.graphics.f("#1E2128").s().p("AgDABIAAgBIADgBIABAAIADABQABAAgGACg");
	this.shape_328.setTransform(244.5,25.1,0.937,0.937);

	this.shape_329 = new cjs.Shape();
	this.shape_329.graphics.f("#1E2128").s().p("AgDABIAAgBIADgBQABgBADACIgEACg");
	this.shape_329.setTransform(246.5,25.1,0.937,0.937);

	this.shape_330 = new cjs.Shape();
	this.shape_330.graphics.f("#D79E73").s().p("AgCAAQAAAAABAAQAAgBAAAAQAAAAABgBQAAAAAAAAQAAAAAAAAQABABAAAAQABAAAAABQAAAAAAAAQAAAAAAABQAAABAAAAQAAAAgBABQAAAAgBAAQAAAAAAAAQgBgBAAAAQAAAAAAgBQgBAAAAgBg");
	this.shape_330.setTransform(246.2,16.6,0.937,0.937);

	this.shape_331 = new cjs.Shape();
	this.shape_331.graphics.f("#181C23").s().p("AgFAGQgCgCAAgDQAAgDACgCQACgDADAAQADgBADADQACACAAADQAAADgCACQgCADgEAAIAAAAQgCAAgDgCg");
	this.shape_331.setTransform(244.8,15.8,0.937,0.937);

	this.shape_332 = new cjs.Shape();
	this.shape_332.graphics.f("#243B67").s().p("AgHABQAAgHAHgBQAHAAABAHQABAHgJABQgGAAgBgHg");
	this.shape_332.setTransform(244.9,15.9,0.937,0.937);

	this.shape_333 = new cjs.Shape();
	this.shape_333.graphics.f("#181C23").s().p("AABALIgEAAQgDgBgCgCIgCgFIAGgMIAHgBQALgCgEAHIgCABQgCABABAEQAAAFgCADQgBABAAAAQgBABAAAAQAAAAgBAAQAAABAAAAIgBgBg");
	this.shape_333.setTransform(245.6,16.3,0.937,0.937);

	this.shape_334 = new cjs.Shape();
	this.shape_334.graphics.f("#D79E73").s().p("AgCACIgBgFIAGgBIABAJg");
	this.shape_334.setTransform(245.5,17.4,0.937,0.937);

	this.shape_335 = new cjs.Shape();
	this.shape_335.graphics.f("#D79E73").s().p("AgHAIQgDgCAAgGQgBgDADgEQADgDAFAAQAEgBADADQAEADAAAFQAAAFgBACQgCAEgIAAIAAAAQgEAAgDgDg");
	this.shape_335.setTransform(245.6,16.4,0.937,0.937);

	this.shape_336 = new cjs.Shape();
	this.shape_336.graphics.f("#243B67").s().p("AACAhQgEgBgDgEIgBgEIgKgfQAAgDABgCIAKgRQAEgFAEADQAGAEgDAFIgHANIAQAXQADAEgBAFQgBAFgEADQgDACgEAAIgDAAg");
	this.shape_336.setTransform(244.7,16.9,0.937,0.937);

	this.shape_337 = new cjs.Shape();
	this.shape_337.graphics.f("#D79E73").s().p("AgBAAQAAAAAAAAQAAgBABAAQAAAAAAgBQAAAAAAAAQABAAAAAAQAAABAAAAQABAAAAABQAAAAAAAAQAAABAAAAQAAABgBAAQAAAAAAABQAAAAgBAAQAAAAAAAAQAAgBAAAAQgBAAAAgBQAAAAAAgBg");
	this.shape_337.setTransform(253.9,21.8,0.937,0.937);

	this.shape_338 = new cjs.Shape();
	this.shape_338.graphics.f("#1E2128").s().p("AAAAGQAAgIgIABQgGABAEgFQADgFAHAAQAHgBAEAFQADAEgBAEQgBAFgFAEIgFABQgCgBAAgFg");
	this.shape_338.setTransform(254.1,21.3,0.937,0.937);

	this.shape_339 = new cjs.Shape();
	this.shape_339.graphics.f("#243B67").s().p("AgFACIADgCQAHgDABACQAAACgGACg");
	this.shape_339.setTransform(254.4,22.7,0.937,0.937);

	this.shape_340 = new cjs.Shape();
	this.shape_340.graphics.f("#243B67").s().p("AgCAAIABgCQABgBAAgBQAAgBAAAAQAAgBABAAQAAAAAAAAQABAAAAAAQAAAAABABQAAAAAAABQAAAAAAABIgCAKg");
	this.shape_340.setTransform(255.3,23.1,0.937,0.937);

	this.shape_341 = new cjs.Shape();
	this.shape_341.graphics.f("#243B67").s().p("AgBAJIgBgLIAFgIIAAARIgDAEg");
	this.shape_341.setTransform(255.1,23.5,0.937,0.937);

	this.shape_342 = new cjs.Shape();
	this.shape_342.graphics.f("#1C3355").s().p("AgCAHIAAgBQAFgIABgFIgCAPg");
	this.shape_342.setTransform(253.4,25.1,0.937,0.937);

	this.shape_343 = new cjs.Shape();
	this.shape_343.graphics.f("#243B67").s().p("AgHAJIgEgBIADgQIAUAAIAAAKQgBAEgIACIgGABIgEAAg");
	this.shape_343.setTransform(254.2,25,0.937,0.937);

	this.shape_344 = new cjs.Shape();
	this.shape_344.graphics.f("#D79E73").s().p("AgBAAQAAgBAAAAQABgBAAAAQAAAAAAAAQAAAAABAAIABADIgCACg");
	this.shape_344.setTransform(251.7,24.7,0.937,0.937);

	this.shape_345 = new cjs.Shape();
	this.shape_345.graphics.f("#1C3355").s().p("AgBALIgCgCIACgVQABABACAKIABAKQABABAAABQAAAAgBABQAAAAAAABQgBAAAAAAIgBAAIgCgCg");
	this.shape_345.setTransform(255.6,23.7,0.937,0.937);

	this.shape_346 = new cjs.Shape();
	this.shape_346.graphics.f("#243B67").s().p("AgGALIgEgBIgCgBIACgFIACgEIABgCIAAAAQAIgJAMABIgBAKIgJALIgEAAIgFAAg");
	this.shape_346.setTransform(254.2,23.5,0.937,0.937);

	this.shape_347 = new cjs.Shape();
	this.shape_347.graphics.f("#243B67").s().p("AABAMQgCAAgFgEIgDgEIACgCIAHAEIAFgNIACgFQAEAEgBAGIAAACQgCAJgDACQAAAAAAABQAAAAgBAAQAAAAgBABQAAAAAAAAIgCgBg");
	this.shape_347.setTransform(252.6,24.6,0.937,0.937);

	this.shape_348 = new cjs.Shape();
	this.shape_348.graphics.f("#243B67").s().p("AgLgBIACgFIACgCIAAAAIATgIIAAAcIgXAFIAAAAg");
	this.shape_348.setTransform(254.2,24.1,0.937,0.937);

	this.shape_349 = new cjs.Shape();
	this.shape_349.graphics.f("#202B41").s().p("AALAcIgJgRIgCgZIgEACIgCAnIgBAAIgCAAIgEgUIAAgiIAXAEIgCAgIAGASIgBABg");
	this.shape_349.setTransform(254.4,27.4,0.937,0.937);

	this.shape_350 = new cjs.Shape();
	this.shape_350.graphics.f("#D79E73").s().p("AgCgDIAFAAIAAAFIgFADg");
	this.shape_350.setTransform(254.4,22.5,0.937,0.937);

	this.shape_351 = new cjs.Shape();
	this.shape_351.graphics.f("#1E2128").s().p("AACACIgDgBIgCgBIAEgBIADABIAAABIgCABIAAAAg");
	this.shape_351.setTransform(255.4,30.1,0.937,0.937);

	this.shape_352 = new cjs.Shape();
	this.shape_352.graphics.f("#1E2128").s().p("AABACIgCgBIgCgBIAEgBIADABIAAABIgCABIgBAAg");
	this.shape_352.setTransform(253.4,30.1,0.937,0.937);

	this.shape_353 = new cjs.Shape();
	this.shape_353.graphics.f("#D79E73").s().p("AgHAJQgDgEAAgFQAAgEADgDQADgEAEAAQAFAAADAEQADADAAAEQAAAEgDAEQgDADgFAAIgDABQgCAAgCgDg");
	this.shape_353.setTransform(254.2,21.4,0.937,0.937);

	this.shape_354 = new cjs.Shape();
	this.shape_354.graphics.f("#222330").s().p("AgSALQgHAAgBgGQgBgHAHgBIAmgHQAHgBACAHQABAGgHACIgmAHg");
	this.shape_354.setTransform(251.6,19.8,0.937,0.937);

	this.shape_355 = new cjs.Shape();
	this.shape_355.graphics.f("#222330").s().p("AgSALQgGAAgBgGQgBgGAHgCIAkgHQAEAAACABQADACAAADQACAGgIACIgkAHg");
	this.shape_355.setTransform(251.8,22.2,0.937,0.937);

	this.shape_356 = new cjs.Shape();
	this.shape_356.graphics.f("#222330").s().p("AgaAFQgBgHAHgBIAmgHQAHgCACAIQABAGgHABIgmAIIgCAAQgGAAgBgGg");
	this.shape_356.setTransform(252,24.6,0.937,0.937);

	this.shape_357 = new cjs.Shape();
	this.shape_357.graphics.f("#222330").s().p("AgSALQgHAAgBgGQAAgDABgCQACgCADgBIAmgHQADgBADACQACACABADQABAGgHACIgmAHg");
	this.shape_357.setTransform(252.1,26.6,0.937,0.937);

	this.shape_358 = new cjs.Shape();
	this.shape_358.graphics.f("#222330").s().p("AAEBCQgFAAgBgHIgJh0QAAgDACgCQACgDADAAQAHgBAAAIIAJB0QABAHgIABg");
	this.shape_358.setTransform(253.7,23.1,0.937,0.937);

	this.shape_359 = new cjs.Shape();
	this.shape_359.graphics.f("#222330").s().p("AAEBCQgFAAgBgHIgJh0QAAgHAHgBQAHAAABAHIAIB0QABAHgIABg");
	this.shape_359.setTransform(250.1,23.8,0.937,0.937);

	this.shape_360 = new cjs.Shape();
	this.shape_360.graphics.f("#7F96F9").s().p("AgkABIgBgGQAmAKAlgKIgBAGQgSAFgTAAQgSAAgSgFg");
	this.shape_360.setTransform(249.8,21.5,0.937,0.937);

	this.shape_361 = new cjs.Shape();
	this.shape_361.graphics.f("#ACC0EB").s().p("AgkAAIgBgFIgBgSQAlALAogKIgBARIgBAGQgGAYgfgBQgeAAgGgYg");
	this.shape_361.setTransform(249.8,21.5,0.937,0.937);

	this.shape_362 = new cjs.Shape();
	this.shape_362.graphics.f("#F0C136").s().p("AgyA0QgWgWAAgeQAAgdAWgVQAVgWAdAAQAeAAAWAWQAVAVgBAdQABAegVAWQgWAVgeAAQgdAAgVgVg");
	this.shape_362.setTransform(249.6,10.1,0.937,0.937);

	this.shape_363 = new cjs.Shape();
	this.shape_363.graphics.f("#DA9C2C").s().p("AgRARQAAgagFgHIANAIQAOAHALgBQAPgBgSALQgOAJgMAAIgEAAg");
	this.shape_363.setTransform(247.8,17.2,0.937,0.937);

	this.shape_364 = new cjs.Shape();
	this.shape_364.graphics.f("#F0C136").s().p("AgkAqQgEgJAAgVIAAgFQAAgagFgGIAxgjIAYALQAXANgGAGQgJAJABAiIAAAEQAAATgFAJQgJAQgZAAQgbAAgHgTg");
	this.shape_364.setTransform(249.9,18.1,0.937,0.937);

	this.shape_365 = new cjs.Shape();
	this.shape_365.graphics.f("#7F96F9").s().p("AgbABQgBgLAJgIQAIgJALAAQAMAAAIAJQAJAIAAALQgBAbgcAAQgbAAAAgbg");
	this.shape_365.setTransform(249.7,21.9,0.937,0.937);

	this.shape_366 = new cjs.Shape();
	this.shape_366.graphics.f("#FFFFFF").s().p("AgqAeQglgLAAgTQAAgFAEgFQAIgLAVgGQAVgHAZAAQAhAAAXAKQAYALAAANQAAAPgYAKQgXAKghAAQgXAAgTgFg");
	this.shape_366.setTransform(249.5,23.4,0.937,0.937);

	this.shape_367 = new cjs.Shape();
	this.shape_367.graphics.f("#617DC4").s().p("AgRgFIAAgMIAEAAIAFgFIAaAhIAAAMQgigLgBgRg");
	this.shape_367.setTransform(243.7,25.2,0.937,0.937);

	this.shape_368 = new cjs.Shape();
	this.shape_368.graphics.f("#7F96F9").s().p("AhPAFIAAgKICfAAIAAALg");
	this.shape_368.setTransform(249.5,24.1,0.937,0.937);

	this.shape_369 = new cjs.Shape();
	this.shape_369.graphics.f("#7F96F9").s().p("AgqAeQgkgLgBgSIAAgBQAAgFAEgFIAGgGQAWgSAvAAQAaAAAVAHQAUAGAJALQAEAFAAAFIAAACQgCAOgXAJQgXAKggAAQgXAAgTgFg");
	this.shape_369.setTransform(249.5,24.6,0.937,0.937);

	this.shape_370 = new cjs.Shape();
	this.shape_370.graphics.f("#181C23").s().p("AgKAGQgCgCABgEQAAgHAHgCQAHgCAFAGQACADADABIgEACQgJgBgBADQAAABgBABQAAAAAAAAQAAABgBAAQAAAAAAAAIgBgDIgBAAIgCAAQAAABAAAAQAAABABAAQAAAAAAABQABAAABAAIAAAFIgGgFg");
	this.shape_370.setTransform(258.5,14,0.937,0.937);

	this.shape_371 = new cjs.Shape();
	this.shape_371.graphics.f("#1C3355").s().p("AgCADQgGgBgDgCQAAAAgBAAQAAAAAAAAQAAgBAAAAQAAAAAAAAQACgDADAAIACAAIASAFIAAAFg");
	this.shape_371.setTransform(258.3,17.7,0.937,0.937);

	this.shape_372 = new cjs.Shape();
	this.shape_372.graphics.f("#202B41").s().p("AgBAAIABgBIAAgBIACABIgBAEg");
	this.shape_372.setTransform(258.6,16,0.937,0.937);

	this.shape_373 = new cjs.Shape();
	this.shape_373.graphics.f("#D79E73").s().p("AAAAKQgDAAgDgDQgDgDAAgEQAAgEADgDQADgDADAAQAEAAADADQADADAAAEQAAAFgCAEQgBAAAAABQgBAAAAAAQgBABAAAAQgBAAAAAAIgEgBg");
	this.shape_373.setTransform(258.4,14.2,0.937,0.937);

	this.shape_374 = new cjs.Shape();
	this.shape_374.graphics.f("#FFFFFF").s().p("AgDAAIgBgBIACgCIADACIACgBIAAgBIACAAIAAAFIgDgCIgBAEg");
	this.shape_374.setTransform(258.3,15.4,0.937,0.937);

	this.shape_375 = new cjs.Shape();
	this.shape_375.graphics.f("#1C3355").s().p("AAAAMIgBgCQgEgJABgGIACgFIACgCQACABACAKIABAKQAAABAAAAQAAABAAAAQAAABgBAAQAAABAAAAIgBAAIgDgBg");
	this.shape_375.setTransform(257.3,16.6,0.937,0.937);

	this.shape_376 = new cjs.Shape();
	this.shape_376.graphics.f("#172C48").s().p("AgFAGIgBgQIAEAHIACAIIAHADIgBADQgJgCgCgDg");
	this.shape_376.setTransform(257.5,17.1,0.937,0.937);

	this.shape_377 = new cjs.Shape();
	this.shape_377.graphics.f("#1C3355").s().p("AgGARIAAgcIACgEQACgDAFgCIACAFIACAMIgCAXIgEABQgGAAgBgEg");
	this.shape_377.setTransform(257.5,17.1,0.937,0.937);

	this.shape_378 = new cjs.Shape();
	this.shape_378.graphics.f("#202B41").s().p("AgBAAIABgCIABABIAAADIgBABg");
	this.shape_378.setTransform(258.5,15.6,0.937,0.937);

	this.shape_379 = new cjs.Shape();
	this.shape_379.graphics.f("#202B41").s().p("AgEAIIADgTIAGAAIgFAXg");
	this.shape_379.setTransform(257.6,19.4,0.937,0.937);

	this.shape_380 = new cjs.Shape();
	this.shape_380.graphics.f("#202B41").s().p("AAAAMIgDgUIAHgDIAAAXIgEAAIAAAAg");
	this.shape_380.setTransform(258.6,21,0.937,0.937);

	this.shape_381 = new cjs.Shape();
	this.shape_381.graphics.f("#1C3355").s().p("AABADQAAgHgBgIIgDgFIACgBIABAAIACABIABAPIgBASQAAAAAAABQAAAAAAABQgBAAAAABQgBAAAAAAg");
	this.shape_381.setTransform(259,16.9,0.937,0.937);

	this.shape_382 = new cjs.Shape();
	this.shape_382.graphics.f("#202B41").s().p("AgGAGIAGgOIAHABIgKAQIgDgDg");
	this.shape_382.setTransform(256.9,21.3,0.937,0.937);

	this.shape_383 = new cjs.Shape();
	this.shape_383.graphics.f("#D79E73").s().p("AgDABIACgBIAEgCIABACQgBADgEAAQgBAAAAAAQgBAAAAAAQAAgBAAAAQAAAAAAgBg");
	this.shape_383.setTransform(259.7,18,0.937,0.937);

	this.shape_384 = new cjs.Shape();
	this.shape_384.graphics.f("#DFE7F2").s().p("AgDgDIAHgBIgBAJg");
	this.shape_384.setTransform(258.4,15.8,0.937,0.937);

	this.shape_385 = new cjs.Shape();
	this.shape_385.graphics.f("#D79E73").s().p("AgCAEIAAgIIAFAAIAAAIIgCABIgDgBg");
	this.shape_385.setTransform(258.3,14.9,0.937,0.937);

	this.shape_386 = new cjs.Shape();
	this.shape_386.graphics.f("#243B67").s().p("AgHAPIgEgCIAAgPQgBgGAFgDIAEgDQAKgEAFAGIAAAWQgBAEgIACIgEAAIgGgBg");
	this.shape_386.setTransform(257.9,16.6,0.937,0.937);

	this.shape_387 = new cjs.Shape();
	this.shape_387.graphics.f("#1C3355").s().p("AgBALIgCgCIACgUIABAAIACAJIABAKQABABAAAAQAAABgBABQAAAAAAABQgBAAAAAAIgBAAIgCgBg");
	this.shape_387.setTransform(259.2,16.3,0.937,0.937);

	this.shape_388 = new cjs.Shape();
	this.shape_388.graphics.f("#202B41").s().p("AgLARIAAgiIAXAEIgBAXIgEACIgEABIgBgRIgEACIgCAUIgBAAIgGgBg");
	this.shape_388.setTransform(257.9,18.9,0.937,0.937);

	this.shape_389 = new cjs.Shape();
	this.shape_389.graphics.f("#F0C136").s().p("AgCgDIANgGIgIAOIgNAFg");
	this.shape_389.setTransform(260.3,17.3,0.937,0.937);

	this.shape_390 = new cjs.Shape();
	this.shape_390.graphics.f("#1C3355").s().p("AgDADQgFgBgDgCIgBgBQABgDADAAIADAAIASAFIAAAFg");
	this.shape_390.setTransform(259.4,17.2,0.937,0.937);

	this.shape_391 = new cjs.Shape();
	this.shape_391.graphics.f("#1A1E26").s().p("AgBACIgDgBIAAgCIAEgBIAEADQABAAAAAAQAAAAAAAAQAAABAAAAQgBAAgBABIgBAAIgDgBg");
	this.shape_391.setTransform(259,22.2,0.937,0.937);

	this.shape_392 = new cjs.Shape();
	this.shape_392.graphics.f("#1A1E26").s().p("AAAADQAAAAgBgBQAAAAgBAAQAAAAAAgBQgBAAAAgBIACgDIABAAQAAAAAAAAQABAAAAAAQAAABAAAAQABAAAAABIABADQAAAAABABQAAAAAAAAQAAAAAAABQgBAAAAAAIgBAAIgCgBg");
	this.shape_392.setTransform(256.5,22.2,0.937,0.937);

	this.shape_393 = new cjs.Shape();
	this.shape_393.graphics.f("#D79E73").s().p("AgBAAQAAAAAAAAQAAgBAAAAQABAAAAgBQAAAAAAAAQAAAAABAAQAAABAAAAQABAAAAABQAAAAAAAAQAAABAAAAQAAABgBAAQAAAAAAABQgBAAAAAAQAAAAAAAAQAAgBgBAAQAAAAAAgBQAAAAAAgBg");
	this.shape_393.setTransform(239,18.1,0.937,0.937);

	this.shape_394 = new cjs.Shape();
	this.shape_394.graphics.f("#1E2128").s().p("AgFAKQgFgDgBgFQgBgEADgEQADgFAHABQAHAAAFAGIgDADQgDgBgCADIgDAFQAAAEgCACg");
	this.shape_394.setTransform(238.9,17.6,0.937,0.937);

	this.shape_395 = new cjs.Shape();
	this.shape_395.graphics.f("#243B67").s().p("AgBACQgBgBgBAAQgBgBAAAAQgBAAAAAAQAAAAAAgBQABgDAHAEQABAAAAAAQABAAAAABQAAAAAAAAQABABAAABIgFAAIgCgBg");
	this.shape_395.setTransform(238.6,18.9,0.937,0.937);

	this.shape_396 = new cjs.Shape();
	this.shape_396.graphics.f("#243B67").s().p("AgCgEIAAgBQAAAAAAAAQAAgBABAAQAAAAAAAAQABAAAAAAQABAAADAGIgEAHg");
	this.shape_396.setTransform(237.7,19.4,0.937,0.937);

	this.shape_397 = new cjs.Shape();
	this.shape_397.graphics.f("#243B67").s().p("AgCAGIAAgQIAFAIIgBALIgCACg");
	this.shape_397.setTransform(237.9,19.7,0.937,0.937);

	this.shape_398 = new cjs.Shape();
	this.shape_398.graphics.f("#1C3355").s().p("AgCgHQAAAFAEAIIABAAIgEACg");
	this.shape_398.setTransform(239.6,21.3,0.937,0.937);

	this.shape_399 = new cjs.Shape();
	this.shape_399.graphics.f("#243B67").s().p("AgCAIQgFgBgDgCIgBgCIAAgLIAUAAIADAQQgEABgEAAIgGgBg");
	this.shape_399.setTransform(238.8,21.2,0.937,0.937);

	this.shape_400 = new cjs.Shape();
	this.shape_400.graphics.f("#1C3355").s().p("AgBANQAAAAgBgBQAAAAAAgBQgBAAAAgBQAAAAABgBIABgKQABgKADgBIABAWQgCADgCAAIgBAAg");
	this.shape_400.setTransform(237.4,19.9,0.937,0.937);

	this.shape_401 = new cjs.Shape();
	this.shape_401.graphics.f("#243B67").s().p("AgCALIgJgLIgBgKIAHABQAHABAFAGIABABIABABIACAEIACAEIgCABQAAABgBAAQAAAAgBABQAAAAgBAAQgBAAAAAAg");
	this.shape_401.setTransform(238.8,19.7,0.937,0.937);

	this.shape_402 = new cjs.Shape();
	this.shape_402.graphics.f("#243B67").s().p("AgEALQgDgEgBgHIgBgCQgBgFAEgFIACAFIAEANIAIgEIACACQgGAIgEABQgBAAgBAAQAAAAgBgBQAAAAgBAAQAAAAAAgBg");
	this.shape_402.setTransform(240.3,20.8,0.937,0.937);

	this.shape_403 = new cjs.Shape();
	this.shape_403.graphics.f("#243B67").s().p("AAMARIgXgFIAAgcIATAIIAAABIABABIADAFIAAASg");
	this.shape_403.setTransform(238.8,20.3,0.937,0.937);

	this.shape_404 = new cjs.Shape();
	this.shape_404.graphics.f("#202B41").s().p("AgMAcIgBAAIAGgTIgCggIAXgEIAAAiIgEAUIgDAAIgCgoIgFgBIgBAZIgJARg");
	this.shape_404.setTransform(238.6,23.7,0.937,0.937);

	this.shape_405 = new cjs.Shape();
	this.shape_405.graphics.f("#D79E73").s().p("AgCACIAAgFIAFAAIAAAIg");
	this.shape_405.setTransform(238.6,18.7,0.937,0.937);

	this.shape_406 = new cjs.Shape();
	this.shape_406.graphics.f("#D79E73").s().p("AgBAAIACgCQAAAAABABQAAAAAAABQAAAAAAAAQAAAAAAABIgDACg");
	this.shape_406.setTransform(241.3,21.1,0.937,0.937);

	this.shape_407 = new cjs.Shape();
	this.shape_407.graphics.f("#F0C136").s().p("AgHAIIAEgTIALAEIgEATg");
	this.shape_407.setTransform(240.8,20.4,0.937,0.937);

	this.shape_408 = new cjs.Shape();
	this.shape_408.graphics.f("#1E2128").s().p("AgDABIAAgCIADAAQADAAABABIgEACg");
	this.shape_408.setTransform(237.6,26.3,0.937,0.937);

	this.shape_409 = new cjs.Shape();
	this.shape_409.graphics.f("#1E2128").s().p("AgDABIAAgCIADAAQADAAABABQABAAgFACg");
	this.shape_409.setTransform(239.6,26.3,0.937,0.937);

	this.shape_410 = new cjs.Shape();
	this.shape_410.graphics.f("#D79E73").s().p("AAAAKQgDAAgDgDQgDgDAAgEQAAgEADgDQADgDADAAQAEAAADADQADADAAAEQAAAFgCADQgBABAAAAQgBABAAAAQgBABAAAAQgBAAAAAAIgEgBg");
	this.shape_410.setTransform(238.8,17.8,0.937,0.937);

	this.shape_411 = new cjs.Shape();
	this.shape_411.graphics.f("#1A1E26").s().p("AgCACIAAgFIAFAAIAAACIAAAEIgDABg");
	this.shape_411.setTransform(240.6,24,0.937,0.937);

	this.shape_412 = new cjs.Shape();
	this.shape_412.graphics.f("#1A1E26").s().p("AgDACIADgFQAAABABAAQAAABABAAQABAAAAAAQAAAAAAAAIAAABIgBADIgCABg");
	this.shape_412.setTransform(238.4,23.9,0.937,0.937);

	this.shape_413 = new cjs.Shape();
	this.shape_413.graphics.f("#181C23").s().p("AgFAAQAAgFAFAAQAGAAAAAFQAAAGgGAAQgFAAAAgGg");
	this.shape_413.setTransform(239.7,15,0.937,0.937);

	this.shape_414 = new cjs.Shape();
	this.shape_414.graphics.f("#181C23").s().p("AgFAEIABgCIgBgCIAEgCQAEgCABACQADACgBACQAAAAAAABQAAAAgBAAQAAABgBAAQAAAAgBAAg");
	this.shape_414.setTransform(240.9,16,0.937,0.937);

	this.shape_415 = new cjs.Shape();
	this.shape_415.graphics.f("#181C23").s().p("AgJAHQgBgDAAgEQAAgHAHgCQAIgCAEAHQACACAAADQgFABgEgCQgBAAAAAAQgBAAAAAAQAAAAAAAAQAAAAAAAAIgCAGIgBgDIgBAAIgBAAQAAABAAAAQAAABAAAAQAAAAABABQAAAAABAAIAAAFg");
	this.shape_415.setTransform(240.3,16,0.937,0.937);

	this.shape_416 = new cjs.Shape();
	this.shape_416.graphics.f("#1C3355").s().p("AgCADQgGgBgDgCIgBgBQACgCADgBIACgBIASAHIAAADg");
	this.shape_416.setTransform(240.3,19.7,0.937,0.937);

	this.shape_417 = new cjs.Shape();
	this.shape_417.graphics.f("#D79E73").s().p("AAAAKQgKgCAAgIQAAgFADgDQAEgDADAAQAEAAAEADQADADAAAFQAAAFgDAEQgCADgCAAIgEgCg");
	this.shape_417.setTransform(240.3,16.1,0.937,0.937);

	this.shape_418 = new cjs.Shape();
	this.shape_418.graphics.f("#FFFFFF").s().p("AgDAAIgBgBIACgBIADACIACgCIAAgBIACABIAAAEIgDgCIgBADIgEgDg");
	this.shape_418.setTransform(240.2,17.4,0.937,0.937);

	this.shape_419 = new cjs.Shape();
	this.shape_419.graphics.f("#1C3355").s().p("AAAAMIgBgCQgEgJABgGIACgFIACgCQACABACAKIABAKQAAABAAAAQAAABAAAAQAAABgBAAQAAABAAAAIgBAAIgDgBg");
	this.shape_419.setTransform(239.2,18.6,0.937,0.937);

	this.shape_420 = new cjs.Shape();
	this.shape_420.graphics.f("#172C48").s().p("AgFAGIAAgQIAFAOIAGAFIAAACQgJgCgCgDg");
	this.shape_420.setTransform(239.4,19.1,0.937,0.937);

	this.shape_421 = new cjs.Shape();
	this.shape_421.graphics.f("#1C3355").s().p("AgGARIAAgcIACgEQACgDAFgCIACAFIACAMIgCAXIgEABQgGAAgBgEg");
	this.shape_421.setTransform(239.4,19.1,0.937,0.937);

	this.shape_422 = new cjs.Shape();
	this.shape_422.graphics.f("#1C3355").s().p("AABADQAAgIgBgHIgDgGIACAAIAAAAIAEABIABAPIgBASIgDADg");
	this.shape_422.setTransform(240.9,18.9,0.937,0.937);

	this.shape_423 = new cjs.Shape();
	this.shape_423.graphics.f("#DFE7F2").s().p("AABACIgEgEIAHgCIAAAFIgBAEg");
	this.shape_423.setTransform(240.3,17.8,0.937,0.937);

	this.shape_424 = new cjs.Shape();
	this.shape_424.graphics.f("#DFE7F2").s().p("AgHAOIgEgCIAAgPQgBgGAFgDIAEgCQAHgBAIACIAAAWQgBAEgIACIgDABQgEAAgDgCg");
	this.shape_424.setTransform(239.9,18.7,0.937,0.937);

	this.shape_425 = new cjs.Shape();
	this.shape_425.graphics.f("#1C3355").s().p("AgBALIgCgCIACgUIABAAIACAKIABAJQABABAAAAQAAABgBABQAAAAAAABQgBAAAAAAIgBAAIgCgBg");
	this.shape_425.setTransform(241.1,18.3,0.937,0.937);

	this.shape_426 = new cjs.Shape();
	this.shape_426.graphics.f("#172C48").s().p("AgHAKIgEgBIAAgHIAHgLIAQgBIgBASQAAACgJABIgCAAIgHgBg");
	this.shape_426.setTransform(239.9,20.4,0.937,0.937);

	this.shape_427 = new cjs.Shape();
	this.shape_427.graphics.f("#D79E73").s().p("AAAAMIgDgUIAHgDIAAAXg");
	this.shape_427.setTransform(240.5,22.9,0.937,0.937);

	this.shape_428 = new cjs.Shape();
	this.shape_428.graphics.f("#D79E73").s().p("AgEAHIADgSIAGAAIgFAXg");
	this.shape_428.setTransform(239.5,21.5,0.937,0.937);

	this.shape_429 = new cjs.Shape();
	this.shape_429.graphics.f("#D79E73").s().p("AgGAGIAGgOIAHABIgKAQQAAAAgBgBQAAAAgBAAQAAgBAAAAQgBAAAAgBg");
	this.shape_429.setTransform(238.8,23.3,0.937,0.937);

	this.shape_430 = new cjs.Shape();
	this.shape_430.graphics.f("#D79E73").s().p("AgBADQgBAAAAAAQgBAAAAAAQAAgBAAAAQAAAAAAgBIACgBIAEgCIABACQgBADgDAAIgBAAg");
	this.shape_430.setTransform(241.7,19.9,0.937,0.937);

	this.shape_431 = new cjs.Shape();
	this.shape_431.graphics.f("#D79E73").s().p("AgCAEIAAgIIAFAAIAAAIIgCABIgDgBg");
	this.shape_431.setTransform(240.2,16.9,0.937,0.937);

	this.shape_432 = new cjs.Shape();
	this.shape_432.graphics.f("#D79E73").s().p("AgLARIAAgiIAXAEIgBAXIgEACIgEABIgBgRIgEACIgCAUg");
	this.shape_432.setTransform(239.9,20.9,0.937,0.937);

	this.shape_433 = new cjs.Shape();
	this.shape_433.graphics.f("#F0C136").s().p("AgCgDIANgGIgIAOIgNAFg");
	this.shape_433.setTransform(242.3,19.3,0.937,0.937);

	this.shape_434 = new cjs.Shape();
	this.shape_434.graphics.f("#1C3355").s().p("AgDADQgJgCAAgCQACgEAFABIASAGIAAADg");
	this.shape_434.setTransform(241.3,19.2,0.937,0.937);

	this.shape_435 = new cjs.Shape();
	this.shape_435.graphics.f("#1A1E26").s().p("AgEABIAAgCIAEAAIAEACIABAAIgCABg");
	this.shape_435.setTransform(240.9,24.2,0.937,0.937);

	this.shape_436 = new cjs.Shape();
	this.shape_436.graphics.f("#1A1E26").s().p("AAAADIgDgDIACgDIABAAQAAAAAAAAQABAAAAAAQAAAAAAABQABAAAAAAIABADQABABAAAAQAAABAAAAQAAAAAAABQAAAAgBAAIgBAAIgCgBg");
	this.shape_436.setTransform(238.4,24.2,0.937,0.937);

	this.shape_437 = new cjs.Shape();
	this.shape_437.graphics.f("#7C4C31").s().p("AhTAlQgHAAgFgFQgFgFAAgHIAAgnQAAgHAFgFQAFgFAHAAICnAAQAHAAAFAFQAFAFAAAHIAAAnQAAAHgFAFQgFAFgHAAg");
	this.shape_437.setTransform(265.3,58.4,0.937,0.937);

	this.shape_438 = new cjs.Shape();
	this.shape_438.graphics.f("#598415").s().p("AAAAgQgNAAgJgKQgJgKAAgMQABgNAJgJQAJgJANAAQANAAAJAKQAJAJAAAMQgBAOgJAJQgJAJgMAAIgBAAg");
	this.shape_438.setTransform(259.6,51.3,0.937,0.937);

	this.shape_439 = new cjs.Shape();
	this.shape_439.graphics.f("#598415").s().p("AgMANQgGgFAAgIQABgHAFgFQAGgGAGABQAIAAAFAFQAGAGAAAGQgBAIgFAFQgGAGgHAAQgHAAgFgGg");
	this.shape_439.setTransform(262.1,49.3,0.937,0.937);

	this.shape_440 = new cjs.Shape();
	this.shape_440.graphics.f("#598415").s().p("AAAAbQgLAAgHgIQgIgIAAgLQABgKAHgIQAJgIAJAAQALABAIAIQAIAIAAAKQAAALgJAHQgHAIgKAAIgBAAg");
	this.shape_440.setTransform(263.2,51.8,0.937,0.937);

	this.shape_441 = new cjs.Shape();
	this.shape_441.graphics.f("#7EAE4E").s().p("AgFAlQgGAAAAgFIAChAQAAgEAFAAIAKAAQAGAAAAAEIgBBBQgCAEgEAAg");
	this.shape_441.setTransform(261.3,53.8,0.937,0.937);

	this.shape_442 = new cjs.Shape();
	this.shape_442.graphics.f("#598415").s().p("AAAAfQgMAAgJgJQgKgJABgNQAAgMAJgJQAKgKAMABQANAAAJAJQAJAKgBAMQAAANgJAJQgJAIgMAAIgBAAg");
	this.shape_442.setTransform(266,51.9,0.937,0.937);

	this.shape_443 = new cjs.Shape();
	this.shape_443.graphics.f("#598415").s().p("AgRASQgHgIAAgKQAAgKAIgHQAHgHAJAAQALAAAHAIQAHAHAAAKQAAAKgIAHQgHAHgKAAQgKAAgHgHg");
	this.shape_443.setTransform(269.1,47.6,0.937,0.937);

	this.shape_444 = new cjs.Shape();
	this.shape_444.graphics.f("#598415").s().p("AAAArQgRgBgNgMQgMgNAAgRQABgRAMgNQANgMARAAQASABAMAMQAMANAAARQgBASgMAMQgMAMgRAAIgBAAg");
	this.shape_444.setTransform(270,50.6,0.937,0.937);

	this.shape_445 = new cjs.Shape();
	this.shape_445.graphics.f("#7EAE4E").s().p("AgIAzQgGgCAAgFIABhXQABgHAGAAIAPABQABAAAAAAQABAAABABQAAAAABAAQAAAAABABQAAAAABABQAAABAAAAQAAABAAAAQAAABAAAAIgBBXQAAAHgHAAg");
	this.shape_445.setTransform(267.9,53.7,0.937,0.937);

	this.shape_446 = new cjs.Shape();
	this.shape_446.graphics.f("#7C4C31").s().p("AhTAlQgHAAgFgFQgFgFAAgHIAAgnQAAgHAFgFQAFgFAHAAICnAAQAHAAAFAFQAFAFAAAHIAAAnQAAAHgFAFQgFAFgHAAg");
	this.shape_446.setTransform(234.5,58.4,0.937,0.937);

	this.shape_447 = new cjs.Shape();
	this.shape_447.graphics.f("#598415").s().p("AAAAgQgNAAgJgKQgJgKAAgMQAAgNAKgJQAJgJANAAQANAAAJAKQAJAJAAAMQAAAOgKAJQgJAJgMAAIgBAAg");
	this.shape_447.setTransform(229.9,51.3,0.937,0.937);

	this.shape_448 = new cjs.Shape();
	this.shape_448.graphics.f("#598415").s().p("AgMANQgGgFAAgIQAAgHAGgFQAFgGAHABQAIAAAFAFQAGAGAAAGQgBAIgFAFQgGAGgHAAQgHAAgFgGg");
	this.shape_448.setTransform(232.4,49.3,0.937,0.937);

	this.shape_449 = new cjs.Shape();
	this.shape_449.graphics.f("#598415").s().p("AAAAbQgKAAgIgIQgIgIAAgLQABgKAIgIQAIgIAKAAQALABAHAIQAIAIAAAKQAAALgIAHQgIAIgKAAIgBAAg");
	this.shape_449.setTransform(233.5,51.8,0.937,0.937);

	this.shape_450 = new cjs.Shape();
	this.shape_450.graphics.f("#7EAE4E").s().p("AgFAlQgGAAAAgFIABhAQABgEAFAAIAKAAQAFAAABAEIgCBBQAAAEgFAAg");
	this.shape_450.setTransform(231.6,53.8,0.937,0.937);

	this.shape_451 = new cjs.Shape();
	this.shape_451.graphics.f("#598415").s().p("AAAArQgSAAgMgNQgMgNAAgRQAAgRANgNQANgMAQAAQASABANAMQAMANAAARQgBASgMAMQgMAMgSAAIAAAAg");
	this.shape_451.setTransform(236,50.3,0.937,0.937);

	this.shape_452 = new cjs.Shape();
	this.shape_452.graphics.f("#598415").s().p("AgRASQgHgIAAgKQAAgKAHgHQAIgHAJAAQALAAAHAIQAHAHAAAKQAAAKgIAHQgHAHgKAAQgKAAgHgHg");
	this.shape_452.setTransform(239.3,47.6,0.937,0.937);

	this.shape_453 = new cjs.Shape();
	this.shape_453.graphics.f("#598415").s().p("AAAAkQgOAAgLgLQgKgLAAgOQAAgOALgLQALgKAOAAQAPABAKAKQAKALAAAOQAAAOgLALQgKAKgPAAIAAAAg");
	this.shape_453.setTransform(240.8,51,0.937,0.937);

	this.shape_454 = new cjs.Shape();
	this.shape_454.graphics.f("#7EAE4E").s().p("AgIAzQgGgCAAgFIABhXQAAgHAHAAIAPABQAGAAAAAGIgBBXQAAAHgHAAg");
	this.shape_454.setTransform(238.2,53.7,0.937,0.937);

	this.shape_455 = new cjs.Shape();
	this.shape_455.graphics.f("#1B2B35").s().p("Aj3ANQgHAAgGgFQgFgFAAgGIAAgJIITAAIAAAJQAAAGgFAFQgFAFgHAAg");
	this.shape_455.setTransform(249.7,34,0.937,0.937);

	this.shape_456 = new cjs.Shape();
	this.shape_456.graphics.f("#44A18E").s().p("AgfByQgGAAgFgFQgFgFAAgGIAAjDQAAgGAFgGQAFgEAGAAIA/AAQAHAAAEAEQAFAGAAAGIAADDQAAAGgFAFQgFAFgGAAg");
	this.shape_456.setTransform(249.9,49.6,0.937,0.937);

	this.shape_457 = new cjs.Shape();
	this.shape_457.graphics.f("#4E758A").s().p("AkJBJIBDiRIGSAAIA+CRg");
	this.shape_457.setTransform(249.7,26,0.937,0.937);

	this.shape_458 = new cjs.Shape();
	this.shape_458.graphics.f("#66C2B0").s().p("AigByQgIAAgGgFQgFgGAAgIIAAi9QAAgIAFgFQAGgGAIAAIFCAAQAIAAAFAGQAFAFAAAIIAAC9QAAAIgFAGQgFAFgIAAg");
	this.shape_458.setTransform(249.9,49.6,0.937,0.937);

	this.shape_459 = new cjs.Shape();
	this.shape_459.graphics.f("#EAECE1").s().p("AjoChIAAlBIHSAAIAAFBg");
	this.shape_459.setTransform(249.9,46.8,0.937,0.937);

	this.shape_460 = new cjs.Shape();
	this.shape_460.graphics.f("#B6E9B7").s().p("AmVBGQgPgfgKghQCwg9C5gLQECgPDyBZQgJAegQAgg");
	this.shape_460.setTransform(249.8,46.3,0.937,0.937);

	this.shape_461 = new cjs.Shape();
	this.shape_461.graphics.f("#B6E9B7").s().p("AjxA4QhrhEg5hxIMrAAQg5BxhrBEQhvBGiDAAQiCAAhvhGg");
	this.shape_461.setTransform(249.9,64.6,0.937,0.937);

	this.shape_462 = new cjs.Shape();
	this.shape_462.graphics.f("#C1EAF8").s().p("AhFDdQi6ALiwA+QgVhDAAhGQAAi7CFiEQCEiFC7AAQC7AACFCFQCFCEAAC7QAABGgWBFQjzhakBAPg");
	this.shape_462.setTransform(249.9,19.2,0.937,0.937);

	this.shape_463 = new cjs.Shape();
	this.shape_463.graphics.f("#000000").s().p("AAgBRIgghdIgfBdIgrAAIgwihIAsAAIAcBoIAjhoIAgAAIAiBoIAchoIAsAAIgwChg");
	this.shape_463.setTransform(281.4,196.2,0.937,0.937);

	this.shape_464 = new cjs.Shape();
	this.shape_464.graphics.f("#000000").s().p("AgtBRIAAihIBbAAIAAAkIgxAAIAAAbIAuAAIAAAiIguAAIAAAcIAxAAIAAAkg");
	this.shape_464.setTransform(264.4,196.2,0.937,0.937);

	this.shape_465 = new cjs.Shape();
	this.shape_465.graphics.f("#000000").s().p("AgUBRIAAihIApAAIAAChg");
	this.shape_465.setTransform(254.9,196.2,0.937,0.937);

	this.shape_466 = new cjs.Shape();
	this.shape_466.graphics.f("#000000").s().p("AgQBRIhEihIAuAAIAmBiIAnhiIAuAAIhFChg");
	this.shape_466.setTransform(243.4,196.2,0.937,0.937);

	this.shape_467 = new cjs.Shape();
	this.shape_467.graphics.f("#000000").s().p("AgtBRIAAihIBbAAIAAAkIgxAAIAAAbIAuAAIAAAiIguAAIAAAcIAxAAIAAAkg");
	this.shape_467.setTransform(229.9,196.2,0.937,0.937);

	this.shape_468 = new cjs.Shape();
	this.shape_468.graphics.f("#000000").s().p("AAPBRIgng+IAAA+IgqAAIAAihIBBAAQAMAAALAEQAKAEAGAHQAGAGAEAKQADAJAAAKQAAASgIAMQgJAKgSAFIAzBCgAgYgHIAIAAQAMAAAGgGQAGgFAAgJQAAgKgGgFQgGgFgMAAIgIAAg");
	this.shape_468.setTransform(217.7,196.2,0.937,0.937);

	this.shape_469 = new cjs.Shape();
	this.shape_469.graphics.f("#000000").s().p("AgUBRIAAh9IgjAAIAAgkIBvAAIAAAkIgjAAIAAB9g");
	this.shape_469.setTransform(326.7,172.1,0.937,0.937);

	this.shape_470 = new cjs.Shape();
	this.shape_470.graphics.f("#000000").s().p("AAnBRIhNhiIAABiIgqAAIAAihIAqAAIBNBiIAAhiIAqAAIAAChg");
	this.shape_470.setTransform(312.2,172.1,0.937,0.937);

	this.shape_471 = new cjs.Shape();
	this.shape_471.graphics.f("#000000").s().p("AgtBRIAAihIBbAAIAAAkIgxAAIAAAbIAvAAIAAAjIgvAAIAAAbIAxAAIAAAkg");
	this.shape_471.setTransform(297.4,172.1,0.937,0.937);

	this.shape_472 = new cjs.Shape();
	this.shape_472.graphics.f("#000000").s().p("AA7BRIgNhdIgnBdIgPAAIglhdIgOBdIgpAAIAbihIAqAAIAfBVIAghVIAqAAIAbChg");
	this.shape_472.setTransform(281.1,172.1,0.937,0.937);

	this.shape_473 = new cjs.Shape();
	this.shape_473.graphics.f("#000000").s().p("AgtBRIAAihIBbAAIAAAkIgxAAIAAAbIAuAAIAAAjIguAAIAAAbIAxAAIAAAkg");
	this.shape_473.setTransform(265.2,172.1,0.937,0.937);

	this.shape_474 = new cjs.Shape();
	this.shape_474.graphics.f("#000000").s().p("AgiBPQgPgGgLgLQgMgMgGgPQgGgQAAgTQAAgSAGgQQAGgQAMgLQALgLAQgGQAPgHATAAQAaAAATAMQATALALAWIgoARQgGgNgJgGQgJgGgLAAQgJAAgHAEQgIADgFAHQgGAGgDAKQgDAJAAAKQAAALADAIQADAJAFAHQAFAGAIAEQAJADAJAAIAMgCQAFgBAFgDQAEgCAEgGIAEgMIgjAAIAAgfIBUAAQAAALgCAKQAAAKgEAKQgEANgIAKQgIAKgKAGQgKAGgNAEQgOAEgMgBQgRABgRgHg");
	this.shape_474.setTransform(250.5,172.1,0.937,0.937);

	this.shape_475 = new cjs.Shape();
	this.shape_475.graphics.f("#000000").s().p("AAoBRIgKgcIg7AAIgKAcIgsAAIA9ihIAtAAIA+ChgAgSAUIAkAAIgSg0g");
	this.shape_475.setTransform(234,172.1,0.937,0.937);

	this.shape_476 = new cjs.Shape();
	this.shape_476.graphics.f("#000000").s().p("AAnBRIhNhiIAABiIgqAAIAAihIAqAAIBNBiIAAhiIAqAAIAAChg");
	this.shape_476.setTransform(216.8,172.1,0.937,0.937);

	this.shape_477 = new cjs.Shape();
	this.shape_477.graphics.f("#000000").s().p("AAoBRIgKgcIg7AAIgKAcIgtAAIA+ihIAtAAIA+ChgAgSAUIAlAAIgTg0g");
	this.shape_477.setTransform(199.5,172.1,0.937,0.937);

	this.shape_478 = new cjs.Shape();
	this.shape_478.graphics.f("#000000").s().p("AA7BRIgNhdIgnBdIgQAAIgkhdIgNBdIgrAAIAcihIAqAAIAfBVIAghVIAqAAIAcChg");
	this.shape_478.setTransform(181.1,172.1,0.937,0.937);

	this.shape_479 = new cjs.Shape();
	this.shape_479.graphics.f("#000000").s().p("AgUBRIAAh9IgiAAIAAgkIBtAAIAAAkIgiAAIAAB9g");
	this.shape_479.setTransform(284.7,148,0.937,0.937);

	this.shape_480 = new cjs.Shape();
	this.shape_480.graphics.f("#000000").s().p("AAnBRIhNhiIAABiIgqAAIAAihIAqAAIBNBiIAAhiIAqAAIAAChg");
	this.shape_480.setTransform(270.1,148,0.937,0.937);

	this.shape_481 = new cjs.Shape();
	this.shape_481.graphics.f("#000000").s().p("AgtBRIAAihIBbAAIAAAkIgxAAIAAAbIAuAAIAAAjIguAAIAAAcIAxAAIAAAjg");
	this.shape_481.setTransform(255.4,148,0.937,0.937);

	this.shape_482 = new cjs.Shape();
	this.shape_482.graphics.f("#000000").s().p("AgtBRIAAihIAqAAIAAB+IAxAAIAAAjg");
	this.shape_482.setTransform(244.7,148,0.937,0.937);

	this.shape_483 = new cjs.Shape();
	this.shape_483.graphics.f("#000000").s().p("AAnBRIgJgcIg7AAIgKAcIgsAAIA9ihIAsAAIA+ChgAgSAVIAkAAIgSg1g");
	this.shape_483.setTransform(230.8,148,0.937,0.937);

	this.shape_484 = new cjs.Shape();
	this.shape_484.graphics.f("#000000").s().p("AgUBRIAAh9IgiAAIAAgkIBtAAIAAAkIgiAAIAAB9g");
	this.shape_484.setTransform(218.1,148,0.937,0.937);

	this.shape_485 = new cjs.Shape();
	this.shape_485.graphics.f("#FFFFFF").s().p("Al1F2QibibAAjbQAAjaCbibQCcibDZAAQDbAACbCbQCbCbAADaQAADbibCbQibCbjbAAQjZAAicibgAkJkJQhuBuAACbQAACbBuBvQBvBuCaABQCbgBBvhuQBvhvgBibQABibhvhuQhvhuibgBQiaABhvBug");
	this.shape_485.setTransform(129.1,104,0.937,0.937);

	this.shape_486 = new cjs.Shape();
	this.shape_486.graphics.f("#FFFFFF").s().p("Ak/FAQiEiEgBi8QABi6CEiFQCEiFC7AAQC8AACECFQCFCFAAC6QAAC8iFCEQiECFi8AAQi7AAiEiFg");
	this.shape_486.setTransform(129.1,104,0.937,0.937);

	this.shape_487 = new cjs.Shape();
	this.shape_487.graphics.f("#FFFFFF").s().p("Al1F2QibibAAjbQAAjaCbibQCbibDaAAQDbAACbCbQCbCbAADaQAADbibCbQibCbjbAAQjaAAibibgAkJkJQhvBuABCbQgBCcBvBuQBvBvCaAAQCcAABuhvQBvhuAAicQAAibhvhuQhuhuicAAQiaAAhvBug");
	this.shape_487.setTransform(128.6,245.5,0.937,0.937);

	this.shape_488 = new cjs.Shape();
	this.shape_488.graphics.f("#FFFFFF").s().p("Ak/FAQiFiEAAi8QAAi7CFiEQCEiFC7AAQC7AACFCFQCFCEAAC7QAAC8iFCEQiFCFi7AAQi7AAiEiFg");
	this.shape_488.setTransform(128.6,245.5,0.937,0.937);

	this.shape_489 = new cjs.Shape();
	this.shape_489.graphics.f("#FFFFFF").s().p("Al1F2QibibAAjbQAAjaCbibQCbibDaAAQDbAACbCbQCbCbAADaQAADbibCbQibCbjbAAQjaAAibibgAkJkJQhuBugBCbQABCcBuBuQBvBuCaAAQCcAABuhuQBuhuABicQgBibhuhuQhuhvicAAQiaAAhvBvg");
	this.shape_489.setTransform(369.1,244,0.937,0.937);

	this.shape_490 = new cjs.Shape();
	this.shape_490.graphics.f("#FFFFFF").s().p("Ak/FAQiFiEAAi8QAAi7CFiEQCEiFC7AAQC7AACFCFQCFCEAAC7QAAC8iFCEQiFCFi7AAQi7AAiEiFg");
	this.shape_490.setTransform(369.1,244,0.937,0.937);

	this.shape_491 = new cjs.Shape();
	this.shape_491.graphics.f("#FFFFFF").s().p("Al1F2QibibAAjbQAAjaCbibQCbibDaAAQDaAACcCbQCbCbAADaQAADbibCbQicCbjaAAQjaAAibibgAkJkJQhvBvABCaQgBCcBvBuQBuBuCbABQCcgBBuhuQBvhuAAicQAAiahvhvQhuhuicgBQibABhuBug");
	this.shape_491.setTransform(368.5,105.2,0.937,0.937);

	this.shape_492 = new cjs.Shape();
	this.shape_492.graphics.f("#FFFFFF").s().p("Ak/FAQiFiFAAi7QAAi6CFiFQCFiEC6AAQC8AACECEQCFCFAAC6QAAC7iFCFQiECFi8gBQi6ABiFiFg");
	this.shape_492.setTransform(368.5,105.2,0.937,0.937);

	this.shape_493 = new cjs.Shape();
	this.shape_493.graphics.f("#FFFFFF").s().p("Al1F2QibibAAjbQAAjaCbibQCcibDZAAQDbAACbCbQCbCbAADaQAADbibCbQibCbjbAAQjZAAicibgAkJkJQhvBuAACbQAACcBvBuQBuBuCbABQCbgBBvhuQBvhugBicQABibhvhuQhvhuibgBQibABhuBug");
	this.shape_493.setTransform(250.1,34.3,0.937,0.937);

	this.shape_494 = new cjs.Shape();
	this.shape_494.graphics.f("#FFFFFF").s().p("Ak/FAQiFiEAAi8QAAi7CFiEQCFiFC6AAQC8AACECFQCFCEAAC7QAAC8iFCEQiECFi8AAQi6AAiFiFg");
	this.shape_494.setTransform(250,34.3,0.937,0.937);

	this.shape_495 = new cjs.Shape();
	this.shape_495.graphics.f("#9BC09F").s().p("AjmBnQBQhJBYg5QB3hSCJg7IAlBWQh/A2hzBNQhRA4hIBAg");
	this.shape_495.setTransform(174.1,58.7,0.937,0.937);

	this.shape_496 = new cjs.Shape();
	this.shape_496.graphics.f("#9BC09F").s().p("ApSWCQiNg7h3hSQh7hThohoQhnhmhUh8QhTh8g6iIQh4keAAk2QAAk1B4keQA6iJBTh6QBVh+BmhlQAcgdAfgbIBCBCQgeAbgdAdQhiBihOBzQhNB0g3CAQhxEKAAEkQAAElBxEKQA3CABNB0QBOBzBiBiQBiBhByBOQB0BOCBA3QELBxEjAAQElAAEKhxQCCg3ByhOQBzhOBihhQBjhkBMhxQBOh0A3iAQBwkKAAklQAAkkhwkKQg3iAhOh0QhMhxhjhkQhihhhzhOQhyhOiCg3QkKhxklAAQi0AAirAsIgThcQC3gtC7AAQE3AAEdB4QCIA6B8BTQB7BUBnBnQBoBoBTB7QBTB6A5CJQB5EdAAE2QAAE3h5EdQg5CIhTB8QhRB5hqBpQhqBqh4BRQh6BSiKA7QkdB4k3AAQk2AAkch4g");
	this.shape_496.setTransform(248.3,174.9,0.937,0.937);

	this.shape_497 = new cjs.Shape();
	this.shape_497.graphics.f("#FFFFFF").s().p("AglAwIAAhfIBLAAIAABfg");
	this.shape_497.setTransform(251,361,0.937,0.937);

	this.shape_498 = new cjs.Shape();
	this.shape_498.graphics.f("#FFFFFF").s().p("AglAwIAAhfIBLAAIAABfg");
	this.shape_498.setTransform(249.8,-13.9,0.937,0.937);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_498},{t:this.shape_497},{t:this.shape_496},{t:this.shape_495},{t:this.shape_494},{t:this.shape_493},{t:this.shape_492},{t:this.shape_491},{t:this.shape_490},{t:this.shape_489},{t:this.shape_488},{t:this.shape_487},{t:this.shape_486},{t:this.shape_485},{t:this.shape_484},{t:this.shape_483},{t:this.shape_482},{t:this.shape_481},{t:this.shape_480},{t:this.shape_479},{t:this.shape_478},{t:this.shape_477},{t:this.shape_476},{t:this.shape_475},{t:this.shape_474},{t:this.shape_473},{t:this.shape_472},{t:this.shape_471},{t:this.shape_470},{t:this.shape_469},{t:this.shape_468},{t:this.shape_467},{t:this.shape_466},{t:this.shape_465},{t:this.shape_464},{t:this.shape_463},{t:this.shape_462},{t:this.shape_461},{t:this.shape_460},{t:this.shape_459},{t:this.shape_458},{t:this.shape_457},{t:this.shape_456},{t:this.shape_455},{t:this.shape_454},{t:this.shape_453},{t:this.shape_452},{t:this.shape_451},{t:this.shape_450},{t:this.shape_449},{t:this.shape_448},{t:this.shape_447},{t:this.shape_446},{t:this.shape_445},{t:this.shape_444},{t:this.shape_443},{t:this.shape_442},{t:this.shape_441},{t:this.shape_440},{t:this.shape_439},{t:this.shape_438},{t:this.shape_437},{t:this.shape_436},{t:this.shape_435},{t:this.shape_434},{t:this.shape_433},{t:this.shape_432},{t:this.shape_431},{t:this.shape_430},{t:this.shape_429},{t:this.shape_428},{t:this.shape_427},{t:this.shape_426},{t:this.shape_425},{t:this.shape_424},{t:this.shape_423},{t:this.shape_422},{t:this.shape_421},{t:this.shape_420},{t:this.shape_419},{t:this.shape_418},{t:this.shape_417},{t:this.shape_416},{t:this.shape_415},{t:this.shape_414},{t:this.shape_413},{t:this.shape_412},{t:this.shape_411},{t:this.shape_410},{t:this.shape_409},{t:this.shape_408},{t:this.shape_407},{t:this.shape_406},{t:this.shape_405},{t:this.shape_404},{t:this.shape_403},{t:this.shape_402},{t:this.shape_401},{t:this.shape_400},{t:this.shape_399},{t:this.shape_398},{t:this.shape_397},{t:this.shape_396},{t:this.shape_395},{t:this.shape_394},{t:this.shape_393},{t:this.shape_392},{t:this.shape_391},{t:this.shape_390},{t:this.shape_389},{t:this.shape_388},{t:this.shape_387},{t:this.shape_386},{t:this.shape_385},{t:this.shape_384},{t:this.shape_383},{t:this.shape_382},{t:this.shape_381},{t:this.shape_380},{t:this.shape_379},{t:this.shape_378},{t:this.shape_377},{t:this.shape_376},{t:this.shape_375},{t:this.shape_374},{t:this.shape_373},{t:this.shape_372},{t:this.shape_371},{t:this.shape_370},{t:this.shape_369},{t:this.shape_368},{t:this.shape_367},{t:this.shape_366},{t:this.shape_365},{t:this.shape_364},{t:this.shape_363},{t:this.shape_362},{t:this.shape_361},{t:this.shape_360},{t:this.shape_359},{t:this.shape_358},{t:this.shape_357},{t:this.shape_356},{t:this.shape_355},{t:this.shape_354},{t:this.shape_353},{t:this.shape_352},{t:this.shape_351},{t:this.shape_350},{t:this.shape_349},{t:this.shape_348},{t:this.shape_347},{t:this.shape_346},{t:this.shape_345},{t:this.shape_344},{t:this.shape_343},{t:this.shape_342},{t:this.shape_341},{t:this.shape_340},{t:this.shape_339},{t:this.shape_338},{t:this.shape_337},{t:this.shape_336},{t:this.shape_335},{t:this.shape_334},{t:this.shape_333},{t:this.shape_332},{t:this.shape_331},{t:this.shape_330},{t:this.shape_329},{t:this.shape_328},{t:this.shape_327},{t:this.shape_326},{t:this.shape_325},{t:this.shape_324},{t:this.shape_323},{t:this.shape_322},{t:this.shape_321},{t:this.shape_320},{t:this.shape_319},{t:this.shape_318},{t:this.shape_317},{t:this.shape_316},{t:this.shape_315},{t:this.shape_314},{t:this.shape_313},{t:this.shape_312},{t:this.shape_311},{t:this.shape_310},{t:this.shape_309},{t:this.shape_308},{t:this.shape_307},{t:this.shape_306},{t:this.shape_305},{t:this.shape_304},{t:this.shape_303},{t:this.shape_302},{t:this.shape_301},{t:this.shape_300},{t:this.shape_299},{t:this.shape_298},{t:this.shape_297},{t:this.shape_296},{t:this.shape_295},{t:this.shape_294},{t:this.shape_293},{t:this.shape_292},{t:this.shape_291},{t:this.shape_290},{t:this.shape_289},{t:this.shape_288},{t:this.shape_287},{t:this.shape_286},{t:this.shape_285},{t:this.shape_284},{t:this.shape_283},{t:this.shape_282},{t:this.shape_281},{t:this.shape_280},{t:this.shape_279},{t:this.shape_278},{t:this.shape_277},{t:this.shape_276},{t:this.shape_275},{t:this.shape_274},{t:this.shape_273},{t:this.shape_272},{t:this.shape_271},{t:this.shape_270},{t:this.shape_269},{t:this.shape_268},{t:this.shape_267},{t:this.shape_266},{t:this.shape_265},{t:this.shape_264},{t:this.shape_263},{t:this.shape_262},{t:this.shape_261},{t:this.shape_260},{t:this.shape_259},{t:this.shape_258},{t:this.shape_257},{t:this.shape_256},{t:this.shape_255},{t:this.shape_254},{t:this.shape_253},{t:this.shape_252},{t:this.shape_251},{t:this.shape_250},{t:this.shape_249},{t:this.shape_248},{t:this.shape_247},{t:this.shape_246},{t:this.shape_245},{t:this.shape_244},{t:this.shape_243},{t:this.shape_242},{t:this.shape_241},{t:this.shape_240},{t:this.shape_239},{t:this.shape_238},{t:this.shape_237},{t:this.shape_236},{t:this.shape_235},{t:this.shape_234},{t:this.shape_233},{t:this.shape_232},{t:this.shape_231},{t:this.shape_230},{t:this.shape_229},{t:this.shape_228},{t:this.shape_227},{t:this.shape_226},{t:this.shape_225},{t:this.shape_224},{t:this.shape_223},{t:this.shape_222},{t:this.shape_221},{t:this.shape_220},{t:this.shape_219},{t:this.shape_218},{t:this.shape_217},{t:this.shape_216},{t:this.shape_215},{t:this.shape_214},{t:this.shape_213},{t:this.shape_212},{t:this.shape_211},{t:this.shape_210},{t:this.shape_209},{t:this.shape_208},{t:this.shape_207},{t:this.shape_206},{t:this.shape_205},{t:this.shape_204},{t:this.shape_203},{t:this.shape_202},{t:this.shape_201},{t:this.shape_200},{t:this.shape_199},{t:this.shape_198},{t:this.shape_197},{t:this.shape_196},{t:this.shape_195},{t:this.shape_194},{t:this.shape_193},{t:this.shape_192},{t:this.shape_191},{t:this.shape_190},{t:this.shape_189},{t:this.shape_188},{t:this.shape_187},{t:this.shape_186},{t:this.shape_185},{t:this.shape_184},{t:this.shape_183},{t:this.shape_182},{t:this.shape_181},{t:this.shape_180},{t:this.shape_179},{t:this.shape_178},{t:this.shape_177},{t:this.shape_176},{t:this.shape_175},{t:this.shape_174},{t:this.shape_173},{t:this.shape_172},{t:this.shape_171},{t:this.shape_170},{t:this.shape_169},{t:this.shape_168},{t:this.shape_167},{t:this.shape_166},{t:this.shape_165},{t:this.shape_164},{t:this.shape_163},{t:this.shape_162},{t:this.shape_161},{t:this.shape_160},{t:this.shape_159},{t:this.shape_158},{t:this.shape_157},{t:this.shape_156},{t:this.shape_155},{t:this.shape_154},{t:this.shape_153},{t:this.shape_152},{t:this.shape_151},{t:this.shape_150},{t:this.shape_149},{t:this.shape_148},{t:this.shape_147},{t:this.shape_146},{t:this.shape_145},{t:this.shape_144},{t:this.shape_143},{t:this.shape_142},{t:this.shape_141},{t:this.shape_140},{t:this.shape_139},{t:this.shape_138},{t:this.shape_137},{t:this.shape_136},{t:this.shape_135},{t:this.shape_134},{t:this.shape_133},{t:this.shape_132},{t:this.shape_131},{t:this.shape_130},{t:this.shape_129},{t:this.shape_128},{t:this.shape_127},{t:this.shape_126},{t:this.shape_125},{t:this.shape_124},{t:this.shape_123},{t:this.shape_122},{t:this.shape_121},{t:this.shape_120},{t:this.shape_119},{t:this.shape_118},{t:this.shape_117},{t:this.shape_116},{t:this.shape_115},{t:this.shape_114},{t:this.shape_113},{t:this.shape_112},{t:this.shape_111},{t:this.shape_110},{t:this.shape_109},{t:this.shape_108},{t:this.shape_107},{t:this.shape_106},{t:this.shape_105},{t:this.shape_104},{t:this.shape_103},{t:this.shape_102},{t:this.shape_101},{t:this.shape_100},{t:this.shape_99},{t:this.shape_98},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_94},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.instance}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(77.8,-18.3,341,383.8);


(lib.flechamueve = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.flechainstrucciones("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(22.6,22.4);

	this.instance_1 = new lib.circulo1instrucciones("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(24,24.5,1,1,0,0,0,105.2,10.2);

	this.instance_2 = new lib.circulo2instrucciones("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(23.3,23.5,1.651,1.651,0,0,0,14.1,14.2);
	this.instance_2.alpha = 0;

	this.instance_3 = new lib.circulo2instrucciones("synched",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(23.3,23.3,1,1,0,0,0,14.2,14.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(1.5,1.5,43.3,43.3);


(lib.Group_26 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_0();
	this.instance.parent = this;
	this.instance.setTransform(0.7,19.3,1,1,0,0,0,0.7,19.3);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_26, new cjs.Rectangle(0,-0.2,1.5,39.1), null);


(lib.Group_25 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_1_1();
	this.instance.parent = this;
	this.instance.setTransform(0.7,19.4,1,1,0,0,0,0.7,19.4);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_25, new cjs.Rectangle(0,-0.2,1.5,39.1), null);


(lib.Group_24 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_2_1();
	this.instance.parent = this;
	this.instance.setTransform(0.7,18.8,1,1,0,0,0,0.7,18.8);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_24, new cjs.Rectangle(0,-0.2,1.5,38.1), null);


(lib.Group_23 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_3();
	this.instance.parent = this;
	this.instance.setTransform(0.7,19.3,1,1,0,0,0,0.7,19.3);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_23, new cjs.Rectangle(0,-0.2,1.4,39.1), null);


(lib.Group_22 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_4();
	this.instance.parent = this;
	this.instance.setTransform(0.7,19.4,1,1,0,0,0,0.7,19.4);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_22, new cjs.Rectangle(0,-0.2,1.5,39.1), null);


(lib.Group_21_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_5_1();
	this.instance.parent = this;
	this.instance.setTransform(0.7,19.4,1,1,0,0,0,0.7,19.4);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_21_1, new cjs.Rectangle(0,-0.2,1.4,39.1), null);


(lib.Group_20_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_6_1();
	this.instance.parent = this;
	this.instance.setTransform(0.7,19.3,1,1,0,0,0,0.7,19.3);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_20_1, new cjs.Rectangle(0,-0.2,1.5,39.1), null);


(lib.Group_19_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_7_1();
	this.instance.parent = this;
	this.instance.setTransform(0.8,19.4,1,1,0,0,0,0.8,19.4);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_19_1, new cjs.Rectangle(0.1,-0.2,1.4,39.1), null);


(lib.Group_18_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_8_1();
	this.instance.parent = this;
	this.instance.setTransform(0.8,18.8,1,1,0,0,0,0.8,18.8);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_18_1, new cjs.Rectangle(0,-0.2,1.5,38.1), null);


(lib.Group_17_4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_9_1();
	this.instance.parent = this;
	this.instance.setTransform(0.7,19.3,1,1,0,0,0,0.7,19.3);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_17_4, new cjs.Rectangle(0,-0.2,1.4,39.1), null);


(lib.Group_16_4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_10_1();
	this.instance.parent = this;
	this.instance.setTransform(0.8,19.4,1,1,0,0,0,0.8,19.4);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_16_4, new cjs.Rectangle(0.1,-0.2,1.4,39.1), null);


(lib.Group_15_4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_11();
	this.instance.parent = this;
	this.instance.setTransform(0.7,19.4,1,1,0,0,0,0.7,19.4);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_15_4, new cjs.Rectangle(0,-0.2,1.5,39.1), null);


(lib.Group_14_4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_12();
	this.instance.parent = this;
	this.instance.setTransform(5.6,17.2,1,1,0,0,0,5.6,17.2);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_14_4, new cjs.Rectangle(0,-0.1,11.4,34.6), null);


(lib.Group_13_4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_13();
	this.instance.parent = this;
	this.instance.setTransform(5.5,16.8,1,1,0,0,0,5.5,16.8);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_13_4, new cjs.Rectangle(0,-0.1,11.1,33.9), null);


(lib.Group_12_4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_14();
	this.instance.parent = this;
	this.instance.setTransform(5,11.8,1,1,0,0,0,5,11.8);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_12_4, new cjs.Rectangle(0,-0.1,10.2,24), null);


(lib.Group_11_4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_15();
	this.instance.parent = this;
	this.instance.setTransform(5.3,13.5,1,1,0,0,0,5.3,13.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_11_4, new cjs.Rectangle(0,-0.2,10.7,27.4), null);


(lib.Group_10_4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_16();
	this.instance.parent = this;
	this.instance.setTransform(5.5,15.1,1,1,0,0,0,5.5,15.1);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_10_4, new cjs.Rectangle(0,-0.2,11.1,30.7), null);


(lib.Group_9_4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_17();
	this.instance.parent = this;
	this.instance.setTransform(1.6,7.5,1,1,0,0,0,1.6,7.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_9_4, new cjs.Rectangle(-0.1,0,3.5,15), null);


(lib.Group_8_4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_18();
	this.instance.parent = this;
	this.instance.setTransform(1.7,7.5,1,1,0,0,0,1.7,7.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_8_4, new cjs.Rectangle(0,0,3.5,15), null);


(lib.Group_7_4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_19();
	this.instance.parent = this;
	this.instance.setTransform(1.5,3.6,1,1,0,0,0,1.5,3.6);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_7_4, new cjs.Rectangle(0,-0.1,3.2,7.5), null);


(lib.Group_6_4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_20();
	this.instance.parent = this;
	this.instance.setTransform(2.1,5,1,1,0,0,0,2.1,5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_6_4, new cjs.Rectangle(0,-0.1,4.4,10.3), null);


(lib.Group_5_4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_21();
	this.instance.parent = this;
	this.instance.setTransform(2.8,6.7,1,1,0,0,0,2.8,6.7);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_5_4, new cjs.Rectangle(0,-0.1,5.6,13.7), null);


(lib.Group_4_4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_22();
	this.instance.parent = this;
	this.instance.setTransform(3,8,1,1,0,0,0,3,8);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_4_4, new cjs.Rectangle(0,-0.1,6,16.2), null);


(lib.Group_3_4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_23();
	this.instance.parent = this;
	this.instance.setTransform(8.1,10.2,1,1,0,0,0,8.1,10.2);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_3_4, new cjs.Rectangle(-0.2,-0.1,16.7,20.6), null);


(lib.Group_2_4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_24();
	this.instance.parent = this;
	this.instance.setTransform(8.4,1.1,1,1,0,0,0,8.4,1.1);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_2_4, new cjs.Rectangle(-0.2,0,17.3,2.2), null);


(lib.Group_1_4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_25();
	this.instance.parent = this;
	this.instance.setTransform(8.5,0.4,1,1,0,0,0,8.5,0.4);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_1_4, new cjs.Rectangle(-0.2,0,17.6,0.8), null);


(lib.Group_27 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_26();
	this.instance.parent = this;
	this.instance.setTransform(7,0.8,1,1,0,0,0,7,0.8);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_27, new cjs.Rectangle(-0.2,0,14.6,1.6), null);


(lib.evapag3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		var root = this;
		var resp = 5;
		var correctas = [0, 1, 2, 3, 4, 5];
		console.log(correctas, correctas.length);
		var cont = 0;
		var contador = 1;
		var seleccion = ["", "", ""];
		var correcto = "";
		var respuestas = "";
		var corr = 0;
		root.p3.text = ("Selecciona 3 pasos del mapa general del proceso Gestión del Talento.");
		root.c3_op0.text = ("Sesión de Sucesión.");
		root.c3_op1.text = ("Perfil de Éxito.");
		root.c3_op2.text = ("Evaluación de Potencial y Desempeño.");
		root.c3_op3.text = ("Sesión de Calibración.");
		root.c3_op4.text = ("Estrategia del Negocio.");
		root.c3_op5.text = ("Identificación de puestos críticos.");
		for (var i = 0; i < correctas.length; i++) {
			correcto += root['c3_op' + correctas[i]].text + "\n";
		}
		
		iniciar();
		root.parent.parent.btn_siguiente.visible = false;
		
		function iniciar() {
			for (var i = 0; i <= resp; i++) {
				root['ch3_' + i].activo = false;
				root['ch3_' + i].cursor = "pointer";
				root['ch3_' + i].n = i;
				root['ch3_' + i].addEventListener("click", cambios);
		
		
			}
			// activar el cambio de estado de los checkbox
			function cambios(r) {
				if (r.currentTarget.activo == false) {
					r.currentTarget.activo = true;
					r.currentTarget.gotoAndStop(1);
					seleccion[r.currentTarget.n] = root['c3_op' + r.currentTarget.n].text + "\n";
					//root.OrdenPreguntas.push();
					cont++
				} else {
					r.currentTarget.activo = false;
					r.currentTarget.gotoAndStop(0);
					seleccion[r.currentTarget.n] = " ";
					cont--
				}
		
				respuestas = "";
				for (var i = 0; i <= resp; i++) {
					respuestas += seleccion[i];
				}
				root.parent.parent.registrar_pregunta(root.p3.text, respuestas, correcto);
		
				if (r.currentTarget.n == 0 || r.currentTarget.n == 1 || r.currentTarget.n == 2 || r.currentTarget.n == 3 || r.currentTarget.n == 4 || r.currentTarget.n == 5) {
					if (r.currentTarget.activo == true) {
						corr++
						console.log("sel corr" + corr);
					} else {
						corr--
						console.log(" des sel corr" + corr);
					}
				}
				if (corr == 3) {
					root.parent.parent.resultados[root.parent.parent.cont] = 10;
				} else {
					root.parent.parent.resultados[root.parent.parent.cont] = 0;
				}
		
				console.log(cont);
		
				if (cont == 3) {
					root.parent.parent.activarSiguiente();
					for (var l = 0; l <= resp; l++) {
						if (root['ch3_' + l].activo == false) {
							root['ch3_' + l].mouseEnabled = false;
						}
					}
				} else {
					root.parent.parent.btn_siguiente.visible = false;
					for (var k = 0; k <= resp; k++) {
						root['ch3_' + k].mouseEnabled = true;
					}
				}
			}
		
			console.log("Estado de calificacion ", root.parent.parent.resultados[root.parent.parent.cont], cont);
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.instance = new lib.graficatoda("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(210.8,325.2,0.749,0.749,0,0,0,254.3,226.5);

	this.ch3_4 = new lib.ch3();
	this.ch3_4.parent = this;
	this.ch3_4.setTransform(495.2,362.5,1,1,0,0,0,18.6,18.6);

	this.ch3_5 = new lib.ch3();
	this.ch3_5.parent = this;
	this.ch3_5.setTransform(495.2,415.8,1,1,0,0,0,18.6,18.6);

	this.c3_op5 = new cjs.Text("Identificación de puestos críticos.", "16px 'Arial'");
	this.c3_op5.name = "c3_op5";
	this.c3_op5.lineHeight = 18;
	this.c3_op5.lineWidth = 300;
	this.c3_op5.parent = this;
	this.c3_op5.setTransform(529.8,408.9);

	this.c3_op4 = new cjs.Text("Estrategia del Negocio.", "16px 'Arial'");
	this.c3_op4.name = "c3_op4";
	this.c3_op4.lineHeight = 18;
	this.c3_op4.lineWidth = 403;
	this.c3_op4.parent = this;
	this.c3_op4.setTransform(530.3,351.1);

	this.ch3_3 = new lib.ch3();
	this.ch3_3.parent = this;
	this.ch3_3.setTransform(495.2,308.3,1,1,0,0,0,18.6,18.6);

	this.ch3_2 = new lib.ch3();
	this.ch3_2.parent = this;
	this.ch3_2.setTransform(495.2,256,1,1,0,0,0,18.6,18.6);

	this.ch3_1 = new lib.ch3();
	this.ch3_1.parent = this;
	this.ch3_1.setTransform(495.2,205.7,1,1,0,0,0,18.6,18.6);

	this.ch3_0 = new lib.ch3();
	this.ch3_0.parent = this;
	this.ch3_0.setTransform(495.2,152,1,1,0,0,0,18.6,18.6);

	this.c3_op3 = new cjs.Text("Sesión de Calibración.", "16px 'Arial'");
	this.c3_op3.name = "c3_op3";
	this.c3_op3.lineHeight = 18;
	this.c3_op3.lineWidth = 395;
	this.c3_op3.parent = this;
	this.c3_op3.setTransform(530.7,298.4);

	this.c3_op2 = new cjs.Text("Evaluación de Potencial y Desempeño.", "16px 'Arial'");
	this.c3_op2.name = "c3_op2";
	this.c3_op2.lineHeight = 18;
	this.c3_op2.lineWidth = 389;
	this.c3_op2.parent = this;
	this.c3_op2.setTransform(531.2,248.1);

	this.c3_op1 = new cjs.Text("Perfil de Éxito.", "16px 'Arial'");
	this.c3_op1.name = "c3_op1";
	this.c3_op1.lineHeight = 18;
	this.c3_op1.lineWidth = 387;
	this.c3_op1.parent = this;
	this.c3_op1.setTransform(532.7,197.8);

	this.c3_op0 = new cjs.Text("Sesión de Sucesión.", "16px 'Arial'");
	this.c3_op0.name = "c3_op0";
	this.c3_op0.lineHeight = 18;
	this.c3_op0.lineWidth = 382;
	this.c3_op0.parent = this;
	this.c3_op0.setTransform(533.2,142.1);

	this.p3 = new cjs.Text("Selecciona 3 pasos del mapa general del proceso Gestión del Talento.", "20px 'Arial'");
	this.p3.name = "p3";
	this.p3.lineHeight = 24;
	this.p3.lineWidth = 322;
	this.p3.parent = this;
	this.p3.setTransform(124.6,16);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.p3},{t:this.c3_op0},{t:this.c3_op1},{t:this.c3_op2},{t:this.c3_op3},{t:this.ch3_0},{t:this.ch3_1},{t:this.ch3_2},{t:this.ch3_3},{t:this.c3_op4},{t:this.c3_op5},{t:this.ch3_5},{t:this.ch3_4},{t:this.instance}]}).wait(1));

	// fondo y encabezado
	this.instance_1 = new lib.iconoactividadesyretos("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(473.7,95.1,0.551,0.551,0,0,0,55.7,55.7);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(230,149,122,0.498)").s().p("EgiSAJ5QjsAAAAjsIAAsZQAAjsDsAAMBElAAAQDsAAAADsIAAMZQAADsjsAAg");
	this.shape.setTransform(252.4,49.7);

	this.instance_2 = new lib.fondo("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(469.6,267.3,1,1,0,0,0,485.2,268.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.shape},{t:this.instance_1}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.evapag3, new cjs.Rectangle(2.4,-36.5,958.3,510.2), null);


(lib.evalpagina15 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		/*NOTA IMPROTANTE:
		EN CADA ACTIVIDAD CON MC IGUALES, SE TIENEN QUE DUPLICAR
		NO BASTA CON CAMBIARLES LA INSTANCIA, A NIVEL CÓDIGO NO HAY DIFERENCIA
		ADEMAS DE QUE TIENEN QUE TENER INSTANCIAS DIFERENTES A LAS ANTERIORES
		*/
		this.stop();
		var root = this;
		var resp = 2;
		var correcta = 2;
		root.p15.text=("Una vez concluida la sesión de calibración, el siguiente paso es:");
		root.c15_op0.text=("Actualizar los perfiles críticos del área y establecer los indicadores de desempeño.");
		root.c15_op1.text=("Esperar al siguiente año para revisar nuevamente la evaluación.");
		root.c15_op2.text=("Generar y dar seguimiento a los planes de desarrollo de tu equipo como líder.");
		iniciar();
		
		function iniciar() {
			root.parent.parent.btn_siguiente.visible = false;
			for (var i = 0; i <= resp; i++) {
				root['c15_' + i].cursor = "pointer";
				root['c15_' + i].n = i;
				root['c15_' + i].addEventListener("click", cambios);
				root['c15_' + i].gotoAndStop(1);
			}
		}
		
		function cambios(r) {
			//Cambia el estatus de la opcion seleccionada
			for (var i = 0; i <= resp; i++) {
				if (root['c15_' + i].n != r.currentTarget.n) {
					root['c15_' + i].gotoAndStop(0);
				} else {
					root['c15_' + i].gotoAndStop(1);
				}
			}
		
			//Valida la respuesta
			if (r.currentTarget.n == correcta) {
				root.parent.parent.resultados[root.parent.parent.cont] = 10;
				console.log("Respuesta Correcta " + root.parent.parent.resultados[root.parent.parent.cont]);
			} else {
				root.parent.parent.resultados[root.parent.parent.cont] = 0;
				console.log("Respuesta Incorrecta " + root.parent.parent.resultados[root.parent.parent.cont]);
			}
			root.parent.parent.activarSiguiente();
			root.parent.parent.registrar_pregunta(root.p15.text, root['c15_op'+r.currentTarget.n].text, root['c15_op'+correcta].text);
		
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000007").s().p("Ag1AJIgpgJIABgOIAgAIQAkAHAWABQAgABA/gOIADAMQgrAIgmAFIgOABQgVAAgggGg");
	this.shape.setTransform(262.8,310,1.092,1.092);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#35343A").s().p("AAAAEIgCgCIABgHIABABIADAEQABAEgCACIgCgCg");
	this.shape_1.setTransform(267.5,275.4,1.092,1.092);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#35343A").s().p("AgFAFQgCgDACgCQADgDAIgCIABAHQgBgBgFADIgEACIgCgBg");
	this.shape_2.setTransform(264.7,275.5,1.092,1.092);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#C3C3C1").s().p("AgGAAQAAgGAGgBQAHABAAAGQAAAIgHAAQgGAAAAgIg");
	this.shape_3.setTransform(266.3,275.1,1.092,1.092);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#35343A").s().p("AgIAAQAAgDACgDQADgCADAAQAEAAADACQACADAAADQAAAEgCADQgDACgEAAQgIAAAAgJg");
	this.shape_4.setTransform(266.3,275.1,1.092,1.092);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#947668").s().p("AAMA7QAKgygKgDQgFgBgEgEIgHgGQgXgMgEgFQgKgLAAgLQgBgKAFgBQADAAAbAJIAMAFQAKADACAAQACgBgJgKQgEgIAEgHQABgCADAFIAEAKQADAGAMALQAEAFAFAUQACAEgCBHg");
	this.shape_5.setTransform(262.9,273.3,1.092,1.092);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#C0DADE").s().p("AgdBtQgPgYgNhPIgLhJIAsgEIAUCAQALg5AGgfQABgHgBgVIgCgUIABgqIAZAGQAbAGAEAOQAFAQgXBYQgUBMgYAaQgHAIgHACIgGAAg");
	this.shape_6.setTransform(270.4,286.4,1.092,1.092);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#C0DADE").s().p("Ag0BoQgFgDgJg+IgNhTQgDgRAPgYQAIgMAIgJQAgAegHAJQgKANAJA0QAHApAFAMQABADAngJIAogJIAQAiQgbANgfAKQgnAOgVAAQgKAAgFgDg");
	this.shape_7.setTransform(256.6,285.9,1.092,1.092);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#DDEAEC").s().p("AgYAFIAogWIAJARQgCAMgYAGg");
	this.shape_8.setTransform(265.3,274,1.092,1.092);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#DDEAEC").s().p("AgYgCIAJgSIAoAcIgTANQgdgMgBgLg");
	this.shape_9.setTransform(259.8,273.7,1.092,1.092);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#3F3231").s().p("AhIA6QgBgDgDgBQgEguALgbQASgsAzADIAAAAQA0gDASAsQALAbgEAuQgDABgBADQAAABAAAAQgBABAAAAQAAABgBAAQAAAAAAAAIgBAAIAAgeQAAgIgIgSQgIgVgJgCQgHgCgPAIQgQAIgGAAIgBAAQgGAAgRgIQgPgIgGACQgIACgJAVQgIASAAAIIAAAeIAAAAQgBAAAAAAQAAAAgBgBQAAAAAAgBQgBAAAAgBg");
	this.shape_10.setTransform(262,254.2,1.092,1.092);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#805F50").s().p("AgMBkQgJgEgMgIQgWgPgNgWIgBgDIAAgOIgBAAIgEgCIgCgBIAAgBIgDgNIgEgcQAAgFACgBQAAAAAAAAQABAAAAABQABAAABAAQAAABABAAIACADIABAAQgCgMAAgOQAAgeAQgIIAAAAIARgNQAVgMATAAIAEAAQAUgBAVANQALAGAHAHIAAAAQAQAIAAAeQAAAOgDAMIAAADIACgCQAFgGADABQADACgCANIgHAfIAAABQgCADgEAAIgBAAIgBARIgBADQgUAdggARIgBAAIgLACIgEAAQgHAAgFgCg");
	this.shape_11.setTransform(262,260.2,1.092,1.092);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#947668").s().p("AgGAgQgzgBAOgOQAMgMADgPIABgPIAagFQAagEAAAJQABARAVAnQgXABgUAAIgKAAg");
	this.shape_12.setTransform(262.4,270.6,1.092,1.092);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#2F2F35").s().p("AA2ElIgagEIgEiXQgEiagBgOIgOiHQgXCmAAAGIgREbIhRAAIALluIAUjZQAWAPBTgFQApgCAmgFIALBIQAHBNABAjIgJGBQgGAEgNAHQgGAEgOAAIgQgBg");
	this.shape_13.setTransform(261.9,340.5,1.092,1.092);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#00011E").s().p("AgkASQgDgIALgPIAKgNIADgPIABgBIAzAAIAAAcQABAQgCAEQgEAHgNAHIgKAHIgeABQgKgFgFgNg");
	this.shape_14.setTransform(252.5,375.7,1.092,1.092);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#A0CBD0").s().p("AgSAOQgFgTABgPIApgBQAHAdgIAHQgGAGgNAAIgBABQgOAAgCgIg");
	this.shape_15.setTransform(257.5,287,1.092,1.092);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#35343A").s().p("AAAAFIgDgDIABgJIACACQACACABADQABAFgCADIgCgDg");
	this.shape_16.setTransform(241.3,311.1,1.092,1.092);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000007").s().p("AARAbIgsgOQgZABgEgCQgCgCAAgKIAAgMIAFgLIA6gDIAGAPIAjARQAOAGgBAJQgBAFgBABg");
	this.shape_17.setTransform(274.5,373.7,1.092,1.092);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#AEC7C9").s().p("AgHCrQgdgDgdgIIgXgHIgHidQgHiZgDgBIB4gLQBHgDALAFQAMAFgECgQgDBOgEBPQgyAQgpAAIgOAAgAhpieIAAAAIAAAAg");
	this.shape_18.setTransform(262.3,291.7,1.092,1.092);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#C5A9B5").s().p("AgTBsIAAgpIAoAAIAAApgAgTA1IAAgKQAAgSAGgLQAFgLASgPQASgPADgEQAGgIAAgIQAAgMgKgIQgKgJgQAAQgOAAgLAJQgLAKgDARIgmgEQACgbAUgSQAWgSAgAAQAiAAAWASQAVATAAAZQAAANgIAMQgHAMgaAUQgNALgDAHQgDAHAAAQg");
	this.shape_19.setTransform(299.1,241.6,1.092,1.092);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#F7DA98").s().p("Ai/CtQASglAGgcIAEgZQABgFgEgFQgggqACgxQAAg4AogrQAngqA9gQQApgKAlAEQBJAHAzAuQApAmAJAzQAJA3ggAwQggAwg4AWQgyAUg2gGIgqgGQgDgBgDABQgYAOgqAMIg3AOIgHABg");
	this.shape_20.setTransform(299.7,244.2,1.092,1.092);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#7F795E").s().p("AgMADIAUgMIAGAJQgBAGgNAEg");
	this.shape_21.setTransform(223.2,229.6,1.092,1.092);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#7F795E").s().p("AgNgBIAFgJIAWAPIgKAGQgQgGgBgGg");
	this.shape_22.setTransform(220.2,229.5,1.092,1.092);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#DAA675").s().p("AAoAOQgBgHgOAAQgSABgHAAQgLgBgJgHIgHgHQgEAPgCACQgCABgCALIgCAKIgEgHQgFgGABgCQACgJgBgHQgDgMAFgFQgBgBAOgGQAPgGAOgCQAOgBASALQASAKAAAIQABAIgCAKQgBALgCABQgCAAgCADIgBACQACgHgBgLg");
	this.shape_23.setTransform(221.5,217.8,1.092,1.092);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#C4B98C").s().p("AgrAfQAQgxAFgDQAKgHAWgBQANgEALAHQAGADADAEIABAyg");
	this.shape_24.setTransform(217.6,232.6,1.092,1.092);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#C4B98C").s().p("AgsAfIACgyIAJgHQALgHAMAEIAMABQAPADAGAEQAIAFAOAvg");
	this.shape_25.setTransform(226,232.6,1.092,1.092);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#F9BD9C").s().p("AgGA2QgTgIgLgTIAAgBIgBgIIgDgCIgEgVIABgDQAAAAAAAAQABAAAAAAQAAAAABAAQAAAAAAABIABABIABAAQgBgGAAgHQAAgRAIgEQAAgBAJgGQALgHALAAIABAAIAAABIAAAAIAAgBQARAAAPAOQAIAEAAARIgBANIAAACIABgCIAEgCQACAAgCAIIAAAAIgDAQIAAAAQgBABAAAAQAAAAAAABQgBAAAAAAQgBAAAAAAIgBAJIgBACQgOARgNAHIgBABIgHABIgHgBg");
	this.shape_26.setTransform(221.5,221.8,1.092,1.092);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#EDAB86").s().p("AgDAVQgdgCAHgHQAKgKABgSIAOgDQAOgCAAAFQAAAJANAbIgVABIgJAAg");
	this.shape_27.setTransform(221.7,227.7,1.092,1.092);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#3F3231").s().p("AgyAlIgDgBQgCABgEgbQgDgNAMgKQgCgRARgJIgDAFQgDAFAAADQAAAAAAAAQAAAAAAAAQAAAAABAAQAAAAAAAAQARgTAmgBQgIABgHAEIAAABIABABQAcgEAQALIgGAAQAAAAAAAAQgBAAAAAAQAAAAABABQAAAAAAAAQAHADAGAFQAIAIAAALIgFgGIgBABQADAJgCAIQAAgCgDgDQgBAOgEASQgEAAgCAEIgCAFQABgagGgJQgLgQgbABIgbADQgFAMgHAHIgCAfQgBgIgEgCg");
	this.shape_28.setTransform(158.9,268.8,1.092,1.092);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#3F3231").s().p("AAOAJIgBgBQgHAAAAgGIAAgBQgBgBAAAAQgBAAAAAAQgBAAAAAAQgBgBgBAAIAAABIAAAAIAAgBQgCABgCABIAAABQAAAGgHAAIAAABIgVAAIgBgBQgGgCAAgFIAAgBIgGABIgBgEIAIgBQACgEAEABIAUAAQAFAAADADQACgBACAAQADAAADABQABgDAHAAIATAAQAEgBADAEIAFAAIgBADIgEABIAAABQAAAFgGACIgBABgAAJgEIAAAGQAAADAEABIAWAAQABAAAAAAQABgBAAAAQAAgBAAAAQAAgBAAAAIAAgHQAAAAAAAAQAAAAAAgBQgBAAAAAAQgBAAgBAAIgWAAQgBAAAAAAQgBAAAAAAQAAABAAAAQgBAAAAAAgAgjgEIAAAGQAAADAEABIAWAAQABAAAAAAQABgBAAAAQAAgBAAAAQAAgBAAAAIAAgHQAAAAAAAAQAAAAAAgBQgBAAAAAAQgBAAgBAAIgWAAQgBAAAAAAQgBAAAAAAQAAABAAAAQgBAAAAAAg");
	this.shape_29.setTransform(158.4,272.8,1.092,1.092);

	this.instance = new lib.Group();
	this.instance.parent = this;
	this.instance.setTransform(166.8,283.6,1.092,1.092,0,0,0,1.5,2);
	this.instance.alpha = 0.391;

	this.instance_1 = new lib.Group_1();
	this.instance_1.parent = this;
	this.instance_1.setTransform(165.7,284.3,1.092,1.092,0,0,0,1.2,1.4);
	this.instance_1.alpha = 0.391;

	this.instance_2 = new lib.Group_2();
	this.instance_2.parent = this;
	this.instance_2.setTransform(165.6,283.6,1.092,1.092,0,0,0,1.6,2.5);
	this.instance_2.alpha = 0.391;

	this.instance_3 = new lib.Group_3();
	this.instance_3.parent = this;
	this.instance_3.setTransform(151.4,283.6,1.092,1.092,0,0,0,1.4,2.5);
	this.instance_3.alpha = 0.391;

	this.instance_4 = new lib.Group_4();
	this.instance_4.parent = this;
	this.instance_4.setTransform(150.9,284,1.092,1.092,0,0,0,1.2,1.8);
	this.instance_4.alpha = 0.391;

	this.instance_5 = new lib.Group_5();
	this.instance_5.parent = this;
	this.instance_5.setTransform(150.3,283.4,1.092,1.092,0,0,0,1.4,2.1);
	this.instance_5.alpha = 0.391;

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#A9B3BC").s().p("AgPAEIAZgPIAGALQgBAHgPAFg");
	this.shape_30.setTransform(160.4,281.8,1.092,1.092);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#A9B3BC").s().p("AgPgBIAGgLIAZARIgMAIQgTgIAAgGg");
	this.shape_31.setTransform(156.9,281.6,1.092,1.092);

	this.instance_6 = new lib.Group_6();
	this.instance_6.parent = this;
	this.instance_6.setTransform(159.2,283.5,1.092,1.092,0,0,0,0.9,2.5);
	this.instance_6.alpha = 0.391;

	this.instance_7 = new lib.Group_7();
	this.instance_7.parent = this;
	this.instance_7.setTransform(160.5,283.2,1.092,1.092,0,0,0,1.1,2.4);
	this.instance_7.alpha = 0.391;

	this.instance_8 = new lib.Group_8();
	this.instance_8.parent = this;
	this.instance_8.setTransform(161.7,283.1,1.092,1.092,0,0,0,1,2.4);
	this.instance_8.alpha = 0.391;

	this.instance_9 = new lib.Group_9();
	this.instance_9.parent = this;
	this.instance_9.setTransform(164.7,283.2,1.092,1.092,0,0,0,1.2,2.4);
	this.instance_9.alpha = 0.391;

	this.instance_10 = new lib.Group_10();
	this.instance_10.parent = this;
	this.instance_10.setTransform(163.7,283,1.092,1.092,0,0,0,1,2.6);
	this.instance_10.alpha = 0.391;

	this.instance_11 = new lib.Group_11();
	this.instance_11.parent = this;
	this.instance_11.setTransform(162.5,282.9,1.092,1.092,0,0,0,1,2.6);
	this.instance_11.alpha = 0.391;

	this.instance_12 = new lib.Group_12();
	this.instance_12.parent = this;
	this.instance_12.setTransform(157.7,283.5,1.092,1.092,0,0,0,0.8,2.5);
	this.instance_12.alpha = 0.391;

	this.instance_13 = new lib.Group_13();
	this.instance_13.parent = this;
	this.instance_13.setTransform(156.4,283.2,1.092,1.092,0,0,0,0.8,2.4);
	this.instance_13.alpha = 0.391;

	this.instance_14 = new lib.Group_14();
	this.instance_14.parent = this;
	this.instance_14.setTransform(155.4,283.1,1.092,1.092,0,0,0,0.8,2.4);
	this.instance_14.alpha = 0.391;

	this.instance_15 = new lib.Group_15();
	this.instance_15.parent = this;
	this.instance_15.setTransform(152.5,283.2,1.092,1.092,0,0,0,1,2.4);
	this.instance_15.alpha = 0.391;

	this.instance_16 = new lib.Group_16();
	this.instance_16.parent = this;
	this.instance_16.setTransform(153.4,283,1.092,1.092,0,0,0,1.1,2.6);
	this.instance_16.alpha = 0.391;

	this.instance_17 = new lib.Group_17();
	this.instance_17.parent = this;
	this.instance_17.setTransform(154.6,282.9,1.092,1.092,0,0,0,1.1,2.6);
	this.instance_17.alpha = 0.391;

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#BBCACB").s().p("AguAZQAMgiAFgEQAMgIAagBQAOgFANAIQAHAEADAFIABAjg");
	this.shape_32.setTransform(154.3,283.9,1.092,1.092);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#CCD0D0").s().p("AgvAZIABgjIALgJQANgIAOAFIAOACQAQACAIAFQAGAEAMAig");
	this.shape_33.setTransform(163.3,283.9,1.092,1.092);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#E8AF93").s().p("AAHAAIgDAAIgCAAIgBAAIgFAAIgGACQACgCADAAIAGgCIABABIACAAIADABQAEAAAAADQgBgCgDgBg");
	this.shape_34.setTransform(156,272.3,1.092,1.092);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#E1BB93").s().p("AgHA+QgWgJgNgWIAAgBIgBgJIAAAAIgEgCIgDgTIgBgGQAAgBAAgBQAAAAAAgBQAAAAAAgBQABAAAAAAIADABIABACIABAAQgCgHAAgJQAAgTAKgEIAAAAQAAgCAKgGQANgIAMAAIACAAQAUgBARARQAKAEAAATQAAAJgCAHIAAACIABgCQADgDACABQACABgCAIIAAAAIgEATQAAAAAAABQgBAAAAAAQgBABAAAAQgBAAAAAAIgBAAIgBALIAAABQgOATgSAKIgBAAIgJABQgEAAgDgBg");
	this.shape_35.setTransform(158.5,272.7,1.092,1.092);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#D6AE89").s().p("AgDAYQgjgCAJgIQAMgMABgVIAQgDQAQgCAAAFQABAKAPAgIgZABIgKAAg");
	this.shape_36.setTransform(158.6,279.6,1.092,1.092);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#3F3F3F").s().p("AgOAdIgEg3QAAgBAAAAQAAAAAAAAQAAgBABAAQAAAAAAAAQAaABAFARQAEAMABAbg");
	this.shape_37.setTransform(197,260.6,1.092,1.092);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#3F3F3F").s().p("AgSAdQABgZAEgOQAFgRAbgBQAAAAAAAAQAAAAAAABQAAAAAAAAQABAAAAABIgIA3g");
	this.shape_38.setTransform(184.1,260.6,1.092,1.092);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#2F2F2F").s().p("AgRAiIAUhDIAIAFQADADAFAWIgNgBIAJAQIgOAWg");
	this.shape_39.setTransform(192.8,260,1.092,1.092);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#2F2F2F").s().p("AAAAhIgOgXIAJgPIgNABIADgNQACgJADgCIAIgEIAUBBg");
	this.shape_40.setTransform(188.1,260.2,1.092,1.092);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#ACADAD").s().p("AgSAVIgKgfIAAgBIAMgKIACAEQAIAMAGABQAJgBAEgHIAGgLIAKAMIAAABIgKAfIgBACQAAABAAAAQAAAAAAgBQAAAAgBAAQAAgBAAgBIgFgJIgMgOIgJAKIgHANIgBADIgBgDg");
	this.shape_41.setTransform(190.4,258.7,1.092,1.092);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#B3B3B3").s().p("AgVAiIARhDIALAJIANADQgCAMACAPIACAcg");
	this.shape_42.setTransform(193.2,260.1,1.092,1.092);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#B3B3B3").s().p("AgTAgQABgkgCgTIANgDQAHgEAAgBQADALAHASIAJAbIACAHg");
	this.shape_43.setTransform(187.8,260.3,1.092,1.092);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#E5E6E6").s().p("AgHAZIgNgeQgBgBAAAAQAAgBAAAAQAAAAABgBQAAAAAAAAQAKgNAKgDQALADAKANQAAAAAAAAQABABAAAAQAAABAAAAQAAAAgBABIgNAeg");
	this.shape_44.setTransform(190.4,261,1.092,1.092);

	this.instance_18 = new lib.ClipGroup_2();
	this.instance_18.parent = this;
	this.instance_18.setTransform(190.3,248,1.092,1.092,0,0,0,6,7.8);

	this.instance_19 = new lib.ClipGroup_1();
	this.instance_19.parent = this;
	this.instance_19.setTransform(190.2,238.9,1.092,1.092,0,0,0,4,2.5);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#ECAA86").s().p("AgCgFQADgHADAEQACAMgJAGg");
	this.shape_45.setTransform(195.3,250.3,1.092,1.092);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#ECAA86").s().p("AgDgIIACgBQACAAACAEIABAPQgIgGABgMg");
	this.shape_46.setTransform(185.7,250.3,1.092,1.092);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#F9BD9C").s().p("AgNA5QgRgKgJgTQgJgGABgNIACgBQADAAACADQgDgJgCgKQgDgWAJgLIAKgKQAMgLAQgBIADAAQAQABAMALQAHAFADAFQAJALgDAWQgBAKgEAJQAEgGADAEQACANgKAGQgJATgQAKIgPAHQgFgBgIgGg");
	this.shape_47.setTransform(190.5,248.3,1.092,1.092);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#ECAA86").s().p("Ag2ArQgHAAgFgHQgGgGAAgJQAAgKAGgGQAFgGAHAAIAYgDQAGgCAEgFQAFgFABgDIAAgXQAGAEAJAAQAKAAAGgEIgBAXQAAAEAFAEQAEAFAGACIAXADQAIAAAGAGQAEAGAAAKQAAAJgEAGQgGAHgIAAg");
	this.shape_48.setTransform(190.5,258.1,1.092,1.092);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#F7DA98").s().p("AhpBqQgsgrAAg/QAAg9AsgsQAsgsA9AAQA+AAAsAsQAsAsAAA9QAAA/gsArQgrAsg/AAQg9AAgsgsg");
	this.shape_49.setTransform(221.9,226,1.092,1.092);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#6DB5C5").s().p("AhpBqQgsgsAAg+QAAg9AsgsQAsgsA9AAQA+AAAsAsQAsAsAAA9QAAA+gsAsQgsAsg+AAQg9AAgsgsg");
	this.shape_50.setTransform(190.5,252.1,1.092,1.092);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#8EA6D9").s().p("AhpBqQgsgsAAg+QAAg9AsgsQAsgsA9AAQA+AAAsAsQAsAsAAA9QAAA+gsAsQgsAsg+AAQg9AAgsgsg");
	this.shape_51.setTransform(158.7,275.6,1.092,1.092);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#D0E1E5").s().p("AgnAoQgRgRAAgXQAAgXAQgRQARgQAXAAQAYAAARAQQAQARAAAXQAAAXgQARQgRAQgXABIgBAAQgWAAgRgRg");
	this.shape_52.setTransform(190.3,243.7,1.092,1.092);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#D0E1E5").s().p("AgoAoQgRgRABgXQAAgWARgRQARgRAWAAQAYAAARARQARARAAAWQAAAYgRARQgRAQgYAAQgXAAgRgRg");
	this.shape_53.setTransform(221.7,218.8,1.092,1.092);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#D0E1E5").s().p("AgoAoQgRgRABgXQAAgXARgRQAQgQAXAAQAYAAARARQARARgBAWQAAAYgRARQgRAQgXAAQgXAAgRgRg");
	this.shape_54.setTransform(158.9,267.3,1.092,1.092);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#8EA6D9").s().p("AgFAeIABg5QAAgNAKgBIAABTQgLAAAAgMg");
	this.shape_55.setTransform(153.1,286,1.092,1.092);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#8EA6D9").s().p("AgFAqIAAhUQAKABAAAKQABAggBAhQAAADgIAGg");
	this.shape_56.setTransform(164.6,286.1,1.092,1.092);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#F7DA98").s().p("AgEAeIAAg5QAAgNAKgCIAABUQgLAAABgMg");
	this.shape_57.setTransform(215.9,237.5,1.092,1.092);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#F7DA98").s().p("AgFApIAAhUQALADAAAJIgBBBQAAACgDACIgEAGg");
	this.shape_58.setTransform(227.4,237.6,1.092,1.092);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#6DB5C5").s().p("AgFApIAAhTQAKABAAALQABAqgBAXQAAACgDACIgEAEg");
	this.shape_59.setTransform(196,262.4,1.092,1.092);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#6DB5C5").s().p("AgFAeIAAg5QAAgNALgBIAABTQgLAAAAgMg");
	this.shape_60.setTransform(184.5,262.3,1.092,1.092);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#6DB5C5").s().p("AgUB9QgCgEABgHIAShOQACgMgHgGIgEgFQgIgQgWAGQgZAHgPATQgOATAAAaIAAAvQgzgqgEhBQgDhAAtgwQAsgwBCAAQBCABAsAwQAtAwgEBAQgEBCgzAoIAAglQAAgQgBgJQgEgYgUgRQgUgSgYABQgFAAgCADIgPASQgDAFABAGIARBPQADALgIAHIgQARgAgohoQgQAQAAAYQAAAYARARQARAQAXAAQAXAAARgRQAQgRAAgXQAAgYgQgQQgRgRgYAAQgXAAgRARg");
	this.shape_61.setTransform(190.3,250.8,1.092,1.092);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#F7DA98").s().p("AgTB+QgCgEABgGIARhTQABgFgEgHIgGgIQgIgKgFgCQgFgBgNAEQgWAGgPARQgRAVABAaIAAAvQgdgVgQgoQgRgsALgsQANgzAoggQAoghAzgBQAzgBArAfQAqAeANAxQAOAvgRAvQgPApgfAWIAAgvQACgcgUgVQgSgTgagFQgKgBgIAIQgRARAHAXQAFARAKA0QABAFgCADIgVAVIgTgUgAAAh5QgWAAgRARQgRARAAAXQgBAXARARQARARAXAAQAYAAARgQQARgRAAgYQAAgXgRgRQgRgRgXAAIgBAAg");
	this.shape_62.setTransform(221.7,225.9,1.092,1.092);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#8EA6D9").s().p("AgTB9QgDgEACgFIARhSQACgJgFgFQgGgGgBgDQgHgNgUAFQgaAHgPATQgPATAAAbIAAAtQgYgJgRgsQgSgsAFgjQAHg3AoglQAmgkA0gEQA2gFAtAeQAsAeAQA0QAOAvgRAvQgPAqgfAWIAAgvQACgdgVgVQgUgUgdgDQgEgBgDADIgRAVQgCACABAGQAJAsAJAoQACAHgFAFIgTASIgTgVgAgnhoQgRAQAAAYQgBAXARARQARARAXABQAXAAARgRQARgRABgXQAAgXgRgRQgRgRgXgBQgXAAgRARg");
	this.shape_63.setTransform(158.8,274.4,1.092,1.092);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#8EA6D9").s().p("AhtBRIAAigIDbAAIAACgg");
	this.shape_64.setTransform(158.6,303.9,1.092,1.092);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#6DB5C5").s().p("AhtC+IAAl5IAAgCIDbAAIAAF7g");
	this.shape_65.setTransform(190.3,292,1.092,1.092);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#F7DA98").s().p("AhuEuIAApbIDcAAIAAJSIABAJg");
	this.shape_66.setTransform(221.7,279.8,1.092,1.092);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#E1A1A7").s().p("AlnNUQilhHiAiAQiAiAhHilQhIisAAi8QAAi7BIisQBHimCAiAQCAiAClhGQCshIC7AAQC8AACsBIQCmBGCACAQB/CABHCmQBICsAAC7QAAC8hICsQhHClh/CAQiACAimBHQisBIi8AAQi7AAishIg");
	this.shape_67.setTransform(219.1,277.3,1.092,1.092);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#EFEFEF").s().p("AljNKQikhGh+h+Qh/h+hFikQhIiqAAi6QAAi5BIiqQBFikB/h+QB+h/CkhFQCqhIC5AAQC6AACqBIQCjBFCAB/QB9B+BGCkQBICqAAC5QAAC6hICqQhGCkh9B+QiAB+ijBGQiqBIi6AAQi5AAiqhIg");
	this.shape_68.setTransform(218.7,277,1.293,1.293);

	this.c15_2 = new lib.mc_radioButton15();
	this.c15_2.parent = this;
	this.c15_2.setTransform(514.9,343.2,1,1,0,0,0,18,18.1);

	this.c15_1 = new lib.mc_radioButton15();
	this.c15_1.parent = this;
	this.c15_1.setTransform(514.9,257.5,1,1,0,0,0,18,18.1);

	this.c15_op0 = new cjs.Text("Actualizar los perfiles críticos del área y establecer los indicadores de desempeño.", "16px 'Arial'", "#333333");
	this.c15_op0.name = "c15_op0";
	this.c15_op0.lineHeight = 18;
	this.c15_op0.lineWidth = 360;
	this.c15_op0.parent = this;
	this.c15_op0.setTransform(539.3,156.3);

	this.c15_op2 = new cjs.Text("Generar y dar seguimiento a los planes de desarrollo de tu equipo como líder.", "16px 'Arial'", "#333333");
	this.c15_op2.name = "c15_op2";
	this.c15_op2.lineHeight = 18;
	this.c15_op2.lineWidth = 363;
	this.c15_op2.parent = this;
	this.c15_op2.setTransform(539.3,335.1);

	this.c15_op1 = new cjs.Text("Esperar al siguiente año para revisar nuevamente la evaluación.", "16px 'Arial'", "#333333");
	this.c15_op1.name = "c15_op1";
	this.c15_op1.lineHeight = 18;
	this.c15_op1.lineWidth = 360;
	this.c15_op1.parent = this;
	this.c15_op1.setTransform(539.3,248.4);

	this.c15_0 = new lib.mc_radioButton15();
	this.c15_0.parent = this;
	this.c15_0.setTransform(514.9,166.7,1,1,0,0,0,18,18.1);

	this.p15 = new cjs.Text("Una vez concluida la sesión de calibración, el siguiente paso es:", "20px 'Arial'");
	this.p15.name = "p15";
	this.p15.lineHeight = 24;
	this.p15.lineWidth = 307;
	this.p15.parent = this;
	this.p15.setTransform(131,22);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.p15},{t:this.c15_0},{t:this.c15_op1},{t:this.c15_op2},{t:this.c15_op0},{t:this.c15_1},{t:this.c15_2},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.instance_19},{t:this.instance_18},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.instance_17},{t:this.instance_16},{t:this.instance_15},{t:this.instance_14},{t:this.instance_13},{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.shape_31},{t:this.shape_30},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// fondo y encabezado
	this.instance_20 = new lib.iconoactividadesyretos("synched",0);
	this.instance_20.parent = this;
	this.instance_20.setTransform(475.7,95.1,0.551,0.551,0,0,0,55.7,55.7);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("rgba(230,149,122,0.498)").s().p("EgiSAJ5QjsAAAAjsIAAsZQAAjsDsAAMBElAAAQDsAAAADsIAAMZQAADsjsAAg");
	this.shape_69.setTransform(254.4,49.7);

	this.instance_21 = new lib.fondo("synched",0);
	this.instance_21.parent = this;
	this.instance_21.setTransform(469.6,267.3,1,1,0,0,0,485.2,268.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_21},{t:this.shape_69},{t:this.instance_20}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.evalpagina15, new cjs.Rectangle(2.4,-36.5,958.3,510.2), null);


(lib.evalpagina12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		/*NOTA IMPROTANTE:
		EN CADA ACTIVIDAD CON MC IGUALES, SE TIENEN QUE DUPLICAR
		NO BASTA CON CAMBIARLES LA INSTANCIA, A NIVEL CÓDIGO NO HAY DIFERENCIA
		ADEMAS DE QUE TIENEN QUE TENER INSTANCIAS DIFERENTES A LAS ANTERIORES
		*/
		this.stop();
		var root = this;
		var resp = 2;
		var correcta = 2;
		root.p12.text=("Un criterio importante a recordar y usar en la discusión durante la sesión de Calibración es:");
		root.c12_op0.text=("Identificar los puestos que quedarán vacantes en el futuro próximo.");
		root.c12_op1.text=("Considerar la edad y antigüedad del colaborador en la empresa.");
		root.c12_op2.text=("Basarse en situaciones específicas, conductas observables y resultados puntuales.");
		iniciar();
		
		function iniciar() {
			root.parent.parent.btn_siguiente.visible = false;
			for (var i = 0; i <= resp; i++) {
				root['c12_' + i].cursor = "pointer";
				root['c12_' + i].n = i;
				root['c12_' + i].addEventListener("click", cambios);
				root['c12_' + i].gotoAndStop(1);
			}
		}
		
		function cambios(r) {
			//Cambia el estatus de la opcion seleccionada
			for (var i = 0; i <= resp; i++) {
				if (root['c12_' + i].n != r.currentTarget.n) {
					root['c12_' + i].gotoAndStop(0);
				} else {
					root['c12_' + i].gotoAndStop(1);
				}
			}
		
			//Valida la respuesta
			if (r.currentTarget.n == correcta) {
				root.parent.parent.resultados[root.parent.parent.cont] = 10;
				console.log("Respuesta Correcta " + root.parent.parent.resultados[root.parent.parent.cont]);
			} else {
				root.parent.parent.resultados[root.parent.parent.cont] = 0;
				console.log("Respuesta Incorrecta " + root.parent.parent.resultados[root.parent.parent.cont]);
			}
			root.parent.parent.activarSiguiente();
			root.parent.parent.registrar_pregunta(root.p12.text, root['c12_op'+r.currentTarget.n].text, root['c12_op'+correcta].text);
		
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#DC6A6D").s().p("AhMClIhziIQgEgGAAgEQAAgEAFgEIAhgbQAFgDAEAAQAEAAAFAFIBPBcIDHjyQAGgHAFgBQAFAAAIAGIAbAYQALAJgJALIisDSIgpAyIgVAZQgIAKgKAAQgJAAgHgIg");
	this.shape.setTransform(169.3,227.8,0.568,0.568);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#DC6A6D").s().p("AhTCqIhchuIgXgbQgMgQAPgMQANgMAUgQQAHgFAIABQAHABAGAGIBJBVIDBjrQAQgSATAPIAcAYQAQAPgNAQIjqEeQgKALgNABIgBAAQgOAAgJgKg");
	this.shape_1.setTransform(169.3,227.9,0.568,0.568);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#FFFFFF").ss(2.8).p("AAzCrIhlAAQgyAAgjgjQgjgjAAgyIAAhmQAAgxAjgjQAjgkAyAAIBlAAQAyAAAjAkQAjAjAAAxIAABmQAAAygjAjQgjAjgyAAg");
	this.shape_2.setTransform(167.5,317.6,0.568,0.568);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#FFFFFF").ss(2.8).p("AAzCrIhlAAQgyAAgjgjQgjgjAAgyIAAhmQAAgxAjgjQAjgkAyAAIBlAAQAyAAAjAkQAjAjAAAxIAABmQAAAygjAjQgjAjgyAAg");
	this.shape_3.setTransform(167.5,275.6,0.568,0.568);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#FFFFFF").ss(2.8).p("AAzCsIhlAAQgyAAgjgjQgjgkAAgxIAAhmQAAgyAjgjQAjgjAyAAIBlAAQAyAAAjAjQAjAjAAAyIAABmQAAAxgjAkQgjAjgyAAg");
	this.shape_4.setTransform(167.5,232.5,0.568,0.568);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#3F3F3F").s().p("AhkC/Igbl1QAAgDADgDQACgCADAAQBOABA1AaQBAAeAQA6QAKAkAKBKQAKBKAGBSg");
	this.shape_5.setTransform(299.7,358.8,0.568,0.568);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#3F3F3F").s().p("AiCC/QAOilAchlQAQg6BAgeQA1gaBOgBQADAAADACQACADAAADIgzF1g");
	this.shape_6.setTransform(254.6,358.8,0.568,0.568);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#2F2F2F").s().p("Ah7DlIAyiiIBiknIAvAmQAOAIASBHIAUBZIhTgJIA8BsQACADgdAtIhFBog");
	this.shape_7.setTransform(284.9,356.6,0.568,0.568);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#2F2F2F").s().p("AgCDcIhGhpQgegsABgDIA9hsIhTAJIAThUQAQhAAPgJIA2gfIBeEVIAxCig");
	this.shape_8.setTransform(268.5,357.1,0.568,0.568);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#ACADAD").s().p("ABzCOIglhAQgGgLgJgKIg/hOIg/BOIgPAVIgkBAQgEAkgKgmIhCjVIAAgEIBPhEIANAbQAbAlAcAXQAdAXASAAQAYAAASgIQAagMAWgfIAkhIIBEBRQABAAAAABQAAABAAAAQAAABAAAAQAAABgBAAIhCDVQgFATgDAAQgDAAgCgRg");
	this.shape_9.setTransform(276.7,351.9,0.568,0.568);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#B3B3B3").s().p("AiRDgIALgrIAzjJIAyjMQAAAHBRAwQAUAJAaAFIApAJQgLBSAHBoIAPC4g");
	this.shape_10.setTransform(286.3,356.9,0.568,0.568);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#B3B3B3").s().p("AiGDVQAFiRAAgrQABhogLhPQAOgDAcgFQAagFATgJIAfgPQAYgNAAgEQARBFAuB7QAvB6ARBEIAKArg");
	this.shape_11.setTransform(267.7,357.5,0.568,0.568);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#E5E6E6").s().p("Ag0CoIhZjRQgEgLAHgKQBChWBIgTQBJATBCBWQAIAKgFALIhZDRg");
	this.shape_12.setTransform(276.7,360.1,0.568,0.568);

	this.instance = new lib.ClipGroup_27();
	this.instance.parent = this;
	this.instance.setTransform(276.6,317.4,0.568,0.568,0,0,0,36.3,49.2);

	this.instance_1 = new lib.ClipGroup_1_2();
	this.instance_1.parent = this;
	this.instance_1.setTransform(276.1,286.2,0.568,0.568,0,0,0,23.2,14.4);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#EEAA83").s().p("AgQgqQAPgaAPACQAIABAEAHQAHA2gdAoIgeAfg");
	this.shape_13.setTransform(293.6,322.8,0.568,0.568);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#EEAA83").s().p("AgDAkQgdgoAHg2IAMgIQAPgCAPAaIAKBtQgQgKgOgVg");
	this.shape_14.setTransform(260.3,322.8,0.568,0.568);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FABD99").s().p("AhfGAQhthGg8iAQgQgKgPgVQgegpAHg2IANgIQAPgCAQAaQgWg8gJhKQgUiWA9hJIAQgVQAVgZAagWQBThGBngKIAfAAQBnAKBUBGQApAjAVAhQA9BJgTCWQgKBKgWA8QAQgaAPACQAIABAFAHQAHA2geApIgfAfQg8CAhsBGQgiAXgjANIgcAKQgpgKg2gkg");
	this.shape_15.setTransform(277,315.9,0.568,0.568);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#EEAA83").s().p("AlrEdQgyAAgigrQgkgsAAg9QAAg+AkgrQAigqAyAAICfgYQAlgMAiggQAgggAAgYIAAiWQAqAXBBAAQBBAAAvgXIgGCXQABAYAcAfQAdAfAjANICfAYQAyAAAiAqQAkArAAA+QAAA9gkAsQgiArgyAAg");
	this.shape_16.setTransform(276.9,349.9,0.568,0.568);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#FFFFFF").ss(2.8).p("APgAAQAADKhOC4QhLCyiKCJQiJCKiyBLQi4BOjKAAQjJAAi4hOQiyhLiJiKQiKiJhLiyQhOi4AAjKQAAjJBOi4QBLiyCKiJQCJiKCyhLQC4hODJAAQDKAAC4BOQCyBLCJCKQCKCJBLCyQBOC4AADJg");
	this.shape_17.setTransform(277.1,328.6,0.568,0.568);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#7CA588").s().p("AmBOSQiyhLiJiKQiKiJhLiyQhOi4AAjKQAAjJBOi4QBLiyCKiJQCJiKCyhLQC4hODJAAQDKAAC4BOQCyBLCJCKQCKCJBLCyQBOC4AADJQAADKhOC4QhLCyiKCJQiJCKiyBLQi4BOjKAAQjJAAi4hOg");
	this.shape_18.setTransform(277.1,328.6,0.568,0.568);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("#FFFFFF").ss(8.5).p("AqQAAIUhAA");
	this.shape_19.setTransform(224.8,317.8,0.568,0.568);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().s("#FFFFFF").ss(8.5).p("AqQAAIUhAA");
	this.shape_20.setTransform(224.8,274.8,0.568,0.568);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f().s("#FFFFFF").ss(8.5).p("AqQAAIUhAA");
	this.shape_21.setTransform(224.8,231.8,0.568,0.568);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#C3D4CA").s().p("ApXWLQkUh1jVjVQjVjVh1kUQh5kfAAk5QAAk4B5kfQB1kUDVjVQDWjVETh1QEeh5E5AAQE5AAEeB5QEVB1DVDVQDVDVB1EUQB5EfAAE4QAAE5h5EfQh1EUjVDVQjVDVkVB1QkeB5k5AAQk5AAkeh5g");
	this.shape_22.setTransform(214.6,275.5,0.568,0.568);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#EFEFEF").s().p("ArMagQlJiMkAj/Qj+j+iMlLQiRlVAAl3QAAl1CRlWQCMlKD+j/QEAj/FJiMQFWiQF2AAQF3AAFVCQQFKCMD/D/QD/D/CMFKQCQFWAAF1QAAF3iQFVQiMFLj/D+Qj/D/lKCMQlVCQl3AAQl2AAlWiQg");
	this.shape_23.setTransform(215,276.4,0.568,0.568);

	this.c12_2 = new lib.mc_radioButton12();
	this.c12_2.parent = this;
	this.c12_2.setTransform(514.9,358.2,1,1,0,0,0,18,18.1);

	this.c12_1 = new lib.mc_radioButton12();
	this.c12_1.parent = this;
	this.c12_1.setTransform(514.9,272.5,1,1,0,0,0,18,18.1);

	this.c12_op0 = new cjs.Text("Identificar los puestos que quedarán vacantes en el futuro próximo.", "16px 'Arial'", "#333333");
	this.c12_op0.name = "c12_op0";
	this.c12_op0.lineHeight = 18;
	this.c12_op0.lineWidth = 345;
	this.c12_op0.parent = this;
	this.c12_op0.setTransform(539.3,178.3);

	this.c12_op2 = new cjs.Text("Basarse en situaciones específicas, conductas observables y resultados puntuales.", "16px 'Arial'", "#333333");
	this.c12_op2.name = "c12_op2";
	this.c12_op2.lineHeight = 18;
	this.c12_op2.lineWidth = 351;
	this.c12_op2.parent = this;
	this.c12_op2.setTransform(539.3,348.8);

	this.c12_op1 = new cjs.Text("Considerar la edad y antigüedad del colaborador en la empresa.", "16px 'Arial'", "#333333");
	this.c12_op1.name = "c12_op1";
	this.c12_op1.lineHeight = 18;
	this.c12_op1.lineWidth = 348;
	this.c12_op1.parent = this;
	this.c12_op1.setTransform(539.3,263.6);

	this.c12_0 = new lib.mc_radioButton12();
	this.c12_0.parent = this;
	this.c12_0.setTransform(514.9,186.7,1,1,0,0,0,18,18.1);

	this.p12 = new cjs.Text("Un criterio importante a recordar y usar en la discusión durante la sesión de Calibración es:", "20px 'Arial'");
	this.p12.name = "p12";
	this.p12.lineHeight = 24;
	this.p12.lineWidth = 311;
	this.p12.parent = this;
	this.p12.setTransform(130,15);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.p12},{t:this.c12_0},{t:this.c12_op1},{t:this.c12_op2},{t:this.c12_op0},{t:this.c12_1},{t:this.c12_2},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.instance_1},{t:this.instance},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// fondo y encabezado
	this.instance_2 = new lib.iconoactividadesyretos("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(475.7,95.1,0.551,0.551,0,0,0,55.7,55.7);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("rgba(230,149,122,0.498)").s().p("EgiSAJ5QjsAAAAjsIAAsZQAAjsDsAAMBElAAAQDsAAAADsIAAMZQAADsjsAAg");
	this.shape_24.setTransform(254.4,49.7);

	this.instance_3 = new lib.fondo("synched",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(469.6,267.3,1,1,0,0,0,485.2,268.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_3},{t:this.shape_24},{t:this.instance_2}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.evalpagina12, new cjs.Rectangle(2.4,-36.5,958.3,510.2), null);


(lib.evalpagina11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		/*NOTA IMPROTANTE:
		EN CADA ACTIVIDAD CON MC IGUALES, SE TIENEN QUE DUPLICAR
		NO BASTA CON CAMBIARLES LA INSTANCIA, A NIVEL CÓDIGO NO HAY DIFERENCIA
		ADEMAS DE QUE TIENEN QUE TENER INSTANCIAS DIFERENTES A LAS ANTERIORES
		*/
		this.stop();
		var root = this;
		var resp = 2;
		var correcta = 2;
		iniciar();
		
		function iniciar() {
			root.parent.parent.btn_siguiente.visible = false;
			for (var i = 0; i <= resp; i++) {
				root['c15_' + i].cursor = "pointer";
				root['c15_' + i].n = i;
				root['c15_' + i].addEventListener("click", cambios);
				root['c15_' + i].gotoAndStop(1);
			}
		}
		
		function cambios(r) {
			//Cambia el estatus de la opcion seleccionada
			for (var i = 0; i <= resp; i++) {
				if (root['c15_' + i].n != r.currentTarget.n) {
					root['c15_' + i].gotoAndStop(0);
				} else {
					root['c15_' + i].gotoAndStop(1);
				}
			}
		
			//Valida la respuesta
			if (r.currentTarget.n == correcta) {
				root.parent.parent.resultados[root.parent.parent.cont] = 10;
				console.log("Respuesta Correcta " + root.parent.parent.resultados[root.parent.parent.cont]);
			} else {
				root.parent.parent.resultados[root.parent.parent.cont] = 0;
				console.log("Respuesta Incorrecta " + root.parent.parent.resultados[root.parent.parent.cont]);
			}
			root.parent.parent.activarSiguiente();
			root.parent.parent.registrar_pregunta(root.p15.text, root['c15_op'+r.currentTarget.n].text, root['c15_op'+correcta].text);
		
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#99CAAB").s().p("AGIJEIsPgBQgrAAgLgLQgLgLAAgtIAAwAQAAgsALgLQALgLAsAAIMLAAQAsAAALALQALAKAAAsQAAMfACDlQAAAkgOAOQgPAPghAAIgDAAgAkPFIQgWAWAAAdQABAcAVAVQAUAWAcABQAeABAWgVQAXgWAAgdQABgegWgWQgVgWgeAAQgeAAgVAWgAEJGWIArgBIAIgCQARgGABgTQAAgUgRgHQgCgCgFAAQirgDisADQgDAAgEACQgQAHAAATQABAUASAGIAHACQAcABA4AAIBUAAIB/AAgAlEB1QgMAAgHAJQgIAJADALIACAFQAmAvAbAVQAGAFAQgCQAQgCAHgGQBAg7BEhMQADgCABgEQAGgQgNgLQgNgLgOAJIgEACIhyBqQgHAHgJgBQgJAAgGgHQgQgUgOgLQgEgDgGAAIgBAAgAgiBmQgFAAgEADQgQAJACATQADATASAEIADAAQAjACAyAAIBUAAIAAgBIBaABQA0AAAmgCQAFAAAFgEQAOgJAAgQQAAgQgNgIQgFgDgEAAIiBgBQhzAAhsADgAlRh4QgMALAHAOIABADQAPAVAmAmQAaAeAdgfIBChEQAngpAZgcIAEgFQAGgPgMgLQgMgKgPAHIgEADIhzBuQgHAHgKgBQgJgBgFgHQgPgUgJgIIgFgCQgGgDgFAAQgIAAgHAHgAggiRQgEAAgFADQgQAHgBATQAAASAQAGQADACAEAAQCuADCugDIAGgCQARgGAAgSQAAgTgRgHIgJgDIgpgBIh/AAgAlTltQgKANAJANIAAAAQAIALARARQATAUAHAHQAPASAOgBQANgBAPgRIA/hAQAmgoAYgaIAAAAQALgNgLgPQgMgOgPAIQgDABgFAEQgYAUhVBXQgHAHgJgBQgIgBgEgHQgPgWgLgIIgIgEIgIgCQgKAAgIAKgAgcmKIgFABQgTADgCAUQgCAVASAIQAFACAEAAIAoACQApABBTgBIBXAAQAzAAAkgCQAFAAADgCQARgHAAgTQAAgTgRgGIgIgCQhUgBhVAAQhVAAhTABg");
	this.shape.setTransform(214.8,288.8,1.075,1.075);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AmLKUQhHAAgigiQghgiAAhFIAAwZQAAhBAhgiQAhgiBBAAQGSgCGSACQCFABAACIIAAQTQAABHghAiQgiAihGAAImNABImMgBgAmFpCQgsAAgLALQgLALAAAsIAAQAQAAAtALALQAKALAsAAIMPABQAkAAAOgPQAOgOAAgkQgBjlAAsfQAAgsgLgKQgLgLgtAAImFAAImFAAg");
	this.shape_1.setTransform(214.7,288.8,1.075,1.075);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#99CAAB").s().p("Al/OEQivhKiHiIQiGiHhKiwQhMi2ABjIQAAjIBNi1QBKiwCJiGQCHiGCxhJQC3hMDJABQDHAACzBNQCvBLCFCIQCGCHBJCwQBMC2AADHQAADHhNC1QhKCviHCHQiICGiwBJQi3BMjHAAQjHAAi1hNgAmSqTQhCAAggAiQgiAiABBBIAAQZQAABFAhAiQAiAiBGAAQGNABGMgBQBHAAAigiQAggiABhHIAAwTQAAiIiFgBImSgBImSABg");
	this.shape_2.setTransform(214.7,288.8,1.075,1.075);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#EFEFEF").s().p("Am5QYQjMhXieidQididhWjNQhajTAAjnQAAjnBajTQBWjMCdidQCeieDMhWQDShZDnAAQDoAADSBZQDMBWCeCeQCeCdBVDMQBaDTAADnQAADnhaDTQhVDNieCdQieCdjMBXQjSBZjoAAQjnAAjShZg");
	this.shape_3.setTransform(212.8,290.2,1.076,1.076);

	this.c15_2 = new lib.mc_radioButton15();
	this.c15_2.parent = this;
	this.c15_2.setTransform(510.9,353.2,1,1,0,0,0,18,18.1);

	this.c15_1 = new lib.mc_radioButton15();
	this.c15_1.parent = this;
	this.c15_1.setTransform(510.9,272,1,1,0,0,0,18,18.1);

	this.c15_op0 = new cjs.Text("Ajustar mediante una discusión, los resultados de desempeño y potencial de los colaboradores en base a conductas observables, y definir posibles sucesores.", "16px 'Arial'", "#333333");
	this.c15_op0.name = "c15_op0";
	this.c15_op0.lineHeight = 20;
	this.c15_op0.lineWidth = 340;
	this.c15_op0.parent = this;
	this.c15_op0.setTransform(535.3,144.8);

	this.c15_op2 = new cjs.Text("Identificar los puestos que deben contar con reemplazos en el largo plazo.", "16px 'Arial'", "#333333");
	this.c15_op2.name = "c15_op2";
	this.c15_op2.lineHeight = 20;
	this.c15_op2.lineWidth = 338;
	this.c15_op2.parent = this;
	this.c15_op2.setTransform(535.3,344.4);

	this.c15_op1 = new cjs.Text("Identificar a los mejores colaboradores para los puestos con vacantes.", "16px 'Arial'", "#333333");
	this.c15_op1.name = "c15_op1";
	this.c15_op1.lineHeight = 20;
	this.c15_op1.lineWidth = 357;
	this.c15_op1.parent = this;
	this.c15_op1.setTransform(535.3,263.2);

	this.c15_0 = new lib.mc_radioButton15();
	this.c15_0.parent = this;
	this.c15_0.setTransform(510.9,156.7,1,1,0,0,0,18,18.1);

	this.p15 = new cjs.Text("¿Qué se logra durante la Sesión de Calibración?", "20px 'Arial'");
	this.p15.name = "p15";
	this.p15.lineHeight = 24;
	this.p15.lineWidth = 301;
	this.p15.parent = this;
	this.p15.setTransform(136,21);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.p15},{t:this.c15_0},{t:this.c15_op1},{t:this.c15_op2},{t:this.c15_op0},{t:this.c15_1},{t:this.c15_2},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// fondo y encabezado
	this.instance = new lib.iconoactividadesyretos("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(475.7,95.1,0.551,0.551,0,0,0,55.7,55.7);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("rgba(230,149,122,0.498)").s().p("EgiSAJ5QjsAAAAjsIAAsZQAAjsDsAAMBElAAAQDsAAAADsIAAMZQAADsjsAAg");
	this.shape_4.setTransform(254.4,49.7);

	this.instance_1 = new lib.fondo("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(469.6,267.3,1,1,0,0,0,485.2,268.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.shape_4},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.evalpagina11, new cjs.Rectangle(2.4,-36.5,958.3,510.2), null);


(lib.evalpagina10 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		/*NOTA IMPROTANTE:
		EN CADA ACTIVIDAD CON MC IGUALES, SE TIENEN QUE DUPLICAR
		NO BASTA CON CAMBIARLES LA INSTANCIA, A NIVEL CÓDIGO NO HAY DIFERENCIA
		ADEMAS DE QUE TIENEN QUE TENER INSTANCIAS DIFERENTES A LAS ANTERIORES
		*/
		this.stop();
		var root = this;
		var resp = 2;
		var correcta = 2;
		root.p10.text=("¿Cuáles cuadrantes de la matriz 9-Box consolidan el área de Alto Potencial (Top Talent) de la compañía?");
		root.c10_op0.text=("Caso Enigma; Profesional efectivo; Profesional experto.");
		root.c10_op1.text=("Colaborador consistente; Alto impacto.");
		root.c10_op2.text=("Talento en crecimiento; Futuro líder; Alto impacto.");
		iniciar();
		
		function iniciar() {
			root.parent.parent.btn_siguiente.visible = false;
			for (var i = 0; i <= resp; i++) {
				root['c10_' + i].cursor = "pointer";
				root['c10_' + i].n = i;
				root['c10_' + i].addEventListener("click", cambios);
				root['c10_' + i].gotoAndStop(1);
			}
		}
		
		function cambios(r) {
			//Cambia el estatus de la opcion seleccionada
			for (var i = 0; i <= resp; i++) {
				if (root['c10_' + i].n != r.currentTarget.n) {
					root['c10_' + i].gotoAndStop(0);
				} else {
					root['c10_' + i].gotoAndStop(1);
				}
			}
		
			//Valida la respuesta
			if (r.currentTarget.n == correcta) {
				root.parent.parent.resultados[root.parent.parent.cont] = 10;
				console.log("Respuesta Correcta " + root.parent.parent.resultados[root.parent.parent.cont]);
			} else {
				root.parent.parent.resultados[root.parent.parent.cont] = 0;
				console.log("Respuesta Incorrecta " + root.parent.parent.resultados[root.parent.parent.cont]);
			}
			root.parent.parent.activarSiguiente();
			root.parent.parent.registrar_pregunta(root.p10.text, root['c10_op'+r.currentTarget.n].text, root['c10_op'+correcta].text);
		
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.instance = new lib.M03_TMR_TABLA4();
	this.instance.parent = this;
	this.instance.setTransform(251.1,281.9,0.446,0.446,0,0,0,313.6,158.8);

	this.text = new cjs.Text("Potencial básico\n", "18px 'Arial'", "#333333");
	this.text.textAlign = "center";
	this.text.lineHeight = 19;
	this.text.lineWidth = 97;
	this.text.parent = this;
	this.text.setTransform(74.1,315.2,0.554,0.554);

	this.text_1 = new cjs.Text("Potencial medio", "18px 'Arial'", "#333333");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 19;
	this.text_1.lineWidth = 97;
	this.text_1.parent = this;
	this.text_1.setTransform(74.1,272,0.554,0.554);

	this.text_2 = new cjs.Text("Alto Potencial ", "18px 'Arial'", "#333333");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 19;
	this.text_2.lineWidth = 97;
	this.text_2.parent = this;
	this.text_2.setTransform(74.1,224.7,0.554,0.554);

	this.text_3 = new cjs.Text("Desempeño alto\n", "18px 'Arial'", "#333333");
	this.text_3.lineHeight = 22;
	this.text_3.lineWidth = 159;
	this.text_3.parent = this;
	this.text_3.setTransform(307.9,193.7,0.554,0.554);

	this.text_4 = new cjs.Text("Desempeño medio", "18px 'Arial'", "#333333");
	this.text_4.lineHeight = 22;
	this.text_4.lineWidth = 159;
	this.text_4.parent = this;
	this.text_4.setTransform(208.7,193.7,0.554,0.554);

	this.text_5 = new cjs.Text("Desempeño bajo", "18px 'Arial'", "#333333");
	this.text_5.lineHeight = 22;
	this.text_5.lineWidth = 276;
	this.text_5.parent = this;
	this.text_5.setTransform(119,193.7,0.554,0.554);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("rgba(102,218,255,0.6)").ss(1,1,1).p("A8cwUMA44AAAQCgAAAACgIAAbpQAACgigAAMg44AAAQigAAAAigIAA7pQAAigCgAAg");
	this.shape.setTransform(219.5,270.5,0.924,0.924);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(255,255,255,0.498)").s().p("A8cQVQigAAAAigIAA7pQAAigCgAAMA45AAAQCgAAAACgIAAbpQAACgigAAg");
	this.shape_1.setTransform(219.5,270.5,0.924,0.924);

	this.c10_2 = new lib.mc_radioButton10();
	this.c10_2.parent = this;
	this.c10_2.setTransform(532.9,352.2,1,1,0,0,0,18,18.1);

	this.c10_1 = new lib.mc_radioButton10();
	this.c10_1.parent = this;
	this.c10_1.setTransform(532.9,276.5,1,1,0,0,0,18,18.1);

	this.c10_op0 = new cjs.Text("Caso Enigma; Profesional efectivo; Profesional experto.", "16px 'Arial'");
	this.c10_op0.name = "c10_op0";
	this.c10_op0.lineHeight = 18;
	this.c10_op0.lineWidth = 360;
	this.c10_op0.parent = this;
	this.c10_op0.setTransform(550.3,181.3);

	this.c10_op2 = new cjs.Text("Talento en crecimiento; Futuro líder; Alto impacto.", "16px 'Arial'");
	this.c10_op2.name = "c10_op2";
	this.c10_op2.lineHeight = 18;
	this.c10_op2.lineWidth = 369;
	this.c10_op2.parent = this;
	this.c10_op2.setTransform(550.8,344.1);

	this.c10_op1 = new cjs.Text("Colaborador consistente; Alto impacto.", "16px 'Arial'");
	this.c10_op1.name = "c10_op1";
	this.c10_op1.lineHeight = 18;
	this.c10_op1.lineWidth = 363;
	this.c10_op1.parent = this;
	this.c10_op1.setTransform(550.3,267.7);

	this.c10_0 = new lib.mc_radioButton10();
	this.c10_0.parent = this;
	this.c10_0.setTransform(532.9,190.7,1,1,0,0,0,18,18.1);

	this.p10 = new cjs.Text("¿Cuáles cuadrantes de la matriz 9-Box consolidan el área de Alto Potencial (Top Talent) de la compañía?", "20px 'Arial'");
	this.p10.name = "p10";
	this.p10.lineHeight = 24;
	this.p10.lineWidth = 309;
	this.p10.parent = this;
	this.p10.setTransform(133,5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.p10},{t:this.c10_0},{t:this.c10_op1},{t:this.c10_op2},{t:this.c10_op0},{t:this.c10_1},{t:this.c10_2},{t:this.shape_1},{t:this.shape},{t:this.text_5},{t:this.text_4},{t:this.text_3},{t:this.text_2},{t:this.text_1},{t:this.text},{t:this.instance}]}).wait(1));

	// fondo y encabezado
	this.instance_1 = new lib.iconoactividadesyretos("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(475.7,95.1,0.551,0.551,0,0,0,55.7,55.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(230,149,122,0.498)").s().p("EgiSAJ5QjsAAAAjsIAAsZQAAjsDsAAMBElAAAQDsAAAADsIAAMZQAADsjsAAg");
	this.shape_2.setTransform(254.4,49.7);

	this.instance_2 = new lib.fondo("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(469.6,267.3,1,1,0,0,0,485.2,268.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.shape_2},{t:this.instance_1}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.evalpagina10, new cjs.Rectangle(2.4,-36.5,958.3,510.2), null);


(lib.evalpag14 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		var root = this;
		var resp = 4;
		var correctas = [0, 2];
		console.log(correctas, correctas.length);
		var cont = 0;
		var contador =1;
		var seleccion = ["", ""];
		var correcto="";
		var respuestas="";
		var corr = 0;
		
		root.p14.text=("Identifica 2 posibles acciones de desarrollo para un colaborador que se ubica en el cuadrante  “Colaborador consistente”.");
		root.c14_op0.text=("Asignar nuevas tareas que le permitan poner a prueba su verdadero potencial (capacidad).");
		root.c14_op1.text=("Dar seguimiento puntual a sus tareas y responsabilidades (Planes de acciones de mejora).");
		root.c14_op2.text=("Asignar proyectos que le permitan desarrollar su capacidad como líder, agente de cambio, así como la adquisición de nuevas experiencias y aumento de su nivel de compromiso.");
		root.c14_op3.text=("Otorgar última oportunidad a prueba.");
		root.c14_op4.text=("Asignar proyectos que le permitan mejorar su desempeño.");
		
		for (var i = 0; i < correctas.length; i++) {
			correcto+= root['c14_op' +correctas[i]].text+"\n"; 
		}
		
		iniciar();
		root.parent.parent.btn_siguiente.visible = false;
		
		function iniciar() {
			for (var i = 0; i <= resp; i++) {
				root['ch14_' + i].activo = false;
				root['ch14_' + i].cursor = "pointer";
				root['ch14_' + i].n = i;
				root['ch14_' + i].addEventListener("click", cambios);
		
		
			}
			// activar el cambio de estado de los checkbox
			function cambios(r) {
				if (r.currentTarget.activo == false) {
					r.currentTarget.activo = true;
					r.currentTarget.gotoAndStop(1);
					seleccion[r.currentTarget.n] = root['c14_op' + r.currentTarget.n].text + "\n";
					//root.OrdenPreguntas.push();
					cont++
				} else {
					r.currentTarget.activo = false;
					r.currentTarget.gotoAndStop(0);
					seleccion[r.currentTarget.n] = " ";
					cont--
				}
		
				respuestas = "";
				for (var i = 0; i <= resp; i++) {
					respuestas += seleccion[i];
				}
				root.parent.parent.registrar_pregunta(root.p14.text, respuestas, correcto);
		
				if (r.currentTarget.n == 0 || r.currentTarget.n == 2) {
					if (r.currentTarget.activo == true) {
						corr++
						console.log("sel corr" + corr);
					} else {
						corr--
						console.log(" des sel corr" + corr);
					}
				}
				if (corr == 2) {
					root.parent.parent.resultados[root.parent.parent.cont] = 10;
				} else {
					root.parent.parent.resultados[root.parent.parent.cont] = 0;
				}
		
				console.log(cont);
		
				if (cont == 2) {
					root.parent.parent.activarSiguiente();
					for (var l = 0; l <= resp; l++) {
						if (root['ch14_' + l].activo == false) {
							root['ch14_' + l].mouseEnabled = false;
						}
					}
				} else {
					root.parent.parent.btn_siguiente.visible = false;
					for (var k = 0; k <= resp; k++) {
						root['ch14_' + k].mouseEnabled = true;
					}
				}
			}
		
			console.log("Estado de calificacion ", root.parent.parent.resultados[root.parent.parent.cont], cont);
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.ch14_4 = new lib.ch14();
	this.ch14_4.parent = this;
	this.ch14_4.setTransform(489.7,395.9,1,1,0,0,0,18.6,18.6);

	this.c14_op4 = new cjs.Text("Asignar proyectos que le permitan mejorar su desempeño.", "16px 'Arial'", "#333333");
	this.c14_op4.name = "c14_op4";
	this.c14_op4.lineHeight = 18;
	this.c14_op4.lineWidth = 348;
	this.c14_op4.parent = this;
	this.c14_op4.setTransform(515.5,383.6);

	this.ch14_3 = new lib.ch14();
	this.ch14_3.parent = this;
	this.ch14_3.setTransform(489.7,355.5,1,1,0,0,0,18.6,18.6);

	this.ch14_2 = new lib.ch14();
	this.ch14_2.parent = this;
	this.ch14_2.setTransform(489.7,264.2,1,1,0,0,0,18.6,18.6);

	this.ch14_1 = new lib.ch14();
	this.ch14_1.parent = this;
	this.ch14_1.setTransform(489.7,207.9,1,1,0,0,0,18.6,18.6);

	this.ch14_0 = new lib.ch14();
	this.ch14_0.parent = this;
	this.ch14_0.setTransform(489.7,155.6,1,1,0,0,0,18.6,18.6);

	this.c14_op3 = new cjs.Text("Otorgar última oportunidad a prueba.", "16px 'Arial'", "#333333");
	this.c14_op3.name = "c14_op3";
	this.c14_op3.lineHeight = 18;
	this.c14_op3.lineWidth = 384;
	this.c14_op3.parent = this;
	this.c14_op3.setTransform(515.5,349);

	this.c14_op2 = new cjs.Text("Asignar proyectos que le permitan desarrollar su capacidad como líder, agente de cambio, así como la adquisición de nuevas experiencias y aumento de su nivel de compromiso.", "16px 'Arial'", "#333333");
	this.c14_op2.name = "c14_op2";
	this.c14_op2.lineHeight = 18;
	this.c14_op2.lineWidth = 383;
	this.c14_op2.parent = this;
	this.c14_op2.setTransform(515.5,252.4);

	this.c14_op1 = new cjs.Text("Dar seguimiento puntual a sus tareas y responsabilidades (Planes de acciones de mejora).", "16px 'Arial'", "#333333");
	this.c14_op1.name = "c14_op1";
	this.c14_op1.lineHeight = 18;
	this.c14_op1.lineWidth = 380;
	this.c14_op1.parent = this;
	this.c14_op1.setTransform(515.5,199.3);

	this.c14_op0 = new cjs.Text("Asignar nuevas tareas que le permitan poner a prueba su verdadero potencial (capacidad).", "16px 'Arial'", "#333333");
	this.c14_op0.name = "c14_op0";
	this.c14_op0.lineHeight = 18;
	this.c14_op0.lineWidth = 379;
	this.c14_op0.parent = this;
	this.c14_op0.setTransform(515.5,142.3);

	this.p14 = new cjs.Text("Identifica 2 posibles acciones de desarrollo para un colaborador que se ubica en el cuadrante  “Colaborador consistente”.", "20px 'Arial'");
	this.p14.name = "p14";
	this.p14.lineHeight = 24;
	this.p14.lineWidth = 293;
	this.p14.parent = this;
	this.p14.setTransform(142.4,2);

	this.instance = new lib.M03_TMR_TABLA4();
	this.instance.parent = this;
	this.instance.setTransform(256.3,285,0.446,0.446,0,0,0,313.6,158.8);

	this.text = new cjs.Text("Potencial básico\n", "18px 'Arial'", "#333333");
	this.text.textAlign = "center";
	this.text.lineHeight = 19;
	this.text.lineWidth = 97;
	this.text.parent = this;
	this.text.setTransform(79.3,318.3,0.554,0.554);

	this.text_1 = new cjs.Text("Potencial medio", "18px 'Arial'", "#333333");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 19;
	this.text_1.lineWidth = 97;
	this.text_1.parent = this;
	this.text_1.setTransform(79.3,275.1,0.554,0.554);

	this.text_2 = new cjs.Text("Alto Potencial ", "18px 'Arial'", "#333333");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 19;
	this.text_2.lineWidth = 97;
	this.text_2.parent = this;
	this.text_2.setTransform(79.3,227.8,0.554,0.554);

	this.text_3 = new cjs.Text("Desempeño alto\n", "18px 'Arial'", "#333333");
	this.text_3.lineHeight = 22;
	this.text_3.lineWidth = 159;
	this.text_3.parent = this;
	this.text_3.setTransform(313,196.8,0.554,0.554);

	this.text_4 = new cjs.Text("Desempeño medio", "18px 'Arial'", "#333333");
	this.text_4.lineHeight = 22;
	this.text_4.lineWidth = 159;
	this.text_4.parent = this;
	this.text_4.setTransform(213.8,196.8,0.554,0.554);

	this.text_5 = new cjs.Text("Desempeño bajo", "18px 'Arial'", "#333333");
	this.text_5.lineHeight = 22;
	this.text_5.lineWidth = 276;
	this.text_5.parent = this;
	this.text_5.setTransform(124.1,196.8,0.554,0.554);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("rgba(102,218,255,0.6)").ss(1,1,1).p("A8cwUMA44AAAQCgAAAACgIAAbpQAACgigAAMg44AAAQigAAAAigIAA7pQAAigCgAAg");
	this.shape.setTransform(224.6,273.6,0.924,0.924);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(255,255,255,0.498)").s().p("A8cQVQigAAAAigIAA7pQAAigCgAAMA45AAAQCgAAAACgIAAbpQAACgigAAg");
	this.shape_1.setTransform(224.6,273.6,0.924,0.924);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape},{t:this.text_5},{t:this.text_4},{t:this.text_3},{t:this.text_2},{t:this.text_1},{t:this.text},{t:this.instance},{t:this.p14},{t:this.c14_op0},{t:this.c14_op1},{t:this.c14_op2},{t:this.c14_op3},{t:this.ch14_0},{t:this.ch14_1},{t:this.ch14_2},{t:this.ch14_3},{t:this.c14_op4},{t:this.ch14_4}]}).wait(1));

	// fondo y encabezado
	this.instance_1 = new lib.iconoactividadesyretos("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(475.7,95.1,0.551,0.551,0,0,0,55.7,55.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(230,149,122,0.498)").s().p("EgiSAJ5QjsAAAAjsIAAsZQAAjsDsAAMBElAAAQDsAAAADsIAAMZQAADsjsAAg");
	this.shape_2.setTransform(254.4,49.7);

	this.instance_2 = new lib.fondo("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(469.6,267.3,1,1,0,0,0,485.2,268.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.shape_2},{t:this.instance_1}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.evalpag14, new cjs.Rectangle(2.4,-36.5,958.3,510.2), null);


(lib.evalpag9 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		/*NOTA IMPROTANTE:
		EN CADA ACTIVIDAD CON MC IGUALES, SE TIENEN QUE DUPLICAR
		NO BASTA CON CAMBIARLES LA INSTANCIA, A NIVEL CÓDIGO NO HAY DIFERENCIA
		ADEMAS DE QUE TIENEN QUE TENER INSTANCIAS DIFERENTES A LAS ANTERIORES
		*/
		this.stop();
		var root = this;
		var resp = 2;
		var correcta = 1;
		root.p9.text=("¿Qué debemos hacer en los casos donde no se cuente con evaluación del desempeño?");
		root.c9_op0.text=("Solicitar ayuda al área de Planeación.");
		root.c9_op1.text=("Realizar la evaluación usando la plataforma SuccessFactors en la sección correspondiente (sólo si el colaborador tiene más de 6 meses en la posición).");
		root.c9_op2.text=("No hacer nada.");
		iniciar();
		
		function iniciar() {
			root.parent.parent.btn_siguiente.visible = false;
			for (var i = 0; i <= resp; i++) {
				root['c9_' + i].cursor = "pointer";
				root['c9_' + i].n = i;
				root['c9_' + i].addEventListener("click", cambios);
				root['c9_' + i].gotoAndStop(1);
			}
		}
		
		function cambios(r) {
			//Cambia el estatus de la opcion seleccionada
			for (var i = 0; i <= resp; i++) {
				if (root['c9_' + i].n != r.currentTarget.n) {
					root['c9_' + i].gotoAndStop(0);
				} else {
					root['c9_' + i].gotoAndStop(1);
				}
			}
		
			//Valida la respuesta
			if (r.currentTarget.n == correcta) {
				root.parent.parent.resultados[root.parent.parent.cont] = 10;
				console.log("Respuesta Correcta " + root.parent.parent.resultados[root.parent.parent.cont]);
			} else {
				root.parent.parent.resultados[root.parent.parent.cont] = 0;
				console.log("Respuesta Incorrecta " + root.parent.parent.resultados[root.parent.parent.cont]);
			}
			root.parent.parent.activarSiguiente();
			root.parent.parent.registrar_pregunta(root.p9.text, root['c9_op'+r.currentTarget.n].text, root['c9_op'+correcta].text);
		
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#EBF4CE").s().p("A/PUfMAAAgo9MA+fAAAMAAAAo9gA8ttHIAAbvQAACgCgAAMA0oAAAQChAAAAigIAA7vQAAigihAAMg0oAAAQigAAAACgg");
	this.shape.setTransform(232.4,261.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#A9B1BA").s().p("Ag8ANIBig3IAXAqQgDARgfAPQgQAHgPAEg");
	this.shape_1.setTransform(381.1,235.5,0.472,0.472);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#A9B1BA").s().p("AgVAgQgmgWgCgQIAVgrIBmBFIgvAeQgRgHgTgLg");
	this.shape_2.setTransform(375.3,235.2,0.472,0.472);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#3F3231").s().p("ACqCUIAAhIQAAgTgSgtQgVgzgVgGQgRgGgkATQgnAVgPAAIgFAAQgPAAgngVQgkgTgRAGQgVAGgUAzQgSAtAAATIgBBIQgCAEgGgMQgDgGgHgDQgKhwAchDQArhqB+AHIABAAQB+gHArBqQAbBDgIBwQgIADgDAGQgFAJgCAAIgBgBg");
	this.shape_3.setTransform(377.6,214.7,0.472,0.472);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#231F20").s().p("AA2ABQgSgRgWAIQgPAFgSADQglAGgKgLIAJgEQAQgEAdgFIAkgBQAnAGAEAhQgEgLgJgIg");
	this.shape_4.setTransform(381.6,218.7,0.472,0.472);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#231F20").s().p("AgXgSQATgDARADQAvAIAHAFQgKALgkgGIgigIQgWgIgSARQgJAJgEAKQAEggAngGg");
	this.shape_5.setTransform(373.5,218.7,0.472,0.472);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#957667").s().p("AgbgGIANgEIANgCQAOACAKAEQAMAFAJAJQgOgHgIgBIgYgFIgFAAIgGABIgMADQgLAFgIAJQAEgMANgHg");
	this.shape_6.setTransform(381.7,219.7,0.472,0.472);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#957667").s().p("AAZgBIgLgDIgGgBIgGAAIgWAFQgJAAgPAIQAKgJAMgFQAKgEAOgCIAOACQAHABAEADQAOAGADANQgHgJgMgFg");
	this.shape_7.setTransform(373.6,219.7,0.472,0.472);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#AB9083").s().p("AgdAKIACgDQAGAFAIgFQACgFAGgBQAEgBABABQATACAGgHQADgDgCgFIAEgBQACAHgEAEQgGAIgWgCIAAAAQgBAAAAAAQAAAAgBAAQAAAAgBAAQgBAAAAAAQgEABgCAEIgBABQgEADgFAAQgFAAgEgDg");
	this.shape_8.setTransform(378.7,224.9,0.472,0.472);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#AB9083").s().p("AAMAKIgBAAIAAgBQgCgEgEgBIgEAAIAAAAQgVACgHgIQgCgDAAgEQAAgBAAgBQAAAAAAgBQAAAAAAAAQAAgBABAAIADABIgBADQAAADACACQAFAHATgCIAGAAQAGABACAFQAIAFAGgFIACADQgEADgEAAQgGAAgEgDg");
	this.shape_9.setTransform(376.8,224.9,0.472,0.472);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#997B6D").s().p("AgyAAIgPgNIBBADIBCgDQgFAHgKAGQgVAOgeAAQgdAAgVgOg");
	this.shape_10.setTransform(377.8,227.8,0.472,0.472);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#957667").s().p("AhBACIAtgIIAFADQAHADAIAAQAQAAAFgGIAtAIQgVAEgYABIgVAAIgPAAQgZAAgZgFg");
	this.shape_11.setTransform(377.8,227.1,0.472,0.472);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#957667").s().p("AgIAUQgbgHgKgIIgBgBIABgBIAJgLQAOgMAUAAIAQADQASAFANAKIACABIgBABQgTAVgcAAgAgpADQAKAIAYAFQAaADAXgUQgNgIgRgEIgOgDQgcAAgLATg");
	this.shape_12.setTransform(381.7,220.1,0.472,0.472);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#3F3231").s().p("AgMANQgFgFgBgIQABgGAFgGQAGgGAGABQAHgBAGAGQAGAGgBAGQABAIgGAFQgGAFgHABQgGgBgGgFg");
	this.shape_13.setTransform(381.7,220.1,0.472,0.472);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgcANIgQgIQAFgOAUgGQAJgCAIAAQARgEAdAUQgDAEgIAFQgPAKgUAAIgDABQgJAAgOgGg");
	this.shape_14.setTransform(381.7,220.1,0.472,0.472);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#957667").s().p("AACAUQgRAAgQgKIgNgKIgCgBIACgBQAWgQAZgBQAVAAANALQAHAGADAFIAAABIgBABQgKAIgbAHgAgpAAQAIAGAKAFQAPAIARgCQAYgGAJgIQgKgTgdAAQgXACgVAOg");
	this.shape_15.setTransform(373.6,220.1,0.472,0.472);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#3F3231").s().p("AgMANQgFgFgBgIQABgGAFgGQAFgGAHABQAHgBAGAGQAGAGgBAGQABAIgGAFQgGAFgHABQgHgBgFgFg");
	this.shape_16.setTransform(373.6,220.1,0.472,0.472);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AADASQgUAAgPgKIgMgJIARgKQAUgIAKACIASACQASAGAFAOQgZAOgNAAIgDgBg");
	this.shape_17.setTransform(373.6,220.1,0.472,0.472);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#815F4F").s().p("AgfD0QgWgJgcgTQg3gngfg1IgCgGIgBgjIgCAAQgKAAgEgIIAAgBIAAAAQgEgHgEgZIgHgqQgDgRAAgKQAAgNAEgCQAEgBAHAGQAEACABAFIADgBQgGgdAAghQAAhKAngTIAAAAIApgfQAygfAwAAIAFAAIAAAAIAFAAIAAAAQAxgCA1AfQAaAQAQARIABAAQAnATAABKQAAAhgGAdIgCAHIAFgFQADgEAGgEQAGgFAEACIAAAAQAIAEgGAgIgHAtQgFAdgDAEIgBABQgFAHgJABIgCAAIgEAqQAAACgCAEQgRAXgXAZQgpApgsAXIgDABQgTAFgSAAQgQAAgPgFg");
	this.shape_18.setTransform(377.7,221,0.472,0.472);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#957667").s().p("AgPBOQh9gDAighQAdgdAIgoIACgjIBAgNQBAgJABAWQABAZAaA6IAaA2Qg2AEgxAAIgbgBg");
	this.shape_19.setTransform(378.1,232,0.472,0.472);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#BBCACB").s().p("AgFEUQgSgMgQgqQgUiTgYh6QgPhQAFg2QAGg8AfgKQAEgBAZgTQAUgPAHAIQANAPAPAqQAPAnALAvQAIA5AOCEIATDBQACAYgTAEQgbADgSADIgOABQgPAAgJgGg");
	this.shape_20.setTransform(393,251.1,0.472,0.472);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#BBCACB").s().p("AjeBvQgwgEgKgaQgNguAdgrQAfgtA4gHIDlgcQCygVAhgCQARA2ADAbQAHAygXAIQgJADiMAXQiQAZgtAMQhQAVg0AAIgTgBg");
	this.shape_21.setTransform(373.3,260.3,0.472,0.472);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f().s("#BBCACB").p("AAHhBQgHACgWgDQgOgCgMANQgPAQAGAmQAGAjASASQAjAlAlgxQAOgTAFgUQAFgVgJgHg");
	this.shape_22.setTransform(385.5,258.5,0.472,0.472);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AghA0QgSgSgGgjQgGgmAPgQQAMgNAOACQAWADAHgCIAvAmQAJAHgFAVQgFAUgOATQgVAcgUAAQgQAAgPgQg");
	this.shape_23.setTransform(385.5,258.5,0.472,0.472);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#957667").s().p("AhKA9QgNgjgCgPQgBgJAIgcIAJgaIBPgSQAxgFAWAjQALARABATQAJAog3AWIg3AOg");
	this.shape_24.setTransform(388.8,257.9,0.472,0.472);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#957667").s().p("AgZBFIgQgHQgQgPgGgkQgFgiAJgQQAIgNAZgLQAWgKAIABQAFABAXAAQAUABgGAIQgBADgLAHIgLAHQgCAFAGACQAHACANgFQARgGgBAEIgFAMQABAGgSAGQgSAGAAADQAAACAVABQAVABAAAGQAAAHgYAHIgYAJIAZACQAYACgFAIQgGAKgRALQgQAMgQAEIgIABQgKAAgNgEg");
	this.shape_25.setTransform(387.6,257.7,0.472,0.472);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#957667").s().p("AgqA6Qg3gWAJgoQABgTALgRQAWgjAxAFIBPASIAJAaQAIAcgBAJQgDAPgMAjIg+ALQgcgDgbgLg");
	this.shape_26.setTransform(368.4,257.9,0.472,0.472);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#957667").s().p("AgNAIIADglQAVgQADAnQABASgDAXg");
	this.shape_27.setTransform(371.6,254.5,0.472,0.472);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#957667").s().p("AgFBIQgQgEgQgMQgRgLgGgKQgFgIAYgCIAZgCIgYgJQgYgHAAgHQAAgGAVgBQAVgBAAgCQAAgDgSgGQgSgGABgGIgFgMQgBgEARAGQANAFAHgCQAGgCgCgFIgLgHQgLgHgBgDQgGgIAUgBIAbgBQAJgBAWAKQAZALAIANQAJAQgFAiQgGAkgQAPQgUALgRAAIgKgBg");
	this.shape_28.setTransform(369.6,257.7,0.472,0.472);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f().s("#BBCACB").p("AgIhEQAIACAWgCQAPgCANAOQAQASgFAmQgFAlgRASQglAkgng0QgQgUgGgUQgGgWAJgIg");
	this.shape_29.setTransform(371.4,258.3,0.472,0.472);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FFFFFF").s().p("AglAnQgQgUgGgUQgGgWAJgIIAwglQAIACAWgCQAPgCANAOQAQASgFAmQgFAlgRASQgPAPgQAAQgVAAgYgfg");
	this.shape_30.setTransform(371.4,258.3,0.472,0.472);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#AFBCBC").s().p("ABIBbQgtgMiQgZQiMgXgJgDQgXgIAHgyQADgZAQg4QAiACCxAVIDlAcQA5AHAfAtQAdArgOAuQgJAagwAEIgTABQgzAAhRgVg");
	this.shape_31.setTransform(383.8,260.3,0.472,0.472);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#BBCACB").s().p("AggEZQgigDgLgDQgTgEACgYIATjBQAOiEAIg5QALgvAPgnQAPgqANgPQAHgIAUAPQAZATAEABQAfAKAGA8QAFA2gPBQQgYB6gUCTQgQAqgSAMQgJAGgPAAIgOgBg");
	this.shape_32.setTransform(364.2,251.1,0.472,0.472);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#747888").s().p("AAAAAIAAAAIABABIgBAAg");
	this.shape_33.setTransform(380.6,268.6,0.472,0.472);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#747888").s().p("AAAAAIAAAAIABABIgBAAg");
	this.shape_34.setTransform(379,271.4,0.472,0.472);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#747888").s().p("AgIgOIAQAZIgBAAIACACIgCACg");
	this.shape_35.setTransform(378.6,270.9,0.472,0.472);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#747888").s().p("AAAAAIAAAAIABABIAAAAg");
	this.shape_36.setTransform(377.4,268.6,0.472,0.472);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#747888").s().p("AgNAZIAAAAIgBgCIAdgxIgcA1g");
	this.shape_37.setTransform(378.1,267.5,0.472,0.472);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#747888").s().p("AgKgSIAUAfIAAABIABACIgCADg");
	this.shape_38.setTransform(380.1,267.9,0.472,0.472);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#747888").s().p("AgfABIAfg3IAAAAIAAAAIAMATIAUAlIggA2g");
	this.shape_39.setTransform(379,268.7,0.472,0.472);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#747888").s().p("AAAAAIAAgBIABABIgBACg");
	this.shape_40.setTransform(378.9,260.7,0.472,0.472);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#747888").s().p("AAAABIAAgBIABAAIgBABg");
	this.shape_41.setTransform(379,260.7,0.472,0.472);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#747888").s().p("AgIgPIAQAZIgBAAIACADIgCADg");
	this.shape_42.setTransform(378.6,265.4,0.472,0.472);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#747888").s().p("AgOAZIAAgBIgBgCIAegxIABABIgdA2g");
	this.shape_43.setTransform(378.2,262,0.472,0.472);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#747888").s().p("AgKAUIABgBIgCgCIAXgkIgWAng");
	this.shape_44.setTransform(379.5,265,0.472,0.472);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#747888").s().p("AgOgaIAcAuIAAAAIABACIgCAGg");
	this.shape_45.setTransform(379.8,262.1,0.472,0.472);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#747888").s().p("AgeACIAeg2IAAABIABgDIACAEIAcA2IgfAyg");
	this.shape_46.setTransform(379,263.3,0.472,0.472);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#747888").s().p("AAAAAIAAAAIABAAIgBABg");
	this.shape_47.setTransform(379,255.3,0.472,0.472);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#747888").s().p("AAAAAIAAAAIABABIgBAAg");
	this.shape_48.setTransform(380.6,257.8,0.472,0.472);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#747888").s().p("AAAAAIAAAAIABABIgBAAg");
	this.shape_49.setTransform(379,260.6,0.472,0.472);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#747888").s().p("AgIgOIAQAZIgBABIACACIgBAAIgBgBIgBACg");
	this.shape_50.setTransform(378.6,260,0.472,0.472);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#747888").s().p("AAAAAIAAAAIABABIAAAAg");
	this.shape_51.setTransform(377.4,257.8,0.472,0.472);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#747888").s().p("AgOAaIAAgBIgBgBIAfgzIAAAAIgdA3g");
	this.shape_52.setTransform(378.2,256.6,0.472,0.472);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#747888").s().p("AgMgVIAXAlIAAAAIABACIgCAEg");
	this.shape_53.setTransform(380,257,0.472,0.472);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#747888").s().p("AgeABIAeg3IAAABIAAgBIAfA5IgfA0g");
	this.shape_54.setTransform(379,257.9,0.472,0.472);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#747888").s().p("AgIgOIAQAYIgBABIACACIgBACIgBAAIAAAAg");
	this.shape_55.setTransform(378.6,254.6,0.472,0.472);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#747888").s().p("AgNAZIAAgBIgBgCIAdgwIgcA1g");
	this.shape_56.setTransform(378.1,251.2,0.472,0.472);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#747888").s().p("AgKAUIABgBIgCgCIAXgkIgWAng");
	this.shape_57.setTransform(379.5,254.3,0.472,0.472);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#747888").s().p("AgKgSIAUAfIAAAAIABADIgCADg");
	this.shape_58.setTransform(380.1,251.7,0.472,0.472);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#747888").s().p("AgfABIAfg3IAAAAIAMATIAUAmIggA0g");
	this.shape_59.setTransform(379,252.5,0.472,0.472);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#747888").s().p("AAAAAIAAgBIABABIgBACg");
	this.shape_60.setTransform(378.9,244.4,0.472,0.472);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#747888").s().p("AAAABIAAgBIABAAIgBABg");
	this.shape_61.setTransform(379,244.5,0.472,0.472);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#747888").s().p("AAAAAIAAAAIABABIgBAAg");
	this.shape_62.setTransform(379,249.7,0.472,0.472);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#747888").s().p("AgIgPIAQAZIgBABIACACIgCADg");
	this.shape_63.setTransform(378.6,249.1,0.472,0.472);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#747888").s().p("AAAAAIAAAAIABABIAAAAg");
	this.shape_64.setTransform(377.4,246.9,0.472,0.472);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#747888").s().p("AgOAZIAAgBIgBgCIAegxIABACIgdA1g");
	this.shape_65.setTransform(378.2,245.8,0.472,0.472);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#747888").s().p("AgOgbIAcAvIAAAAIABACIgCAGg");
	this.shape_66.setTransform(379.8,245.9,0.472,0.472);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#747888").s().p("AgeABIAeg1IAAAAIABgCIACADIAcA3IgfAyg");
	this.shape_67.setTransform(379,247,0.472,0.472);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#747888").s().p("AAAAAIAAAAIABABIgBAAg");
	this.shape_68.setTransform(379,244.3,0.472,0.472);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#747888").s().p("AAHANIgBACIgOgdIAQAZIgBAAIACADIgBABg");
	this.shape_69.setTransform(378.6,243.7,0.472,0.472);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#747888").s().p("AAAAAIAAgBIABABIAAABg");
	this.shape_70.setTransform(377.4,241.6,0.472,0.472);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#747888").s().p("AgNAZIAAgBIgBgCIAdgvIgcA0g");
	this.shape_71.setTransform(378.1,240.4,0.472,0.472);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#747888").s().p("AgKAUIABgBIgCgCIAXglIgWApg");
	this.shape_72.setTransform(379.5,243.5,0.472,0.472);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#747888").s().p("AgKgSIAUAfIAAAAIABADIgCADg");
	this.shape_73.setTransform(380.1,240.9,0.472,0.472);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#747888").s().p("AgfAAIAfg2IAAAAIAMATIAUAmIggA0g");
	this.shape_74.setTransform(379,241.7,0.472,0.472);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#747888").s().p("AgIgOIAQAZIgBAAIACACIgCACg");
	this.shape_75.setTransform(378.6,238.3,0.472,0.472);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#747888").s().p("AAAAAIAAAAIABABIAAAAg");
	this.shape_76.setTransform(377.4,236.1,0.472,0.472);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#747888").s().p("AgFALIAAgBIgBgCIALgTIACAAIgMAXg");
	this.shape_77.setTransform(377.8,235.6,0.472,0.472);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#747888").s().p("AgHgNIABAAIANAVIABACIgCAEg");
	this.shape_78.setTransform(380.2,235.6,0.472,0.472);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#747888").s().p("AgfgMIAOgZIAOgBIAAgDIAUADIAPAcIggA0g");
	this.shape_79.setTransform(379,236.8,0.472,0.472);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#747888").s().p("AAAAAIAAAAIABABIgBAAg");
	this.shape_80.setTransform(383.7,268.6,0.472,0.472);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#747888").s().p("AgIgOIAQAZIAAAAIABACIgCACg");
	this.shape_81.setTransform(381.7,270.9,0.472,0.472);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#747888").s().p("AgOAZIABAAIgCgCIAegxIgcA1g");
	this.shape_82.setTransform(381.3,267.5,0.472,0.472);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#747888").s().p("AgKgSIAUAfIAAABIABACIgCADg");
	this.shape_83.setTransform(383.2,267.9,0.472,0.472);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#747888").s().p("AgfABIAfg3IAAAAIAAAAIAMATIAUAlIggA2g");
	this.shape_84.setTransform(382.1,268.7,0.472,0.472);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#747888").s().p("AAAAAIABgBIAAABIgBACg");
	this.shape_85.setTransform(382.1,260.7,0.472,0.472);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#747888").s().p("AAAABIAAgBIABAAIgBABg");
	this.shape_86.setTransform(382.1,260.7,0.472,0.472);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#747888").s().p("AgIgPIAQAZIAAAAIABADIgCADg");
	this.shape_87.setTransform(381.7,265.4,0.472,0.472);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#747888").s().p("AgOAZIAAgBIgBgCIAegxIABABIgdA2g");
	this.shape_88.setTransform(381.3,262,0.472,0.472);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#747888").s().p("AgKAUIABgBIgCgCIAXgkIgWAng");
	this.shape_89.setTransform(382.6,265,0.472,0.472);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#747888").s().p("AgOgaIAcAuIAAAAIABACIgDAGg");
	this.shape_90.setTransform(383,262.1,0.472,0.472);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#747888").s().p("AgeACIAeg2IAAABIABgDIACAEIAcA2IgfAyg");
	this.shape_91.setTransform(382.1,263.3,0.472,0.472);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#747888").s().p("AAAAAIAAAAIAAAAIAAABg");
	this.shape_92.setTransform(382.1,255.3,0.472,0.472);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#747888").s().p("AAAAAIAAAAIABABIgBAAg");
	this.shape_93.setTransform(383.7,257.8,0.472,0.472);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#747888").s().p("AAAAAIAAAAIABABIgBAAg");
	this.shape_94.setTransform(382.1,260.6,0.472,0.472);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#747888").s().p("AgIgOIAQAZIAAABIABACIgBAAIAAgBIgCACg");
	this.shape_95.setTransform(381.7,260,0.472,0.472);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#747888").s().p("AgOAaIAAgBIgBgBIAfgzIAAAAIgdA3g");
	this.shape_96.setTransform(381.3,256.6,0.472,0.472);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#747888").s().p("AgLgVIAWAlIAAAAIABACIgCAEg");
	this.shape_97.setTransform(383.1,257,0.472,0.472);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#747888").s().p("AgfABIAfg3IAAABIAAgBIAfA5IgfA0g");
	this.shape_98.setTransform(382.1,257.9,0.472,0.472);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#747888").s().p("AgIgOIAQAYIAAABIABACIgBACIgBAAg");
	this.shape_99.setTransform(381.7,254.6,0.472,0.472);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#747888").s().p("AgOAZIABgBIgCgCIAegwIgcA1g");
	this.shape_100.setTransform(381.3,251.2,0.472,0.472);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#747888").s().p("AgKAUIABgBIgCgCIAXgkIgWAng");
	this.shape_101.setTransform(382.6,254.3,0.472,0.472);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("#747888").s().p("AgKgSIAUAfIAAAAIABADIgCADg");
	this.shape_102.setTransform(383.2,251.7,0.472,0.472);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("#747888").s().p("AgfABIAfg3IAAAAIAMATIAUAmIggA0g");
	this.shape_103.setTransform(382.1,252.5,0.472,0.472);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f("#747888").s().p("AAAAAIABgBIAAABIgBACg");
	this.shape_104.setTransform(382.1,244.4,0.472,0.472);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f("#747888").s().p("AgIgPIAQAZIAAABIABACIgCADg");
	this.shape_105.setTransform(381.7,249.1,0.472,0.472);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f("#747888").s().p("AgOAZIAAgBIgBgCIAegxIABACIgdA1g");
	this.shape_106.setTransform(381.3,245.8,0.472,0.472);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f("#747888").s().p("AgOgbIAcAvIAAAAIABACIgDAGg");
	this.shape_107.setTransform(383,245.9,0.472,0.472);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f("#747888").s().p("AgeABIAeg1IAAAAIABgCIACADIAcA3IgfAyg");
	this.shape_108.setTransform(382.1,247,0.472,0.472);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f("#747888").s().p("AAIANIgCACIgOgdIAQAZIAAAAIABADIgBABg");
	this.shape_109.setTransform(381.7,243.7,0.472,0.472);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f("#747888").s().p("AgOAZIABgBIgCgCIAegvIgcA0g");
	this.shape_110.setTransform(381.3,240.4,0.472,0.472);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f("#747888").s().p("AgKAUIABgBIgCgCIAXglIgWApg");
	this.shape_111.setTransform(382.6,243.5,0.472,0.472);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.f("#747888").s().p("AgKgSIAUAfIAAAAIABADIgCADg");
	this.shape_112.setTransform(383.2,240.9,0.472,0.472);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.f("#747888").s().p("AgfAAIAfg2IAAAAIAMATIAUAmIggA0g");
	this.shape_113.setTransform(382.1,241.7,0.472,0.472);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.f("#747888").s().p("AgIgOIAQAZIABACIgCACg");
	this.shape_114.setTransform(381.7,238.3,0.472,0.472);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.f("#747888").s().p("AgFAKIABgBIgCgCIALgRIACAAIgLAVg");
	this.shape_115.setTransform(380.8,235.7,0.472,0.472);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.f("#747888").s().p("AgFgIIAEABIAFAKIABACIgCAEg");
	this.shape_116.setTransform(383.4,235.9,0.472,0.472);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.f("#747888").s().p("AgfgPIAMgXIAqAHIAJASIggA0g");
	this.shape_117.setTransform(382.1,237,0.472,0.472);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.f("#747888").s().p("AAAAAIAAAAIABABIgBAAg");
	this.shape_118.setTransform(386.8,268.6,0.472,0.472);

	this.shape_119 = new cjs.Shape();
	this.shape_119.graphics.f("#747888").s().p("AgKAUIABgBIgCgCIAXgkIgVAng");
	this.shape_119.setTransform(385.8,270.5,0.472,0.472);

	this.shape_120 = new cjs.Shape();
	this.shape_120.graphics.f("#747888").s().p("AgKgSIAUAfIAAABIABACIgCADg");
	this.shape_120.setTransform(386.3,267.9,0.472,0.472);

	this.shape_121 = new cjs.Shape();
	this.shape_121.graphics.f("#747888").s().p("AgIgOIAQAZIAAAAIABACIgCACg");
	this.shape_121.setTransform(384.8,270.9,0.472,0.472);

	this.shape_122 = new cjs.Shape();
	this.shape_122.graphics.f("#747888").s().p("AgOAZIABAAIgCgCIAfgxIgdA1g");
	this.shape_122.setTransform(384.4,267.5,0.472,0.472);

	this.shape_123 = new cjs.Shape();
	this.shape_123.graphics.f("#747888").s().p("AAAABIAAgBIABAAIgBABg");
	this.shape_123.setTransform(385.2,271.5,0.472,0.472);

	this.shape_124 = new cjs.Shape();
	this.shape_124.graphics.f("#747888").s().p("AgfABIAfg3IAAAAIAAAAIAMATIAUAlIggA2g");
	this.shape_124.setTransform(385.2,268.7,0.472,0.472);

	this.shape_125 = new cjs.Shape();
	this.shape_125.graphics.f("#747888").s().p("AAAAAIAAgBIABABIgBACg");
	this.shape_125.setTransform(385.2,260.7,0.472,0.472);

	this.shape_126 = new cjs.Shape();
	this.shape_126.graphics.f("#747888").s().p("AgKAUIABgBIgCgCIAXgkIgVAng");
	this.shape_126.setTransform(385.8,265,0.472,0.472);

	this.shape_127 = new cjs.Shape();
	this.shape_127.graphics.f("#747888").s().p("AgPgaIAeAuIAAAAIABACIgEAGg");
	this.shape_127.setTransform(386.1,262.1,0.472,0.472);

	this.shape_128 = new cjs.Shape();
	this.shape_128.graphics.f("#747888").s().p("AgIgPIAQAZIAAAAIABADIgCADg");
	this.shape_128.setTransform(384.8,265.4,0.472,0.472);

	this.shape_129 = new cjs.Shape();
	this.shape_129.graphics.f("#747888").s().p("AgOAZIAAgBIgBgCIAegxIABABIgdA2g");
	this.shape_129.setTransform(384.4,262,0.472,0.472);

	this.shape_130 = new cjs.Shape();
	this.shape_130.graphics.f("#747888").s().p("AgeACIAeg2IAAABIABgDIACAEIAcA2IgfAyg");
	this.shape_130.setTransform(385.2,263.3,0.472,0.472);

	this.shape_131 = new cjs.Shape();
	this.shape_131.graphics.f("#747888").s().p("AAAAAIAAAAIABABIgBAAg");
	this.shape_131.setTransform(385.2,260.6,0.472,0.472);

	this.shape_132 = new cjs.Shape();
	this.shape_132.graphics.f("#747888").s().p("AgKAUIABgBIgCgCIAXgkIgVAng");
	this.shape_132.setTransform(385.8,259.7,0.472,0.472);

	this.shape_133 = new cjs.Shape();
	this.shape_133.graphics.f("#747888").s().p("AgLgVIAWAlIAAAAIABACIgCAEg");
	this.shape_133.setTransform(386.2,257,0.472,0.472);

	this.shape_134 = new cjs.Shape();
	this.shape_134.graphics.f("#747888").s().p("AgIgOIAQAZIAAABIABACIAAAAIgBgBIgCACg");
	this.shape_134.setTransform(384.8,260,0.472,0.472);

	this.shape_135 = new cjs.Shape();
	this.shape_135.graphics.f("#747888").s().p("AgOAaIAAgBIgBgBIAfgzIAAAAIgdA3g");
	this.shape_135.setTransform(384.4,256.6,0.472,0.472);

	this.shape_136 = new cjs.Shape();
	this.shape_136.graphics.f("#747888").s().p("AgeABIAeg3IAAABIAAgBIAJAOIAXArIggA0g");
	this.shape_136.setTransform(385.2,257.9,0.472,0.472);

	this.shape_137 = new cjs.Shape();
	this.shape_137.graphics.f("#747888").s().p("AgKAUIABgBIgCgCIAXgkIgVAng");
	this.shape_137.setTransform(385.8,254.3,0.472,0.472);

	this.shape_138 = new cjs.Shape();
	this.shape_138.graphics.f("#747888").s().p("AgKgSIAUAfIAAAAIABADIgCADg");
	this.shape_138.setTransform(386.3,251.7,0.472,0.472);

	this.shape_139 = new cjs.Shape();
	this.shape_139.graphics.f("#747888").s().p("AgIgOIAQAYIAAABIABACIgBACIgBAAg");
	this.shape_139.setTransform(384.8,254.6,0.472,0.472);

	this.shape_140 = new cjs.Shape();
	this.shape_140.graphics.f("#747888").s().p("AgOAZIABgBIgCgCIAfgwIgdA1g");
	this.shape_140.setTransform(384.4,251.2,0.472,0.472);

	this.shape_141 = new cjs.Shape();
	this.shape_141.graphics.f("#747888").s().p("AgfABIAfg3IAAAAIAMATIAUAmIggA0g");
	this.shape_141.setTransform(385.2,252.5,0.472,0.472);

	this.shape_142 = new cjs.Shape();
	this.shape_142.graphics.f("#747888").s().p("AAAAAIAAAAIABAAIgBABg");
	this.shape_142.setTransform(385.2,255.3,0.472,0.472);

	this.shape_143 = new cjs.Shape();
	this.shape_143.graphics.f("#747888").s().p("AAAAAIAAgBIABABIgBACg");
	this.shape_143.setTransform(385.2,244.4,0.472,0.472);

	this.shape_144 = new cjs.Shape();
	this.shape_144.graphics.f("#747888").s().p("AgKAUIABgBIgCgCIAXgkIgVAng");
	this.shape_144.setTransform(385.8,248.8,0.472,0.472);

	this.shape_145 = new cjs.Shape();
	this.shape_145.graphics.f("#747888").s().p("AgPgbIAeAvIAAAAIABACIgEAGg");
	this.shape_145.setTransform(386.1,245.9,0.472,0.472);

	this.shape_146 = new cjs.Shape();
	this.shape_146.graphics.f("#747888").s().p("AgIgPIAQAZIAAABIABACIgCADg");
	this.shape_146.setTransform(384.8,249.1,0.472,0.472);

	this.shape_147 = new cjs.Shape();
	this.shape_147.graphics.f("#747888").s().p("AgOAZIAAgBIgBgCIAegxIABACIgdA1g");
	this.shape_147.setTransform(384.4,245.8,0.472,0.472);

	this.shape_148 = new cjs.Shape();
	this.shape_148.graphics.f("#747888").s().p("AAAABIAAAAIAAAAIAAgCIABABIgBABg");
	this.shape_148.setTransform(385.2,249.8,0.472,0.472);

	this.shape_149 = new cjs.Shape();
	this.shape_149.graphics.f("#747888").s().p("AgeABIAeg1IAAAAIABgCIACADIAcA3IgfAyg");
	this.shape_149.setTransform(385.2,247,0.472,0.472);

	this.shape_150 = new cjs.Shape();
	this.shape_150.graphics.f("#747888").s().p("AgKAUIABgBIgCgCIAXglIgVApg");
	this.shape_150.setTransform(385.8,243.5,0.472,0.472);

	this.shape_151 = new cjs.Shape();
	this.shape_151.graphics.f("#747888").s().p("AgKgSIAUAfIAAAAIABADIgCADg");
	this.shape_151.setTransform(386.3,240.9,0.472,0.472);

	this.shape_152 = new cjs.Shape();
	this.shape_152.graphics.f("#747888").s().p("AAIANIgCACIgOgdIAQAZIAAAAIABADIAAABg");
	this.shape_152.setTransform(384.8,243.7,0.472,0.472);

	this.shape_153 = new cjs.Shape();
	this.shape_153.graphics.f("#747888").s().p("AgOAZIABgBIgCgCIAfgvIgdA0g");
	this.shape_153.setTransform(384.4,240.4,0.472,0.472);

	this.shape_154 = new cjs.Shape();
	this.shape_154.graphics.f("#747888").s().p("AgfAAIAfg2IAAAAIAMATIAUAmIggA0g");
	this.shape_154.setTransform(385.2,241.7,0.472,0.472);

	this.shape_155 = new cjs.Shape();
	this.shape_155.graphics.f("#747888").s().p("AgKAUIABgBIgCgCIAXgkIgVAng");
	this.shape_155.setTransform(385.8,238,0.472,0.472);

	this.shape_156 = new cjs.Shape();
	this.shape_156.graphics.f("#747888").s().p("AgBgBIADABIgCACg");
	this.shape_156.setTransform(386.7,236.2,0.472,0.472);

	this.shape_157 = new cjs.Shape();
	this.shape_157.graphics.f("#747888").s().p("AgIgOIAQAZIABACIgCACg");
	this.shape_157.setTransform(384.8,238.3,0.472,0.472);

	this.shape_158 = new cjs.Shape();
	this.shape_158.graphics.f("#747888").s().p("AgCAFIAAgBIgBgCIAEgHIADAAIgGALg");
	this.shape_158.setTransform(383.8,235.9,0.472,0.472);

	this.shape_159 = new cjs.Shape();
	this.shape_159.graphics.f("#747888").s().p("AgfgUIAHgNIA2ALIACAEIggA0g");
	this.shape_159.setTransform(385.2,237.2,0.472,0.472);

	this.shape_160 = new cjs.Shape();
	this.shape_160.graphics.f("#747888").s().p("AAAABIAAABIAAgBIAAgBIABAAIgBACg");
	this.shape_160.setTransform(385.2,239,0.472,0.472);

	this.shape_161 = new cjs.Shape();
	this.shape_161.graphics.f("#747888").s().p("AgHgOIAOAZIAAAAIABACIgBACg");
	this.shape_161.setTransform(388,270.9,0.472,0.472);

	this.shape_162 = new cjs.Shape();
	this.shape_162.graphics.f("#747888").s().p("AgNAZIAAAAIgBgCIAdgxIgbA1g");
	this.shape_162.setTransform(387.5,267.5,0.472,0.472);

	this.shape_163 = new cjs.Shape();
	this.shape_163.graphics.f("#747888").s().p("AgIAQIABgBIgCgBIASgdIAAAAIgQAfg");
	this.shape_163.setTransform(388.8,270.7,0.472,0.472);

	this.shape_164 = new cjs.Shape();
	this.shape_164.graphics.f("#747888").s().p("AAAABIAAgBIABAAIgBABg");
	this.shape_164.setTransform(388.3,271.5,0.472,0.472);

	this.shape_165 = new cjs.Shape();
	this.shape_165.graphics.f("#747888").s().p("AgYABIAcg1IACgCIAMASQAFAiACAcIgTAeg");
	this.shape_165.setTransform(388,268.7,0.472,0.472);

	this.shape_166 = new cjs.Shape();
	this.shape_166.graphics.f("#747888").s().p("AgHgPIAOAZIAAAAIABADIgBADg");
	this.shape_166.setTransform(388,265.4,0.472,0.472);

	this.shape_167 = new cjs.Shape();
	this.shape_167.graphics.f("#747888").s().p("AgNAXIAAgBIgBgCIAcgtIABADIgbAwg");
	this.shape_167.setTransform(387.5,262.1,0.472,0.472);

	this.shape_168 = new cjs.Shape();
	this.shape_168.graphics.f("#747888").s().p("AgCAHIABgBIgCgDIAGgJIABADIgFAKg");
	this.shape_168.setTransform(388.5,265.7,0.472,0.472);

	this.shape_169 = new cjs.Shape();
	this.shape_169.graphics.f("#747888").s().p("AgSgBIAbgxQAEAVABAdQAAAJAFAgIgHAKg");
	this.shape_169.setTransform(387.8,263.4,0.472,0.472);

	this.shape_170 = new cjs.Shape();
	this.shape_170.graphics.f("#747888").s().p("AAAAAIAAAAIABAAIgBABg");
	this.shape_170.setTransform(388.3,255.3,0.472,0.472);

	this.shape_171 = new cjs.Shape();
	this.shape_171.graphics.f("#747888").s().p("AgOAaIAAgBIgBgBIAfgzIAAAAIgdA3g");
	this.shape_171.setTransform(387.5,256.6,0.472,0.472);

	this.shape_172 = new cjs.Shape();
	this.shape_172.graphics.f("#747888").s().p("AgSARIAeg3IAAABIABgBIAGAKIgZBDg");
	this.shape_172.setTransform(387.7,257.2,0.472,0.472);

	this.shape_173 = new cjs.Shape();
	this.shape_173.graphics.f("#957667").s().p("AgHgOIAOAYIAAABIABACIgBACIAAAAg");
	this.shape_173.setTransform(388,254.6,0.472,0.472);

	this.shape_174 = new cjs.Shape();
	this.shape_174.graphics.f("#747888").s().p("AgNAZIAAgBIgBgCIAdgwIgbA1g");
	this.shape_174.setTransform(387.5,251.2,0.472,0.472);

	this.shape_175 = new cjs.Shape();
	this.shape_175.graphics.f("#747888").s().p("AgKAUIABgBIgCgCIAXgkIgVAng");
	this.shape_175.setTransform(388.9,254.3,0.472,0.472);

	this.shape_176 = new cjs.Shape();
	this.shape_176.graphics.f("#747888").s().p("AgKgSIAUAfIAAAAIABACIgCADIAAABg");
	this.shape_176.setTransform(389.4,251.7,0.472,0.472);

	this.shape_177 = new cjs.Shape();
	this.shape_177.graphics.f("#747888").s().p("AgfABIAdg1IACgCIAgA5IggA0g");
	this.shape_177.setTransform(388.3,252.5,0.472,0.472);

	this.shape_178 = new cjs.Shape();
	this.shape_178.graphics.f("#747888").s().p("AAAAAIAAAAIABAAIgBABg");
	this.shape_178.setTransform(388.3,255.3,0.472,0.472);

	this.shape_179 = new cjs.Shape();
	this.shape_179.graphics.f("#747888").s().p("AAAAAIAAgBIABABIgBACg");
	this.shape_179.setTransform(388.3,244.4,0.472,0.472);

	this.shape_180 = new cjs.Shape();
	this.shape_180.graphics.f("#747888").s().p("AgHgPIAOAZIAAABIABACIgBADg");
	this.shape_180.setTransform(388,249.1,0.472,0.472);

	this.shape_181 = new cjs.Shape();
	this.shape_181.graphics.f("#747888").s().p("AgOAZIAAgBIgBgCIAfgxIAAACIgdA1g");
	this.shape_181.setTransform(387.5,245.8,0.472,0.472);

	this.shape_182 = new cjs.Shape();
	this.shape_182.graphics.f("#747888").s().p("AgKAUIABgBIgCgCIAXgkIgVAng");
	this.shape_182.setTransform(388.9,248.8,0.472,0.472);

	this.shape_183 = new cjs.Shape();
	this.shape_183.graphics.f("#747888").s().p("AgOgbIAcAvIAAAAIABACIgCAGg");
	this.shape_183.setTransform(389.2,245.9,0.472,0.472);

	this.shape_184 = new cjs.Shape();
	this.shape_184.graphics.f("#747888").s().p("AgeABIAeg1IAAAAIAAgCIADADIAcA3IgfAyg");
	this.shape_184.setTransform(388.3,247,0.472,0.472);

	this.shape_185 = new cjs.Shape();
	this.shape_185.graphics.f("#747888").s().p("AAAABIAAgCIABABIgBABg");
	this.shape_185.setTransform(388.3,249.8,0.472,0.472);

	this.shape_186 = new cjs.Shape();
	this.shape_186.graphics.f("#747888").s().p("AAHANIgBACIgNgdIAOAZIAAAAIABADIAAABg");
	this.shape_186.setTransform(388,243.7,0.472,0.472);

	this.shape_187 = new cjs.Shape();
	this.shape_187.graphics.f("#747888").s().p("AgNAZIAAgBIgBgCIAdgvIgbA0g");
	this.shape_187.setTransform(387.5,240.4,0.472,0.472);

	this.shape_188 = new cjs.Shape();
	this.shape_188.graphics.f("#747888").s().p("AgKAUIABgBIgCgCIAXglIgVApg");
	this.shape_188.setTransform(388.9,243.5,0.472,0.472);

	this.shape_189 = new cjs.Shape();
	this.shape_189.graphics.f("#747888").s().p("AgKgSIAUAfIAAAAIABADIgCADg");
	this.shape_189.setTransform(389.4,240.9,0.472,0.472);

	this.shape_190 = new cjs.Shape();
	this.shape_190.graphics.f("#747888").s().p("AgfAAIAdg0IACgCIAgA5IggA0g");
	this.shape_190.setTransform(388.3,241.7,0.472,0.472);

	this.shape_191 = new cjs.Shape();
	this.shape_191.graphics.f("#747888").s().p("AgHgOIAOAZIABACIgBACg");
	this.shape_191.setTransform(388,238.3,0.472,0.472);

	this.shape_192 = new cjs.Shape();
	this.shape_192.graphics.f("#747888").s().p("AgKAUIABgBIgCgCIAXgkIgVAng");
	this.shape_192.setTransform(388.9,238,0.472,0.472);

	this.shape_193 = new cjs.Shape();
	this.shape_193.graphics.f("#747888").s().p("AAAABIAAgBIABAAIgBACg");
	this.shape_193.setTransform(388.3,239,0.472,0.472);

	this.shape_194 = new cjs.Shape();
	this.shape_194.graphics.f("#747888").s().p("AgbgaIAAgBQAZAFAeAJIgCAEIgYAlg");
	this.shape_194.setTransform(388.2,237.5,0.472,0.472);

	this.shape_195 = new cjs.Shape();
	this.shape_195.graphics.f("#747888").s().p("AAAAAIAAAAIAAAAIAAABg");
	this.shape_195.setTransform(391.4,255.3,0.472,0.472);

	this.shape_196 = new cjs.Shape();
	this.shape_196.graphics.f("#747888").s().p("AAAAAIAAgBIABABIgBACg");
	this.shape_196.setTransform(391.4,244.4,0.472,0.472);

	this.shape_197 = new cjs.Shape();
	this.shape_197.graphics.f("#747888").s().p("AgOAZIAAgBIgBgCIAfgxIAAACIgcA1g");
	this.shape_197.setTransform(390.6,245.8,0.472,0.472);

	this.shape_198 = new cjs.Shape();
	this.shape_198.graphics.f("#747888").s().p("AgWAHIAcg1IABAAIABgCIAPAXQgIAdgPAtg");
	this.shape_198.setTransform(391.1,246.8,0.472,0.472);

	this.shape_199 = new cjs.Shape();
	this.shape_199.graphics.f("#747888").s().p("AAHANIgBACIgOgdIARAbIgBACg");
	this.shape_199.setTransform(391.1,243.7,0.472,0.472);

	this.shape_200 = new cjs.Shape();
	this.shape_200.graphics.f("#747888").s().p("AgOAZIABgBIgBgCIAdgvIgcA0g");
	this.shape_200.setTransform(390.6,240.4,0.472,0.472);

	this.shape_201 = new cjs.Shape();
	this.shape_201.graphics.f("#747888").s().p("AgIgOIARAbIgCACg");
	this.shape_201.setTransform(391.1,238.3,0.472,0.472);

	this.shape_202 = new cjs.Shape();
	this.shape_202.graphics.f("#747888").s().p("AACAUIACgDIgVglQAQAFAUAJIgQAbg");
	this.shape_202.setTransform(391.3,238.1,0.472,0.472);

	this.shape_203 = new cjs.Shape();
	this.shape_203.graphics.f("#BBCACB").s().p("AgfAKIAfg2IAAABIAAgBIAgA4IgMAXIgiAJg");
	this.shape_203.setTransform(386.8,271,0.472,0.472);

	this.shape_204 = new cjs.Shape();
	this.shape_204.graphics.f("#BBCACB").s().p("AAAAAIAAgBIABABIgBACg");
	this.shape_204.setTransform(386.7,263.5,0.472,0.472);

	this.shape_205 = new cjs.Shape();
	this.shape_205.graphics.f("#BBCACB").s().p("AgfAAIAeg1IABACIABgCIAfA3IggA0g");
	this.shape_205.setTransform(386.8,266,0.472,0.472);

	this.shape_206 = new cjs.Shape();
	this.shape_206.graphics.f("#BBCACB").s().p("AAAACIAAgBIABgCIABABIgCACg");
	this.shape_206.setTransform(386.8,268.8,0.472,0.472);

	this.shape_207 = new cjs.Shape();
	this.shape_207.graphics.f("#BBCACB").s().p("AAAABIgBACIAAgBIACgEIABACIgBADg");
	this.shape_207.setTransform(386.8,263.3,0.472,0.472);

	this.shape_208 = new cjs.Shape();
	this.shape_208.graphics.f("#BBCACB").s().p("AgcAGIgBgEIAdg2IABABIAAgBIAOAVQgCAFAGAHQAHAKAEAQIgdAug");
	this.shape_208.setTransform(386.7,260.6,0.472,0.472);

	this.shape_209 = new cjs.Shape();
	this.shape_209.graphics.f("#BBCACB").s().p("AgDgGQgGgHABgFIAEAFIANAcIgCAEQgEgQgGgJg");
	this.shape_209.setTransform(387.8,260,0.472,0.472);

	this.shape_210 = new cjs.Shape();
	this.shape_210.graphics.f("#BBCACB").s().p("AAAACIAAAAIAAgBIABgCIABABIgCACg");
	this.shape_210.setTransform(386.8,258,0.472,0.472);

	this.shape_211 = new cjs.Shape();
	this.shape_211.graphics.f("#BBCACB").s().p("AgfABIAfg2IAAAAIAAAAIAgA4IggAzg");
	this.shape_211.setTransform(386.8,255.2,0.472,0.472);

	this.shape_212 = new cjs.Shape();
	this.shape_212.graphics.f("#BBCACB").s().p("AAAAAIAAgBIABABIgBACg");
	this.shape_212.setTransform(386.7,247.2,0.472,0.472);

	this.shape_213 = new cjs.Shape();
	this.shape_213.graphics.f("#BBCACB").s().p("AAAACIAAAAIAAgBIABgCIABABIgCACg");
	this.shape_213.setTransform(386.8,252.5,0.472,0.472);

	this.shape_214 = new cjs.Shape();
	this.shape_214.graphics.f("#BBCACB").s().p("AgUAWIgLgWIAeg1IABADIABgCIAQAYIAPAeIgCADIgeAxg");
	this.shape_214.setTransform(386.8,249.8,0.472,0.472);

	this.shape_215 = new cjs.Shape();
	this.shape_215.graphics.f("#BBCACB").s().p("AgdAGIgCgEIAfg2IAAAAIAgA2IggAzg");
	this.shape_215.setTransform(386.8,244.3,0.472,0.472);

	this.shape_216 = new cjs.Shape();
	this.shape_216.graphics.f("#BBCACB").s().p("AAAABIgBACIAAgBIACgEIABACIgBADg");
	this.shape_216.setTransform(386.8,247.1,0.472,0.472);

	this.shape_217 = new cjs.Shape();
	this.shape_217.graphics.f("#BBCACB").s().p("AAAACIAAAAIAAgBIABgCIABABIgCACg");
	this.shape_217.setTransform(386.8,241.7,0.472,0.472);

	this.shape_218 = new cjs.Shape();
	this.shape_218.graphics.f("#BBCACB").s().p("AgUAXIgLgXIAfg2IAAABIAAgBIAgA4IgCAEIgeAwg");
	this.shape_218.setTransform(386.8,238.9,0.472,0.472);

	this.shape_219 = new cjs.Shape();
	this.shape_219.graphics.f("#BBCACB").s().p("AAAABIAAABIAAgBIABgCIABABIgCACg");
	this.shape_219.setTransform(386.8,236.2,0.472,0.472);

	this.shape_220 = new cjs.Shape();
	this.shape_220.graphics.f("#BBCACB").s().p("AgJAIIARgfQACAZgBAPQAAACgKAFg");
	this.shape_220.setTransform(388.8,271.1,0.472,0.472);

	this.shape_221 = new cjs.Shape();
	this.shape_221.graphics.f("#BBCACB").s().p("AgEgEIAFgLIAEAfg");
	this.shape_221.setTransform(388.6,266.2,0.472,0.472);

	this.shape_222 = new cjs.Shape();
	this.shape_222.graphics.f("#BBCACB").s().p("AgOAUIAdgzIgXA+g");
	this.shape_222.setTransform(389.1,254.3,0.472,0.472);

	this.shape_223 = new cjs.Shape();
	this.shape_223.graphics.f("#BBCACB").s().p("AAAAAIAAgBIABABIgBACg");
	this.shape_223.setTransform(389.9,247.2,0.472,0.472);

	this.shape_224 = new cjs.Shape();
	this.shape_224.graphics.f("#BBCACB").s().p("AgQAWIgLgWIAdg1IABADIABgCIAQAYIAIAQIgVA9IgEAFg");
	this.shape_224.setTransform(389.7,249.8,0.472,0.472);

	this.shape_225 = new cjs.Shape();
	this.shape_225.graphics.f("#BBCACB").s().p("AAAABIAAgBIAAgBIABABIgBACg");
	this.shape_225.setTransform(389.9,252.5,0.472,0.472);

	this.shape_226 = new cjs.Shape();
	this.shape_226.graphics.f("#BBCACB").s().p("AAAABIgBACIAAgBIABgEIACACIgCADg");
	this.shape_226.setTransform(389.9,247.1,0.472,0.472);

	this.shape_227 = new cjs.Shape();
	this.shape_227.graphics.f("#BBCACB").s().p("AgfACIAfg2IAgA2IggAzg");
	this.shape_227.setTransform(389.9,244.3,0.472,0.472);

	this.shape_228 = new cjs.Shape();
	this.shape_228.graphics.f("#BBCACB").s().p("AAAABIAAgCIABABIgBACg");
	this.shape_228.setTransform(389.9,241.7,0.472,0.472);

	this.shape_229 = new cjs.Shape();
	this.shape_229.graphics.f("#BBCACB").s().p("AgUARIgLgVIAZgsIAPAFIAIAKIAPAfIgCACIgeAxg");
	this.shape_229.setTransform(389.9,239.2,0.472,0.472);

	this.shape_230 = new cjs.Shape();
	this.shape_230.graphics.f("#BBCACB").s().p("AAAAAIAAAAIABABIAAAAg");
	this.shape_230.setTransform(375.9,271.4,0.472,0.472);

	this.shape_231 = new cjs.Shape();
	this.shape_231.graphics.f("#BBCACB").s().p("AgfgCIAfg3IAAAAIAAAAIAgA5IggA6g");
	this.shape_231.setTransform(377.4,271.6,0.472,0.472);

	this.shape_232 = new cjs.Shape();
	this.shape_232.graphics.f("#BBCACB").s().p("AAAAAIAAgBIABABIgBACg");
	this.shape_232.setTransform(377.4,263.5,0.472,0.472);

	this.shape_233 = new cjs.Shape();
	this.shape_233.graphics.f("#BBCACB").s().p("AgKgSIAUAfIgBABIACACIgCADg");
	this.shape_233.setTransform(376.9,267.9,0.472,0.472);

	this.shape_234 = new cjs.Shape();
	this.shape_234.graphics.f("#BBCACB").s().p("AgKATIgBgCIAXgkIgWAng");
	this.shape_234.setTransform(376.4,265,0.472,0.472);

	this.shape_235 = new cjs.Shape();
	this.shape_235.graphics.f("#BBCACB").s().p("AgfAAIAeg1IABACIABgCIAfA3IggA0g");
	this.shape_235.setTransform(377.4,266,0.472,0.472);

	this.shape_236 = new cjs.Shape();
	this.shape_236.graphics.f("#BBCACB").s().p("AAAACIAAgBIABgCIAAABIgBACg");
	this.shape_236.setTransform(377.4,268.8,0.472,0.472);

	this.shape_237 = new cjs.Shape();
	this.shape_237.graphics.f("#BBCACB").s().p("AgPgaIAeAuIgBAAIACACIgEAGg");
	this.shape_237.setTransform(376.7,262.1,0.472,0.472);

	this.shape_238 = new cjs.Shape();
	this.shape_238.graphics.f("#BBCACB").s().p("AAAABIgBACIAAgBIACgEIABACIgBADg");
	this.shape_238.setTransform(377.4,263.3,0.472,0.472);

	this.shape_239 = new cjs.Shape();
	this.shape_239.graphics.f("#BBCACB").s().p("AgfACIAfg2IAAABIAAgBIAgA2IggAzg");
	this.shape_239.setTransform(377.4,260.6,0.472,0.472);

	this.shape_240 = new cjs.Shape();
	this.shape_240.graphics.f("#BBCACB").s().p("AgMgVIAYAlIgBAAIACACIgDAEg");
	this.shape_240.setTransform(376.9,257,0.472,0.472);

	this.shape_241 = new cjs.Shape();
	this.shape_241.graphics.f("#BBCACB").s().p("AgKATIgBgCIAXgkIgWAng");
	this.shape_241.setTransform(376.4,254.3,0.472,0.472);

	this.shape_242 = new cjs.Shape();
	this.shape_242.graphics.f("#BBCACB").s().p("AgXAQIgIgPIAfg2IAAAAIAAAAIAgA4IggAzg");
	this.shape_242.setTransform(377.4,255.2,0.472,0.472);

	this.shape_243 = new cjs.Shape();
	this.shape_243.graphics.f("#BBCACB").s().p("AAAACIAAAAIgBgBIACgCIABABIgCACg");
	this.shape_243.setTransform(377.4,258,0.472,0.472);

	this.shape_244 = new cjs.Shape();
	this.shape_244.graphics.f("#BBCACB").s().p("AAAAAIAAgBIABABIgBACg");
	this.shape_244.setTransform(377.4,247.2,0.472,0.472);

	this.shape_245 = new cjs.Shape();
	this.shape_245.graphics.f("#BBCACB").s().p("AgKgSIAUAfIgBAAIACADIgCADg");
	this.shape_245.setTransform(376.9,251.7,0.472,0.472);

	this.shape_246 = new cjs.Shape();
	this.shape_246.graphics.f("#BBCACB").s().p("AgKATIgBgCIAXgkIgWAng");
	this.shape_246.setTransform(376.4,248.8,0.472,0.472);

	this.shape_247 = new cjs.Shape();
	this.shape_247.graphics.f("#BBCACB").s().p("AAAACIAAAAIAAgBIABgCIAAABIgBACg");
	this.shape_247.setTransform(377.4,252.5,0.472,0.472);

	this.shape_248 = new cjs.Shape();
	this.shape_248.graphics.f("#BBCACB").s().p("AgUAWIgLgWIAeg1IABADIABgCIAfA2IgBADIgfAxg");
	this.shape_248.setTransform(377.4,249.8,0.472,0.472);

	this.shape_249 = new cjs.Shape();
	this.shape_249.graphics.f("#BBCACB").s().p("AgPgbIAeAvIgBAAIACACIgEAGg");
	this.shape_249.setTransform(376.7,245.9,0.472,0.472);

	this.shape_250 = new cjs.Shape();
	this.shape_250.graphics.f("#BBCACB").s().p("AgKATIgBgCIAXglIgWApg");
	this.shape_250.setTransform(376.4,243.5,0.472,0.472);

	this.shape_251 = new cjs.Shape();
	this.shape_251.graphics.f("#BBCACB").s().p("AAAABIgBACIAAgBIACgEIABACIgBADg");
	this.shape_251.setTransform(377.4,247.1,0.472,0.472);

	this.shape_252 = new cjs.Shape();
	this.shape_252.graphics.f("#BBCACB").s().p("AgfACIAfg2IAAAAIAgA2IggAzg");
	this.shape_252.setTransform(377.4,244.3,0.472,0.472);

	this.shape_253 = new cjs.Shape();
	this.shape_253.graphics.f("#BBCACB").s().p("AgKgSIAUAfIgBAAIACADIgCADg");
	this.shape_253.setTransform(376.9,240.9,0.472,0.472);

	this.shape_254 = new cjs.Shape();
	this.shape_254.graphics.f("#BBCACB").s().p("AgKATIgBgCIAXgkIgWAng");
	this.shape_254.setTransform(376.4,238,0.472,0.472);

	this.shape_255 = new cjs.Shape();
	this.shape_255.graphics.f("#BBCACB").s().p("AAAACIAAAAIAAgBIABgCIAAABIgBACg");
	this.shape_255.setTransform(377.4,241.7,0.472,0.472);

	this.shape_256 = new cjs.Shape();
	this.shape_256.graphics.f("#BBCACB").s().p("AgfAAIAfg2IAAABIAAgBIAgA4IgBAEIgfAwg");
	this.shape_256.setTransform(377.4,238.9,0.472,0.472);

	this.shape_257 = new cjs.Shape();
	this.shape_257.graphics.f("#BBCACB").s().p("AgGgLIACAAIAKARIAAAAIABADIgCADg");
	this.shape_257.setTransform(377.1,235.7,0.472,0.472);

	this.shape_258 = new cjs.Shape();
	this.shape_258.graphics.f("#BBCACB").s().p("AgLgHIAXgCIgMATg");
	this.shape_258.setTransform(377.4,235.5,0.472,0.472);

	this.shape_259 = new cjs.Shape();
	this.shape_259.graphics.f("#BBCACB").s().p("AAAACIAAAAIAAgBIABgCIAAABIgBACg");
	this.shape_259.setTransform(377.4,236.2,0.472,0.472);

	this.shape_260 = new cjs.Shape();
	this.shape_260.graphics.f("#BBCACB").s().p("AgfgBIAfg3IAAABIAAgBIAgA4IgfA4IgCABg");
	this.shape_260.setTransform(380.5,271.6,0.472,0.472);

	this.shape_261 = new cjs.Shape();
	this.shape_261.graphics.f("#BBCACB").s().p("AgBAAIADgBIgCADg");
	this.shape_261.setTransform(380.5,274.3,0.472,0.472);

	this.shape_262 = new cjs.Shape();
	this.shape_262.graphics.f("#BBCACB").s().p("AAAAAIAAgBIABABIgBACg");
	this.shape_262.setTransform(380.5,263.5,0.472,0.472);

	this.shape_263 = new cjs.Shape();
	this.shape_263.graphics.f("#BBCACB").s().p("AgfAAIAeg1IABACIABgCIAfA3IggA0g");
	this.shape_263.setTransform(380.5,266,0.472,0.472);

	this.shape_264 = new cjs.Shape();
	this.shape_264.graphics.f("#BBCACB").s().p("AAAACIAAgBIABgCIAAABIgBACg");
	this.shape_264.setTransform(380.5,268.8,0.472,0.472);

	this.shape_265 = new cjs.Shape();
	this.shape_265.graphics.f("#BBCACB").s().p("AAAAAIAAAAIABAAIgBABg");
	this.shape_265.setTransform(380.5,258.1,0.472,0.472);

	this.shape_266 = new cjs.Shape();
	this.shape_266.graphics.f("#BBCACB").s().p("AAAABIgBACIAAgBIACgEIABACIgBADg");
	this.shape_266.setTransform(380.5,263.3,0.472,0.472);

	this.shape_267 = new cjs.Shape();
	this.shape_267.graphics.f("#BBCACB").s().p("AgfACIAfg2IAAABIABgBIAfA2IggAzg");
	this.shape_267.setTransform(380.5,260.6,0.472,0.472);

	this.shape_268 = new cjs.Shape();
	this.shape_268.graphics.f("#BBCACB").s().p("AgXAQIgIgPIAfg2IAAAAIAAAAIAgA4IggAzg");
	this.shape_268.setTransform(380.5,255.2,0.472,0.472);

	this.shape_269 = new cjs.Shape();
	this.shape_269.graphics.f("#BBCACB").s().p("AAAACIAAAAIgBgBIACgCIABABIgCACg");
	this.shape_269.setTransform(380.5,258,0.472,0.472);

	this.shape_270 = new cjs.Shape();
	this.shape_270.graphics.f("#BBCACB").s().p("AAAAAIAAgBIABABIgBACg");
	this.shape_270.setTransform(380.5,247.2,0.472,0.472);

	this.shape_271 = new cjs.Shape();
	this.shape_271.graphics.f("#BBCACB").s().p("AgfAAIAeg1IABADIABgCIAfA2IgBADIgfAxg");
	this.shape_271.setTransform(380.5,249.8,0.472,0.472);

	this.shape_272 = new cjs.Shape();
	this.shape_272.graphics.f("#BBCACB").s().p("AAAACIAAAAIAAgBIABgCIAAABIgBACg");
	this.shape_272.setTransform(380.5,252.5,0.472,0.472);

	this.shape_273 = new cjs.Shape();
	this.shape_273.graphics.f("#BBCACB").s().p("AgfACIAfg2IAAAAIAgA2IggAzg");
	this.shape_273.setTransform(380.5,244.3,0.472,0.472);

	this.shape_274 = new cjs.Shape();
	this.shape_274.graphics.f("#BBCACB").s().p("AAAABIgBACIAAgBIACgEIABACIgBADg");
	this.shape_274.setTransform(380.5,247.1,0.472,0.472);

	this.shape_275 = new cjs.Shape();
	this.shape_275.graphics.f("#BBCACB").s().p("AgfAAIAfg2IAAABIAAgBIAgA4IgBAEIgfAwg");
	this.shape_275.setTransform(380.5,238.9,0.472,0.472);

	this.shape_276 = new cjs.Shape();
	this.shape_276.graphics.f("#BBCACB").s().p("AAAACIAAAAIAAgBIABgCIAAABIgBACg");
	this.shape_276.setTransform(380.5,236.2,0.472,0.472);

	this.shape_277 = new cjs.Shape();
	this.shape_277.graphics.f("#BBCACB").s().p("AgMgKIAZAEIgMARg");
	this.shape_277.setTransform(380.5,235.5,0.472,0.472);

	this.shape_278 = new cjs.Shape();
	this.shape_278.graphics.f("#BBCACB").s().p("AgfAEIAfg2IAAAAIAAAAIAgA4IgXAqIgQADg");
	this.shape_278.setTransform(383.7,271.3,0.472,0.472);

	this.shape_279 = new cjs.Shape();
	this.shape_279.graphics.f("#BBCACB").s().p("AAAAAIAAgBIABABIgBACg");
	this.shape_279.setTransform(383.6,263.5,0.472,0.472);

	this.shape_280 = new cjs.Shape();
	this.shape_280.graphics.f("#BBCACB").s().p("AgfAAIAeg1IABACIABgCIAfA3IggA0g");
	this.shape_280.setTransform(383.7,266,0.472,0.472);

	this.shape_281 = new cjs.Shape();
	this.shape_281.graphics.f("#BBCACB").s().p("AAAACIAAgBIABgCIAAABIgBACg");
	this.shape_281.setTransform(383.7,268.8,0.472,0.472);

	this.shape_282 = new cjs.Shape();
	this.shape_282.graphics.f("#BBCACB").s().p("AAAABIgBACIAAgBIACgEIABACIgBADg");
	this.shape_282.setTransform(383.7,263.3,0.472,0.472);

	this.shape_283 = new cjs.Shape();
	this.shape_283.graphics.f("#BBCACB").s().p("AgfACIAfg2IAAABIABgBIAfA2IggAzg");
	this.shape_283.setTransform(383.6,260.6,0.472,0.472);

	this.shape_284 = new cjs.Shape();
	this.shape_284.graphics.f("#BBCACB").s().p("AAAACIAAAAIgBgBIABgCIACABIgCACg");
	this.shape_284.setTransform(383.7,258,0.472,0.472);

	this.shape_285 = new cjs.Shape();
	this.shape_285.graphics.f("#BBCACB").s().p("AgXAQIgIgPIAfg2IAAAAIAAAAIAgA4IggAzg");
	this.shape_285.setTransform(383.7,255.2,0.472,0.472);

	this.shape_286 = new cjs.Shape();
	this.shape_286.graphics.f("#BBCACB").s().p("AAAAAIAAgBIABABIgBACg");
	this.shape_286.setTransform(383.6,247.2,0.472,0.472);

	this.shape_287 = new cjs.Shape();
	this.shape_287.graphics.f("#BBCACB").s().p("AgfAAIAeg1IABADIABgCIAfA2IgBADIgfAxg");
	this.shape_287.setTransform(383.7,249.8,0.472,0.472);

	this.shape_288 = new cjs.Shape();
	this.shape_288.graphics.f("#BBCACB").s().p("AAAABIgBACIAAgBIACgEIABACIgBADg");
	this.shape_288.setTransform(383.7,247.1,0.472,0.472);

	this.shape_289 = new cjs.Shape();
	this.shape_289.graphics.f("#BBCACB").s().p("AgfACIAfg2IAAAAIAgA2IggAzg");
	this.shape_289.setTransform(383.6,244.3,0.472,0.472);

	this.shape_290 = new cjs.Shape();
	this.shape_290.graphics.f("#BBCACB").s().p("AgfAAIAfg2IAAABIAAgBIAgA4IgBAEIgfAwg");
	this.shape_290.setTransform(383.7,238.9,0.472,0.472);

	this.shape_291 = new cjs.Shape();
	this.shape_291.graphics.f("#BBCACB").s().p("AgFgEIALACIgGAHg");
	this.shape_291.setTransform(383.6,235.7,0.472,0.472);

	this.shape_292 = new cjs.Shape();
	this.shape_292.graphics.f("#BBCACB").s().p("AAAACIAAAAIAAgBIABgCIAAABIgBACg");
	this.shape_292.setTransform(383.7,236.2,0.472,0.472);

	this.shape_293 = new cjs.Shape();
	this.shape_293.graphics.f("#BBCACB").s().p("AAAAAIAAAAIABABIAAAAg");
	this.shape_293.setTransform(372.7,271.4,0.472,0.472);

	this.shape_294 = new cjs.Shape();
	this.shape_294.graphics.f("#BBCACB").s().p("AgIgOIAQAZIgBAAIACACIgCACg");
	this.shape_294.setTransform(375.5,270.9,0.472,0.472);

	this.shape_295 = new cjs.Shape();
	this.shape_295.graphics.f("#BBCACB").s().p("AgGAyIgZgwIAfg2IAAABIAAgBIAgA4IgbAxg");
	this.shape_295.setTransform(374.3,271.4,0.472,0.472);

	this.shape_296 = new cjs.Shape();
	this.shape_296.graphics.f("#BBCACB").s().p("AAAAAIAAgBIABABIgBACg");
	this.shape_296.setTransform(374.3,263.5,0.472,0.472);

	this.shape_297 = new cjs.Shape();
	this.shape_297.graphics.f("#BBCACB").s().p("AgOAZIAAAAIgBgCIAfgxIgdA1g");
	this.shape_297.setTransform(375,267.5,0.472,0.472);

	this.shape_298 = new cjs.Shape();
	this.shape_298.graphics.f("#BBCACB").s().p("AgIgPIAQAZIgBAAIACADIgCADg");
	this.shape_298.setTransform(375.5,265.4,0.472,0.472);

	this.shape_299 = new cjs.Shape();
	this.shape_299.graphics.f("#BBCACB").s().p("AgKgSIAUAfIAAABIABACIgCADg");
	this.shape_299.setTransform(373.8,267.9,0.472,0.472);

	this.shape_300 = new cjs.Shape();
	this.shape_300.graphics.f("#BBCACB").s().p("AgKATIgBgCIAXgkIgWAng");
	this.shape_300.setTransform(373.3,265,0.472,0.472);

	this.shape_301 = new cjs.Shape();
	this.shape_301.graphics.f("#BBCACB").s().p("AAAACIAAgBIABgCIAAABIgBACg");
	this.shape_301.setTransform(374.3,268.8,0.472,0.472);

	this.shape_302 = new cjs.Shape();
	this.shape_302.graphics.f("#BBCACB").s().p("AgfAAIAeg1IABACIABgCIAfA3IggA0g");
	this.shape_302.setTransform(374.3,266,0.472,0.472);

	this.shape_303 = new cjs.Shape();
	this.shape_303.graphics.f("#BBCACB").s().p("AAAAAIAAgBIABABIgBACg");
	this.shape_303.setTransform(375.8,260.7,0.472,0.472);

	this.shape_304 = new cjs.Shape();
	this.shape_304.graphics.f("#BBCACB").s().p("AgOAZIAAgBIgBgCIAegxIABABIgdA2g");
	this.shape_304.setTransform(375.1,262,0.472,0.472);

	this.shape_305 = new cjs.Shape();
	this.shape_305.graphics.f("#BBCACB").s().p("AgIgOIAQAZIgBABIACACIgBAAIgBgBIgBACg");
	this.shape_305.setTransform(375.5,260,0.472,0.472);

	this.shape_306 = new cjs.Shape();
	this.shape_306.graphics.f("#BBCACB").s().p("AgPgaIAdAuIAAAAIABACIgDAGg");
	this.shape_306.setTransform(373.6,262.1,0.472,0.472);

	this.shape_307 = new cjs.Shape();
	this.shape_307.graphics.f("#BBCACB").s().p("AgfACIAfg2IAAABIAAgBIAgA2IggAzg");
	this.shape_307.setTransform(374.3,260.6,0.472,0.472);

	this.shape_308 = new cjs.Shape();
	this.shape_308.graphics.f("#BBCACB").s().p("AAAABIgBACIAAgBIACgEIABACIgBADg");
	this.shape_308.setTransform(374.3,263.3,0.472,0.472);

	this.shape_309 = new cjs.Shape();
	this.shape_309.graphics.f("#BBCACB").s().p("AgOAaIAAgBIgBgBIAfgzIAAAAIgdA3g");
	this.shape_309.setTransform(375.1,256.6,0.472,0.472);

	this.shape_310 = new cjs.Shape();
	this.shape_310.graphics.f("#BBCACB").s().p("AgIgOIAQAYIgBABIACACIgBACIgBAAIAAAAg");
	this.shape_310.setTransform(375.5,254.6,0.472,0.472);

	this.shape_311 = new cjs.Shape();
	this.shape_311.graphics.f("#BBCACB").s().p("AgLgVIAWAlIAAAAIABACIgCAEg");
	this.shape_311.setTransform(373.7,257,0.472,0.472);

	this.shape_312 = new cjs.Shape();
	this.shape_312.graphics.f("#BBCACB").s().p("AgKATIgBgCIAXgkIgWAng");
	this.shape_312.setTransform(373.3,254.3,0.472,0.472);

	this.shape_313 = new cjs.Shape();
	this.shape_313.graphics.f("#BBCACB").s().p("AgXAQIgIgPIAfg2IAAAAIAAAAIAgA4IggAzg");
	this.shape_313.setTransform(374.3,255.2,0.472,0.472);

	this.shape_314 = new cjs.Shape();
	this.shape_314.graphics.f("#BBCACB").s().p("AAAACIAAAAIgBgBIACgCIABABIgCACg");
	this.shape_314.setTransform(374.3,258,0.472,0.472);

	this.shape_315 = new cjs.Shape();
	this.shape_315.graphics.f("#BBCACB").s().p("AAAAAIAAgBIABABIgBACg");
	this.shape_315.setTransform(374.3,247.2,0.472,0.472);

	this.shape_316 = new cjs.Shape();
	this.shape_316.graphics.f("#BBCACB").s().p("AgOAZIAAgBIgBgCIAfgwIgdA1g");
	this.shape_316.setTransform(375,251.2,0.472,0.472);

	this.shape_317 = new cjs.Shape();
	this.shape_317.graphics.f("#BBCACB").s().p("AgIgPIAQAZIgBABIACACIgCADg");
	this.shape_317.setTransform(375.5,249.1,0.472,0.472);

	this.shape_318 = new cjs.Shape();
	this.shape_318.graphics.f("#BBCACB").s().p("AgKgSIAUAfIAAAAIABADIgCADg");
	this.shape_318.setTransform(373.8,251.7,0.472,0.472);

	this.shape_319 = new cjs.Shape();
	this.shape_319.graphics.f("#BBCACB").s().p("AgKATIgBgCIAXgkIgWAng");
	this.shape_319.setTransform(373.3,248.8,0.472,0.472);

	this.shape_320 = new cjs.Shape();
	this.shape_320.graphics.f("#BBCACB").s().p("AgUAWIgLgWIAeg1IABADIABgCIAfA2IgBADIgfAxg");
	this.shape_320.setTransform(374.3,249.8,0.472,0.472);

	this.shape_321 = new cjs.Shape();
	this.shape_321.graphics.f("#BBCACB").s().p("AAAACIAAAAIAAgBIABgCIAAABIgBACg");
	this.shape_321.setTransform(374.3,252.5,0.472,0.472);

	this.shape_322 = new cjs.Shape();
	this.shape_322.graphics.f("#BBCACB").s().p("AAAAAIAAgBIABABIgBACg");
	this.shape_322.setTransform(375.8,244.4,0.472,0.472);

	this.shape_323 = new cjs.Shape();
	this.shape_323.graphics.f("#BBCACB").s().p("AgOAZIAAgBIgBgCIAegxIABACIgdA1g");
	this.shape_323.setTransform(375.1,245.8,0.472,0.472);

	this.shape_324 = new cjs.Shape();
	this.shape_324.graphics.f("#BBCACB").s().p("AAHANIgBACIgOgdIAQAZIgBAAIACADIgBABg");
	this.shape_324.setTransform(375.5,243.7,0.472,0.472);

	this.shape_325 = new cjs.Shape();
	this.shape_325.graphics.f("#BBCACB").s().p("AgPgbIAdAvIAAAAIABACIgDAGg");
	this.shape_325.setTransform(373.6,245.9,0.472,0.472);

	this.shape_326 = new cjs.Shape();
	this.shape_326.graphics.f("#BBCACB").s().p("AgKATIgBgCIAXglIgWApg");
	this.shape_326.setTransform(373.3,243.5,0.472,0.472);

	this.shape_327 = new cjs.Shape();
	this.shape_327.graphics.f("#BBCACB").s().p("AAAABIgBACIAAgBIACgEIABACIgBADg");
	this.shape_327.setTransform(374.3,247.1,0.472,0.472);

	this.shape_328 = new cjs.Shape();
	this.shape_328.graphics.f("#BBCACB").s().p("AgfACIAfg2IAAAAIAgA2IggAzg");
	this.shape_328.setTransform(374.3,244.3,0.472,0.472);

	this.shape_329 = new cjs.Shape();
	this.shape_329.graphics.f("#BBCACB").s().p("AgOAZIAAgBIgBgCIAfgvIgdA0g");
	this.shape_329.setTransform(375,240.4,0.472,0.472);

	this.shape_330 = new cjs.Shape();
	this.shape_330.graphics.f("#BBCACB").s().p("AgIgOIAQAZIgBAAIACACIgCACg");
	this.shape_330.setTransform(375.5,238.3,0.472,0.472);

	this.shape_331 = new cjs.Shape();
	this.shape_331.graphics.f("#BBCACB").s().p("AgKgSIAUAfIAAAAIABADIgCADg");
	this.shape_331.setTransform(373.8,240.9,0.472,0.472);

	this.shape_332 = new cjs.Shape();
	this.shape_332.graphics.f("#BBCACB").s().p("AgKATIgBgCIAXgkIgWAng");
	this.shape_332.setTransform(373.3,238,0.472,0.472);

	this.shape_333 = new cjs.Shape();
	this.shape_333.graphics.f("#BBCACB").s().p("AgUAXIgLgXIAfg2IAAABIAAgBIAgA4IgBAEIgfAwg");
	this.shape_333.setTransform(374.3,238.9,0.472,0.472);

	this.shape_334 = new cjs.Shape();
	this.shape_334.graphics.f("#BBCACB").s().p("AAAACIAAAAIAAgBIABgCIAAABIgBACg");
	this.shape_334.setTransform(374.3,241.7,0.472,0.472);

	this.shape_335 = new cjs.Shape();
	this.shape_335.graphics.f("#BBCACB").s().p("AgEAHIAAAAIgBgCIAHgNIAEAAIgJARg");
	this.shape_335.setTransform(374.6,235.8,0.472,0.472);

	this.shape_336 = new cjs.Shape();
	this.shape_336.graphics.f("#BBCACB").s().p("AgFgHIADgBIAGALIAAAAIABACIgCAEg");
	this.shape_336.setTransform(374.1,235.9,0.472,0.472);

	this.shape_337 = new cjs.Shape();
	this.shape_337.graphics.f("#BBCACB").s().p("AgHgEIAPgCIgIANg");
	this.shape_337.setTransform(374.3,235.7,0.472,0.472);

	this.shape_338 = new cjs.Shape();
	this.shape_338.graphics.f("#BBCACB").s().p("AAAACIAAAAIAAgBIABgCIAAABIgBACg");
	this.shape_338.setTransform(374.3,236.2,0.472,0.472);

	this.shape_339 = new cjs.Shape();
	this.shape_339.graphics.f("#BBCACB").s().p("AAAAAIAAAAIABABIgBAAg");
	this.shape_339.setTransform(369.6,271.4,0.472,0.472);

	this.shape_340 = new cjs.Shape();
	this.shape_340.graphics.f("#BBCACB").s().p("AgIgOIAQAZIgBAAIACACIgCACg");
	this.shape_340.setTransform(372.4,270.9,0.472,0.472);

	this.shape_341 = new cjs.Shape();
	this.shape_341.graphics.f("#BBCACB").s().p("AgPAnIgQgfIAfg2IAgA4IgUAlg");
	this.shape_341.setTransform(371.2,271.1,0.472,0.472);

	this.shape_342 = new cjs.Shape();
	this.shape_342.graphics.f("#BBCACB").s().p("AAAAAIAAgBIABABIgBACg");
	this.shape_342.setTransform(371.2,263.5,0.472,0.472);

	this.shape_343 = new cjs.Shape();
	this.shape_343.graphics.f("#BBCACB").s().p("AAAAAIAAAAIABABIgBAAg");
	this.shape_343.setTransform(371.2,268.6,0.472,0.472);

	this.shape_344 = new cjs.Shape();
	this.shape_344.graphics.f("#BBCACB").s().p("AgOAZIAAAAIgBgCIAegxIgcA1g");
	this.shape_344.setTransform(371.9,267.5,0.472,0.472);

	this.shape_345 = new cjs.Shape();
	this.shape_345.graphics.f("#BBCACB").s().p("AgIgPIAQAZIgBAAIACADIgCADg");
	this.shape_345.setTransform(372.4,265.4,0.472,0.472);

	this.shape_346 = new cjs.Shape();
	this.shape_346.graphics.f("#BBCACB").s().p("AgKgSIAUAfIAAABIABACIgCADg");
	this.shape_346.setTransform(370.7,267.9,0.472,0.472);

	this.shape_347 = new cjs.Shape();
	this.shape_347.graphics.f("#BBCACB").s().p("AgKAUIAAgBIgBgCIAXgkIgWAng");
	this.shape_347.setTransform(370.2,265,0.472,0.472);

	this.shape_348 = new cjs.Shape();
	this.shape_348.graphics.f("#BBCACB").s().p("AAAABIAAgCIABABIgBACg");
	this.shape_348.setTransform(371.2,268.8,0.472,0.472);

	this.shape_349 = new cjs.Shape();
	this.shape_349.graphics.f("#BBCACB").s().p("AgfAAIAeg1IABACIABgCIAfA3IggA0g");
	this.shape_349.setTransform(371.2,266,0.472,0.472);

	this.shape_350 = new cjs.Shape();
	this.shape_350.graphics.f("#BBCACB").s().p("AAAAAIAAAAIABABIgBAAg");
	this.shape_350.setTransform(369.6,260.6,0.472,0.472);

	this.shape_351 = new cjs.Shape();
	this.shape_351.graphics.f("#BBCACB").s().p("AAAAAIAAgBIABABIgBACg");
	this.shape_351.setTransform(372.7,260.7,0.472,0.472);

	this.shape_352 = new cjs.Shape();
	this.shape_352.graphics.f("#BBCACB").s().p("AgPAZIABgBIgBgCIAegxIABABIgdA2g");
	this.shape_352.setTransform(371.9,262,0.472,0.472);

	this.shape_353 = new cjs.Shape();
	this.shape_353.graphics.f("#BBCACB").s().p("AgIgOIAQAZIgBABIACACIgBAAIgBgBIgBACg");
	this.shape_353.setTransform(372.4,260,0.472,0.472);

	this.shape_354 = new cjs.Shape();
	this.shape_354.graphics.f("#BBCACB").s().p("AgOgaIAdAuIgBAAIABACIgCAGg");
	this.shape_354.setTransform(370.5,262.1,0.472,0.472);

	this.shape_355 = new cjs.Shape();
	this.shape_355.graphics.f("#BBCACB").s().p("AgKAUIAAgBIgBgCIAXgkIgWAng");
	this.shape_355.setTransform(370.2,259.7,0.472,0.472);

	this.shape_356 = new cjs.Shape();
	this.shape_356.graphics.f("#BBCACB").s().p("AAAABIgBACIAAgBIABgEIACACIgBADg");
	this.shape_356.setTransform(371.2,263.3,0.472,0.472);

	this.shape_357 = new cjs.Shape();
	this.shape_357.graphics.f("#BBCACB").s().p("AgfACIAfg2IAAABIAAgBIAgA2IggAzg");
	this.shape_357.setTransform(371.2,260.6,0.472,0.472);

	this.shape_358 = new cjs.Shape();
	this.shape_358.graphics.f("#BBCACB").s().p("AAAAAIAAAAIABAAIgBAAg");
	this.shape_358.setTransform(372.7,255.3,0.472,0.472);

	this.shape_359 = new cjs.Shape();
	this.shape_359.graphics.f("#BBCACB").s().p("AAAAAIAAAAIABABIgBAAg");
	this.shape_359.setTransform(371.2,257.8,0.472,0.472);

	this.shape_360 = new cjs.Shape();
	this.shape_360.graphics.f("#BBCACB").s().p("AgPAaIABgBIgBgBIAfgzIAAAAIgdA3g");
	this.shape_360.setTransform(371.9,256.6,0.472,0.472);

	this.shape_361 = new cjs.Shape();
	this.shape_361.graphics.f("#BBCACB").s().p("AgIgOIAQAYIgBABIACACIgBACIgBAAIAAAAg");
	this.shape_361.setTransform(372.4,254.6,0.472,0.472);

	this.shape_362 = new cjs.Shape();
	this.shape_362.graphics.f("#BBCACB").s().p("AgLgVIAXAlIgBAAIABACIgCAEg");
	this.shape_362.setTransform(370.6,257,0.472,0.472);

	this.shape_363 = new cjs.Shape();
	this.shape_363.graphics.f("#BBCACB").s().p("AgKAUIAAgBIgBgCIAXgkIgWAng");
	this.shape_363.setTransform(370.2,254.3,0.472,0.472);

	this.shape_364 = new cjs.Shape();
	this.shape_364.graphics.f("#BBCACB").s().p("AgXAQIgIgPIAfg2IAgA4IggAzg");
	this.shape_364.setTransform(371.2,255.2,0.472,0.472);

	this.shape_365 = new cjs.Shape();
	this.shape_365.graphics.f("#BBCACB").s().p("AAAACIAAAAIgBgBIABgCIACABIgCACg");
	this.shape_365.setTransform(371.2,258,0.472,0.472);

	this.shape_366 = new cjs.Shape();
	this.shape_366.graphics.f("#BBCACB").s().p("AAAAAIAAgBIABABIgBACg");
	this.shape_366.setTransform(371.2,247.2,0.472,0.472);

	this.shape_367 = new cjs.Shape();
	this.shape_367.graphics.f("#BBCACB").s().p("AAAAAIAAAAIABABIgBAAg");
	this.shape_367.setTransform(369.6,249.7,0.472,0.472);

	this.shape_368 = new cjs.Shape();
	this.shape_368.graphics.f("#BBCACB").s().p("AgOAZIAAgBIgBgCIAegwIgcA1g");
	this.shape_368.setTransform(371.9,251.2,0.472,0.472);

	this.shape_369 = new cjs.Shape();
	this.shape_369.graphics.f("#BBCACB").s().p("AgIgPIAQAZIgBABIACACIgCADg");
	this.shape_369.setTransform(372.4,249.1,0.472,0.472);

	this.shape_370 = new cjs.Shape();
	this.shape_370.graphics.f("#BBCACB").s().p("AgKgSIAUAfIAAAAIABADIgCADg");
	this.shape_370.setTransform(370.7,251.7,0.472,0.472);

	this.shape_371 = new cjs.Shape();
	this.shape_371.graphics.f("#BBCACB").s().p("AgKAUIAAgBIgBgCIAXgkIgWAng");
	this.shape_371.setTransform(370.2,248.8,0.472,0.472);

	this.shape_372 = new cjs.Shape();
	this.shape_372.graphics.f("#BBCACB").s().p("AAAABIAAgCIABABIgBACg");
	this.shape_372.setTransform(371.2,252.5,0.472,0.472);

	this.shape_373 = new cjs.Shape();
	this.shape_373.graphics.f("#BBCACB").s().p("AgUAWIgLgWIAeg1IABADIABgCIAfA2IgBADIgfAxg");
	this.shape_373.setTransform(371.2,249.8,0.472,0.472);

	this.shape_374 = new cjs.Shape();
	this.shape_374.graphics.f("#BBCACB").s().p("AAAAAIAAgBIABABIgBACg");
	this.shape_374.setTransform(372.7,244.4,0.472,0.472);

	this.shape_375 = new cjs.Shape();
	this.shape_375.graphics.f("#BBCACB").s().p("AAAAAIAAAAIABABIgBAAg");
	this.shape_375.setTransform(371.2,246.9,0.472,0.472);

	this.shape_376 = new cjs.Shape();
	this.shape_376.graphics.f("#BBCACB").s().p("AgPAZIABgBIgBgCIAegxIABACIgdA1g");
	this.shape_376.setTransform(371.9,245.8,0.472,0.472);

	this.shape_377 = new cjs.Shape();
	this.shape_377.graphics.f("#BBCACB").s().p("AAHANIgBACIgOgdIAQAZIgBAAIACADIgBABg");
	this.shape_377.setTransform(372.4,243.7,0.472,0.472);

	this.shape_378 = new cjs.Shape();
	this.shape_378.graphics.f("#BBCACB").s().p("AgOgbIAdAvIgBAAIABACIgCAGg");
	this.shape_378.setTransform(370.5,245.9,0.472,0.472);

	this.shape_379 = new cjs.Shape();
	this.shape_379.graphics.f("#BBCACB").s().p("AgKAUIAAgBIgBgCIAXglIgWApg");
	this.shape_379.setTransform(370.2,243.5,0.472,0.472);

	this.shape_380 = new cjs.Shape();
	this.shape_380.graphics.f("#BBCACB").s().p("AgfACIAfg2IAgA2IggAzg");
	this.shape_380.setTransform(371.2,244.3,0.472,0.472);

	this.shape_381 = new cjs.Shape();
	this.shape_381.graphics.f("#BBCACB").s().p("AAAABIgBACIAAgBIABgEIACACIgBADg");
	this.shape_381.setTransform(371.2,247.1,0.472,0.472);

	this.shape_382 = new cjs.Shape();
	this.shape_382.graphics.f("#BBCACB").s().p("AgOAZIABgBIgBgCIAdgvIgcA0g");
	this.shape_382.setTransform(371.9,240.4,0.472,0.472);

	this.shape_383 = new cjs.Shape();
	this.shape_383.graphics.f("#BBCACB").s().p("AgIgOIAQAZIgBAAIACACIgCACg");
	this.shape_383.setTransform(372.4,238.3,0.472,0.472);

	this.shape_384 = new cjs.Shape();
	this.shape_384.graphics.f("#BBCACB").s().p("AgKgSIAUAfIAAAAIABADIgCADg");
	this.shape_384.setTransform(370.7,240.9,0.472,0.472);

	this.shape_385 = new cjs.Shape();
	this.shape_385.graphics.f("#BBCACB").s().p("AgKAUIAAgBIgBgCIAXgkIgWAng");
	this.shape_385.setTransform(370.2,238,0.472,0.472);

	this.shape_386 = new cjs.Shape();
	this.shape_386.graphics.f("#BBCACB").s().p("AgUAXIgLgXIAfg2IAgA4IggA0g");
	this.shape_386.setTransform(371.2,238.9,0.472,0.472);

	this.shape_387 = new cjs.Shape();
	this.shape_387.graphics.f("#BBCACB").s().p("AAAABIAAgCIABABIgBACg");
	this.shape_387.setTransform(371.2,241.7,0.472,0.472);

	this.shape_388 = new cjs.Shape();
	this.shape_388.graphics.f("#BBCACB").s().p("AgBACIAAAAIgBgCIACgDIADAAIgDAHg");
	this.shape_388.setTransform(371.3,236,0.472,0.472);

	this.shape_389 = new cjs.Shape();
	this.shape_389.graphics.f("#BBCACB").s().p("AgCgDIADAAIABACIAAAAIABACIgBAEg");
	this.shape_389.setTransform(371.1,236.1,0.472,0.472);

	this.shape_390 = new cjs.Shape();
	this.shape_390.graphics.f("#BBCACB").s().p("AAAABIAAgCIABABIgBACg");
	this.shape_390.setTransform(371.2,236.2,0.472,0.472);

	this.shape_391 = new cjs.Shape();
	this.shape_391.graphics.f("#BBCACB").s().p("AgBAAIADgBIgCADg");
	this.shape_391.setTransform(371.2,235.9,0.472,0.472);

	this.shape_392 = new cjs.Shape();
	this.shape_392.graphics.f("#BBCACB").s().p("AgHgOIAPAZIAAAAIABACIgCACg");
	this.shape_392.setTransform(369.2,270.9,0.472,0.472);

	this.shape_393 = new cjs.Shape();
	this.shape_393.graphics.f("#BBCACB").s().p("AgSAZQgCgVAFgmIADgEIAgA4IgLAVQgagJgBgFg");
	this.shape_393.setTransform(368.6,270.7,0.472,0.472);

	this.shape_394 = new cjs.Shape();
	this.shape_394.graphics.f("#BBCACB").s().p("AAAAAIAAgBIABABIgBACg");
	this.shape_394.setTransform(368,263.5,0.472,0.472);

	this.shape_395 = new cjs.Shape();
	this.shape_395.graphics.f("#BBCACB").s().p("AAAAAIAAAAIABABIgBAAg");
	this.shape_395.setTransform(368.1,268.6,0.472,0.472);

	this.shape_396 = new cjs.Shape();
	this.shape_396.graphics.f("#BBCACB").s().p("AgOAZIABAAIgBgCIAdgxIgcA1g");
	this.shape_396.setTransform(368.8,267.5,0.472,0.472);

	this.shape_397 = new cjs.Shape();
	this.shape_397.graphics.f("#BBCACB").s().p("AgHgPIAPAZIAAAAIABADIgCADg");
	this.shape_397.setTransform(369.2,265.4,0.472,0.472);

	this.shape_398 = new cjs.Shape();
	this.shape_398.graphics.f("#BBCACB").s().p("AAAACIAAgFIABACIgBABIABABIgBADg");
	this.shape_398.setTransform(368,268.6,0.472,0.472);

	this.shape_399 = new cjs.Shape();
	this.shape_399.graphics.f("#BBCACB").s().p("AgQArIANhXIAFAHIAPAfIgBADIgeAwg");
	this.shape_399.setTransform(368.8,266.4,0.472,0.472);

	this.shape_400 = new cjs.Shape();
	this.shape_400.graphics.f("#BBCACB").s().p("AAAABIAAgCIABABIgBACg");
	this.shape_400.setTransform(368.1,268.8,0.472,0.472);

	this.shape_401 = new cjs.Shape();
	this.shape_401.graphics.f("#BBCACB").s().p("AAAAAIAAgBIABABIgBACg");
	this.shape_401.setTransform(369.6,260.7,0.472,0.472);

	this.shape_402 = new cjs.Shape();
	this.shape_402.graphics.f("#BBCACB").s().p("AgHAIIAPgXIAAABIgPAeg");
	this.shape_402.setTransform(369.2,261.5,0.472,0.472);

	this.shape_403 = new cjs.Shape();
	this.shape_403.graphics.f("#BBCACB").s().p("AgFgIIAAgCIALARIgBABIABACIAAAAIgBgBIgBACg");
	this.shape_403.setTransform(369.3,260.2,0.472,0.472);

	this.shape_404 = new cjs.Shape();
	this.shape_404.graphics.f("#BBCACB").s().p("AgCgVIAKAUIgPAXIAFgrg");
	this.shape_404.setTransform(369.2,260.8,0.472,0.472);

	this.shape_405 = new cjs.Shape();
	this.shape_405.graphics.f("#BBCACB").s().p("AAAABIgBACIAAgBIABgEIACACIgCADg");
	this.shape_405.setTransform(368.1,263.3,0.472,0.472);

	this.shape_406 = new cjs.Shape();
	this.shape_406.graphics.f("#BBCACB").s().p("AgMASIAZgnIAAAAIgXAsg");
	this.shape_406.setTransform(369,256.4,0.472,0.472);

	this.shape_407 = new cjs.Shape();
	this.shape_407.graphics.f("#BBCACB").s().p("AgHgOIAPAYIAAABIABACIgBACIAAAAIgBAAg");
	this.shape_407.setTransform(369.2,254.6,0.472,0.472);

	this.shape_408 = new cjs.Shape();
	this.shape_408.graphics.f("#BBCACB").s().p("AgXgUIAQgcIAfA4IgYApg");
	this.shape_408.setTransform(368.4,255,0.472,0.472);

	this.shape_409 = new cjs.Shape();
	this.shape_409.graphics.f("#BBCACB").s().p("AAAACIAAAAIgBgBIABgCIABABIgBACg");
	this.shape_409.setTransform(368.1,258,0.472,0.472);

	this.shape_410 = new cjs.Shape();
	this.shape_410.graphics.f("#BBCACB").s().p("AAAAAIAAgBIABABIgBACg");
	this.shape_410.setTransform(368,247.2,0.472,0.472);

	this.shape_411 = new cjs.Shape();
	this.shape_411.graphics.f("#BBCACB").s().p("AgOAZIABgBIgBgCIAdgwIgcA1g");
	this.shape_411.setTransform(368.8,251.2,0.472,0.472);

	this.shape_412 = new cjs.Shape();
	this.shape_412.graphics.f("#BBCACB").s().p("AgHgPIAPAZIAAABIABACIgCADg");
	this.shape_412.setTransform(369.2,249.1,0.472,0.472);

	this.shape_413 = new cjs.Shape();
	this.shape_413.graphics.f("#BBCACB").s().p("AgKgSIAUAfIAAAAIABADIgCADg");
	this.shape_413.setTransform(367.6,251.7,0.472,0.472);

	this.shape_414 = new cjs.Shape();
	this.shape_414.graphics.f("#BBCACB").s().p("AgLASIAXglIgWAng");
	this.shape_414.setTransform(367,248.8,0.472,0.472);

	this.shape_415 = new cjs.Shape();
	this.shape_415.graphics.f("#BBCACB").s().p("AgUAWIgLgWIAeg1IABADIAAgCIARAYIAPAeIgBADIgfAxg");
	this.shape_415.setTransform(368.1,249.8,0.472,0.472);

	this.shape_416 = new cjs.Shape();
	this.shape_416.graphics.f("#BBCACB").s().p("AAAABIAAgCIABABIgBACg");
	this.shape_416.setTransform(368.1,252.5,0.472,0.472);

	this.shape_417 = new cjs.Shape();
	this.shape_417.graphics.f("#BBCACB").s().p("AAAAAIAAgBIABABIgBACg");
	this.shape_417.setTransform(369.6,244.4,0.472,0.472);

	this.shape_418 = new cjs.Shape();
	this.shape_418.graphics.f("#BBCACB").s().p("AAAAAIAAAAIABABIgBAAg");
	this.shape_418.setTransform(368.1,246.9,0.472,0.472);

	this.shape_419 = new cjs.Shape();
	this.shape_419.graphics.f("#BBCACB").s().p("AgPAZIABgBIgBgCIAfgxIAAACIgdA1g");
	this.shape_419.setTransform(368.8,245.8,0.472,0.472);

	this.shape_420 = new cjs.Shape();
	this.shape_420.graphics.f("#BBCACB").s().p("AAIANIgBACIgOgdIAPAZIAAAAIABADIAAABg");
	this.shape_420.setTransform(369.2,243.7,0.472,0.472);

	this.shape_421 = new cjs.Shape();
	this.shape_421.graphics.f("#BBCACB").s().p("AgOgbIAdAvIgBAAIABACIgCAGg");
	this.shape_421.setTransform(367.4,245.9,0.472,0.472);

	this.shape_422 = new cjs.Shape();
	this.shape_422.graphics.f("#BBCACB").s().p("AgLARIAXglIgWApg");
	this.shape_422.setTransform(367,243.5,0.472,0.472);

	this.shape_423 = new cjs.Shape();
	this.shape_423.graphics.f("#BBCACB").s().p("AAAABIgBACIAAgBIABgEIACACIgCADg");
	this.shape_423.setTransform(368.1,247.1,0.472,0.472);

	this.shape_424 = new cjs.Shape();
	this.shape_424.graphics.f("#BBCACB").s().p("AgfACIAfg2IAgA2IggAzg");
	this.shape_424.setTransform(368,244.3,0.472,0.472);

	this.shape_425 = new cjs.Shape();
	this.shape_425.graphics.f("#BBCACB").s().p("AAAAAIAAgBIABABIgBABg");
	this.shape_425.setTransform(368.1,241.6,0.472,0.472);

	this.shape_426 = new cjs.Shape();
	this.shape_426.graphics.f("#BBCACB").s().p("AgOAZIABgBIgBgCIAdgvIgcA0g");
	this.shape_426.setTransform(368.8,240.4,0.472,0.472);

	this.shape_427 = new cjs.Shape();
	this.shape_427.graphics.f("#BBCACB").s().p("AgHgOIAPAZIAAAAIABACIgCACg");
	this.shape_427.setTransform(369.2,238.3,0.472,0.472);

	this.shape_428 = new cjs.Shape();
	this.shape_428.graphics.f("#BBCACB").s().p("AgKgSIAUAfIAAAAIABADIgCADg");
	this.shape_428.setTransform(367.6,240.9,0.472,0.472);

	this.shape_429 = new cjs.Shape();
	this.shape_429.graphics.f("#BBCACB").s().p("AgLARIAXgkIgWAng");
	this.shape_429.setTransform(367,238,0.472,0.472);

	this.shape_430 = new cjs.Shape();
	this.shape_430.graphics.f("#BBCACB").s().p("AAAABIAAgCIABABIgBACg");
	this.shape_430.setTransform(368.1,241.7,0.472,0.472);

	this.shape_431 = new cjs.Shape();
	this.shape_431.graphics.f("#BBCACB").s().p("AgUAVIgLgVIAdgzIADgBIAQAXIAPAeIgBADIgfAxg");
	this.shape_431.setTransform(368.1,239,0.472,0.472);

	this.shape_432 = new cjs.Shape();
	this.shape_432.graphics.f("#747888").s().p("AgfABIAfg3IAAAAIAAAAIAgA4IggA2g");
	this.shape_432.setTransform(375.9,268.7,0.472,0.472);

	this.shape_433 = new cjs.Shape();
	this.shape_433.graphics.f("#747888").s().p("AAAABIAAgBIABAAIgBABg");
	this.shape_433.setTransform(375.9,260.7,0.472,0.472);

	this.shape_434 = new cjs.Shape();
	this.shape_434.graphics.f("#747888").s().p("AgeACIAeg2IAAABIABgDIACAEIAcA2IgfAyg");
	this.shape_434.setTransform(375.9,263.3,0.472,0.472);

	this.shape_435 = new cjs.Shape();
	this.shape_435.graphics.f("#747888").s().p("AgeABIAeg3IAAABIAAgBIAJAOIAWArIgfA0g");
	this.shape_435.setTransform(375.9,257.9,0.472,0.472);

	this.shape_436 = new cjs.Shape();
	this.shape_436.graphics.f("#747888").s().p("AgfABIAfg3IAAAAIAgA5IggA0g");
	this.shape_436.setTransform(375.9,252.5,0.472,0.472);

	this.shape_437 = new cjs.Shape();
	this.shape_437.graphics.f("#747888").s().p("AAAABIAAgBIABAAIgBABg");
	this.shape_437.setTransform(375.9,244.5,0.472,0.472);

	this.shape_438 = new cjs.Shape();
	this.shape_438.graphics.f("#747888").s().p("AgeABIAeg1IAAAAIABgCIACADIAcA3IgfAyg");
	this.shape_438.setTransform(375.9,247,0.472,0.472);

	this.shape_439 = new cjs.Shape();
	this.shape_439.graphics.f("#747888").s().p("AgfAAIAfg2IAAAAIAMATIAUAmIggA0g");
	this.shape_439.setTransform(375.9,241.7,0.472,0.472);

	this.shape_440 = new cjs.Shape();
	this.shape_440.graphics.f("#747888").s().p("AgfgPIAKgSIAogFIANAZIggA0g");
	this.shape_440.setTransform(375.9,237,0.472,0.472);

	this.shape_441 = new cjs.Shape();
	this.shape_441.graphics.f("#747888").s().p("AgfABIAfg3IAAAAIAAAAIAgA4IggA2g");
	this.shape_441.setTransform(372.7,268.7,0.472,0.472);

	this.shape_442 = new cjs.Shape();
	this.shape_442.graphics.f("#747888").s().p("AAAABIAAgBIABAAIgBABg");
	this.shape_442.setTransform(372.7,260.7,0.472,0.472);

	this.shape_443 = new cjs.Shape();
	this.shape_443.graphics.f("#747888").s().p("AgeACIAeg2IAAABIABgDIACAEIAcA2IgfAyg");
	this.shape_443.setTransform(372.7,263.3,0.472,0.472);

	this.shape_444 = new cjs.Shape();
	this.shape_444.graphics.f("#747888").s().p("AgeABIAeg3IAAABIAAgBIAJAOIAWArIgfA0g");
	this.shape_444.setTransform(372.7,257.9,0.472,0.472);

	this.shape_445 = new cjs.Shape();
	this.shape_445.graphics.f("#747888").s().p("AgfABIAfg3IAAAAIAgA5IggA0g");
	this.shape_445.setTransform(372.7,252.5,0.472,0.472);

	this.shape_446 = new cjs.Shape();
	this.shape_446.graphics.f("#747888").s().p("AAAABIAAgBIABAAIgBABg");
	this.shape_446.setTransform(372.7,244.5,0.472,0.472);

	this.shape_447 = new cjs.Shape();
	this.shape_447.graphics.f("#747888").s().p("AgeABIAeg1IAAAAIABgCIACADIAcA3IgfAyg");
	this.shape_447.setTransform(372.7,247,0.472,0.472);

	this.shape_448 = new cjs.Shape();
	this.shape_448.graphics.f("#747888").s().p("AgfAAIAdg0IACgCIAAAAIAgA5IggA0g");
	this.shape_448.setTransform(372.7,241.7,0.472,0.472);

	this.shape_449 = new cjs.Shape();
	this.shape_449.graphics.f("#747888").s().p("AgfgTIAFgIIAxgHIAJARIggA0g");
	this.shape_449.setTransform(372.7,237.1,0.472,0.472);

	this.shape_450 = new cjs.Shape();
	this.shape_450.graphics.f("#747888").s().p("AAAABIABgBIAAAAIgBABg");
	this.shape_450.setTransform(369.6,271.5,0.472,0.472);

	this.shape_451 = new cjs.Shape();
	this.shape_451.graphics.f("#747888").s().p("AgfABIAfg3IAgA4IggA2g");
	this.shape_451.setTransform(369.6,268.7,0.472,0.472);

	this.shape_452 = new cjs.Shape();
	this.shape_452.graphics.f("#747888").s().p("AAAABIABgBIAAAAIgBABg");
	this.shape_452.setTransform(369.6,260.7,0.472,0.472);

	this.shape_453 = new cjs.Shape();
	this.shape_453.graphics.f("#747888").s().p("AgUAdIgFgIIAEgqIAQgfIABABIABgDIACAEIAbA2IgeAyg");
	this.shape_453.setTransform(369.9,263.3,0.472,0.472);

	this.shape_454 = new cjs.Shape();
	this.shape_454.graphics.f("#747888").s().p("AAAAAIAAAAIAAAAIAAABg");
	this.shape_454.setTransform(369.6,255.3,0.472,0.472);

	this.shape_455 = new cjs.Shape();
	this.shape_455.graphics.f("#747888").s().p("AgOAlQABgGgEgMIgKgcIAYgtIAAABIABgBIAIAOIAWArIgeA0g");
	this.shape_455.setTransform(369.8,257.9,0.472,0.472);

	this.shape_456 = new cjs.Shape();
	this.shape_456.graphics.f("#747888").s().p("AgfABIAfg3IAgA5IggA0g");
	this.shape_456.setTransform(369.6,252.5,0.472,0.472);

	this.shape_457 = new cjs.Shape();
	this.shape_457.graphics.f("#747888").s().p("AgeABIAeg1IAAAAIAAgCIADADIAcA3IgfAyg");
	this.shape_457.setTransform(369.6,247,0.472,0.472);

	this.shape_458 = new cjs.Shape();
	this.shape_458.graphics.f("#747888").s().p("AgfAAIAdg0IACgCIAgA5IggA0g");
	this.shape_458.setTransform(369.6,241.7,0.472,0.472);

	this.shape_459 = new cjs.Shape();
	this.shape_459.graphics.f("#747888").s().p("AgegSQAUgFAkgHIAFAJIggA0g");
	this.shape_459.setTransform(369.7,237.3,0.472,0.472);

	this.shape_460 = new cjs.Shape();
	this.shape_460.graphics.f("#747888").s().p("AAAgCIABACIgBADg");
	this.shape_460.setTransform(368,268.9,0.472,0.472);

	this.shape_461 = new cjs.Shape();
	this.shape_461.graphics.f("#747888").s().p("AgTgfIAHgLIAgA5IgRAcg");
	this.shape_461.setTransform(367.1,251.9,0.472,0.472);

	this.shape_462 = new cjs.Shape();
	this.shape_462.graphics.f("#747888").s().p("AAAAAIAAgBIABABIgBACg");
	this.shape_462.setTransform(366.5,244.5,0.472,0.472);

	this.shape_463 = new cjs.Shape();
	this.shape_463.graphics.f("#747888").s().p("AgWAQIgHgdIAcgrIABACIAAgCIACADIAcA2IgeA0IAAACIAAACg");
	this.shape_463.setTransform(366.5,247.1,0.472,0.472);

	this.shape_464 = new cjs.Shape();
	this.shape_464.graphics.f("#747888").s().p("AgFgHIAEgHIAHAdg");
	this.shape_464.setTransform(365.2,247.2,0.472,0.472);

	this.shape_465 = new cjs.Shape();
	this.shape_465.graphics.f("#747888").s().p("AAAA3IAAACIggg9IAgg0IAhA5IghA1IACADIgBAAg");
	this.shape_465.setTransform(366.5,241.8,0.472,0.472);

	this.shape_466 = new cjs.Shape();
	this.shape_466.graphics.f("#747888").s().p("AgYgLQATgHAegIIgGALIgXAlIACACIgCADg");
	this.shape_466.setTransform(366.7,237.8,0.472,0.472);

	this.shape_467 = new cjs.Shape();
	this.shape_467.graphics.f("#D6D8D8").s().p("AgIgLIACgCIAPAcg");
	this.shape_467.setTransform(368.4,269.4,0.472,0.472);

	this.shape_468 = new cjs.Shape();
	this.shape_468.graphics.f("#D6D8D8").s().p("AgHgLIABgCIAOAcg");
	this.shape_468.setTransform(374.7,236.9,0.472,0.472);

	this.shape_469 = new cjs.Shape();
	this.shape_469.graphics.f("#D6D8D8").s().p("AgHgKIABgEIAOAdg");
	this.shape_469.setTransform(384,242.4,0.472,0.472);

	this.shape_470 = new cjs.Shape();
	this.shape_470.graphics.f("#D6D8D8").s().p("AgHgJIACgEIANAag");
	this.shape_470.setTransform(384.1,247.7,0.472,0.472);

	this.shape_471 = new cjs.Shape();
	this.shape_471.graphics.f("#D6D8D8").s().p("AgHgKIABgDIAOAcg");
	this.shape_471.setTransform(384,253.2,0.472,0.472);

	this.shape_472 = new cjs.Shape();
	this.shape_472.graphics.f("#D6D8D8").s().p("AgHgLIABgCIAOAcg");
	this.shape_472.setTransform(380.9,269.4,0.472,0.472);

	this.shape_473 = new cjs.Shape();
	this.shape_473.graphics.f("#D6D8D8").s().p("AgHgLIABgCIAOAcg");
	this.shape_473.setTransform(380.9,236.9,0.472,0.472);

	this.shape_474 = new cjs.Shape();
	this.shape_474.graphics.f("#D6D8D8").s().p("AgHgLIABgCIAOAcg");
	this.shape_474.setTransform(377.8,236.9,0.472,0.472);

	this.shape_475 = new cjs.Shape();
	this.shape_475.graphics.f("#D6D8D8").s().p("AgIgLIADgCIANAcg");
	this.shape_475.setTransform(371.6,269.4,0.472,0.472);

	this.shape_476 = new cjs.Shape();
	this.shape_476.graphics.f("#D6D8D8").s().p("AgHgLIABgCIAOAcg");
	this.shape_476.setTransform(384,236.9,0.472,0.472);

	this.shape_477 = new cjs.Shape();
	this.shape_477.graphics.f("#D6D8D8").s().p("AgHgLIABgCIAOAcg");
	this.shape_477.setTransform(377.8,269.4,0.472,0.472);

	this.shape_478 = new cjs.Shape();
	this.shape_478.graphics.f("#D6D8D8").s().p("AgHgLIABgCIAOAcg");
	this.shape_478.setTransform(374.7,269.4,0.472,0.472);

	this.shape_479 = new cjs.Shape();
	this.shape_479.graphics.f("#D6D8D8").s().p("AgRA8IAgg8Ighg2IAPgcIAIAFQAhARgoCPg");
	this.shape_479.setTransform(392.3,241.6,0.472,0.472);

	this.shape_480 = new cjs.Shape();
	this.shape_480.graphics.f("#D6D8D8").s().p("AgOAIIALgVIABABIABgDIAPAfg");
	this.shape_480.setTransform(369.7,272.2,0.472,0.472);

	this.shape_481 = new cjs.Shape();
	this.shape_481.graphics.f("#D6D8D8").s().p("AgHgJIACgEIANAag");
	this.shape_481.setTransform(377.8,247.7,0.472,0.472);

	this.shape_482 = new cjs.Shape();
	this.shape_482.graphics.f("#D6D8D8").s().p("AgHgKIABgEIAOAdg");
	this.shape_482.setTransform(377.8,242.4,0.472,0.472);

	this.shape_483 = new cjs.Shape();
	this.shape_483.graphics.f("#D6D8D8").s().p("AgdAUIAbgwIAAABIABgDIAfA9QgVgDgmgIg");
	this.shape_483.setTransform(376,272.9,0.472,0.472);

	this.shape_484 = new cjs.Shape();
	this.shape_484.graphics.f("#D6D8D8").s().p("AgWAOIAUgjIAAAAIABgCIAYAvg");
	this.shape_484.setTransform(372.9,272.6,0.472,0.472);

	this.shape_485 = new cjs.Shape();
	this.shape_485.graphics.f("#D6D8D8").s().p("AgHgKIACgDIANAbg");
	this.shape_485.setTransform(371.6,258.6,0.472,0.472);

	this.shape_486 = new cjs.Shape();
	this.shape_486.graphics.f("#D6D8D8").s().p("AgFgIIABgCIAKAVg");
	this.shape_486.setTransform(373,250.3,0.472,0.472);

	this.shape_487 = new cjs.Shape();
	this.shape_487.graphics.f("#D6D8D8").s().p("AgHhbIANgGIAUAmIggA0IAfA9IgbAsQgqiqAlgTg");
	this.shape_487.setTransform(365.3,241.9,0.472,0.472);

	this.shape_488 = new cjs.Shape();
	this.shape_488.graphics.f("#D6D8D8").s().p("AgFgHIABgDIAKAVg");
	this.shape_488.setTransform(373,239.5,0.472,0.472);

	this.shape_489 = new cjs.Shape();
	this.shape_489.graphics.f("#D6D8D8").s().p("AgKgZIAVAoIgHALg");
	this.shape_489.setTransform(366,249.1,0.472,0.472);

	this.shape_490 = new cjs.Shape();
	this.shape_490.graphics.f("#D6D8D8").s().p("AgHgKIABgEIAOAdg");
	this.shape_490.setTransform(374.7,242.4,0.472,0.472);

	this.shape_491 = new cjs.Shape();
	this.shape_491.graphics.f("#D6D8D8").s().p("AgHgKIABgDIAOAcg");
	this.shape_491.setTransform(374.7,253.2,0.472,0.472);

	this.shape_492 = new cjs.Shape();
	this.shape_492.graphics.f("#D6D8D8").s().p("AgHgJIACgEIANAag");
	this.shape_492.setTransform(374.7,247.7,0.472,0.472);

	this.shape_493 = new cjs.Shape();
	this.shape_493.graphics.f("#D6D8D8").s().p("AgFgIIABgCIAKAVg");
	this.shape_493.setTransform(379.3,250.3,0.472,0.472);

	this.shape_494 = new cjs.Shape();
	this.shape_494.graphics.f("#D6D8D8").s().p("AACgaIABAAIABgCIAZAuQgjAIgVADg");
	this.shape_494.setTransform(381.9,272.9,0.472,0.472);

	this.shape_495 = new cjs.Shape();
	this.shape_495.graphics.f("#D6D8D8").s().p("AggAeIAhg7IAAAAIABgCIAeA6QgWAEgRABQgJAAgQgCg");
	this.shape_495.setTransform(378.9,273,0.472,0.472);

	this.shape_496 = new cjs.Shape();
	this.shape_496.graphics.f("#D6D8D8").s().p("AACgTIABAAIABgCIARAhIgpAKg");
	this.shape_496.setTransform(385.1,272.5,0.472,0.472);

	this.shape_497 = new cjs.Shape();
	this.shape_497.graphics.f("#D6D8D8").s().p("AgFgIIABgCIAKAVg");
	this.shape_497.setTransform(376.1,250.3,0.472,0.472);

	this.shape_498 = new cjs.Shape();
	this.shape_498.graphics.f("#D6D8D8").s().p("AgFgHIABgDIAKAVg");
	this.shape_498.setTransform(376.1,239.5,0.472,0.472);

	this.shape_499 = new cjs.Shape();
	this.shape_499.graphics.f("#D6D8D8").s().p("AABgJIAAAAIACgCIAIAPIgVAIg");
	this.shape_499.setTransform(388.3,272.1,0.472,0.472);

	this.shape_500 = new cjs.Shape();
	this.shape_500.graphics.f("#D6D8D8").s().p("AgHgKIABgEIAOAdg");
	this.shape_500.setTransform(380.9,242.4,0.472,0.472);

	this.shape_501 = new cjs.Shape();
	this.shape_501.graphics.f("#D6D8D8").s().p("AgIgKIADgDIANAcg");
	this.shape_501.setTransform(371.6,253.2,0.472,0.472);

	this.shape_502 = new cjs.Shape();
	this.shape_502.graphics.f("#D6D8D8").s().p("AgFgHIABgDIAKAVg");
	this.shape_502.setTransform(382.4,239.5,0.472,0.472);

	this.shape_503 = new cjs.Shape();
	this.shape_503.graphics.f("#D6D8D8").s().p("AgHgLIACgCIAOAcg");
	this.shape_503.setTransform(387.2,269.4,0.472,0.472);

	this.shape_504 = new cjs.Shape();
	this.shape_504.graphics.f("#D6D8D8").s().p("AgHgLIABgCIAOAcg");
	this.shape_504.setTransform(384,269.4,0.472,0.472);

	this.shape_505 = new cjs.Shape();
	this.shape_505.graphics.f("#D6D8D8").s().p("AAAAAIAAgBIABADg");
	this.shape_505.setTransform(388.4,244.5,0.472,0.472);

	this.shape_506 = new cjs.Shape();
	this.shape_506.graphics.f("#D6D8D8").s().p("AgFgHIABgDIAKAVg");
	this.shape_506.setTransform(379.3,239.5,0.472,0.472);

	this.shape_507 = new cjs.Shape();
	this.shape_507.graphics.f("#D6D8D8").s().p("AgHgJIACgEIANAag");
	this.shape_507.setTransform(380.9,247.7,0.472,0.472);

	this.shape_508 = new cjs.Shape();
	this.shape_508.graphics.f("#D6D8D8").s().p("AgFgIIABgCIAKAVg");
	this.shape_508.setTransform(382.4,250.3,0.472,0.472);

	this.shape_509 = new cjs.Shape();
	this.shape_509.graphics.f("#D6D8D8").s().p("AgIgKIADgEIANAdg");
	this.shape_509.setTransform(371.6,242.4,0.472,0.472);

	this.shape_510 = new cjs.Shape();
	this.shape_510.graphics.f("#D6D8D8").s().p("AgHgKIABgDIAOAcg");
	this.shape_510.setTransform(380.9,253.2,0.472,0.472);

	this.shape_511 = new cjs.Shape();
	this.shape_511.graphics.f("#D6D8D8").s().p("AgHgJIACgEIANAag");
	this.shape_511.setTransform(371.6,247.7,0.472,0.472);

	this.shape_512 = new cjs.Shape();
	this.shape_512.graphics.f("#D6D8D8").s().p("AgHgKIABgDIAOAcg");
	this.shape_512.setTransform(377.8,253.2,0.472,0.472);

	this.shape_513 = new cjs.Shape();
	this.shape_513.graphics.f("#D6D8D8").s().p("AgIgLIADgCIANAcg");
	this.shape_513.setTransform(371.6,236.9,0.472,0.472);

	this.shape_514 = new cjs.Shape();
	this.shape_514.graphics.f("#D6D8D8").s().p("AgHgKIACgDIANAbg");
	this.shape_514.setTransform(374.7,264,0.472,0.472);

	this.shape_515 = new cjs.Shape();
	this.shape_515.graphics.f("#D6D8D8").s().p("AgCgDIABgCIAEAKIAAABg");
	this.shape_515.setTransform(388.5,255.5,0.472,0.472);

	this.shape_516 = new cjs.Shape();
	this.shape_516.graphics.f("#D6D8D8").s().p("AgHgKIADgBIAMAXg");
	this.shape_516.setTransform(368.5,237,0.472,0.472);

	this.shape_517 = new cjs.Shape();
	this.shape_517.graphics.f("#D6D8D8").s().p("AgIgKIACgEIAPAdg");
	this.shape_517.setTransform(368.4,242.4,0.472,0.472);

	this.shape_518 = new cjs.Shape();
	this.shape_518.graphics.f("#D6D8D8").s().p("AgHgJIACgEIANAag");
	this.shape_518.setTransform(368.5,247.7,0.472,0.472);

	this.shape_519 = new cjs.Shape();
	this.shape_519.graphics.f("#D6D8D8").s().p("AgFgHIABgCIAKATg");
	this.shape_519.setTransform(388.6,266.5,0.472,0.472);

	this.shape_520 = new cjs.Shape();
	this.shape_520.graphics.f("#D6D8D8").s().p("AgHgJIACgEIANAag");
	this.shape_520.setTransform(390.3,247.7,0.472,0.472);

	this.shape_521 = new cjs.Shape();
	this.shape_521.graphics.f("#D6D8D8").s().p("AgHgKIACgDIAOAcg");
	this.shape_521.setTransform(387.2,253.2,0.472,0.472);

	this.shape_522 = new cjs.Shape();
	this.shape_522.graphics.f("#D6D8D8").s().p("AgFgIIABgCIAKAVg");
	this.shape_522.setTransform(379.3,266.5,0.472,0.472);

	this.shape_523 = new cjs.Shape();
	this.shape_523.graphics.f("#D6D8D8").s().p("AgFgIIABgCIAKAVg");
	this.shape_523.setTransform(369.9,266.5,0.472,0.472);

	this.shape_524 = new cjs.Shape();
	this.shape_524.graphics.f("#D6D8D8").s().p("AgIgKIACgDIAPAcg");
	this.shape_524.setTransform(368.4,253.2,0.472,0.472);

	this.shape_525 = new cjs.Shape();
	this.shape_525.graphics.f("#D6D8D8").s().p("AgFgIIABgCIAKAVg");
	this.shape_525.setTransform(366.8,250.3,0.472,0.472);

	this.shape_526 = new cjs.Shape();
	this.shape_526.graphics.f("#D6D8D8").s().p("AgHgJIABgEIAOAag");
	this.shape_526.setTransform(387.2,247.7,0.472,0.472);

	this.shape_527 = new cjs.Shape();
	this.shape_527.graphics.f("#D6D8D8").s().p("AgHgLIACgCIAOAcg");
	this.shape_527.setTransform(387.2,236.9,0.472,0.472);

	this.shape_528 = new cjs.Shape();
	this.shape_528.graphics.f("#D6D8D8").s().p("AgFgIIABgCIAKAVg");
	this.shape_528.setTransform(385.5,266.5,0.472,0.472);

	this.shape_529 = new cjs.Shape();
	this.shape_529.graphics.f("#D6D8D8").s().p("AgHgKIACgEIAOAdg");
	this.shape_529.setTransform(387.2,242.4,0.472,0.472);

	this.shape_530 = new cjs.Shape();
	this.shape_530.graphics.f("#D6D8D8").s().p("AgFgIIABgCIAKAVg");
	this.shape_530.setTransform(382.4,266.5,0.472,0.472);

	this.shape_531 = new cjs.Shape();
	this.shape_531.graphics.f("#D6D8D8").s().p("AgHgKIACgDIANAbg");
	this.shape_531.setTransform(371.6,264,0.472,0.472);

	this.shape_532 = new cjs.Shape();
	this.shape_532.graphics.f("#D6D8D8").s().p("AAAABIABgDIAAABIgBAEg");
	this.shape_532.setTransform(368,269,0.472,0.472);

	this.shape_533 = new cjs.Shape();
	this.shape_533.graphics.f("#D6D8D8").s().p("AgHgKIABgDIAOAbg");
	this.shape_533.setTransform(387.2,264,0.472,0.472);

	this.shape_534 = new cjs.Shape();
	this.shape_534.graphics.f("#D6D8D8").s().p("AgHgKIABgEIAPAdg");
	this.shape_534.setTransform(390.3,242.4,0.472,0.472);

	this.shape_535 = new cjs.Shape();
	this.shape_535.graphics.f("#D6D8D8").s().p("AgFgHIABgDIAKAVg");
	this.shape_535.setTransform(388.6,239.5,0.472,0.472);

	this.shape_536 = new cjs.Shape();
	this.shape_536.graphics.f("#D6D8D8").s().p("AgFgIIABgCIAKAVg");
	this.shape_536.setTransform(385.5,250.3,0.472,0.472);

	this.shape_537 = new cjs.Shape();
	this.shape_537.graphics.f("#D6D8D8").s().p("AgGgIIACgDIALAWIAAABg");
	this.shape_537.setTransform(387.1,258.5,0.472,0.472);

	this.shape_538 = new cjs.Shape();
	this.shape_538.graphics.f("#D6D8D8").s().p("AgFgIIABgCIAKAVg");
	this.shape_538.setTransform(388.6,250.3,0.472,0.472);

	this.shape_539 = new cjs.Shape();
	this.shape_539.graphics.f("#D6D8D8").s().p("AgHgKIACgDIANAbg");
	this.shape_539.setTransform(384,258.6,0.472,0.472);

	this.shape_540 = new cjs.Shape();
	this.shape_540.graphics.f("#D6D8D8").s().p("AgHgKIABgDIAOAbg");
	this.shape_540.setTransform(380.9,258.6,0.472,0.472);

	this.shape_541 = new cjs.Shape();
	this.shape_541.graphics.f("#D6D8D8").s().p("AgFgIIABgCIAKAVg");
	this.shape_541.setTransform(369.9,250.3,0.472,0.472);

	this.shape_542 = new cjs.Shape();
	this.shape_542.graphics.f("#D6D8D8").s().p("AgDgFIABgCIAHAPg");
	this.shape_542.setTransform(385.4,255.6,0.472,0.472);

	this.shape_543 = new cjs.Shape();
	this.shape_543.graphics.f("#D6D8D8").s().p("AgFgHIABgDIAKAVg");
	this.shape_543.setTransform(366.8,239.5,0.472,0.472);

	this.shape_544 = new cjs.Shape();
	this.shape_544.graphics.f("#D6D8D8").s().p("AgFgHIABgDIAKAVg");
	this.shape_544.setTransform(385.5,239.5,0.472,0.472);

	this.shape_545 = new cjs.Shape();
	this.shape_545.graphics.f("#D6D8D8").s().p("AgHgKIACgDIANAbg");
	this.shape_545.setTransform(377.8,258.6,0.472,0.472);

	this.shape_546 = new cjs.Shape();
	this.shape_546.graphics.f("#D6D8D8").s().p("AgHgKIACgDIANAbg");
	this.shape_546.setTransform(377.8,264,0.472,0.472);

	this.shape_547 = new cjs.Shape();
	this.shape_547.graphics.f("#D6D8D8").s().p("AgHgKIACgDIANAbg");
	this.shape_547.setTransform(380.9,264,0.472,0.472);

	this.shape_548 = new cjs.Shape();
	this.shape_548.graphics.f("#D6D8D8").s().p("AgHgKIACgDIANAbg");
	this.shape_548.setTransform(374.7,258.6,0.472,0.472);

	this.shape_549 = new cjs.Shape();
	this.shape_549.graphics.f("#D6D8D8").s().p("AgFgHIABgDIAKAVg");
	this.shape_549.setTransform(369.9,239.5,0.472,0.472);

	this.shape_550 = new cjs.Shape();
	this.shape_550.graphics.f("#D6D8D8").s().p("AgHgKIACgDIANAbg");
	this.shape_550.setTransform(384.1,264,0.472,0.472);

	this.shape_551 = new cjs.Shape();
	this.shape_551.graphics.f("#2F2F35").s().p("ACBLIIg/gJIgIlwQgJl2gFgkIgglJQg5GXAAAPIgrKwIjFAAIANorIAOlSIAyoOQA0AiDLgKQBmgFBcgMIAZCtQAEApAIBZQAIBsAAAkQAAAigLHHIgLHBIguAcQgOAHggAAQgSAAgZgCg");
	this.shape_551.setTransform(377.6,304.9,0.472,0.472);

	this.shape_552 = new cjs.Shape();
	this.shape_552.graphics.f("#00001F").s().p("AArBDIhwgiQhBADgIgGQgFgEgBgdIAAgcIAMgdICUgGIAQAkIAhASQAlASASAIQAjAQgDAXQgBAOgEAAg");
	this.shape_552.setTransform(388.8,340.7,0.472,0.472);

	this.shape_553 = new cjs.Shape();
	this.shape_553.graphics.f("#00001F").s().p("AhCBNQgPgNgHgUQgHgTAYglIAagjIAJgmIB/AAIAABcQAAAXgEAFQgJASghARQgZANADACIhMACQgGgDgHgHg");
	this.shape_553.setTransform(367.6,341.8,0.472,0.472);

	this.shape_554 = new cjs.Shape();
	this.shape_554.graphics.f("#C4BA89").s().p("AgdAmQgKgHACgGQADgLASgOIAogjQAFgEAGAFQADADAAADQABAEgDACIgtA7IgBABg");
	this.shape_554.setTransform(242,216.3,0.87,0.87);

	this.shape_555 = new cjs.Shape();
	this.shape_555.graphics.f("#7F795D").s().p("AgMADIAUgLIAFAIQgBAGgMAEg");
	this.shape_555.setTransform(234.5,209.8,0.87,0.87);

	this.shape_556 = new cjs.Shape();
	this.shape_556.graphics.f("#7F795D").s().p("AgMgBIAEgJIAVAOIgKAHQgPgHAAgFg");
	this.shape_556.setTransform(232.2,209.6,0.87,0.87);

	this.shape_557 = new cjs.Shape();
	this.shape_557.graphics.f("#DBA771").s().p("AAmANQgBgHgNAAQgRACgHgBQgKAAgJgHIgHgGQgEAOgCACQgBABgCAKIgCAJIgEgGQgEgGAAgCQADgJgCgGQgDgLAFgFIAAAAQgBgBANgGQAOgGAOgBQANgBASAKQAQAKABAHQABAHgCALQgBAKgCAAQgCABgCADIgBABQACgGgBgLg");
	this.shape_557.setTransform(233.3,200.8,0.87,0.87);

	this.shape_558 = new cjs.Shape();
	this.shape_558.graphics.f("#C4BA89").s().p("AABA7QABgLgCgTQAAgTgBAFQAAAEgRAoIgeAAQAchmAHgFQALgGAUgCQAMgEALAHQAGADADAEIAABpg");
	this.shape_558.setTransform(229.5,214.5,0.87,0.87);

	this.shape_559 = new cjs.Shape();
	this.shape_559.graphics.f("#C4BA89").s().p("AAUA2QgOgggBgHQAAgEgBASIgCAeIgyAAIADhpIAJgHQAKgHAMAEIAMACQANACAGAEQAFADAKAcQAKAcAGAfQADALgUAGg");
	this.shape_559.setTransform(237.1,214.5,0.87,0.87);

	this.shape_560 = new cjs.Shape();
	this.shape_560.graphics.f("#FABD99").s().p("AgGAzQgSgIgKgRIgBgJIAAAAQgBAAAAAAQgBAAAAAAQAAAAgBgBQAAAAAAgBIAAAAIgCgGIgCgOIABgDIACABIABABIABAAQgBgGAAgHQAAgPAIgEIAJgHQAKgGAKAAIABAAQARgBANAOQAJAEAAAPQAAAHgCAGIAAACIABgBQABgBAAAAQABgBAAAAQABgBAAAAQABAAAAAAQABABgBAHIAAAAIgDAPQAAABAAAAQgBABAAAAQgBAAAAAAQAAAAgBAAIAAAAIgBAJIgBABQgJAPgRAJIAAAAIgHABIgHgBg");
	this.shape_560.setTransform(233.2,203.8,0.87,0.87);

	this.shape_561 = new cjs.Shape();
	this.shape_561.graphics.f("#EFAB83").s().p("AgDAUQgcgBAHgHQAKgKABgRIANgDQANgCAAAFQABAIAMAaIgUABIgJAAg");
	this.shape_561.setTransform(233.4,208.3,0.87,0.87);

	this.shape_562 = new cjs.Shape();
	this.shape_562.graphics.f("#FABD99").s().p("AggAcIA7hBQACgCADABQAAAAABAAQAAABAAAAQAAAAAAABQAAAAAAABQAAAEgDACIgCABQgFAFABABIAEAFQACAEAAAFQgCAOgVACIgKAKIgVAWg");
	this.shape_562.setTransform(245,213.1,0.87,0.87);

	this.shape_563 = new cjs.Shape();
	this.shape_563.graphics.f("#FFFFFF").s().p("AgMANQgGgFAAgIQAAgHAGgFQAFgGAHAAQAIAAAFAGQAGAFAAAHQAAAIgGAFQgFAGgIAAQgHAAgFgGg");
	this.shape_563.setTransform(121.9,246.7,0.87,0.87);

	this.shape_564 = new cjs.Shape();
	this.shape_564.graphics.f("#FFFFFF").s().p("AgMANQgGgFAAgIQAAgHAGgFQAFgGAHAAQAIAAAGAGQAFAFAAAHQAAAIgFAFQgGAGgIAAQgHAAgFgGg");
	this.shape_564.setTransform(127.7,246.7,0.87,0.87);

	this.shape_565 = new cjs.Shape();
	this.shape_565.graphics.f("#FFFFFF").s().p("AgMANQgGgFAAgIQAAgHAGgFQAFgGAHAAQAIAAAFAGQAGAFAAAHQAAAIgGAFQgFAGgIAAQgHAAgFgGg");
	this.shape_565.setTransform(133.6,246.7,0.87,0.87);

	this.shape_566 = new cjs.Shape();
	this.shape_566.graphics.f().s("#FFFFFF").p("AiBBkIA5glQAiASAqAAQA2AAAmgbQAmgcAAgmQAAgngmgbQgmgcg2AAQg1AAgmAcQgmAbAAAnQAAAZASAWg");
	this.shape_566.setTransform(127.3,247.9,0.87,0.87);

	this.shape_567 = new cjs.Shape();
	this.shape_567.graphics.f("#B1C0C9").s().p("AhtAmQgSgWAAgYQAAgnAmgcQAmgcA1AAQA2AAAmAcQAmAcAAAnQAAAmgmAbQgmAcg2AAQgqAAgigTIg5Amg");
	this.shape_567.setTransform(127.5,247.5,0.87,0.87);

	this.shape_568 = new cjs.Shape();
	this.shape_568.graphics.f("#FFFFFF").s().p("AgRASQgIgIAAgKQAAgKAIgHQAHgIAKAAQALAAAHAIQAHAHAAAKQAAAKgHAIQgHAHgLABQgKgBgHgHg");
	this.shape_568.setTransform(354.1,288.9,0.87,0.87);

	this.shape_569 = new cjs.Shape();
	this.shape_569.graphics.f("#FFFFFF").s().p("AgRASQgHgIAAgKQAAgKAHgHQAIgIAJAAQALAAAHAIQAIAHgBAKQABAKgIAIQgHAHgLABQgJgBgIgHg");
	this.shape_569.setTransform(346.1,288.9,0.87,0.87);

	this.shape_570 = new cjs.Shape();
	this.shape_570.graphics.f("#FFFFFF").s().p("AgRASQgIgIABgKQgBgKAIgHQAIgIAJAAQAKAAAIAIQAIAHgBAKQABAKgIAIQgIAHgKABQgJgBgIgHg");
	this.shape_570.setTransform(338.2,288.9,0.87,0.87);

	this.shape_571 = new cjs.Shape();
	this.shape_571.graphics.f().s("#FFFFFF").p("ACxiIIhMAzQgwgZg5AAQhJAAg0AlQgzAmAAA0QAAA1AzAlQA0AlBJAAQBIAAA0glQA0glAAg1QAAgigZgeg");
	this.shape_571.setTransform(346.5,287.5,0.87,0.87);

	this.shape_572 = new cjs.Shape();
	this.shape_572.graphics.f("#B1C0C9").s().p("Ah/BnQgzglAAg1QAAg0AzglQA0gmBJAAQA5AAAwAZIBMgzIgeBZQAZAeAAAiQAAA1g0AlQg0AmhIAAQhJAAg0gmg");
	this.shape_572.setTransform(346.3,287.8,0.87,0.87);

	this.shape_573 = new cjs.Shape();
	this.shape_573.graphics.f().s("#FFFFFF").p("ACNBQQAtg2AAhGQAAhQg4g5Qg5g4hPAAQhRAAg4A4Qg5A5AABQQAABQA5A4QA5A5BQAAQAMAAASgCICtBWg");
	this.shape_573.setTransform(236.4,214.3,0.87,0.87);

	this.shape_574 = new cjs.Shape();
	this.shape_574.graphics.f("#C0C9CE").s().p("AAaCVQgSADgMAAQhQAAg5g5Qg5g5AAhPQAAhQA5g5QA4g5BRAAQBPAAA5A5QA4A5AABQQAABGgtA2IA4CZg");
	this.shape_574.setTransform(236.3,214.1,0.87,0.87);

	this.shape_575 = new cjs.Shape();
	this.shape_575.graphics.f("#7A7476").s().p("Aj/AJIAAgRIH/AAIAAARg");
	this.shape_575.setTransform(321.2,313.6,0.87,0.87);

	this.shape_576 = new cjs.Shape();
	this.shape_576.graphics.f("#7A7476").s().p("Aj/AJIAAgRIH/AAIAAARg");
	this.shape_576.setTransform(201.8,313.6,0.87,0.87);

	this.shape_577 = new cjs.Shape();
	this.shape_577.graphics.f("#E62F33").s().p("AggAaQgDggAFgWIAMACQAOABALAAIAYgDIACASQACAUgBAQQgUADgQAAQgQAAgOgDg");
	this.shape_577.setTransform(187.2,296.3,0.87,0.87);

	this.shape_578 = new cjs.Shape();
	this.shape_578.graphics.f("#2A1213").s().p("AgWBqQgIgDgBgPIAAgQQACgDABgGQABgJgDgSQgEgRACgeQAAgVACgMQABgDAFgJIAJgRQADgFABgMIAAgJIgDAAIAAgFIAdAAIAAAFIgDAAIAAAJQABAMADAFIAJARQAFAJABADIACAhQACAegEARQgDASACAJIACAJQAEAdgNAFg");
	this.shape_578.setTransform(187.2,297.7,0.87,0.87);

	this.shape_579 = new cjs.Shape();
	this.shape_579.graphics.f("#E62F33").s().p("AgPAHIAAgLIABAAIAEgBIAXAAIABAAIACACIAAAKg");
	this.shape_579.setTransform(187.2,287.8,0.87,0.87);

	this.shape_580 = new cjs.Shape();
	this.shape_580.graphics.f("#E62F33").s().p("AggAaQgDggAFgWIAMACQAOABALgBQAVgBADgBIACASQACAUgBAQQgUADgQAAQgQAAgOgDg");
	this.shape_580.setTransform(311.1,295.4,0.87,0.87);

	this.shape_581 = new cjs.Shape();
	this.shape_581.graphics.f("#2A1213").s().p("AgWBqQgIgDgBgOIAAgRQACgEABgFQABgKgDgRQgFgWAFg6QABgDAFgKIAJgQQAFgJgBgRIgDAAIAAgGIAdAAIAAAGIgDAAIAAAJQABALADAGIAJAQQAFAKABADQACALAAAWQACAegEARQgDARACAKIACAJIAAARQgBAOgIADg");
	this.shape_581.setTransform(311.1,296.8,0.87,0.87);

	this.shape_582 = new cjs.Shape();
	this.shape_582.graphics.f("#E62F33").s().p("AgPAGIAAgJIABgBIAEgBIAXAAIABAAIACACIAAAJg");
	this.shape_582.setTransform(311.2,286.9,0.87,0.87);

	this.shape_583 = new cjs.Shape();
	this.shape_583.graphics.f("#E62F33").s().p("AgPAHIAAgLIABgBIAFgBIAWAAIABABIACACIAAAKg");
	this.shape_583.setTransform(347.5,290.6,0.87,0.87);

	this.shape_584 = new cjs.Shape();
	this.shape_584.graphics.f("#252931").s().p("AgFgQIALgEIgCAoIgFABg");
	this.shape_584.setTransform(149.8,347.7,0.87,0.87);

	this.shape_585 = new cjs.Shape();
	this.shape_585.graphics.f("#252931").s().p("AgDAWIgCgsIALADIgDAqg");
	this.shape_585.setTransform(154,348,0.87,0.87);

	this.shape_586 = new cjs.Shape();
	this.shape_586.graphics.f("#252931").s().p("AAAA1QgIgHAAgLIAAhfIAPABIACB4g");
	this.shape_586.setTransform(150,340.8,0.87,0.87);

	this.shape_587 = new cjs.Shape();
	this.shape_587.graphics.f("#323436").s().p("AgIA3IAAhvIARgBIAABwQgGADgEAAQgEAAgDgDg");
	this.shape_587.setTransform(152.5,341.4,0.87,0.87);

	this.shape_588 = new cjs.Shape();
	this.shape_588.graphics.f("#2B2E32").s().p("AikBBQgQgBgRgFQghgKgFgVQgEgWAHgZQAEgNAOghQAGgOAVAyQAbA+AbAKQAjANAjACQAfACAwgGQAwgHAngBQArgCAQAGQAYAJA0gEIgCAFQgFAFgTACQgdADimAAIgdAAQiQAAgIgFg");
	this.shape_588.setTransform(150.3,330.3,0.87,0.87);

	this.shape_589 = new cjs.Shape();
	this.shape_589.graphics.f("#2B2E32").s().p("AgZANQgFhCAOgNQAOgMAQADQAIABAGAEQgUAAgIAEQgUALABAnQADA7AAAiQgGgfgDghg");
	this.shape_589.setTransform(136.1,281.4,0.87,0.87);

	this.shape_590 = new cjs.Shape();
	this.shape_590.graphics.f("#323436").s().p("AgQAXQhPAAhAgRIgwgPQgJgFACgFQABgFAHAEQARAJApAKQA/APBGACQBJACA3gLQAegGAqgMQAfgIgBAHQAAAHgQADQhIAQgPACQgrAHhKAAIgLAAg");
	this.shape_590.setTransform(151.2,316.3,0.87,0.87);

	this.shape_591 = new cjs.Shape();
	this.shape_591.graphics.f("#3D4659").s().p("AgRAdQhPgBg+gRIgvgPQgJgIAEgKQAFgKAHAHQAJAHA5ANQBBAOAwABQBKABA5gKQASgDA4gOQAmgKgQAbQhfAch2AAIgMAAg");
	this.shape_591.setTransform(151.3,316.2,0.87,0.87);

	this.shape_592 = new cjs.Shape();
	this.shape_592.graphics.f("#323436").s().p("Ai/B0QgugJgMgaQgLgXATgzQAYg+AAgeQAAgrAjALQAIADAsAGICEALQBogBBAgQIAYgFQAGABADAJIAMA4QALAvAYA8QANAggeAUQgUAOgcAAIlDAAIgJAAQgXAAgVgEg");
	this.shape_592.setTransform(151.8,325.9,0.87,0.87);

	this.shape_593 = new cjs.Shape();
	this.shape_593.graphics.f("#323436").s().p("AiJDzQhBgTABgkQABgggCgmIgak2QgDgWAIgSQAQglA3AQQBHAVBMABQBVACBCgZQAXgJAYAOQAcAQAIAnQAFAbgOCRQgPCZAFA4QADAfhAAUQg7AThVACIgQAAQhLAAgzgQg");
	this.shape_593.setTransform(151.2,295.3,0.87,0.87);

	this.shape_594 = new cjs.Shape();
	this.shape_594.graphics.f("#626666").s().p("AjkAdIgEgRQgDgUAJgTQAQglA2APQBMAWAtAFQA7AGA2gRQBCgUAdADQAhADAQAjQANAegCAVQAAALgEAFg");
	this.shape_594.setTransform(151.3,276.8,0.87,0.87);

	this.shape_595 = new cjs.Shape();
	this.shape_595.graphics.f("#252931").s().p("AAAgFIABAGIgBAFg");
	this.shape_595.setTransform(166.4,333.3,0.87,0.87);

	this.shape_596 = new cjs.Shape();
	this.shape_596.graphics.f("#717677").s().p("AgFBKIgIiTIAbAAIgJCTg");
	this.shape_596.setTransform(151.8,352.7,0.87,0.87);

	this.shape_597 = new cjs.Shape();
	this.shape_597.graphics.f("#717677").s().p("Ah8AhIDthYIAMAQIj4BOIAAARg");
	this.shape_597.setTransform(139.5,349.4,0.87,0.87);

	this.shape_598 = new cjs.Shape();
	this.shape_598.graphics.f("#3D4659").s().p("AiCBJIAAg9IDuhUIAIAAQgCABAIAHIAJAHIgHAmIjmAuIgBAug");
	this.shape_598.setTransform(139.5,351.2,0.87,0.87);

	this.shape_599 = new cjs.Shape();
	this.shape_599.graphics.f("#231F20").s().p("AgBAbQgEABgEgEQgEgEABgFIAAgdQgBgGAEgDQAEgDAEgBIACAAQAGABADADQADADABAGIAAAdQgBAFgDAEQgDAEgGgBg");
	this.shape_599.setTransform(174.7,356.9,0.87,0.87);

	this.shape_600 = new cjs.Shape();
	this.shape_600.graphics.f("#717677").s().p("AB9AiIj9hPIAOgJIDwBUIADAGIgDATg");
	this.shape_600.setTransform(164.5,349.9,0.87,0.87);

	this.shape_601 = new cjs.Shape();
	this.shape_601.graphics.f("#3D4659").s().p("ABsBJIgBguIjmguIgHgsQASgIgDgBQAAAAgBAAQAAAAABAAQAAAAABAAQAAAAABAAIAFAAIDvBVIAAA8g");
	this.shape_601.setTransform(164.4,351.7,0.87,0.87);

	this.shape_602 = new cjs.Shape();
	this.shape_602.graphics.f("#3D4659").s().p("AAfANIAAgIIgZAAIgvgRIBTAEIAAAVg");
	this.shape_602.setTransform(160.8,347.3,0.87,0.87);

	this.shape_603 = new cjs.Shape();
	this.shape_603.graphics.f("#3D4659").s().p("AgoANIAAgVIBRgEIguARIgZAAIAAAIg");
	this.shape_603.setTransform(141.6,347.2,0.87,0.87);

	this.shape_604 = new cjs.Shape();
	this.shape_604.graphics.f("#231F20").s().p("AAAAcQgFgBgEgDQgEgDAAgGIAAgdQAAgFAEgEQAEgEAFABIABAAQAFgBAEAEQADAEAAAFIAAAdQAAAGgDADQgEADgFABg");
	this.shape_604.setTransform(138.8,350.6,0.87,0.87);

	this.shape_605 = new cjs.Shape();
	this.shape_605.graphics.f("#231F20").s().p("AAAAcQgFgBgEgDQgDgDAAgGIAAgdQAAgFADgEQAEgEAFABIABAAQAFgBAEAEQADAEAAAFIAAAdQAAAGgDADQgEADgFABg");
	this.shape_605.setTransform(163.8,350.6,0.87,0.87);

	this.shape_606 = new cjs.Shape();
	this.shape_606.graphics.f("#231F20").s().p("AAAAZQgGAAgDgEQgEgDAAgFIAAgYQAAgFAEgEQADgEAGAAIABAAQAFAAAEAEQAEAEgBAFIAAAYQABAFgEADQgEAEgFAAg");
	this.shape_606.setTransform(128.9,357.1,0.87,0.87);

	this.shape_607 = new cjs.Shape();
	this.shape_607.graphics.f("#231F20").s().p("AAAAbQgFAAgEgDQgDgDgBgGIAAgeQABgFADgDQADgDAGAAIACAAQAFAAADADQADADAAAFIAAAeQAAAFgDAEQgDADgFAAg");
	this.shape_607.setTransform(151.8,361.4,0.87,0.87);

	this.shape_608 = new cjs.Shape();
	this.shape_608.graphics.f("#717677").s().p("AgFAUIAAgoQAAgGAFABQAGgBAAAGIAAAoQAAAGgGABQgFgBAAgGg");
	this.shape_608.setTransform(165.1,350.6,0.87,0.87);

	this.shape_609 = new cjs.Shape();
	this.shape_609.graphics.f("#717677").s().p("AgEAUIAAgoQgBgGAFABQAFgBABAGIAAAoQgBAGgFABQgFgBABgGg");
	this.shape_609.setTransform(162.5,350.6,0.87,0.87);

	this.shape_610 = new cjs.Shape();
	this.shape_610.graphics.f("#717677").s().p("AgFAUIAAgoQABgGAEABQAGgBgBAGIAAAoQABAGgGABQgEgBgBgGg");
	this.shape_610.setTransform(140.2,350.6,0.87,0.87);

	this.shape_611 = new cjs.Shape();
	this.shape_611.graphics.f("#717677").s().p("AgFAUIAAgoQAAgGAFABQAGgBAAAGIAAAoQAAAGgGABQgFgBAAgGg");
	this.shape_611.setTransform(137.6,350.6,0.87,0.87);

	this.shape_612 = new cjs.Shape();
	this.shape_612.graphics.f("#717677").s().p("AgEAZQgCgDAAgDIAAglQAAgIAGAAQAHAAAAAIIAAAlQAAADgCADQgDABgCAAQgCAAgCgBg");
	this.shape_612.setTransform(130.7,357.1,0.87,0.87);

	this.shape_613 = new cjs.Shape();
	this.shape_613.graphics.f("#717677").s().p("AgEAZQgCgDAAgDIAAglQAAgEACgCQACgCACAAQAHAAAAAIIAAAlQAAAIgHgBQgCAAgCgBg");
	this.shape_613.setTransform(127.4,357.1,0.87,0.87);

	this.shape_614 = new cjs.Shape();
	this.shape_614.graphics.f("#717677").s().p("AgGATIAAglQAAgIAGAAQAHAAAAAIIAAAlQAAAIgHgBQgGABAAgIg");
	this.shape_614.setTransform(176.4,357.1,0.87,0.87);

	this.shape_615 = new cjs.Shape();
	this.shape_615.graphics.f("#717677").s().p("AgGATIAAglQAAgIAGAAQAHAAAAAIIAAAlQAAADgCADQgDABgCAAQgGABAAgIg");
	this.shape_615.setTransform(173.1,357.1,0.87,0.87);

	this.shape_616 = new cjs.Shape();
	this.shape_616.graphics.f("#717677").s().p("AgGAZIAAgxQAAgHAGAAQAHAAAAAHIAAAxQAAAHgHAAQgGAAAAgHg");
	this.shape_616.setTransform(153.4,361.5,0.87,0.87);

	this.shape_617 = new cjs.Shape();
	this.shape_617.graphics.f("#717677").s().p("AgGAZIAAgxQAAgHAGAAQAHAAAAAHIAAAxQAAAHgHAAQgGAAAAgHg");
	this.shape_617.setTransform(150.1,361.5,0.87,0.87);

	this.shape_618 = new cjs.Shape();
	this.shape_618.graphics.f("#717677").s().p("AgaADIgdgJIBeAJIARAEg");
	this.shape_618.setTransform(159.6,345.9,0.87,0.87);

	this.shape_619 = new cjs.Shape();
	this.shape_619.graphics.f("#717677").s().p("AgpAAIBegDIgXAEIhSAEg");
	this.shape_619.setTransform(142.6,346,0.87,0.87);

	this.shape_620 = new cjs.Shape();
	this.shape_620.graphics.f("#717677").s().p("AgZA2IgFgDIAAhsIA9ABIAABrQgMAIgXAAQgOAAgHgFg");
	this.shape_620.setTransform(151.9,341.2,0.87,0.87);

	this.shape_621 = new cjs.Shape();
	this.shape_621.graphics.f("#3D4659").s().p("AgTgjIAFgkIAdgCIAFArIgNBoIgRAAg");
	this.shape_621.setTransform(151.9,352.6,0.87,0.87);

	this.shape_622 = new cjs.Shape();
	this.shape_622.graphics.f("#B3ADAE").s().p("A2JAzQgVAAgOgPQgPgPAAgUIAAgBQAAgVAPgOQAOgOAVAAMAsUAAAQAUAAAPAOQAOAOAAAVIAAABQAAAUgOAPQgPAPgUAAg");
	this.shape_622.setTransform(231.9,308.4,0.87,0.87);

	this.shape_623 = new cjs.Shape();
	this.shape_623.graphics.f("#7A7476").s().p("A2IAyQgVAAgPgOQgPgPAAgVQAAgUAPgPQAPgPAVABMAsSAAAQAUgBAPAPQAPAPAAAUQAAAVgPAPQgPAOgUAAg");
	this.shape_623.setTransform(231.9,310,0.87,0.87);

	this.shape_624 = new cjs.Shape();
	this.shape_624.graphics.f("#3F3231").s().p("AhbBEIgGgCQgFABgHgxQgEgZAVgRQgDghAfgOIgFAHQgFAJgCAGIABABIABAAQAKgMATgJQAfgOArgBQgQACgMAHQAAAAAAAAQAAAAAAAAQAAABAAAAQAAAAAAABIABAAQASgCATACQAcACARAMQgFgBgHABIgBAAIABABQANAFAKAKQAQAPAAAVIgKgLIgBAAQAGARgEAQQgBgFgFgEQgBAZgHAhQgIAAgFAIIgDAIQADgvgMgRQgTgdg0ABIgxAHQgKAVgMAPIgEA3QgBgOgHgEg");
	this.shape_624.setTransform(267.8,227.2,0.87,0.87);

	this.shape_625 = new cjs.Shape();
	this.shape_625.graphics.f("#3F3231").s().p("AAYAPIAAAAQgEAAgEgDQgFgEAAgFIAAgCQgEgDgFAAIAAABIgBAAIAAgBQgEAAgEADIAAACQAAALgMABIgBAAIgmAAIgBAAQgLgFAAgIIAAgCIgLABIgCgHIAOgCQACgFAJgBIAlAAQAJgBAFAIQAEgCAFAAQAGAAAEACQAEgIAKABIAkAAQAJABADAFIAKABIgBAFIgIACIAAACQABAHgMAGIgBAAgAARgHIAAALQAAAFAGADIApAAQAFgCAAgGIAAgLQgCgDgDAAIgqAAQgFABAAACgAhAgHIAAALQAAAFAFADIAqAAQAFgCAAgGIAAgLQgCgDgEAAIgqAAQgEABAAACg");
	this.shape_625.setTransform(267.1,233,0.87,0.87);

	this.shape_626 = new cjs.Shape();
	this.shape_626.graphics.f("#E2BB90").s().p("AgaAsQgLgHADgWQAEgVAOgQIAQgZIAeASQAIAfgDACIgDAEQgBAAgCgFQgCgDgEAEIgIATQgNAZgOAAQgHAAgHgEg");
	this.shape_626.setTransform(247.7,281.6,0.87,0.87);

	this.instance = new lib.Group_27();
	this.instance.parent = this;
	this.instance.setTransform(277.3,267.7,0.87,0.87,0,0,0,7.7,1.7);
	this.instance.alpha = 0.391;

	this.instance_1 = new lib.Group_1_4();
	this.instance_1.parent = this;
	this.instance_1.setTransform(278.6,266.7,0.87,0.87,0,0,0,9.2,1.2);
	this.instance_1.alpha = 0.391;

	this.instance_2 = new lib.Group_2_4();
	this.instance_2.parent = this;
	this.instance_2.setTransform(278.6,265.4,0.87,0.87,0,0,0,9,1.7);
	this.instance_2.alpha = 0.391;

	this.instance_3 = new lib.Group_3_4();
	this.instance_3.parent = this;
	this.instance_3.setTransform(278.2,256.4,0.87,0.87,0,0,0,8.8,10.5);
	this.instance_3.alpha = 0.391;

	this.instance_4 = new lib.Group_4_4();
	this.instance_4.parent = this;
	this.instance_4.setTransform(280.9,256.2,0.87,0.87,0,0,0,3.7,8.3);
	this.instance_4.alpha = 0.391;

	this.instance_5 = new lib.Group_5_4();
	this.instance_5.parent = this;
	this.instance_5.setTransform(280,258.1,0.87,0.87,0,0,0,3.5,7.5);
	this.instance_5.alpha = 0.391;

	this.instance_6 = new lib.Group_6_4();
	this.instance_6.parent = this;
	this.instance_6.setTransform(279.2,259.6,0.87,0.87,0,0,0,2.9,5.7);
	this.instance_6.alpha = 0.391;

	this.instance_7 = new lib.Group_7_4();
	this.instance_7.parent = this;
	this.instance_7.setTransform(278.6,260.9,0.87,0.87,0,0,0,2.2,4.4);
	this.instance_7.alpha = 0.391;

	this.shape_627 = new cjs.Shape();
	this.shape_627.graphics.f("#E2BB90").s().p("AgRAdQgIgCgCgIQgBgGAAgNQAAgKAIgEQAFgCAEAAQgGAAAEgJQACgGAGADIAIAJQAGAFAIAAQAKAFACAOQABAHgCAGQgGACgDAEQgEADgMACIgKABIgKgBg");
	this.shape_627.setTransform(268,265.5,0.87,0.87);

	this.shape_628 = new cjs.Shape();
	this.shape_628.graphics.f("#3C3D3E").s().p("AgZAAQAAgCAZAAQAaAAAAACQAAADgaAAQgZAAAAgDg");
	this.shape_628.setTransform(262.4,261.8,0.87,0.87);

	this.shape_629 = new cjs.Shape();
	this.shape_629.graphics.f("#9D3728").s().p("AgTAsQgFAAgEgEQgEgEAAgFIAAg9QAAgFAEgEQAFgEAEAAIAmAAQAGAAAEAEQAEAEAAAFIAAA9QAAAFgEAEQgEAEgGAAg");
	this.shape_629.setTransform(262.4,265.1,0.87,0.87);

	this.shape_630 = new cjs.Shape();
	this.shape_630.graphics.f("#BBCACB").s().p("AAXAbIhjgJQgFAAgEgEQgEgFgBgFQAAgGAEgFQAEgEAHgBICSgPQAGAAAFADQAFADABAGQAHAcgMAHQgKAGgYABIgJABIgRgBg");
	this.shape_630.setTransform(277.7,265.8,0.87,0.87);

	this.instance_8 = new lib.Group_8_4();
	this.instance_8.parent = this;
	this.instance_8.setTransform(278.7,253.5,0.87,0.87,0,0,0,2.4,8.3);
	this.instance_8.alpha = 0.391;

	this.instance_9 = new lib.Group_9_4();
	this.instance_9.parent = this;
	this.instance_9.setTransform(258.3,253.5,0.87,0.87,0,0,0,2.4,8.3);
	this.instance_9.alpha = 0.391;

	this.instance_10 = new lib.Group_10_4();
	this.instance_10.parent = this;
	this.instance_10.setTransform(254.5,265.3,0.87,0.87,0,0,0,6.3,15.7);
	this.instance_10.alpha = 0.391;

	this.instance_11 = new lib.Group_11_4();
	this.instance_11.parent = this;
	this.instance_11.setTransform(255.1,267.2,0.87,0.87,0,0,0,6.2,14.2);
	this.instance_11.alpha = 0.391;

	this.instance_12 = new lib.Group_12_4();
	this.instance_12.parent = this;
	this.instance_12.setTransform(255.3,269,0.87,0.87,0,0,0,5.9,12.6);
	this.instance_12.alpha = 0.391;

	this.instance_13 = new lib.Group_13_4();
	this.instance_13.parent = this;
	this.instance_13.setTransform(253.6,263.2,0.87,0.87,0,0,0,6.5,17.6);
	this.instance_13.alpha = 0.391;

	this.instance_14 = new lib.Group_14_4();
	this.instance_14.parent = this;
	this.instance_14.setTransform(252.6,262.4,0.87,0.87,0,0,0,6.5,17.8);
	this.instance_14.alpha = 0.391;

	this.shape_631 = new cjs.Shape();
	this.shape_631.graphics.f("#A9B3BC").s().p("AgcAHIAugbIALAUQgCANgcAIg");
	this.shape_631.setTransform(270.1,246.2,0.87,0.87);

	this.shape_632 = new cjs.Shape();
	this.shape_632.graphics.f("#A9B3BC").s().p("AgdgCIALgVIAwAhIgXAOQgigOgCgMg");
	this.shape_632.setTransform(265.1,245.9,0.87,0.87);

	this.instance_15 = new lib.Group_15_4();
	this.instance_15.parent = this;
	this.instance_15.setTransform(269.2,263.6,0.87,0.87,0,0,0,1.2,20.3);
	this.instance_15.alpha = 0.391;

	this.instance_16 = new lib.Group_16_4();
	this.instance_16.parent = this;
	this.instance_16.setTransform(271.1,263.2,0.87,0.87,0,0,0,1.4,19.9);
	this.instance_16.alpha = 0.391;

	this.instance_17 = new lib.Group_17_4();
	this.instance_17.parent = this;
	this.instance_17.setTransform(272.6,263.1,0.87,0.87,0,0,0,1.2,20);
	this.instance_17.alpha = 0.391;

	this.instance_18 = new lib.Group_18_1();
	this.instance_18.parent = this;
	this.instance_18.setTransform(277.1,262.7,0.87,0.87,0,0,0,1.5,19.3);
	this.instance_18.alpha = 0.391;

	this.instance_19 = new lib.Group_19_1();
	this.instance_19.parent = this;
	this.instance_19.setTransform(275.9,263,0.87,0.87,0,0,0,1.5,20.1);
	this.instance_19.alpha = 0.391;

	this.instance_20 = new lib.Group_20_1();
	this.instance_20.parent = this;
	this.instance_20.setTransform(274.1,262.5,0.87,0.87,0,0,0,1.4,19.9);
	this.instance_20.alpha = 0.391;

	this.instance_21 = new lib.Group_21_1();
	this.instance_21.parent = this;
	this.instance_21.setTransform(267.7,263.6,0.87,0.87,0,0,0,1.5,20.3);
	this.instance_21.alpha = 0.391;

	this.instance_22 = new lib.Group_22();
	this.instance_22.parent = this;
	this.instance_22.setTransform(266,263.2,0.87,0.87,0,0,0,1.7,19.9);
	this.instance_22.alpha = 0.391;

	this.instance_23 = new lib.Group_23();
	this.instance_23.parent = this;
	this.instance_23.setTransform(264.4,263.1,0.87,0.87,0,0,0,1.5,20);
	this.instance_23.alpha = 0.391;

	this.instance_24 = new lib.Group_24();
	this.instance_24.parent = this;
	this.instance_24.setTransform(259.8,262.7,0.87,0.87,0,0,0,1.2,19.3);
	this.instance_24.alpha = 0.391;

	this.instance_25 = new lib.Group_25();
	this.instance_25.parent = this;
	this.instance_25.setTransform(261,263,0.87,0.87,0,0,0,1.3,20.1);
	this.instance_25.alpha = 0.391;

	this.instance_26 = new lib.Group_26();
	this.instance_26.parent = this;
	this.instance_26.setTransform(263,262.5,0.87,0.87,0,0,0,1.5,19.9);
	this.instance_26.alpha = 0.391;

	this.shape_633 = new cjs.Shape();
	this.shape_633.graphics.f("#BBCACB").s().p("AAxDAIgrgJIAJhwQACgSgEgzQgDgygBANQgBAKgtBsIguBrIgpgYQAVhTAYhTQAwioAOgKQAWgOAxgDQAagJAYAOQAMAIAHAJIACC5QgCC7gOABIgFAAQgQAAgngIg");
	this.shape_633.setTransform(257.9,262.7,0.87,0.87);

	this.shape_634 = new cjs.Shape();
	this.shape_634.graphics.f("#CCD0D0").s().p("AhhDIQgOgBAEi7IAGi5IATgRQAYgOAaAJIAbADQAdAFAOAJQALAHAWA9QAXBAAOBGQADAPgVAMIgWAKIgYgKQgfhGgBgQQgBgNgDAyQgEAzABASIAJBwQhNARgcAAIgGAAg");
	this.shape_634.setTransform(275.8,262.7,0.87,0.87);

	this.shape_635 = new cjs.Shape();
	this.shape_635.graphics.f("#E2BB90").s().p("AgOBxQgKgEgNgJQgagRgOgZIgBgDIgBgQIgBAAQgDgBgDgDIgEgQIgFgfQAAgHACAAQACgBAEADIACAEIABgBQgDgNAAgQQAAgiASgJIABAAIATgOQAXgPAWAAIAFAAQAXgBAYAPQAMAHAIAIQASAJAAAiIgCAUIgBAJIgBADIACgCQAGgGADABQAEACgDAPIAAABIgHAiIAAABQgCADgFABIAAAAIgCATIgBADQgZAjgiARIgBABIgMACIgDAAQgJAAgHgDg");
	this.shape_635.setTransform(267.3,232.9,0.87,0.87);

	this.shape_636 = new cjs.Shape();
	this.shape_636.graphics.f("#D7AE86").s().p("AgHArQg+gCAPgQQAOgNAHgZIAEgWIAdgHQAegEAAALQABASAbA7IgtACIgUgBg");
	this.shape_636.setTransform(267.6,242.9,0.87,0.87);

	this.shape_637 = new cjs.Shape();
	this.shape_637.graphics.f("#000007").s().p("AA+FUIgfgFIgDivQgFiygCgRIgPidQgbDBAAAHIgVFJIheAAIANmqIAYj7QAZARBhgFQAwgCAsgGIAMBSIAGA+QAEA0AAARIgLG/IgWANQgHAEgPAAIgUgBg");
	this.shape_637.setTransform(267.1,307.8,0.87,0.87);

	this.shape_638 = new cjs.Shape();
	this.shape_638.graphics.f("#554436").s().p("AAUAgIg0gQQgfABgEgDQgDgCAAgNIAAgOIAGgNIBGgDIAHARIAqAVQARAHgBALQgBAHgCAAg");
	this.shape_638.setTransform(276.9,339.3,0.87,0.87);

	this.shape_639 = new cjs.Shape();
	this.shape_639.graphics.f("#554436").s().p("AgpAVQgEgJAMgRIAMgRIAEgSIA8AAIAAArQAAALgBADQgEAIgQAIQgNAHACAAIgkABQgLgFgFgPg");
	this.shape_639.setTransform(258.3,340.3,0.87,0.87);

	this.shape_640 = new cjs.Shape();
	this.shape_640.graphics.f("#2B2E32").s().p("AiXgGQgBAAAAAAQgBAAAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQABgBAAAAQAAAAABAAQAAAAABAAIANADQANAEA1ADQA2ACA4AAQAwAAAxgLIASgEIgeAIQg9AQg1ADIgQAAQg+AAhTgUg");
	this.shape_640.setTransform(202,309.9,0.87,0.87);

	this.shape_641 = new cjs.Shape();
	this.shape_641.graphics.f("#626666").s().p("AhFCfQhggGgUgMQgSgMAGhRQAMhjABgtQACgqAOgPQAKgKAOADQALADAOABIEEAEQAgAAALALQAGAIADAWQADAuADBRQADBvgIAQQgIAPgiADIhQAAIgpABQgvAAg1gDg");
	this.shape_641.setTransform(202.2,273.2,0.87,0.87);

	this.shape_642 = new cjs.Shape();
	this.shape_642.graphics.f("#626666").s().p("AhZDOIhHgJQg6gFgdgwIAAgBQgCgbAOgyQAQgzADgOQAEgRAFg8QAFg4ABgXQABgQAMgPQAIgJAHgFIACAAIFbgJQAkgBAMBdQAGAxACBGIAMBUQAHA8gIATQgJAVgMAFIgrAKQgdAGgzADIhpABQgvAAgkgFg");
	this.shape_642.setTransform(201.3,302.9,0.87,0.87);

	this.shape_643 = new cjs.Shape();
	this.shape_643.graphics.f("#717677").s().p("Ah3AfIDohUIAIAPIjvBKIAAARg");
	this.shape_643.setTransform(188.3,334.8,0.87,0.87);

	this.shape_644 = new cjs.Shape();
	this.shape_644.graphics.f("#3D4659").s().p("AiCBJIAAg8IDuhVIAIAAQgCABAJAHIAIAHIgHAmIjnAuIAAAug");
	this.shape_644.setTransform(188.7,336.5,0.87,0.87);

	this.shape_645 = new cjs.Shape();
	this.shape_645.graphics.f("#231F20").s().p("AAAAcQgFAAgEgEQgDgDAAgGIAAgdQAAgFADgEQAEgEAFAAIABAAQAFAAAEAEQADAEAAAFIAAAdQAAAGgDADQgDAEgGAAg");
	this.shape_645.setTransform(223.9,342.2,0.87,0.87);

	this.shape_646 = new cjs.Shape();
	this.shape_646.graphics.f("#717677").s().p("AB6AhIj3hMIAKgKIDvBSIACAHIgCASg");
	this.shape_646.setTransform(214,335.3,0.87,0.87);

	this.shape_647 = new cjs.Shape();
	this.shape_647.graphics.f("#3D4659").s().p("ABsBJIgBguIjlguIgIgsQASgIgDAAQAAAAgBAAQAAAAABAAQAAgBABAAQABAAABAAIAFAAIDuBVIAAA8g");
	this.shape_647.setTransform(213.6,337,0.87,0.87);

	this.shape_648 = new cjs.Shape();
	this.shape_648.graphics.f("#3D4659").s().p("AAfANIAAgIIgZAAIgvgRIBTAEIAAAVg");
	this.shape_648.setTransform(210.1,332.6,0.87,0.87);

	this.shape_649 = new cjs.Shape();
	this.shape_649.graphics.f("#3D4659").s().p("AgpANIAAgVIBSgEIguARIgZAAIAAAIg");
	this.shape_649.setTransform(190.8,332.5,0.87,0.87);

	this.shape_650 = new cjs.Shape();
	this.shape_650.graphics.f("#231F20").s().p("AgBAcQgEgBgEgDQgEgDABgFIAAgfQgBgEAEgEQAEgDAEAAIACAAQAGAAADADQADAEABAEIAAAfQgBAFgDADQgDADgGABg");
	this.shape_650.setTransform(188,335.8,0.87,0.87);

	this.shape_651 = new cjs.Shape();
	this.shape_651.graphics.f("#231F20").s().p("AgBAcQgEgBgEgDQgEgDABgFIAAgfQgBgEAEgEQAEgDAEAAIACAAQAGAAADADQAEAEAAAEIAAAfQAAAFgEADQgDADgGABg");
	this.shape_651.setTransform(213,335.8,0.87,0.87);

	this.shape_652 = new cjs.Shape();
	this.shape_652.graphics.f("#231F20").s().p("AgBAYQgEAAgEgDQgEgDABgFIAAgYQgBgGAEgDQAEgDAEAAIACAAQAGAAADADQAEADAAAGIAAAYQAAAFgEADQgDADgGAAg");
	this.shape_652.setTransform(178.1,342.4,0.87,0.87);

	this.shape_653 = new cjs.Shape();
	this.shape_653.graphics.f("#231F20").s().p("AgBAbQgEABgEgEQgDgEAAgEIAAgeQAAgGADgDQAEgDAEgBIADAAQAFABADADQADADABAGIAAAeQgBAEgDAEQgDAEgFgBg");
	this.shape_653.setTransform(201,346.7,0.87,0.87);

	this.shape_654 = new cjs.Shape();
	this.shape_654.graphics.f("#717677").s().p("AgEAVIAAgpQgBgFAFAAQAFAAAAAFIAAApQAAAFgFABQgFgBABgFg");
	this.shape_654.setTransform(214.3,335.8,0.87,0.87);

	this.shape_655 = new cjs.Shape();
	this.shape_655.graphics.f("#717677").s().p("AgEAVIAAgpQAAgFAEAAQAFAAAAAFIAAApQAAAFgFABQgEgBAAgFg");
	this.shape_655.setTransform(211.7,335.8,0.87,0.87);

	this.shape_656 = new cjs.Shape();
	this.shape_656.graphics.f("#717677").s().p("AgFAVIAAgpQAAgFAFAAQAGAAAAAFIAAApQAAAFgGABQgFgBAAgFg");
	this.shape_656.setTransform(189.4,335.8,0.87,0.87);

	this.shape_657 = new cjs.Shape();
	this.shape_657.graphics.f("#717677").s().p("AgFAVIAAgpQABgFAEAAQAGAAgBAFIAAApQABAFgGABQgEgBgBgFg");
	this.shape_657.setTransform(186.8,335.8,0.87,0.87);

	this.shape_658 = new cjs.Shape();
	this.shape_658.graphics.f("#717677").s().p("AgGATIAAgmQAAgGAGgBQAHABAAAGIAAAmQAAAIgHgBQgGABAAgIg");
	this.shape_658.setTransform(179.9,342.4,0.87,0.87);

	this.shape_659 = new cjs.Shape();
	this.shape_659.graphics.f("#717677").s().p("AgGATIAAgmQAAgGAGgBQAHABAAAGIAAAmQAAADgCACQgDACgCAAQgGABAAgIg");
	this.shape_659.setTransform(176.6,342.4,0.87,0.87);

	this.shape_660 = new cjs.Shape();
	this.shape_660.graphics.f("#717677").s().p("AgEAYQgCgCAAgDIAAgmQAAgGAGgBQAHABAAAGIAAAmQAAAIgHgBQgCAAgCgCg");
	this.shape_660.setTransform(225.7,342.4,0.87,0.87);

	this.shape_661 = new cjs.Shape();
	this.shape_661.graphics.f("#717677").s().p("AgGATIAAgmQAAgGAGgBQAHABAAAGIAAAmQAAAIgHgBQgGABAAgIg");
	this.shape_661.setTransform(222.3,342.4,0.87,0.87);

	this.shape_662 = new cjs.Shape();
	this.shape_662.graphics.f("#717677").s().p("AgGAZIAAgxQAAgHAGAAQAHAAAAAHIAAAxQAAAHgHAAQgGAAAAgHg");
	this.shape_662.setTransform(202.6,346.8,0.87,0.87);

	this.shape_663 = new cjs.Shape();
	this.shape_663.graphics.f("#717677").s().p("AgGAZIAAgxQAAgHAGAAQAHAAAAAHIAAAxQAAAHgHAAQgGAAAAgHg");
	this.shape_663.setTransform(199.3,346.8,0.87,0.87);

	this.shape_664 = new cjs.Shape();
	this.shape_664.graphics.f("#717677").s().p("AgaADIgegIIBxALg");
	this.shape_664.setTransform(208.8,331.2,0.87,0.87);

	this.shape_665 = new cjs.Shape();
	this.shape_665.graphics.f("#717677").s().p("AgpAAIBegEIgXAFIhSADg");
	this.shape_665.setTransform(191.8,331.3,0.87,0.87);

	this.shape_666 = new cjs.Shape();
	this.shape_666.graphics.f("#717677").s().p("AgGBKIgHiTIAbAAIgJCTg");
	this.shape_666.setTransform(201.1,338,0.87,0.87);

	this.shape_667 = new cjs.Shape();
	this.shape_667.graphics.f("#717677").s().p("AgaA3IgDgFIAAhsIA7ABIAABsQgLAIgWAAQgPgBgIgDg");
	this.shape_667.setTransform(201.2,326.5,0.87,0.87);

	this.shape_668 = new cjs.Shape();
	this.shape_668.graphics.f("#3D4659").s().p("AAACDQgCgCgCgIQgDgKAHgqQADgNAEgqQAEgvgDgUQgCgVgHgTQgGgPgFgFQgDgEgDgHIgCgHIARAOQAPAQACAGQAEAPACAYQACAngHApQgQBiABAGQABABAAABQAAAAABABQAAAAAAAAQgBABAAAAIgBgBg");
	this.shape_668.setTransform(332.6,298,0.87,0.87);

	this.shape_669 = new cjs.Shape();
	this.shape_669.graphics.f("#3D4659").s().p("AAACAQACgGgQhiQgMhEANgzQACgGAPgPIARgOQgDALgFAGQgFAFgGAQQgHATgCAUQgDAUAEAvQADApADAOQAIAngDAOQgCAHgDACIAAAAQAAAAAAAAQAAAAAAgBQAAAAAAgBQAAAAAAgBg");
	this.shape_669.setTransform(295.9,296.9,0.87,0.87);

	this.shape_670 = new cjs.Shape();
	this.shape_670.graphics.f("#B5B7B8").s().p("AgICFIgJgDQgEgDgEgpQgFgwgDg0QgFhJAEgOQAEgPAVgKQAKgFAKgCIAaADQgMAWgPAQQgKAKACAwQACAbAHA1IAIA8QACAYgJADIgKABIgKgBg");
	this.shape_670.setTransform(294.5,296.9,0.87,0.87);

	this.shape_671 = new cjs.Shape();
	this.shape_671.graphics.f("#323436").s().p("AgIAYQhKAAg/gSIgwgRQgIgFABgEQABgFAHAEQAOAIAoALQA7APBBACQBFACAygLIBEgSQAdgIgBAHQAAAHgPADQgzAOgbAFQgoAIhEAAIgIAAg");
	this.shape_671.setTransform(314.8,286,0.87,0.87);

	this.shape_672 = new cjs.Shape();
	this.shape_672.graphics.f("#3D4659").s().p("AgRAdQhHgBg5gQQgegIgRgIIAAgBQgJgIAFgJQAEgKAHAHQAIAHA1ANQA9AOAsABQBFABA2gKQARgDA0gOQAXgHACALQACALgHACQgJAGg2AKQhDAMhFAAIgLAAg");
	this.shape_672.setTransform(315.1,286,0.87,0.87);

	this.shape_673 = new cjs.Shape();
	this.shape_673.graphics.f("#626666").s().p("AhFCfQhhgGgTgMQgSgMAGhRQAMhjABgtQACgqAOgPQAKgKAOADQALADAOABIEEAEQAgAAALALQAGAIADAWQADAuADBRQADBvgIAQQgIAPgiADIhQABIgiAAQgzAAg4gDg");
	this.shape_673.setTransform(314.7,272.5,0.87,0.87);

	this.shape_674 = new cjs.Shape();
	this.shape_674.graphics.f("#626666").s().p("AhZDOIhHgJQgmgDgagXQgQgNgGgOIgBgBQgCgbAOgyQAQgzADgOQAEgRAFg8QAFg4ABgXQABgQAMgPQAIgJAIgFIABAAIFbgJQAlgBALBdQAGAxACBGIAMBUQAIA8gJATQgJAVgMAFIgrAKQgdAGgzADIhpABQgvAAgkgFg");
	this.shape_674.setTransform(313.8,302.1,0.87,0.87);

	this.shape_675 = new cjs.Shape();
	this.shape_675.graphics.f("#717677").s().p("Ah3AfIDohUIAHAQIjvBJIAAARg");
	this.shape_675.setTransform(300.8,334.1,0.87,0.87);

	this.shape_676 = new cjs.Shape();
	this.shape_676.graphics.f("#3D4659").s().p("AiCBJIAAg8IDvhVIAHAAQgCABAIAHIAJAIIgIAlIjlAuIgBAug");
	this.shape_676.setTransform(301.1,335.7,0.87,0.87);

	this.shape_677 = new cjs.Shape();
	this.shape_677.graphics.f("#231F20").s().p("AAAAcQgGAAgDgEQgDgDgBgGIAAgdQABgGADgDQADgEAGAAIABAAQAGAAADAEQAEAEgBAFIAAAdQABAGgEADQgDAEgGAAg");
	this.shape_677.setTransform(336.4,341.4,0.87,0.87);

	this.shape_678 = new cjs.Shape();
	this.shape_678.graphics.f("#717677").s().p("AB6AiIj3hNIAKgKIDvBSIACAHIgCASg");
	this.shape_678.setTransform(326.4,334.5,0.87,0.87);

	this.shape_679 = new cjs.Shape();
	this.shape_679.graphics.f("#3D4659").s().p("ABsBJIAAguIjnguIgHgsQASgIgDAAQAAAAgBAAQAAAAABAAQAAgBABAAQABAAABAAIAFAAIDuBVIAAA8g");
	this.shape_679.setTransform(326,336.2,0.87,0.87);

	this.shape_680 = new cjs.Shape();
	this.shape_680.graphics.f("#3D4659").s().p("AAfANIAAgIIgaAAIgugQIBTACIAAAWg");
	this.shape_680.setTransform(322.5,331.8,0.87,0.87);

	this.shape_681 = new cjs.Shape();
	this.shape_681.graphics.f("#3D4659").s().p("AgoANIAAgVIBRgEIgtARIgZAAIAAAIg");
	this.shape_681.setTransform(303.2,331.7,0.87,0.87);

	this.shape_682 = new cjs.Shape();
	this.shape_682.graphics.f("#231F20").s().p("AAAAcQgGgBgDgDQgEgDAAgFIAAgfQAAgEAEgEQADgDAGAAIABAAQAFAAAEADQAEAEgBAEIAAAfQABAFgEADQgEADgFABg");
	this.shape_682.setTransform(300.4,335.1,0.87,0.87);

	this.shape_683 = new cjs.Shape();
	this.shape_683.graphics.f("#231F20").s().p("AAAAcQgGgBgDgDQgDgDgBgFIAAgfQABgEADgEQADgDAGAAIACAAQAEAAAEADQAEAEgBAEIAAAfQABAFgEADQgEADgEABg");
	this.shape_683.setTransform(325.4,335.1,0.87,0.87);

	this.shape_684 = new cjs.Shape();
	this.shape_684.graphics.f("#231F20").s().p("AAAAYQgGAAgDgDQgDgDgBgFIAAgYQABgFADgEQADgDAGAAIACAAQAEAAAEADQAEAEgBAFIAAAYQABAFgEADQgEADgEAAg");
	this.shape_684.setTransform(290.6,341.6,0.87,0.87);

	this.shape_685 = new cjs.Shape();
	this.shape_685.graphics.f("#231F20").s().p("AAAAbQgFABgEgEQgEgEAAgEIAAgeQAAgGAEgDQAEgDAFgBIABAAQAFABAEADQADADAAAGIAAAeQAAAEgDAEQgEAEgFgBg");
	this.shape_685.setTransform(313.5,345.9,0.87,0.87);

	this.shape_686 = new cjs.Shape();
	this.shape_686.graphics.f("#717677").s().p("AgFAVIAAgpQAAgFAFgBQAGABAAAFIAAApQAAAFgGABQgFgBAAgFg");
	this.shape_686.setTransform(326.8,335.1,0.87,0.87);

	this.shape_687 = new cjs.Shape();
	this.shape_687.graphics.f("#717677").s().p("AgFAVIAAgpQAAgFAFgBQAGABAAAFIAAApQAAAFgGABQgFgBAAgFg");
	this.shape_687.setTransform(324.1,335.1,0.87,0.87);

	this.shape_688 = new cjs.Shape();
	this.shape_688.graphics.f("#717677").s().p("AgEAVIAAgpQgBgFAFgBQAFABABAFIAAApQgBAFgFABQgFgBABgFg");
	this.shape_688.setTransform(301.9,335.1,0.87,0.87);

	this.shape_689 = new cjs.Shape();
	this.shape_689.graphics.f("#717677").s().p("AgEAVIAAgpQgBgFAFgBQAFABABAFIAAApQgBAFgFABQgFgBABgFg");
	this.shape_689.setTransform(299.2,335.1,0.87,0.87);

	this.shape_690 = new cjs.Shape();
	this.shape_690.graphics.f("#717677").s().p("AgEAYQgCgCAAgDIAAgmQAAgCACgCQADgDABAAQADAAACADQACACAAACIAAAmQAAAIgHgBQgBAAgDgCg");
	this.shape_690.setTransform(292.4,341.6,0.87,0.87);

	this.shape_691 = new cjs.Shape();
	this.shape_691.graphics.f("#717677").s().p("AgGATIAAgmQAAgGAGgBQAHABAAAGIAAAmQAAAIgHgBQgGABAAgIg");
	this.shape_691.setTransform(289,341.6,0.87,0.87);

	this.shape_692 = new cjs.Shape();
	this.shape_692.graphics.f("#717677").s().p("AgEAYQgCgCAAgDIAAgmQAAgCACgCQADgDABAAQAHABAAAGIAAAmQAAAIgHgBQgBAAgDgCg");
	this.shape_692.setTransform(338.1,341.6,0.87,0.87);

	this.shape_693 = new cjs.Shape();
	this.shape_693.graphics.f("#717677").s().p("AgEAYQgCgCAAgDIAAgmQAAgGAGgBQAHABAAAGIAAAmQAAAIgHgBQgCAAgCgCg");
	this.shape_693.setTransform(334.8,341.6,0.87,0.87);

	this.shape_694 = new cjs.Shape();
	this.shape_694.graphics.f("#717677").s().p("AgGAZIAAgxQAAgHAGAAQAHAAAAAHIAAAxQAAAHgHAAQgGAAAAgHg");
	this.shape_694.setTransform(315,346,0.87,0.87);

	this.shape_695 = new cjs.Shape();
	this.shape_695.graphics.f("#717677").s().p("AgGAZIAAgxQAAgHAGAAQAHAAAAAHIAAAxQAAAHgHAAQgGAAAAgHg");
	this.shape_695.setTransform(311.7,346,0.87,0.87);

	this.shape_696 = new cjs.Shape();
	this.shape_696.graphics.f("#717677").s().p("AgaAEIgegJIBxALg");
	this.shape_696.setTransform(321.2,330.4,0.87,0.87);

	this.shape_697 = new cjs.Shape();
	this.shape_697.graphics.f("#717677").s().p("AgpAAIBegEIgXAFIhSADg");
	this.shape_697.setTransform(304.3,330.5,0.87,0.87);

	this.shape_698 = new cjs.Shape();
	this.shape_698.graphics.f("#717677").s().p("AgGBKIgHiTIAbAAIgJCTg");
	this.shape_698.setTransform(313.5,337.2,0.87,0.87);

	this.shape_699 = new cjs.Shape();
	this.shape_699.graphics.f("#717677").s().p("AgaA3IgEgFIAAhsIA9ABIAABsQgNAIgWgBQgOAAgIgDg");
	this.shape_699.setTransform(313.6,325.7,0.87,0.87);

	this.shape_700 = new cjs.Shape();
	this.shape_700.graphics.f("#B5B7B8").s().p("AgLCFQgJgCACgZIAIg8QAHg1ACgbQABgwgJgKQgJgKgKgPIgIgNIAagDIAUAHQAWAKADAPQAEAOgFBJQgDA0gFAwQgEApgEADQgKAEgIAAIgLgBg");
	this.shape_700.setTransform(334,297.8,0.87,0.87);

	this.shape_701 = new cjs.Shape();
	this.shape_701.graphics.f("#2B2E32").s().p("AiXgFQgBAAAAAAQgBgBAAAAQAAAAAAgBQAAAAAAgBQAAgBAAAAQAAgBABAAQAAAAABAAQAAAAABAAIANADQANAEA1ADQA2ACA4AAQAwAAAxgLIASgEIgeAIQg9AQg1ADIgRAAQg8AAhUgTg");
	this.shape_701.setTransform(322,309.1,0.87,0.87);

	this.shape_702 = new cjs.Shape();
	this.shape_702.graphics.f("#252931").s().p("AAAACIABgHIAAALg");
	this.shape_702.setTransform(95.5,324,0.87,0.87);

	this.shape_703 = new cjs.Shape();
	this.shape_703.graphics.f("#626666").s().p("AgKBbQgOgVAAgXQABgXAFgqIAIgrQACgiALgDQAMgEAKgFIgRAzQgQA3gCARQgDAeAGApIAIAVQgFgGgGgLg");
	this.shape_703.setTransform(74.8,313.9,0.87,0.87);

	this.shape_704 = new cjs.Shape();
	this.shape_704.graphics.f("#626666").s().p("AAHA8QgHgDgEgJQgEgJgGg0IgIgvIAtB0QgFAFgGAAIgFgBg");
	this.shape_704.setTransform(74.5,298.9,0.87,0.87);

	this.shape_705 = new cjs.Shape();
	this.shape_705.graphics.f("#717677").s().p("AAAACIgCgCIAAgBQACAAADADg");
	this.shape_705.setTransform(92.5,332,0.87,0.87);

	this.shape_706 = new cjs.Shape();
	this.shape_706.graphics.f("#717677").s().p("AAAgCIgFABIALgGIAAACQgBABAAABQAAAAAAABQAAAAABAAQAAABAAAAQABABgBAIQgDgJgDgBg");
	this.shape_706.setTransform(91.6,333.2,0.87,0.87);

	this.shape_707 = new cjs.Shape();
	this.shape_707.graphics.f("#252931").s().p("AgFAwQgMgBgEgGIgCgFIAAhTIAvAAIAABXQgKAIgOAAIgFAAg");
	this.shape_707.setTransform(90.1,328.7,0.87,0.87);

	this.shape_708 = new cjs.Shape();
	this.shape_708.graphics.f("#323436").s().p("ABrAjQgBgjAOgmQAGgSAOgYQAJgQgDgGQgEgJgGgCQgJgFgcgBQgigCg9AEQhDAFgiAIQggAIgPgCQgLgBAAgFQgBgDAHgBIARgBIBZgMIAfgDQBlgEARACQAXABAHACQAWAHgCAVQgBAGgFAKQgMAUgLAdQgKAagDCCIgJACg");
	this.shape_708.setTransform(86.9,313.5,0.87,0.87);

	this.shape_709 = new cjs.Shape();
	this.shape_709.graphics.f("#B7BBC1").s().p("ABlCDIgDgBQgCgBAAgDIABgFIAEhPQgDggAOgnQALghAJgNQAHgMAAgEIgDgJQgFgGgIgBIghgCQgkgCg3ACQg+ADggAIQgvALgLgHQgDgCgBgEQgBgDACgDQADgDAOgCIAHgBIBLgJIAPgDIAegCIATgBQBfgEAIACIAFABQAPABALAHQAQAIABAQIgEATIgJAQQgKATgGAQQgKAZgEB+QAAADgDABIgKACgABrAlIgCBVIABgBIAEhFQAEg6AGgTQgMAjgBAbgABoh1QAYACAJAEQAGADAEAKIACADQABAEgBAFIABgBQACgSgMgIQgIgFgSgCIgGgBIhkACIgTABIgfADIgOACQAagDAigBIA3gBIAtABgAiKhmQgGAAgEABQAJAEApgJIATgEg");
	this.shape_709.setTransform(87.1,313.3,0.87,0.87);

	this.shape_710 = new cjs.Shape();
	this.shape_710.graphics.f("#FED5B5").s().p("AAMAcQgZgDgIgHQgGgFgQgFIgQgDIgCgWQAhAEAFgCIAPgEIAUgEIALgEQAGgBgBADQgCAFgJAEIgIACQgBAAgBAAQgBAAAAABQgBAAAAAAQAAABAAAAQACACAaAJIAQAGQAMAFABACIAAAAQgCAFgggLIgBAAQADADgCAEIgDAHQgDAEgDACQgDACgDAAIgBAAg");
	this.shape_710.setTransform(98.8,297.4,0.87,0.87);

	this.shape_711 = new cjs.Shape();
	this.shape_711.graphics.f("#050505").s().p("AhACLQgbgngIgUQgKgcAEhSQAGheAbgdQAfgfAlAEQASADAOAJIAKgCQAKgBAKAEQAdAMAMA6QANA9gIApQgJAtgTA3QgZBJgUAAIAljeQAHg1gqgkQgEgDgHAAQgUACgSAQQgfAZgSA2QgRA0AXAvQANAaAUBgQgKgDgcgog");
	this.shape_711.setTransform(97.1,270.6,0.87,0.87);

	this.shape_712 = new cjs.Shape();
	this.shape_712.graphics.f("#F4C9D9").s().p("AgGAGQgGgHgCgLIABAAQAGARAOAAQAEAAAEgCIgCAJIgGABQgHAAgGgHg");
	this.shape_712.setTransform(101.6,289.8,0.87,0.87);

	this.shape_713 = new cjs.Shape();
	this.shape_713.graphics.f("#F4C9D9").s().p("AgSAMIgCgKQAGADAGAAQAJAAAHgFQAIgEADgJIACAAQgCAMgIAHQgJAIgKAAQgEAAgGgCg");
	this.shape_713.setTransform(94.3,289.9,0.87,0.87);

	this.shape_714 = new cjs.Shape();
	this.shape_714.graphics.f("#F4C9D9").s().p("AgIgJIAFgCQADAKAJAGIAAAIQgOgJgDgNg");
	this.shape_714.setTransform(102.7,299.7,0.87,0.87);

	this.shape_715 = new cjs.Shape();
	this.shape_715.graphics.f("#F4C9D9").s().p("AgOAKIAAgBQAUgFADgRIAGAEQgEAQgRAGg");
	this.shape_715.setTransform(92,300.5,0.87,0.87);

	this.shape_716 = new cjs.Shape();
	this.shape_716.graphics.f("#F4C9D9").s().p("AAJhXIAWAGIAFA1IgRAEIAHAOIg9Big");
	this.shape_716.setTransform(101,285.9,0.87,0.87);

	this.shape_717 = new cjs.Shape();
	this.shape_717.graphics.f("#F4C9D9").s().p("AgdgBIAIgPIgRgEIAFg1IAVgFIAzCdg");
	this.shape_717.setTransform(94.6,284.7,0.87,0.87);

	this.shape_718 = new cjs.Shape();
	this.shape_718.graphics.f("#EEAA83").s().p("AgEgLQAEgHAEABQAAAAABAAQAAAAABABQAAAAAAAAQABAAAAABQACAOgIALQgDAGgEACg");
	this.shape_718.setTransform(104,268.5,0.87,0.87);

	this.shape_719 = new cjs.Shape();
	this.shape_719.graphics.f("#EEAA83").s().p("AAAAKQgIgLACgOIADgCQADgBAEAHIADAdQgEgCgDgGg");
	this.shape_719.setTransform(90.1,268.5,0.87,0.87);

	this.shape_720 = new cjs.Shape();
	this.shape_720.graphics.f("#FABD99").s().p("AgZBpQgegUgQgiQgFgCgEgHQgIgLACgOIADgDQAFAAADAHQgFgRgDgTQgFgpARgUQAGgJAKgKQAYgSAbgDIAIAAQAcADAYASQALAKAGAJQAQAUgFApQgDATgGARQAFgHAEAAQAAABABAAQAAAAABAAQAAAAAAABQABAAAAABQACAOgIALQgEAHgEACQgRAigdAUQgQAKgLADQgLgDgOgKg");
	this.shape_720.setTransform(97,265.6,0.87,0.87);

	this.shape_721 = new cjs.Shape();
	this.shape_721.graphics.f("#FFE5EE").s().p("AADBnQg9gPgIgRQgCgFAag/QAdhEAFgPQAFgRAJgKIAIgHIAIALQAIAOAEAQQAHAjgHAIQgOAUgQAcQgNAaAAAEQAAADAmAOIAmAMIgEAmQgdgEgfgIg");
	this.shape_721.setTransform(88.8,288.6,0.87,0.87);

	this.shape_722 = new cjs.Shape();
	this.shape_722.graphics.f("#FFE5EE").s().p("AADBnQg9gPgIgRQgCgFAag/QAdhEAFgPQAFgRAJgKIAIgHQA0A8gKAEQgQAHgaArQgXAoAAAIQAAADAmAOIAmAMIgEAmQgdgEgfgIg");
	this.shape_722.setTransform(88.8,288.6,0.87,0.87);

	this.shape_723 = new cjs.Shape();
	this.shape_723.graphics.f("#FFE5EE").s().p("AgzAXQAHgfgShIQgGgTgEgbIgDgYIAigHIAEALQAGANAMALQANALAXgBQAUgBALgIQAIgGgCgQIgCgPIATAIIAJAjQAEAQAEAYQADAYgBAGQgDAPgNAKQgGAGgCAOIAAAmQAAAiAeBDIi/AUQAnhsAFgcg");
	this.shape_723.setTransform(96.6,291.8,0.87,0.87);

	this.instance_27 = new lib.ClipGroup();
	this.instance_27.parent = this;
	this.instance_27.setTransform(108.5,284.4,0.87,0.87,0,0,0,11.6,9.5);

	this.shape_724 = new cjs.Shape();
	this.shape_724.graphics.f("#000000").s().p("AgLAgIgBgCQgDgHgBgLIgCgRIgGgNQgFgJABgEQAAgFAFgEQACACADAIQACAFAEAWQACANAPACIALABQACAAgBgFQgDgKABgDQADAMADAFIAHAHQAFAOgKAIg");
	this.shape_724.setTransform(104,342.7,0.87,0.87);

	this.shape_725 = new cjs.Shape();
	this.shape_725.graphics.f("#1B1A1F").s().p("Ag0ACQAigEAsgBIAbABIgBABQhBAAgmAFIAAAAQgBAAAAAAQAAAAAAAAQAAgBAAAAQAAgBAAAAg");
	this.shape_725.setTransform(103.2,309.5,0.87,0.87);

	this.shape_726 = new cjs.Shape();
	this.shape_726.graphics.f("#000000").s().p("AizBqQg6gIAQhfQAFgcAMgjIALgdIAGgDQAIgEAKgCQA5gMAUAAQAaAAAbAOIAKAkQADAMAJArIBFADQBUADAnAGQAsAIAGAUQAEANgOAeIAAABQgGANhIAJIhGAHQgnADgxAAIgiAAQhNAAgvgFg");
	this.shape_726.setTransform(107,309.7,0.87,0.87);

	this.shape_727 = new cjs.Shape();
	this.shape_727.graphics.f("#000000").s().p("AgIAaIAFg2IAMAOIgJAqg");
	this.shape_727.setTransform(102,342.8,0.87,0.87);

	this.shape_728 = new cjs.Shape();
	this.shape_728.graphics.f("#000000").s().p("AgTAdIgBgEQgCgHABgLIABgRIAAgBIgBgKIgCgLQgBgFACgDIAEgDQADADADAHQACAJgBATQAAAGACAEQAEAFAIADIAKADQABAAAAgBQABAAAAAAQAAgBAAgBQAAgBAAgBIAAgHIABgHQABANACAGIAFAHQADAPgMAGg");
	this.shape_728.setTransform(108.6,342.9,0.87,0.87);

	this.shape_729 = new cjs.Shape();
	this.shape_729.graphics.f("#EEAA83").s().p("AhvDGIgBgEQgBgHABgLIABgSIAAgBIgCgKIgCgLIAAgBIABgEQAMgQADgGQAGgJAMgdIALgaQBFhWAKgQQAJgNAOgbQAMgWAGgHQAMgOADgRQAEgUgMgMQgNgMgvgDIgtAAIALgEQALgEAEAAQBQADAjAPQASAIABAHQAHAMgFARQgFANgKALQgGAHgMAWQgOAagJAOQgIALg1BCQg2BCgQAZQgGAKAAAJIAEAdIABAOQAAAHACAFIAFAHQADAPgLAGg");
	this.shape_729.setTransform(116.6,328.2,0.87,0.87);

	this.shape_730 = new cjs.Shape();
	this.shape_730.graphics.f("#000000").s().p("AgMAZIANg1IAMAMIgRAtg");
	this.shape_730.setTransform(106.6,342.6,0.87,0.87);

	this.shape_731 = new cjs.Shape();
	this.shape_731.graphics.f("#EEAA83").s().p("AhuDKIgBgDQgDgGgBgLIgCgTIgEgKQgDgHAAgEIgBgHQABgEACgCIAIgHIAHgHQAXggAwhjIAphdIg/AHIA9hrQA5ACAiAOQAhANgCAQQgEAqhKBaQgkAsgjAlIg5BCQgHAKAAAIQgBAIABAFIADALQAGAWACADIAHAGQAFAOgKAJg");
	this.shape_731.setTransform(112.6,327.9,0.87,0.87);

	this.shape_732 = new cjs.Shape();
	this.shape_732.graphics.f("#EEAA83").s().p("AAABEQglgDgQgjIgJghQAbgDAJgMQAFgIABgVIgBgQIAAAAIAAgFIAsACIgBATQABAVAGAJQAIAMAVAIIAEALQACAOgCAKQgHAfgsAAIgLgBg");
	this.shape_732.setTransform(97.3,278.6,0.87,0.87);

	this.shape_733 = new cjs.Shape();
	this.shape_733.graphics.f("#110D0B").s().p("AhjA7QgNhFAMg1QAMg6AdgMQAPgHAOAGIAkgJQAngDAaAbQAbAdAHBBQAFA2gJAaQgKAbgmA2QgMADgzACIgOgDQgFgBgRAHQgngFgOhQg");
	this.shape_733.setTransform(97.3,267.6,0.87,0.87);

	this.shape_734 = new cjs.Shape();
	this.shape_734.graphics.f("#FED5B5").s().p("AgZA/QADgmgBgFIgDgMQgEgIABgEQADgQAAgHIgCgLQgBgBAAgBQAAgBAAgBQABAAAAAAQAAAAABAAQAHAEABAIIAAAIQAAAGABgBQACAAAGgJIAHgLQARgYADgBQAFgCAFAJQAFAJgCAQQAAAGgMAWQgDAFgOAQQgGAIABAkg");
	this.shape_734.setTransform(117,276.2,0.87,0.87);

	this.shape_735 = new cjs.Shape();
	this.shape_735.graphics.f("#323436").s().p("AgJAPQACgHAHgIQAOgTgGgDIACAAQAAABABAAQAAAAAAABQABAAAAABQAAABAAABQAAADgEAGIgIALQgKAQAAAEQgBgCACgGg");
	this.shape_735.setTransform(81.8,317.3,0.87,0.87);

	this.shape_736 = new cjs.Shape();
	this.shape_736.graphics.f("#626666").s().p("AiPFFQgFgDgLgQQgHgLAPhOQAOhPgHgMQgLgSgvhzQgvh2gDgUIgChhQAAhIgIgLIAKALQAOAMAFAAQAEAAAEgGQACgEAHAGQANALAAAlQAAB1AUAoQAWAtAaBAQAgBRADAbQACATgHAkQgGAdgGAQQgFAKAAAWQAAAWAEAAIBigYQBrgWA9AKQA+AJAfAQQAQAIADAGIADAPQACAQgDARQAAgIgEgJQgLgWgsgFIgkgEQgYgBgaAFQjZAtgSADIgQABQgGAAgDgBg");
	this.shape_736.setTransform(93,292,0.87,0.87);

	this.shape_737 = new cjs.Shape();
	this.shape_737.graphics.f("#323436").s().p("AgnA4QgBgKgPgtQgLghACgWQABgTgDg7QgEg6ACgOQACgVACgEQABgDAHAAQAKAAAEAYQADATgBBDQgBA8AFAOQASAwAWBBQALAhA2B8QgVACgOAFIgKAEQg5iNgGgkg");
	this.shape_737.setTransform(74.4,283.5,0.87,0.87);

	this.shape_738 = new cjs.Shape();
	this.shape_738.graphics.f("#323436").s().p("AibCAQgfgBgOgHQgZgNgMgqQgNgsAWhMIAZhEIAogFQAHAAgDARQgBANgKAyQgKA1ACAVQACAcAUADQAQACCGgcQCFgcAJABIBIADQAbAFAGAXQAIAfgQAUQgSAVgjgKQgggJhoALQhUAJgjAJQgvAMgdAAIgEgBg");
	this.shape_738.setTransform(94.7,315.2,0.87,0.87);

	this.shape_739 = new cjs.Shape();
	this.shape_739.graphics.f("#454748").s().p("AgZAHIAJgEQAMgEAIgCIAWgDIgdALIgQACg");
	this.shape_739.setTransform(75,336.1,0.87,0.87);

	this.shape_740 = new cjs.Shape();
	this.shape_740.graphics.f("#717677").s().p("AgFAWIAEgTQABgNAAgCQgBgBgFAAIgFAAIAQgJIAHACIgCAAQgCABgCAEQgCADgBARIAAASg");
	this.shape_740.setTransform(87.9,334.6,0.87,0.87);

	this.shape_741 = new cjs.Shape();
	this.shape_741.graphics.f("#717677").s().p("AgQAEIgIgFIgBgFIAKAGQALAEAHgBQAOgCAGgGIAAgCIADAEIgBADQgEAFgOACIgHABQgJAAgHgEg");
	this.shape_741.setTransform(90.2,332.5,0.87,0.87);

	this.shape_742 = new cjs.Shape();
	this.shape_742.graphics.f("#3D4659").s().p("AAYAxIglhMQgihFAEACQAGACASgBIA4CNQAGAPABAfIgRABQABgkgEgKg");
	this.shape_742.setTransform(93.4,341.1,0.87,0.87);

	this.shape_743 = new cjs.Shape();
	this.shape_743.graphics.f("#D2D6D7").s().p("AAAAiIgLhEQAOAOAKA3g");
	this.shape_743.setTransform(97.1,346.4,0.87,0.87);

	this.shape_744 = new cjs.Shape();
	this.shape_744.graphics.f("#B5B7B8").s().p("AATAmQgEgHgQgmQgNgggGgFIgZgHQgBABABgpIAKgEIAKACQABAAAAAAQAAAAAAAAQAAABAAAAQAAABgBAAIANAPQANATADARQADAQARAkQASAmABAFQAEAQgBAYIgSABQADglgMgVg");
	this.shape_744.setTransform(92.1,341.1,0.87,0.87);

	this.shape_745 = new cjs.Shape();
	this.shape_745.graphics.f("#252931").s().p("Ah4A/QADgXAPgRQALgOBWggQBVgiAqgFIAAAmIghABQglADgVAGIgeAIIghAKIgtAQQgRAHgHANQgLAVADACg");
	this.shape_745.setTransform(77.3,338.7,0.87,0.87);

	this.shape_746 = new cjs.Shape();
	this.shape_746.graphics.f("#252931").s().p("AB9A5QADgHgLgSQgEgHgUgFIgwgNIgjgJIgdgIQgVgEgtgBIgpAAIgMgpQArAEBqAhQBrAhAMAMQAJAJAAAMQAAAGgCAEg");
	this.shape_746.setTransform(103.8,337.9,0.87,0.87);

	this.shape_747 = new cjs.Shape();
	this.shape_747.graphics.f("#B5B7B8").s().p("AiFBDQAEgeARgPQATgRBWggQBYgkAqgEIAKAEQhPAjgiAIQgRAEgJAIQgLAJgUAHIgvAPQgRAHgFAIQgMATAAALg");
	this.shape_747.setTransform(77.1,338.3,0.87,0.87);

	this.shape_748 = new cjs.Shape();
	this.shape_748.graphics.f("#B5B7B8").s().p("ACBA+QgBgMgLgSQgFgIgTgHIgwgPIgjgKIgdgHQgWgFg5gRIg1gQIAQgIQAtAFBpAiQBtAhARAPQAKAJABAOQABAHgCAGg");
	this.shape_748.setTransform(104.3,337.6,0.87,0.87);

	this.shape_749 = new cjs.Shape();
	this.shape_749.graphics.f("#B3B5B8").s().p("AgBAuIAAhbIADAAIAABbg");
	this.shape_749.setTransform(88.2,328.3,0.87,0.87);

	this.shape_750 = new cjs.Shape();
	this.shape_750.graphics.f("#3D4659").s().p("AgJAwIAAhfIASAAIAABfg");
	this.shape_750.setTransform(90.4,328.7,0.87,0.87);

	this.shape_751 = new cjs.Shape();
	this.shape_751.graphics.f("#454748").s().p("AgHAWQgIgFgDgLQgEgKAEgJQADgJAIgCQAHgDAIAGQAIAGADAKQAEAKgEAJQgDAJgIADIgFAAQgFAAgFgEg");
	this.shape_751.setTransform(116.4,346.7,0.87,0.87);

	this.shape_752 = new cjs.Shape();
	this.shape_752.graphics.f("#454748").s().p("AgNAWQgHgIgBgMQgCgLAGgJQAGgKAJgBQAIAAAHAHQAIAIABANQABALgFAJQgGAJgJABIgCABQgHAAgHgIg");
	this.shape_752.setTransform(96.1,353.2,0.87,0.87);

	this.shape_753 = new cjs.Shape();
	this.shape_753.graphics.f("#040D1C").s().p("AgOAbQgKgDgEgPQgBgGABgPIAAgPIAbgBIAAAGIALABQANADADAJQAFAJgDAKQgCAJgIAFQgIAEgKABIgDAAQgHAAgEgCg");
	this.shape_753.setTransform(117.5,345.4,0.87,0.87);

	this.shape_754 = new cjs.Shape();
	this.shape_754.graphics.f("#040D1C").s().p("AgPAdQgLgDgEgQQgBgHABgQIAAgRIAkAAIAAAFIAKACQAKADADAKQAIAagRAJQgJAFgLABIgDAAQgHAAgFgCg");
	this.shape_754.setTransform(97.5,352.2,0.87,0.87);

	this.shape_755 = new cjs.Shape();
	this.shape_755.graphics.f("#454748").s().p("AgMASQgHgHAAgLQAAgKAHgHQAFgIAHAAQAIAAAGAIQAGAHAAAKQAAALgGAHQgGAIgIAAQgHAAgFgIg");
	this.shape_755.setTransform(66.3,347.1,0.87,0.87);

	this.shape_756 = new cjs.Shape();
	this.shape_756.graphics.f("#454748").s().p("AgDAOQgGgDgCgGQgCgGABgGQACgGAFgCQAFgCAEAEQAFADADAGQACAGgBAGQgCAGgFACIgEAAQgCAAgDgCg");
	this.shape_756.setTransform(71.1,338.7,0.87,0.87);

	this.shape_757 = new cjs.Shape();
	this.shape_757.graphics.f("#454748").s().p("AgFAWQgIgFgEgKQgEgJADgJQACgJAIgDQAHgDAHAFQAJAFADAKQAEAJgDAJQgCAJgIADIgGABQgDAAgFgDg");
	this.shape_757.setTransform(99.7,338.6,0.87,0.87);

	this.shape_758 = new cjs.Shape();
	this.shape_758.graphics.f("#040D1C").s().p("AgOAbQgKgDgDgPQgBgGAAgPIABgQIAhAAIAAAFIAJACQAJADADAJQAIAYgRAJQgHAEgLABIgDAAQgHAAgEgCg");
	this.shape_758.setTransform(100.6,337.5,0.87,0.87);

	this.shape_759 = new cjs.Shape();
	this.shape_759.graphics.f("#040D1C").s().p("AAAATQgFgBgFgDQgMgFAGgQQACgGAGgCIAGgBIAAgDIAVAAIAAAYQgCAKgHACIgHABIgDAAg");
	this.shape_759.setTransform(71.6,338.3,0.87,0.87);

	this.shape_760 = new cjs.Shape();
	this.shape_760.graphics.f("#040D1C").s().p("AgPAVQgOgJAHgUQACgIAJgCIAHgCIAAgEIAdAAIABAOQAAANgBAFQgDANgJADQgFABgGAAQgIAAgJgEg");
	this.shape_760.setTransform(65.8,346.1,0.87,0.87);

	this.shape_761 = new cjs.Shape();
	this.shape_761.graphics.f("#717677").s().p("AhNAcQgDgCgHABIgGAAQgFgBAJgHQAEgDBagWIBbgWIAAAFIhpAdIgRAHIgVAFQgPACgEACQgEACgDAEIgCABIgCgBg");
	this.shape_761.setTransform(79.7,334.4,0.87,0.87);

	this.shape_762 = new cjs.Shape();
	this.shape_762.graphics.f("#454748").s().p("AgHAWQgIgFgEgLQgDgKAEgJQAEgKAHgBQAIgDAHAFQAIAHADAKQAEAKgEAJQgDAKgJACIgEAAQgFAAgFgEg");
	this.shape_762.setTransform(119,345.6,0.87,0.87);

	this.shape_763 = new cjs.Shape();
	this.shape_763.graphics.f("#454748").s().p("AgMAWQgIgIgBgMQgBgLAFgJQAGgKAJgBQAIAAAIAHQAHAIABAMQACAMgGAJQgFAJgKABIgCABQgHAAgGgIg");
	this.shape_763.setTransform(99.1,352.3,0.87,0.87);

	this.shape_764 = new cjs.Shape();
	this.shape_764.graphics.f("#454748").s().p("AgMASQgHgHAAgLQAAgKAHgHQAFgIAHAAQAIAAAGAIQAGAHAAAKQAAALgGAHQgGAIgIAAQgHAAgFgIg");
	this.shape_764.setTransform(64,346.5,0.87,0.87);

	this.shape_765 = new cjs.Shape();
	this.shape_765.graphics.f("#454748").s().p("AgFAWQgJgFgDgKQgEgJADgJQACgJAIgDQAHgDAHAFQAIAFAEAKQAEAJgCAJQgDAJgIADIgFABQgEAAgFgDg");
	this.shape_765.setTransform(102.9,337.4,0.87,0.87);

	this.shape_766 = new cjs.Shape();
	this.shape_766.graphics.f("#323436").s().p("ABrAjQgBgjAOgmQAGgSAOgZQAJgPgDgFQgEgKgGgCQgJgEgcgCQghgCg+AEQhDAEgiAJQggAIgPgCQgLgBAAgFQgBgDAHgBIARgCIBZgLQARgCAOgBIB2gDQAbADADACQAWAGgCAVQgBAGgFAJQgMAWgLAdQgKAZgDCBIgJACg");
	this.shape_766.setTransform(86.9,309.1,0.87,0.87);

	this.shape_767 = new cjs.Shape();
	this.shape_767.graphics.f("#B7BBC1").s().p("ABlCDIgDAAQgCgDAAgCIABgFIAEhPQgDggAOgnQAKgfAKgPQAHgMAAgEIgDgIQgFgHgIgBIghgCQglgCg2ACQg+ADggAIQgvAMgLgIQgEgDAAgDIABgFQADgEAOgCIBSgKIAPgCQARgDANAAIATgBQBbgEAMACIAFABQAPABALAHQAQAJABAPIgEATIgJARQgKATgGAPQgKAZgEB+QAAADgDABIgKACgABrAmIgCBUIABAAIAEhGQAEg5AGgUQgMAjgBAcgABoh1QAYACAJAEQAGADAEAKIACADQABAEgBAFIABgBQACgSgMgHQgJgGgRgCIgGgBQgEgBhgADIgTABQgOABgRACIgOACQAagDAigBIA3gBIAtABgAiUhlQAKAFAogKIARgEgAhRhuIACAAg");
	this.shape_767.setTransform(87.1,308.8,0.87,0.87);

	this.shape_768 = new cjs.Shape();
	this.shape_768.graphics.f("#252931").s().p("AAAgFIABAHIgBAEg");
	this.shape_768.setTransform(368.6,323.1,0.87,0.87);

	this.shape_769 = new cjs.Shape();
	this.shape_769.graphics.f("rgba(204,204,204,0.498)").s().p("A9YOzIAA9lMA6xAAAIAAdlg");
	this.shape_769.setTransform(234.5,235.7);

	this.shape_770 = new cjs.Shape();
	this.shape_770.graphics.f("#B5B7B8").s().p("EghwAEOIAAobMBDhAAAIAAIbg");
	this.shape_770.setTransform(234.5,353.8,0.87,0.87);

	this.c9_2 = new lib.mc_radioButton9();
	this.c9_2.parent = this;
	this.c9_2.setTransform(544.9,348.2,1,1,0,0,0,18,18.1);

	this.c9_1 = new lib.mc_radioButton9();
	this.c9_1.parent = this;
	this.c9_1.setTransform(544.9,239,1,1,0,0,0,18,18.1);

	this.c9_op0 = new cjs.Text("Solicitar ayuda al área de Planeación.", "16px 'Arial'", "#333333");
	this.c9_op0.name = "c9_op0";
	this.c9_op0.lineHeight = 18;
	this.c9_op0.lineWidth = 319;
	this.c9_op0.parent = this;
	this.c9_op0.setTransform(570.3,164.5);

	this.c9_op2 = new cjs.Text("No hacer nada.", "16px 'Arial'", "#333333");
	this.c9_op2.name = "c9_op2";
	this.c9_op2.lineHeight = 18;
	this.c9_op2.lineWidth = 227;
	this.c9_op2.parent = this;
	this.c9_op2.setTransform(570.3,340.2);

	this.c9_op1 = new cjs.Text("Realizar la evaluación usando la plataforma SuccessFactors en la sección correspondiente (sólo si el colaborador tiene más de 6 meses en la posición).", "16px 'Arial'", "#333333");
	this.c9_op1.name = "c9_op1";
	this.c9_op1.lineHeight = 18;
	this.c9_op1.lineWidth = 318;
	this.c9_op1.parent = this;
	this.c9_op1.setTransform(570.3,229.5);

	this.c9_0 = new lib.mc_radioButton9();
	this.c9_0.parent = this;
	this.c9_0.setTransform(544.9,171.9,1,1,0,0,0,18,18.1);

	this.p9 = new cjs.Text("¿Qué debemos hacer en los casos donde no se cuente con evaluación del desempeño?", "20px 'Arial'");
	this.p9.name = "p9";
	this.p9.lineHeight = 24;
	this.p9.lineWidth = 331;
	this.p9.parent = this;
	this.p9.setTransform(110,17.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.p9},{t:this.c9_0},{t:this.c9_op1},{t:this.c9_op2},{t:this.c9_op0},{t:this.c9_1},{t:this.c9_2},{t:this.shape_770},{t:this.shape_769},{t:this.shape_768},{t:this.shape_767},{t:this.shape_766},{t:this.shape_765},{t:this.shape_764},{t:this.shape_763},{t:this.shape_762},{t:this.shape_761},{t:this.shape_760},{t:this.shape_759},{t:this.shape_758},{t:this.shape_757},{t:this.shape_756},{t:this.shape_755},{t:this.shape_754},{t:this.shape_753},{t:this.shape_752},{t:this.shape_751},{t:this.shape_750},{t:this.shape_749},{t:this.shape_748},{t:this.shape_747},{t:this.shape_746},{t:this.shape_745},{t:this.shape_744},{t:this.shape_743},{t:this.shape_742},{t:this.shape_741},{t:this.shape_740},{t:this.shape_739},{t:this.shape_738},{t:this.shape_737},{t:this.shape_736},{t:this.shape_735},{t:this.shape_734},{t:this.shape_733},{t:this.shape_732},{t:this.shape_731},{t:this.shape_730},{t:this.shape_729},{t:this.shape_728},{t:this.shape_727},{t:this.shape_726},{t:this.shape_725},{t:this.shape_724},{t:this.instance_27},{t:this.shape_723},{t:this.shape_722},{t:this.shape_721},{t:this.shape_720},{t:this.shape_719},{t:this.shape_718},{t:this.shape_717},{t:this.shape_716},{t:this.shape_715},{t:this.shape_714},{t:this.shape_713},{t:this.shape_712},{t:this.shape_711},{t:this.shape_710},{t:this.shape_709},{t:this.shape_708},{t:this.shape_707},{t:this.shape_706},{t:this.shape_705},{t:this.shape_704},{t:this.shape_703},{t:this.shape_702},{t:this.shape_701},{t:this.shape_700},{t:this.shape_699},{t:this.shape_698},{t:this.shape_697},{t:this.shape_696},{t:this.shape_695},{t:this.shape_694},{t:this.shape_693},{t:this.shape_692},{t:this.shape_691},{t:this.shape_690},{t:this.shape_689},{t:this.shape_688},{t:this.shape_687},{t:this.shape_686},{t:this.shape_685},{t:this.shape_684},{t:this.shape_683},{t:this.shape_682},{t:this.shape_681},{t:this.shape_680},{t:this.shape_679},{t:this.shape_678},{t:this.shape_677},{t:this.shape_676},{t:this.shape_675},{t:this.shape_674},{t:this.shape_673},{t:this.shape_672},{t:this.shape_671},{t:this.shape_670},{t:this.shape_669},{t:this.shape_668},{t:this.shape_667},{t:this.shape_666},{t:this.shape_665},{t:this.shape_664},{t:this.shape_663},{t:this.shape_662},{t:this.shape_661},{t:this.shape_660},{t:this.shape_659},{t:this.shape_658},{t:this.shape_657},{t:this.shape_656},{t:this.shape_655},{t:this.shape_654},{t:this.shape_653},{t:this.shape_652},{t:this.shape_651},{t:this.shape_650},{t:this.shape_649},{t:this.shape_648},{t:this.shape_647},{t:this.shape_646},{t:this.shape_645},{t:this.shape_644},{t:this.shape_643},{t:this.shape_642},{t:this.shape_641},{t:this.shape_640},{t:this.shape_639},{t:this.shape_638},{t:this.shape_637},{t:this.shape_636},{t:this.shape_635},{t:this.shape_634},{t:this.shape_633},{t:this.instance_26},{t:this.instance_25},{t:this.instance_24},{t:this.instance_23},{t:this.instance_22},{t:this.instance_21},{t:this.instance_20},{t:this.instance_19},{t:this.instance_18},{t:this.instance_17},{t:this.instance_16},{t:this.instance_15},{t:this.shape_632},{t:this.shape_631},{t:this.instance_14},{t:this.instance_13},{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.shape_630},{t:this.shape_629},{t:this.shape_628},{t:this.shape_627},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance},{t:this.shape_626},{t:this.shape_625},{t:this.shape_624},{t:this.shape_623},{t:this.shape_622},{t:this.shape_621},{t:this.shape_620},{t:this.shape_619},{t:this.shape_618},{t:this.shape_617},{t:this.shape_616},{t:this.shape_615},{t:this.shape_614},{t:this.shape_613},{t:this.shape_612},{t:this.shape_611},{t:this.shape_610},{t:this.shape_609},{t:this.shape_608},{t:this.shape_607},{t:this.shape_606},{t:this.shape_605},{t:this.shape_604},{t:this.shape_603},{t:this.shape_602},{t:this.shape_601},{t:this.shape_600},{t:this.shape_599},{t:this.shape_598},{t:this.shape_597},{t:this.shape_596},{t:this.shape_595},{t:this.shape_594},{t:this.shape_593},{t:this.shape_592},{t:this.shape_591},{t:this.shape_590},{t:this.shape_589},{t:this.shape_588},{t:this.shape_587},{t:this.shape_586},{t:this.shape_585},{t:this.shape_584},{t:this.shape_583},{t:this.shape_582},{t:this.shape_581},{t:this.shape_580},{t:this.shape_579},{t:this.shape_578},{t:this.shape_577},{t:this.shape_576},{t:this.shape_575},{t:this.shape_574},{t:this.shape_573},{t:this.shape_572},{t:this.shape_571},{t:this.shape_570},{t:this.shape_569},{t:this.shape_568},{t:this.shape_567},{t:this.shape_566},{t:this.shape_565},{t:this.shape_564},{t:this.shape_563},{t:this.shape_562},{t:this.shape_561},{t:this.shape_560},{t:this.shape_559},{t:this.shape_558},{t:this.shape_557},{t:this.shape_556},{t:this.shape_555},{t:this.shape_554},{t:this.shape_553},{t:this.shape_552},{t:this.shape_551},{t:this.shape_550},{t:this.shape_549},{t:this.shape_548},{t:this.shape_547},{t:this.shape_546},{t:this.shape_545},{t:this.shape_544},{t:this.shape_543},{t:this.shape_542},{t:this.shape_541},{t:this.shape_540},{t:this.shape_539},{t:this.shape_538},{t:this.shape_537},{t:this.shape_536},{t:this.shape_535},{t:this.shape_534},{t:this.shape_533},{t:this.shape_532},{t:this.shape_531},{t:this.shape_530},{t:this.shape_529},{t:this.shape_528},{t:this.shape_527},{t:this.shape_526},{t:this.shape_525},{t:this.shape_524},{t:this.shape_523},{t:this.shape_522},{t:this.shape_521},{t:this.shape_520},{t:this.shape_519},{t:this.shape_518},{t:this.shape_517},{t:this.shape_516},{t:this.shape_515},{t:this.shape_514},{t:this.shape_513},{t:this.shape_512},{t:this.shape_511},{t:this.shape_510},{t:this.shape_509},{t:this.shape_508},{t:this.shape_507},{t:this.shape_506},{t:this.shape_505},{t:this.shape_504},{t:this.shape_503},{t:this.shape_502},{t:this.shape_501},{t:this.shape_500},{t:this.shape_499},{t:this.shape_498},{t:this.shape_497},{t:this.shape_496},{t:this.shape_495},{t:this.shape_494},{t:this.shape_493},{t:this.shape_492},{t:this.shape_491},{t:this.shape_490},{t:this.shape_489},{t:this.shape_488},{t:this.shape_487},{t:this.shape_486},{t:this.shape_485},{t:this.shape_484},{t:this.shape_483},{t:this.shape_482},{t:this.shape_481},{t:this.shape_480},{t:this.shape_479},{t:this.shape_478},{t:this.shape_477},{t:this.shape_476},{t:this.shape_475},{t:this.shape_474},{t:this.shape_473},{t:this.shape_472},{t:this.shape_471},{t:this.shape_470},{t:this.shape_469},{t:this.shape_468},{t:this.shape_467},{t:this.shape_466},{t:this.shape_465},{t:this.shape_464},{t:this.shape_463},{t:this.shape_462},{t:this.shape_461},{t:this.shape_460},{t:this.shape_459},{t:this.shape_458},{t:this.shape_457},{t:this.shape_456},{t:this.shape_455},{t:this.shape_454},{t:this.shape_453},{t:this.shape_452},{t:this.shape_451},{t:this.shape_450},{t:this.shape_449},{t:this.shape_448},{t:this.shape_447},{t:this.shape_446},{t:this.shape_445},{t:this.shape_444},{t:this.shape_443},{t:this.shape_442},{t:this.shape_441},{t:this.shape_440},{t:this.shape_439},{t:this.shape_438},{t:this.shape_437},{t:this.shape_436},{t:this.shape_435},{t:this.shape_434},{t:this.shape_433},{t:this.shape_432},{t:this.shape_431},{t:this.shape_430},{t:this.shape_429},{t:this.shape_428},{t:this.shape_427},{t:this.shape_426},{t:this.shape_425},{t:this.shape_424},{t:this.shape_423},{t:this.shape_422},{t:this.shape_421},{t:this.shape_420},{t:this.shape_419},{t:this.shape_418},{t:this.shape_417},{t:this.shape_416},{t:this.shape_415},{t:this.shape_414},{t:this.shape_413},{t:this.shape_412},{t:this.shape_411},{t:this.shape_410},{t:this.shape_409},{t:this.shape_408},{t:this.shape_407},{t:this.shape_406},{t:this.shape_405},{t:this.shape_404},{t:this.shape_403},{t:this.shape_402},{t:this.shape_401},{t:this.shape_400},{t:this.shape_399},{t:this.shape_398},{t:this.shape_397},{t:this.shape_396},{t:this.shape_395},{t:this.shape_394},{t:this.shape_393},{t:this.shape_392},{t:this.shape_391},{t:this.shape_390},{t:this.shape_389},{t:this.shape_388},{t:this.shape_387},{t:this.shape_386},{t:this.shape_385},{t:this.shape_384},{t:this.shape_383},{t:this.shape_382},{t:this.shape_381},{t:this.shape_380},{t:this.shape_379},{t:this.shape_378},{t:this.shape_377},{t:this.shape_376},{t:this.shape_375},{t:this.shape_374},{t:this.shape_373},{t:this.shape_372},{t:this.shape_371},{t:this.shape_370},{t:this.shape_369},{t:this.shape_368},{t:this.shape_367},{t:this.shape_366},{t:this.shape_365},{t:this.shape_364},{t:this.shape_363},{t:this.shape_362},{t:this.shape_361},{t:this.shape_360},{t:this.shape_359},{t:this.shape_358},{t:this.shape_357},{t:this.shape_356},{t:this.shape_355},{t:this.shape_354},{t:this.shape_353},{t:this.shape_352},{t:this.shape_351},{t:this.shape_350},{t:this.shape_349},{t:this.shape_348},{t:this.shape_347},{t:this.shape_346},{t:this.shape_345},{t:this.shape_344},{t:this.shape_343},{t:this.shape_342},{t:this.shape_341},{t:this.shape_340},{t:this.shape_339},{t:this.shape_338},{t:this.shape_337},{t:this.shape_336},{t:this.shape_335},{t:this.shape_334},{t:this.shape_333},{t:this.shape_332},{t:this.shape_331},{t:this.shape_330},{t:this.shape_329},{t:this.shape_328},{t:this.shape_327},{t:this.shape_326},{t:this.shape_325},{t:this.shape_324},{t:this.shape_323},{t:this.shape_322},{t:this.shape_321},{t:this.shape_320},{t:this.shape_319},{t:this.shape_318},{t:this.shape_317},{t:this.shape_316},{t:this.shape_315},{t:this.shape_314},{t:this.shape_313},{t:this.shape_312},{t:this.shape_311},{t:this.shape_310},{t:this.shape_309},{t:this.shape_308},{t:this.shape_307},{t:this.shape_306},{t:this.shape_305},{t:this.shape_304},{t:this.shape_303},{t:this.shape_302},{t:this.shape_301},{t:this.shape_300},{t:this.shape_299},{t:this.shape_298},{t:this.shape_297},{t:this.shape_296},{t:this.shape_295},{t:this.shape_294},{t:this.shape_293},{t:this.shape_292},{t:this.shape_291},{t:this.shape_290},{t:this.shape_289},{t:this.shape_288},{t:this.shape_287},{t:this.shape_286},{t:this.shape_285},{t:this.shape_284},{t:this.shape_283},{t:this.shape_282},{t:this.shape_281},{t:this.shape_280},{t:this.shape_279},{t:this.shape_278},{t:this.shape_277},{t:this.shape_276},{t:this.shape_275},{t:this.shape_274},{t:this.shape_273},{t:this.shape_272},{t:this.shape_271},{t:this.shape_270},{t:this.shape_269},{t:this.shape_268},{t:this.shape_267},{t:this.shape_266},{t:this.shape_265},{t:this.shape_264},{t:this.shape_263},{t:this.shape_262},{t:this.shape_261},{t:this.shape_260},{t:this.shape_259},{t:this.shape_258},{t:this.shape_257},{t:this.shape_256},{t:this.shape_255},{t:this.shape_254},{t:this.shape_253},{t:this.shape_252},{t:this.shape_251},{t:this.shape_250},{t:this.shape_249},{t:this.shape_248},{t:this.shape_247},{t:this.shape_246},{t:this.shape_245},{t:this.shape_244},{t:this.shape_243},{t:this.shape_242},{t:this.shape_241},{t:this.shape_240},{t:this.shape_239},{t:this.shape_238},{t:this.shape_237},{t:this.shape_236},{t:this.shape_235},{t:this.shape_234},{t:this.shape_233},{t:this.shape_232},{t:this.shape_231},{t:this.shape_230},{t:this.shape_229},{t:this.shape_228},{t:this.shape_227},{t:this.shape_226},{t:this.shape_225},{t:this.shape_224},{t:this.shape_223},{t:this.shape_222},{t:this.shape_221},{t:this.shape_220},{t:this.shape_219},{t:this.shape_218},{t:this.shape_217},{t:this.shape_216},{t:this.shape_215},{t:this.shape_214},{t:this.shape_213},{t:this.shape_212},{t:this.shape_211},{t:this.shape_210},{t:this.shape_209},{t:this.shape_208},{t:this.shape_207},{t:this.shape_206},{t:this.shape_205},{t:this.shape_204},{t:this.shape_203},{t:this.shape_202},{t:this.shape_201},{t:this.shape_200},{t:this.shape_199},{t:this.shape_198},{t:this.shape_197},{t:this.shape_196},{t:this.shape_195},{t:this.shape_194},{t:this.shape_193},{t:this.shape_192},{t:this.shape_191},{t:this.shape_190},{t:this.shape_189},{t:this.shape_188},{t:this.shape_187},{t:this.shape_186},{t:this.shape_185},{t:this.shape_184},{t:this.shape_183},{t:this.shape_182},{t:this.shape_181},{t:this.shape_180},{t:this.shape_179},{t:this.shape_178},{t:this.shape_177},{t:this.shape_176},{t:this.shape_175},{t:this.shape_174},{t:this.shape_173},{t:this.shape_172},{t:this.shape_171},{t:this.shape_170},{t:this.shape_169},{t:this.shape_168},{t:this.shape_167},{t:this.shape_166},{t:this.shape_165},{t:this.shape_164},{t:this.shape_163},{t:this.shape_162},{t:this.shape_161},{t:this.shape_160},{t:this.shape_159},{t:this.shape_158},{t:this.shape_157},{t:this.shape_156},{t:this.shape_155},{t:this.shape_154},{t:this.shape_153},{t:this.shape_152},{t:this.shape_151},{t:this.shape_150},{t:this.shape_149},{t:this.shape_148},{t:this.shape_147},{t:this.shape_146},{t:this.shape_145},{t:this.shape_144},{t:this.shape_143},{t:this.shape_142},{t:this.shape_141},{t:this.shape_140},{t:this.shape_139},{t:this.shape_138},{t:this.shape_137},{t:this.shape_136},{t:this.shape_135},{t:this.shape_134},{t:this.shape_133},{t:this.shape_132},{t:this.shape_131},{t:this.shape_130},{t:this.shape_129},{t:this.shape_128},{t:this.shape_127},{t:this.shape_126},{t:this.shape_125},{t:this.shape_124},{t:this.shape_123},{t:this.shape_122},{t:this.shape_121},{t:this.shape_120},{t:this.shape_119},{t:this.shape_118},{t:this.shape_117},{t:this.shape_116},{t:this.shape_115},{t:this.shape_114},{t:this.shape_113},{t:this.shape_112},{t:this.shape_111},{t:this.shape_110},{t:this.shape_109},{t:this.shape_108},{t:this.shape_107},{t:this.shape_106},{t:this.shape_105},{t:this.shape_104},{t:this.shape_103},{t:this.shape_102},{t:this.shape_101},{t:this.shape_100},{t:this.shape_99},{t:this.shape_98},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_94},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// fondo y encabezado
	this.instance_28 = new lib.iconoactividadesyretos("synched",0);
	this.instance_28.parent = this;
	this.instance_28.setTransform(475.7,95.1,0.551,0.551,0,0,0,55.7,55.7);

	this.shape_771 = new cjs.Shape();
	this.shape_771.graphics.f("rgba(230,149,122,0.498)").s().p("EgiSAJ5QjsAAAAjsIAAsZQAAjsDsAAMBElAAAQDsAAAADsIAAMZQAADsjsAAg");
	this.shape_771.setTransform(254.4,49.7);

	this.instance_29 = new lib.fondo("synched",0);
	this.instance_29.parent = this;
	this.instance_29.setTransform(469.6,267.3,1,1,0,0,0,485.2,268.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_29},{t:this.shape_771},{t:this.instance_28}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.evalpag9, new cjs.Rectangle(2.4,-36.5,958.3,510.2), null);


(lib.evalpag8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		/*NOTA IMPROTANTE:
		EN CADA ACTIVIDAD CON MC IGUALES, SE TIENEN QUE DUPLICAR
		NO BASTA CON CAMBIARLES LA INSTANCIA, A NIVEL CÓDIGO NO HAY DIFERENCIA
		ADEMAS DE QUE TIENEN QUE TENER INSTANCIAS DIFERENTES A LAS ANTERIORES
		*/
		this.stop();
		var root = this;
		var resp = 2;
		var correcta = 2;
		root.p8.text=("Se define como el resultado del cumplimiento de objetivos y principios culturales que realiza el colaborador para contribuir a la organización y al equipo.");
		root.c8_op0.text=("Potencial.");
		root.c8_op1.text=("Éxito.");
		root.c8_op2.text=("Desempeño.");
		iniciar();
		
		function iniciar() {
			root.parent.parent.btn_siguiente.visible = false;
			for (var i = 0; i <= resp; i++) {
				root['c8_' + i].cursor = "pointer";
				root['c8_' + i].n = i;
				root['c8_' + i].addEventListener("click", cambios);
				root['c8_' + i].gotoAndStop(1);
			}
		}
		
		function cambios(r) {
			//Cambia el estatus de la opcion seleccionada
			for (var i = 0; i <= resp; i++) {
				if (root['c8_' + i].n != r.currentTarget.n) {
					root['c8_' + i].gotoAndStop(0);
				} else {
					root['c8_' + i].gotoAndStop(1);
				}
			}
		
			//Valida la respuesta
			if (r.currentTarget.n == correcta) {
				root.parent.parent.resultados[root.parent.parent.cont] = 10;
				console.log("Respuesta Correcta " + root.parent.parent.resultados[root.parent.parent.cont]);
			} else {
				root.parent.parent.resultados[root.parent.parent.cont] = 0;
				console.log("Respuesta Incorrecta " + root.parent.parent.resultados[root.parent.parent.cont]);
			}
			root.parent.parent.activarSiguiente();
			root.parent.parent.registrar_pregunta(root.p8.text, root['c8_op'+r.currentTarget.n].text, root['c8_op'+correcta].text);
		
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.instance = new lib.M03_TMR_DESEMPEÑO();
	this.instance.parent = this;
	this.instance.setTransform(248.7,310,0.866,0.866,0,0,0,117.1,110.9);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#DFE5DF").s().p("AlaM0QifhEh7h7Qh7h7hEifQhGimAAi1QAAi0BGilQBEigB7h8QB7h6CfhEQCmhGC0AAQC1AAClBGQCgBEB7B6QB7B8BECgQBGClAAC0QAAC1hGCmQhECfh7B7Qh7B7igBEQilBGi1AAQi0AAimhGg");
	this.shape.setTransform(241.6,280.6,1.389,1.389);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#EFEFEF").s().p("AljNKQikhGh+h+Qh/h+hFikQhIiqAAi6QAAi5BIiqQBFikB/h+QB+h/CkhFQCqhIC5AAQC6AACqBIQCjBFCAB/QB9B+BGCkQBICqAAC5QAAC6hICqQhGCkh9B+QiAB+ijBGQiqBIi6AAQi5AAiqhIg");
	this.shape_1.setTransform(241.6,280.4,1.525,1.525);

	this.c8_2 = new lib.mc_radioButton8();
	this.c8_2.parent = this;
	this.c8_2.setTransform(634.9,368.2,1,1,0,0,0,18,18.1);

	this.c8_1 = new lib.mc_radioButton8();
	this.c8_1.parent = this;
	this.c8_1.setTransform(634.9,272.5,1,1,0,0,0,18,18.1);

	this.c8_op0 = new cjs.Text("Potencial.", "16px 'Arial'", "#333333");
	this.c8_op0.name = "c8_op0";
	this.c8_op0.lineHeight = 18;
	this.c8_op0.lineWidth = 165;
	this.c8_op0.parent = this;
	this.c8_op0.setTransform(664.3,167.3);

	this.c8_op2 = new cjs.Text("Desempeño.", "16px 'Arial'", "#333333");
	this.c8_op2.name = "c8_op2";
	this.c8_op2.lineHeight = 18;
	this.c8_op2.lineWidth = 166;
	this.c8_op2.parent = this;
	this.c8_op2.setTransform(664.3,358.8);

	this.c8_op1 = new cjs.Text("Éxito.", "16px 'Arial'");
	this.c8_op1.name = "c8_op1";
	this.c8_op1.lineHeight = 18;
	this.c8_op1.lineWidth = 165;
	this.c8_op1.parent = this;
	this.c8_op1.setTransform(664.3,263.1);

	this.c8_0 = new lib.mc_radioButton8();
	this.c8_0.parent = this;
	this.c8_0.setTransform(634.9,176.7,1,1,0,0,0,18,18.1);

	this.p8 = new cjs.Text("Se define como el resultado del cumplimiento de objetivos y principios culturales que realiza el colaborador para contribuir a la organización y al equipo.", "20px 'Arial'");
	this.p8.name = "p8";
	this.p8.lineHeight = 22;
	this.p8.lineWidth = 368;
	this.p8.parent = this;
	this.p8.setTransform(107,6.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.p8},{t:this.c8_0},{t:this.c8_op1},{t:this.c8_op2},{t:this.c8_op0},{t:this.c8_1},{t:this.c8_2},{t:this.shape_1},{t:this.shape},{t:this.instance}]}).wait(1));

	// fondo y encabezado
	this.instance_1 = new lib.iconoactividadesyretos("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(501.7,99.7,0.551,0.551,0,0,0,55.7,55.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(230,149,122,0.498)").s().p("Egi/AJ5QjmAAAAjsIAAsZQAAjsDmAAMBF/AAAQDmAAAADsIAAMZQAADsjmAAg");
	this.shape_2.setTransform(258,49.7);

	this.instance_2 = new lib.fondo("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(469.6,267.3,1,1,0,0,0,485.2,268.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.shape_2},{t:this.instance_1}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.evalpag8, new cjs.Rectangle(2.4,-36.5,958.3,510.2), null);


(lib.evalpag7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		/*NOTA IMPROTANTE:
		EN CADA ACTIVIDAD CON MC IGUALES, SE TIENEN QUE DUPLICAR
		NO BASTA CON CAMBIARLES LA INSTANCIA, A NIVEL CÓDIGO NO HAY DIFERENCIA
		ADEMAS DE QUE TIENEN QUE TENER INSTANCIAS DIFERENTES A LAS ANTERIORES
		*/
		this.stop();
		var root = this;
		var resp = 2;
		var correcta = 2;
		root.p7.text=("Consideramos que un colaborador tiene “Alto Potencial” cuando:");
		root.c7_op0.text=("Cumple con los requerimientos del puesto o presenta algunas brechas para cumplir con su rol actual.");
		root.c7_op1.text=("Tiene buena relación con sus compañeros, clientes y proveedores.");
		root.c7_op2.text=("Tiene las habilidades, aspiraciones y compromiso para asumir un puesto con mayor responsabilidad y desempeñarlo de forma exitosa.");
		iniciar();
		
		function iniciar() {
			root.parent.parent.btn_siguiente.visible = false;
			for (var i = 0; i <= resp; i++) {
				root['c7_' + i].cursor = "pointer";
				root['c7_' + i].n = i;
				root['c7_' + i].addEventListener("click", cambios);
				root['c7_' + i].gotoAndStop(1);
			}
		}
		
		function cambios(r) {
			//Cambia el estatus de la opcion seleccionada
			for (var i = 0; i <= resp; i++) {
				if (root['c7_' + i].n != r.currentTarget.n) {
					root['c7_' + i].gotoAndStop(0);
				} else {
					root['c7_' + i].gotoAndStop(1);
				}
			}
		
			//Valida la respuesta
			if (r.currentTarget.n == correcta) {
				root.parent.parent.resultados[root.parent.parent.cont] = 10;
				console.log("Respuesta Correcta " + root.parent.parent.resultados[root.parent.parent.cont]);
			} else {
				root.parent.parent.resultados[root.parent.parent.cont] = 0;
				console.log("Respuesta Incorrecta " + root.parent.parent.resultados[root.parent.parent.cont]);
			}
			root.parent.parent.activarSiguiente();
			root.parent.parent.registrar_pregunta(root.p7.text, root['c7_op'+r.currentTarget.n].text, root['c7_op'+correcta].text);
		
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.instance = new lib.M03_TMR_BICI3();
	this.instance.parent = this;
	this.instance.setTransform(240.2,294.7,0.396,0.396,0,0,0,198.5,217.6);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("ArKLLQkckcgMmuQAMmvEckcQEdkdGtgKQGvAKEcEdQEdEcALGvQgLGukdEcQkcEcmvALQmtgLkdkcg");
	this.shape.setTransform(230.7,296);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CFE1B5").s().p("AtnMiQkelFgLnOQAOn2FOlLQFMlPH2gNQIGANFSFfQEhFGAKHOQgOH0lPFNQlLFOn5AOQoHgOlQlfg");
	this.shape_1.setTransform(230,294);

	this.c7_2 = new lib.mc_radioButton7();
	this.c7_2.parent = this;
	this.c7_2.setTransform(544.9,332,1,1,0,0,0,18,18.1);

	this.c7_1 = new lib.mc_radioButton7();
	this.c7_1.parent = this;
	this.c7_1.setTransform(544.9,250.2,1,1,0,0,0,18,18.1);

	this.c7_op0 = new cjs.Text("Cumple con los requerimientos del puesto o presenta algunas brechas para cumplir con su rol actual.\n", "16px 'Arial'", "#333333");
	this.c7_op0.name = "c7_op0";
	this.c7_op0.lineHeight = 18;
	this.c7_op0.lineWidth = 359;
	this.c7_op0.parent = this;
	this.c7_op0.setTransform(573.3,140.1);

	this.c7_op2 = new cjs.Text("Tiene las habilidades, aspiraciones y compromiso para asumir un puesto con mayor responsabilidad y desempeñarlo de forma exitosa.", "16px 'Arial'", "#333333");
	this.c7_op2.name = "c7_op2";
	this.c7_op2.lineHeight = 18;
	this.c7_op2.lineWidth = 366;
	this.c7_op2.parent = this;
	this.c7_op2.setTransform(573.8,322.8);

	this.c7_op1 = new cjs.Text("Tiene buena relación con sus compañeros, clientes y proveedores.", "16px 'Arial'", "#333333");
	this.c7_op1.name = "c7_op1";
	this.c7_op1.lineHeight = 18;
	this.c7_op1.lineWidth = 361;
	this.c7_op1.parent = this;
	this.c7_op1.setTransform(573.3,239.8);

	this.c7_0 = new lib.mc_radioButton7();
	this.c7_0.parent = this;
	this.c7_0.setTransform(544.9,150.5,1,1,0,0,0,18,18.1);

	this.p7 = new cjs.Text("Consideramos que un colaborador tiene “Alto Potencial” cuando:", "20px 'Arial'");
	this.p7.name = "p7";
	this.p7.lineHeight = 24;
	this.p7.lineWidth = 316;
	this.p7.parent = this;
	this.p7.setTransform(118,25.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.p7},{t:this.c7_0},{t:this.c7_op1},{t:this.c7_op2},{t:this.c7_op0},{t:this.c7_1},{t:this.c7_2},{t:this.shape_1},{t:this.shape},{t:this.instance}]}).wait(1));

	// fondo y encabezado
	this.instance_1 = new lib.iconoactividadesyretos("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(475.7,95.1,0.551,0.551,0,0,0,55.7,55.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(230,149,122,0.498)").s().p("EgiSAJ5QjsAAAAjsIAAsZQAAjsDsAAMBElAAAQDsAAAADsIAAMZQAADsjsAAg");
	this.shape_2.setTransform(254.4,49.7);

	this.instance_2 = new lib.fondo("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(469.6,267.3,1,1,0,0,0,485.2,268.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.shape_2},{t:this.instance_1}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.evalpag7, new cjs.Rectangle(2.4,-36.5,958.3,510.2), null);


(lib.evalpag6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		/*NOTA IMPROTANTE:
		EN CADA ACTIVIDAD CON MC IGUALES, SE TIENEN QUE DUPLICAR
		NO BASTA CON CAMBIARLES LA INSTANCIA, A NIVEL CÓDIGO NO HAY DIFERENCIA
		ADEMAS DE QUE TIENEN QUE TENER INSTANCIAS DIFERENTES A LAS ANTERIORES
		*/
		this.stop();
		var root = this;
		var resp = 2;
		var correcta = 1;
		root.p6.text=("Es la herramienta que nos ayuda a evaluar el potencial de nuestros colaboradores en el sistema SuccessFactors.");
		root.c6_op0.text=("Brecha de disponibilidad.");
		root.c6_op1.text=("Check list de potencial.");
		root.c6_op2.text=("Herramienta de criticidad.");
		iniciar();
		
		function iniciar() {
			root.parent.parent.btn_siguiente.visible = false;
			for (var i = 0; i <= resp; i++) {
				root['c6_' + i].cursor = "pointer";
				root['c6_' + i].n = i;
				root['c6_' + i].addEventListener("click", cambios);
				root['c6_' + i].gotoAndStop(1);
			}
		}
		
		function cambios(r) {
			//Cambia el estatus de la opcion seleccionada
			for (var i = 0; i <= resp; i++) {
				if (root['c6_' + i].n != r.currentTarget.n) {
					root['c6_' + i].gotoAndStop(0);
				} else {
					root['c6_' + i].gotoAndStop(1);
				}
			}
		
			//Valida la respuesta
			if (r.currentTarget.n == correcta) {
				root.parent.parent.resultados[root.parent.parent.cont] = 10;
				console.log("Respuesta Correcta " + root.parent.parent.resultados[root.parent.parent.cont]);
			} else {
				root.parent.parent.resultados[root.parent.parent.cont] = 0;
				console.log("Respuesta Incorrecta " + root.parent.parent.resultados[root.parent.parent.cont]);
			}
			root.parent.parent.activarSiguiente();
			root.parent.parent.registrar_pregunta(root.p6.text, root['c6_op'+r.currentTarget.n].text, root['c6_op'+correcta].text);
		
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#3F3231").s().p("AkHDCIgTgFQgDABgFgRQgMghgOhZQgGgqASgiQANgaAZgUQgDgkANgfQATguAygXIgOAVQgPAZgEASQAAAAAAABQAAAAAAABQAAAAABABQAAAAABAAQAAAAABABQAAAAABgBQAAAAABAAQAAAAABgBQAdgjA3gZQBYgpB8gDQgtAHghASQgEACACAEQABADAEAAQA2gGAzAEQBPAIAzAhQgOgDgVABQAAAAgBAAQAAAAgBABQAAAAAAAAQAAABAAAAQgBABABAAQAAABAAAAQAAAAAAAAQABABAAAAQAoAQAcAbQAtArAAA8QgQgUgLgLQgBgBAAAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQAAABgBAAQAAAAAAAAQAAABAAAAQAAAAAAABQARAvgNAvQgBgNgQgOQgCBJgVBhQgVgCgPAXIgKAYQACghgCgpQgEhQgVghQg3hTiXADQgwAAgzAKIgqAJIgSAlQgXArgWAZQgDAMgEBLIgEBIQgDgogUgMg");
	this.shape.setTransform(260.3,307.6,0.912,0.912);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#3F3231").s().p("ABGAtIgCgBQgMgCgKgIQgNgKAAgQIAAgEQgNgLgOACIgCAAQgNgCgMALIAAAEQAAAQgOAKQgJAIgNACIgCABIhuAAIgDgCQgSgHgIgMQgGgJAAgJIAAgHIggADIgFgVIAogGQAIgPAZgDIABgBIBnAAQAQAAALAHQAJAGAEAIQAQgGANABQAOgBAQAGQAEgIAJgGQALgHAQAAIBnAAIABABQAZADAIAPIAeAEIgDAOIgYAGIAAAHQABAJgHAJQgIAMgSAHIgDACgAAxgWIAAAiQAAAEACAEQAEAIAKAGIB3AAQAOgFAAgQIAAgiQgEgJgMAAIh4AAQgNADAAAFgAi7gWIAAAiQAAAEACAEQAEAIAKAGIB3AAQAOgEAAgRIAAgiQgDgJgNAAIh4AAQgNADAAAFg");
	this.shape_1.setTransform(258.3,324.8,0.912,0.912);

	this.instance = new lib.Group_19();
	this.instance.parent = this;
	this.instance.setTransform(295.5,375.8,0.912,0.912,0,0,0,3.4,8);
	this.instance.alpha = 0.391;

	this.instance_1 = new lib.Group_1_2();
	this.instance_1.parent = this;
	this.instance_1.setTransform(291.4,378.6,0.912,0.912,0,0,0,2.1,5);
	this.instance_1.alpha = 0.391;

	this.instance_2 = new lib.Group_2_2();
	this.instance_2.parent = this;
	this.instance_2.setTransform(291.2,375.1,0.912,0.912,0,0,0,4.5,9.1);
	this.instance_2.alpha = 0.391;

	this.instance_3 = new lib.Group_3_2();
	this.instance_3.parent = this;
	this.instance_3.setTransform(228.5,375.1,0.912,0.912,0,0,0,4.4,9.1);
	this.instance_3.alpha = 0.391;

	this.instance_4 = new lib.Group_4_2();
	this.instance_4.parent = this;
	this.instance_4.setTransform(226.7,377.2,0.912,0.912,0,0,0,2.5,6.4);
	this.instance_4.alpha = 0.391;

	this.instance_5 = new lib.Group_5_2();
	this.instance_5.parent = this;
	this.instance_5.setTransform(223.7,375.4,0.912,0.912,0,0,0,3.3,8.4);
	this.instance_5.alpha = 0.391;

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#A9B3BC").s().p("AhSATICHhOIAeA7QgDAXgsAVIgpAQg");
	this.shape_2.setTransform(267.2,364.5,0.912,0.912);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#A9B3BC").s().p("AgdAsQg0gegDgWIAdg8ICMBgIhAApQgZgKgZgPg");
	this.shape_3.setTransform(252,363.7,0.912,0.912);

	this.instance_6 = new lib.Group_6_2();
	this.instance_6.parent = this;
	this.instance_6.setTransform(262.8,374.1,0.912,0.912,0,0,0,1.2,9.8);
	this.instance_6.alpha = 0.391;

	this.instance_7 = new lib.Group_7_2();
	this.instance_7.parent = this;
	this.instance_7.setTransform(268.4,374,0.912,0.912,0,0,0,1.2,10.4);
	this.instance_7.alpha = 0.391;

	this.instance_8 = new lib.Group_8_2();
	this.instance_8.parent = this;
	this.instance_8.setTransform(272.9,373.5,0.912,0.912,0,0,0,1.2,10.6);
	this.instance_8.alpha = 0.391;

	this.instance_9 = new lib.Group_9_2();
	this.instance_9.parent = this;
	this.instance_9.setTransform(286.5,374,0.912,0.912,0,0,0,1.3,10.2);
	this.instance_9.alpha = 0.391;

	this.instance_10 = new lib.Group_10_2();
	this.instance_10.parent = this;
	this.instance_10.setTransform(282.7,373.3,0.912,0.912,0,0,0,1.3,10.9);
	this.instance_10.alpha = 0.391;

	this.instance_11 = new lib.Group_11_2();
	this.instance_11.parent = this;
	this.instance_11.setTransform(277.2,372.8,0.912,0.912,0,0,0,1.5,11.1);
	this.instance_11.alpha = 0.391;

	this.instance_12 = new lib.Group_12_2();
	this.instance_12.parent = this;
	this.instance_12.setTransform(256.8,374.1,0.912,0.912,0,0,0,1.2,9.8);
	this.instance_12.alpha = 0.391;

	this.instance_13 = new lib.Group_13_2();
	this.instance_13.parent = this;
	this.instance_13.setTransform(251.1,374,0.912,0.912,0,0,0,1.3,10.4);
	this.instance_13.alpha = 0.391;

	this.instance_14 = new lib.Group_14_2();
	this.instance_14.parent = this;
	this.instance_14.setTransform(246.5,373.5,0.912,0.912,0,0,0,1.3,10.6);
	this.instance_14.alpha = 0.391;

	this.instance_15 = new lib.Group_15_2();
	this.instance_15.parent = this;
	this.instance_15.setTransform(233,374,0.912,0.912,0,0,0,1.3,10.2);
	this.instance_15.alpha = 0.391;

	this.instance_16 = new lib.Group_16_2();
	this.instance_16.parent = this;
	this.instance_16.setTransform(236.9,373.3,0.912,0.912,0,0,0,1.2,10.9);
	this.instance_16.alpha = 0.391;

	this.instance_17 = new lib.Group_17_2();
	this.instance_17.parent = this;
	this.instance_17.setTransform(242.5,372.8,0.912,0.912,0,0,0,1.2,11.1);
	this.instance_17.alpha = 0.391;

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#BBCACB").s().p("Aj1CDQA7i3AagRQAogbBXgPQAqgHAjgCQBMgaBFAqQAjAVATAaIADC8g");
	this.shape_4.setTransform(240.4,373.8,0.912,0.912);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#CCD0D0").s().p("Aj9CDIAIi8IAOgQQATgSAVgNQBFgqBLAaIBOAJQBXAPAoAbQAPAKAaA2QAaA1AdBTg");
	this.shape_5.setTransform(280,373.8,0.912,0.912);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#E8AF93").s().p("AAigBQgJgDgGAAIgIgBIgIAAIgPACIgPADQgQACgPAGQAMgJAQgEQARgGAQgCIASACIAQAFQASAIAEAMQgJgKgQgFg");
	this.shape_6.setTransform(247.8,322.6,0.912,0.912);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#E1BB93").s().p("AgrFGQgdgMglgaQhKgzgqhIIgCgIIgBguIgDAAQgLgBgHgKIgBgBQgDgFgIgmIgIg4QgFgVAAgQQAAgQAGgDQAEgDALAJQAEAEACAGIAEgBQgIgnAAgsQAAhkA0gZIABAAIA3gqQBCgpBAAAIAHAAIAAAAIAHAAIABAAQBBgCBGAqQAjAVAWAWIABAAQA0AZAABkQAAAsgJAnIgCAJIAHgHQAEgGAHgFQAKgGAEACQALAGgIArIgJA8QgIAogEAEIAAABQgHAKgMABIgCAAIgGA4QAAAEgDAEQgWAfggAhQg2A3g8AfIgDABQgaAHgXAAQgWAAgVgHg");
	this.shape_7.setTransform(258.8,324.5,0.912,0.912);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#D6AE89").s().p("AgWB8Qi0gHAtgsQAngnAUhIIALhBIBWgSQBWgNABAfQACAhAoBjQATAyAUArQg9AEg5AAIhHgCg");
	this.shape_8.setTransform(259.5,354.8,0.912,0.912);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#E16F74").s().p("Ah1AVIASgRIA1A0ICSiSIARARIijCkg");
	this.shape_9.setTransform(188.5,328.1,0.912,0.912);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#E16F74").s().p("Ah1AUIASgRIA1A1ICSiSIARASIijCjg");
	this.shape_10.setTransform(188.5,296.9,0.912,0.912);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#E16F74").s().p("Ah1AVIASgRIA1A0ICSiSIARARIijCkg");
	this.shape_11.setTransform(188.5,265.5,0.912,0.912);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#B0B0B0").s().p("AhBBDIAAiFICDAAIAACFg");
	this.shape_12.setTransform(182,269.2,0.912,0.912);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#B0B0B0").s().p("AhBBDIAAiEICDAAIAACEg");
	this.shape_13.setTransform(182,300.3,0.912,0.912);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#B0B0B0").s().p("AhBBDIAAiFICDAAIAACFg");
	this.shape_14.setTransform(182,331.9,0.912,0.912);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#B0B0B0").s().p("ABeAIIAAgPIARAAIAAAPgAA8AIIAAgPIARAAIAAAPgAAaAIIAAgPIARAAIAAAPgAgHAIIAAgPIAQAAIAAAPgAgqAIIAAgPIASAAIAAAPgAhMAIIAAgPIARAAIAAAPgAhuAIIAAgPIARAAIAAAPg");
	this.shape_15.setTransform(181.9,256.7,0.912,0.912);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#B0B0B0").s().p("AgHAIIAAgPIAPAAIAAAPg");
	this.shape_16.setTransform(169.5,256.7,0.912,0.912);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#B0B0B0").s().p("AgHBvIAAgRIAPAAIAAARgAgHBNIAAgRIAPAAIAAARgAgHArIAAgRIAPAAIAAARgAgHAJIAAgRIAPAAIAAARgAgHgZIAAgRIAPAAIAAARgAgHg7IAAgRIAPAAIAAARgAgHhdIAAgRIAPAAIAAARg");
	this.shape_17.setTransform(169.5,269.2,0.912,0.912);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#B0B0B0").s().p("AgHAIIAAgPIAPAAIAAAPg");
	this.shape_18.setTransform(169.5,281.6,0.912,0.912);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#B0B0B0").s().p("ABeAIIAAgPIARAAIAAAPgAA8AIIAAgPIARAAIAAAPgAAaAIIAAgPIARAAIAAAPgAgHAIIAAgPIAQAAIAAAPgAgqAIIAAgPIASAAIAAAPgAhMAIIAAgPIARAAIAAAPgAhuAIIAAgPIARAAIAAAPg");
	this.shape_19.setTransform(181.9,281.6,0.912,0.912);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#B0B0B0").s().p("AgHAIIAAgPIAPAAIAAAPg");
	this.shape_20.setTransform(194.4,281.6,0.912,0.912);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#B0B0B0").s().p("AgHBvIAAgRIAPAAIAAARgAgHBNIAAgRIAPAAIAAARgAgHArIAAgRIAPAAIAAARgAgHAJIAAgRIAPAAIAAARgAgHgZIAAgRIAPAAIAAARgAgHg7IAAgRIAPAAIAAARgAgHhdIAAgRIAPAAIAAARg");
	this.shape_21.setTransform(194.4,269.2,0.912,0.912);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#B0B0B0").s().p("AgHAIIAAgPIAPAAIAAAPg");
	this.shape_22.setTransform(194.4,256.7,0.912,0.912);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#B0B0B0").s().p("ABeAIIAAgPIARAAIAAAPgAA8AIIAAgPIARAAIAAAPgAAaAIIAAgPIARAAIAAAPgAgHAIIAAgPIAQAAIAAAPgAgqAIIAAgPIASAAIAAAPgAhMAIIAAgPIARAAIAAAPgAhuAIIAAgPIARAAIAAAPg");
	this.shape_23.setTransform(181.9,287.9,0.912,0.912);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#B0B0B0").s().p("AgHAIIAAgPIAPAAIAAAPg");
	this.shape_24.setTransform(169.5,287.9,0.912,0.912);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#B0B0B0").s().p("AgHBvIAAgRIAPAAIAAARgAgHBNIAAgRIAPAAIAAARgAgHArIAAgRIAPAAIAAARgAgHAJIAAgQIAPAAIAAAQgAgHgZIAAgRIAPAAIAAARgAgHg7IAAgRIAPAAIAAARgAgHhdIAAgRIAPAAIAAARg");
	this.shape_25.setTransform(169.5,300.3,0.912,0.912);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#B0B0B0").s().p("AgHAIIAAgPIAPAAIAAAPg");
	this.shape_26.setTransform(169.5,312.8,0.912,0.912);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#B0B0B0").s().p("ABeAIIAAgPIARAAIAAAPgAA8AIIAAgPIARAAIAAAPgAAaAIIAAgPIARAAIAAAPgAgHAIIAAgPIAQAAIAAAPgAgqAIIAAgPIASAAIAAAPgAhMAIIAAgPIARAAIAAAPgAhuAIIAAgPIARAAIAAAPg");
	this.shape_27.setTransform(181.9,312.8,0.912,0.912);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#B0B0B0").s().p("AgHAIIAAgPIAPAAIAAAPg");
	this.shape_28.setTransform(194.4,312.8,0.912,0.912);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#B0B0B0").s().p("AgHBvIAAgRIAPAAIAAARgAgHBNIAAgRIAPAAIAAARgAgHArIAAgRIAPAAIAAARgAgHAJIAAgQIAPAAIAAAQgAgHgZIAAgRIAPAAIAAARgAgHg7IAAgRIAPAAIAAARgAgHhdIAAgRIAPAAIAAARg");
	this.shape_29.setTransform(194.4,300.3,0.912,0.912);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#B0B0B0").s().p("AgHAIIAAgPIAPAAIAAAPg");
	this.shape_30.setTransform(194.4,287.9,0.912,0.912);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#B0B0B0").s().p("ABeAIIAAgPIARAAIAAAPgAA8AIIAAgPIARAAIAAAPgAAaAIIAAgPIARAAIAAAPgAgHAIIAAgPIAQAAIAAAPgAgqAIIAAgPIASAAIAAAPgAhMAIIAAgPIARAAIAAAPgAhuAIIAAgPIARAAIAAAPg");
	this.shape_31.setTransform(181.9,319.1,0.912,0.912);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#B0B0B0").s().p("AgHAIIAAgPIAPAAIAAAPg");
	this.shape_32.setTransform(169.5,319.1,0.912,0.912);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#B0B0B0").s().p("AgHBvIAAgRIAPAAIAAARgAgHBNIAAgRIAPAAIAAARgAgHAqIAAgRIAPAAIAAARgAgHAIIAAgQIAPAAIAAAQgAgHgYIAAgSIAPAAIAAASgAgHg7IAAgRIAPAAIAAARgAgHhdIAAgRIAPAAIAAARg");
	this.shape_33.setTransform(169.5,331.5,0.912,0.912);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#B0B0B0").s().p("AgHAIIAAgPIAPAAIAAAPg");
	this.shape_34.setTransform(169.5,344,0.912,0.912);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#B0B0B0").s().p("ABeAIIAAgPIARAAIAAAPgAA8AIIAAgPIARAAIAAAPgAAaAIIAAgPIARAAIAAAPgAgHAIIAAgPIAQAAIAAAPgAgqAIIAAgPIASAAIAAAPgAhMAIIAAgPIARAAIAAAPgAhuAIIAAgPIARAAIAAAPg");
	this.shape_35.setTransform(181.9,344,0.912,0.912);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#B0B0B0").s().p("AgHAIIAAgPIAPAAIAAAPg");
	this.shape_36.setTransform(194.4,344,0.912,0.912);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#B0B0B0").s().p("AgHBvIAAgRIAPAAIAAARgAgHBNIAAgRIAPAAIAAARgAgHAqIAAgRIAPAAIAAARgAgHAIIAAgQIAPAAIAAAQgAgHgYIAAgSIAPAAIAAASgAgHg7IAAgRIAPAAIAAARgAgHhdIAAgRIAPAAIAAARg");
	this.shape_37.setTransform(194.4,331.5,0.912,0.912);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#B0B0B0").s().p("AgHAIIAAgPIAPAAIAAAPg");
	this.shape_38.setTransform(194.4,319.1,0.912,0.912);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#B0B0B0").s().p("ABuEiIhKlWIAGgCQAhgNATgdQAUgdAAgjQAAgvgigiQghghgvAAQguAAgiAhQghAiAAAvQAAAjATAcQAUAdAgANIAGADIhJFWIgPAAIBHlNQgigQgVggQgUgfAAgmQAAg2AmglQAmgmA0AAQA1AAAmAmQAmAlAAA2QAAAmgVAgQgUAfgjAQIBIFNg");
	this.shape_39.setTransform(217.1,205.1,0.912,0.912);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#F0A693").s().p("ACLBtIAAgTIkXAAIAAATIhqAAIAAjaIHtAAIAADag");
	this.shape_40.setTransform(217.1,222.7,0.912,0.912);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#EBE5EE").s().p("AgNADIgBgGIAdAAIAAAGg");
	this.shape_41.setTransform(228.4,231.7,0.912,0.912);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#EBE5EE").s().p("AgPADIAAgGIAfAAIgCAGg");
	this.shape_42.setTransform(205.7,231.7,0.912,0.912);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#FEE69D").s().p("AncAjIAAhFIO5AAIAABFg");
	this.shape_43.setTransform(206.1,225.5,0.912,0.912);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#B0B0B0").s().p("AkgARIAAghIJBAAIAAAhg");
	this.shape_44.setTransform(233.6,341.7,0.912,0.912);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#B0B0B0").s().p("AkgARIAAghIJBAAIAAAhg");
	this.shape_45.setTransform(233.6,334.8,0.912,0.912);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#B0B0B0").s().p("AkgARIAAghIJBAAIAAAhg");
	this.shape_46.setTransform(233.6,327.9,0.912,0.912);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#B0B0B0").s().p("AkgARIAAghIJBAAIAAAhg");
	this.shape_47.setTransform(233.6,321,0.912,0.912);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#B0B0B0").s().p("AkgARIAAghIJBAAIAAAhg");
	this.shape_48.setTransform(233.6,314,0.912,0.912);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#B0B0B0").s().p("AkgAQIAAgfIJBAAIAAAfg");
	this.shape_49.setTransform(233.6,307.1,0.912,0.912);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#B0B0B0").s().p("AkgARIAAghIJBAAIAAAhg");
	this.shape_50.setTransform(233.6,300.2,0.912,0.912);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#B0B0B0").s().p("AkgARIAAghIJBAAIAAAhg");
	this.shape_51.setTransform(233.6,293.2,0.912,0.912);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#B0B0B0").s().p("AkgARIAAghIJBAAIAAAhg");
	this.shape_52.setTransform(233.6,286.3,0.912,0.912);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#B0B0B0").s().p("AkgARIAAghIJBAAIAAAhg");
	this.shape_53.setTransform(233.6,279.4,0.912,0.912);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#B0B0B0").s().p("AkgARIAAghIJBAAIAAAhg");
	this.shape_54.setTransform(233.6,272.4,0.912,0.912);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#B0B0B0").s().p("AiCARIAAghIEFAAIAAAhg");
	this.shape_55.setTransform(219.2,260,0.912,0.912);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#FFFFFF").s().p("ApWL2IAA3rIO5AAIAAD0ID0AAIAAT3g");
	this.shape_56.setTransform(217.2,291.3,0.912,0.912);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#E6E7E8").s().p("ApWKdIAA05IO5AAID0D0IAARFg");
	this.shape_57.setTransform(217.2,283.2,0.912,0.912);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#FFFFFF").s().p("ApSLxIAA3hISlAAIAAXhg");
	this.shape_58.setTransform(217.3,291,0.912,0.912);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#7F8487").s().p("ApzM4QgKABgHgIQgHgHAAgKIAA4/QAAgKAHgHQAHgIAKABITnAAQAJgBAIAIQAHAHAAAKIAAY/QAAAKgHAHQgIAIgJgBg");
	this.shape_59.setTransform(217.2,291.3,0.912,0.912);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#E6E6E6").s().p("AoVTwQj2hoi+i+Qi+i+hoj2Qhsj/AAkXQAAkWBsj/QBoj2C+i+QC+i+D2hoQD/hsEWAAQEXAAD/BsQD2BoC+C+QC+C+BoD2QBsD/AAEWQAAEXhsD/QhoD2i+C+Qi+C+j2BoQj/BskXAAQkWAAj/hsg");
	this.shape_60.setTransform(230.1,288.2,0.912,0.912);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#EFEFEF").s().p("ApeWcQkXh2jYjYQjYjYh2kXQh6kiAAk9QAAk8B6kiQB2kXDYjYQDYjYEXh2QEih7E8AAQE9AAEiB7QEXB2DYDYQDYDYB2EXQB7EiAAE8QAAE9h7EiQh2EXjYDYQjYDYkXB2QkiB7k9AAQk8AAkih7g");
	this.shape_61.setTransform(228.9,288.9,0.912,0.912);

	this.c6_2 = new lib.mc_radioButton6();
	this.c6_2.parent = this;
	this.c6_2.setTransform(576.9,351.2,1,1,0,0,0,18,18.1);

	this.c6_1 = new lib.mc_radioButton6();
	this.c6_1.parent = this;
	this.c6_1.setTransform(576.9,260.5,1,1,0,0,0,18,18.1);

	this.c6_op0 = new cjs.Text("Brecha de disponibilidad.", "16px 'Arial'", "#333333");
	this.c6_op0.name = "c6_op0";
	this.c6_op0.lineHeight = 18;
	this.c6_op0.lineWidth = 296;
	this.c6_op0.parent = this;
	this.c6_op0.setTransform(609.3,159.3);

	this.c6_op2 = new cjs.Text("Herramienta de criticidad.", "16px 'Arial'", "#333333");
	this.c6_op2.name = "c6_op2";
	this.c6_op2.lineHeight = 18;
	this.c6_op2.lineWidth = 319;
	this.c6_op2.parent = this;
	this.c6_op2.setTransform(609.3,342.5);

	this.c6_op1 = new cjs.Text("Check list de potencial.", "16px 'Arial'", "#333333");
	this.c6_op1.name = "c6_op1";
	this.c6_op1.lineHeight = 18;
	this.c6_op1.lineWidth = 307;
	this.c6_op1.parent = this;
	this.c6_op1.setTransform(609.3,251.8);

	this.c6_0 = new lib.mc_radioButton6();
	this.c6_0.parent = this;
	this.c6_0.setTransform(576.9,169.7,1,1,0,0,0,18,18.1);

	this.p6 = new cjs.Text("Es la herramienta que nos ayuda a evaluar el potencial de nuestros colaboradores en el sistema SuccessFactors.", "20px 'Arial'");
	this.p6.name = "p6";
	this.p6.lineHeight = 23;
	this.p6.lineWidth = 330;
	this.p6.parent = this;
	this.p6.setTransform(120,8.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.p6},{t:this.c6_0},{t:this.c6_op1},{t:this.c6_op2},{t:this.c6_op0},{t:this.c6_1},{t:this.c6_2},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.instance_17},{t:this.instance_16},{t:this.instance_15},{t:this.instance_14},{t:this.instance_13},{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.shape_3},{t:this.shape_2},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// fondo y encabezado
	this.instance_18 = new lib.iconoactividadesyretos("synched",0);
	this.instance_18.parent = this;
	this.instance_18.setTransform(475.7,95.1,0.551,0.551,0,0,0,55.7,55.7);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("rgba(230,149,122,0.498)").s().p("EgiSAJ5QjsAAAAjsIAAsZQAAjsDsAAMBElAAAQDsAAAADsIAAMZQAADsjsAAg");
	this.shape_62.setTransform(254.4,49.7);

	this.instance_19 = new lib.fondo("synched",0);
	this.instance_19.parent = this;
	this.instance_19.setTransform(469.6,267.3,1,1,0,0,0,485.2,268.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_19},{t:this.shape_62},{t:this.instance_18}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.evalpag6, new cjs.Rectangle(2.4,-36.5,958.3,510.2), null);


(lib.evalpag2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		var root = this;
		var resp = 4;
		var correctas = [1, 2, 4];
		console.log(correctas, correctas.length);
		var cont = 0;
		var contador = 1;
		var corr = 0;
		var seleccion = ["", "", ""];
		var correcto = "";
		var respuestas = "";
		root.p2.text = "Identifica 3 beneficios que obtenemos al gestionar el talento de la organización.";
		root.c2_op0.text = "Atraer individuos en suficiente número y con los debidos atributos y estimularlos para que soliciten empleo en la organización.";
		root.c2_op1.text = "Contar con un inventario de talento dentro de la organización.";
		root.c2_op2.text = "Identificar a los mejores candidatos internos para los puestos con los que cuenta la organización.";
		root.c2_op3.text = "Clarificar los objetivos estratégicos de la empresa en el largo plazo.";
		root.c2_op4.text = "Identificar, retener y desarrollar a personas con alto potencial (“Top Talent”) en la organización.";
		for (var i = 0; i < correctas.length; i++) {
			correcto += root['c2_op' + correctas[i]].text + "\n";
		}
		
		iniciar();
		root.parent.parent.btn_siguiente.visible = false;
		
		function iniciar() {
			for (var i = 0; i <= resp; i++) {
				root['ch1_' + i].activo = false;
				root['ch1_' + i].cursor = "pointer";
				root['ch1_' + i].n = i;
				root['ch1_' + i].addEventListener("click", cambios);
		
		
			}
			// activar el cambio de estado de los checkbox
			function cambios(r) {
				if (r.currentTarget.activo == false) {
					r.currentTarget.activo = true;
					r.currentTarget.gotoAndStop(1);
					seleccion[r.currentTarget.n] = root['c2_op' + r.currentTarget.n].text + "\n";
					//root.OrdenPreguntas.push();
					cont++
				} else {
					r.currentTarget.activo = false;
					r.currentTarget.gotoAndStop(0);
					seleccion[r.currentTarget.n] = " ";
					cont--
				}
		
				respuestas = "";
				for (var i = 0; i <= resp; i++) {
					respuestas += seleccion[i];
				}
				root.parent.parent.registrar_pregunta(root.p2.text, respuestas, correcto);
		
				if (r.currentTarget.n == 1 || r.currentTarget.n == 2 || r.currentTarget.n == 4) {
					if (r.currentTarget.activo == true) {
						corr++
						console.log("sel corr" + corr);
					} else {
						corr--
						console.log(" des sel corr" + corr);
					}
				}
				if (corr == 3) {
					root.parent.parent.resultados[root.parent.parent.cont] = 10;
				} else {
					root.parent.parent.resultados[root.parent.parent.cont] = 0;
				}
		
				console.log(cont);
		
				if (cont == 3) {
					root.parent.parent.activarSiguiente();
					for (var l = 0; l <= resp; l++) {
						if (root['ch1_' + l].activo == false) {
							root['ch1_' + l].mouseEnabled = false;
						}
					}
				} else {
					root.parent.parent.btn_siguiente.visible = false;
					for (var k = 0; k <= resp; k++) {
						root['ch1_' + k].mouseEnabled = true;
					}
				}
			}
			
			console.log("Estado de calificacion ", root.parent.parent.resultados[root.parent.parent.cont], cont);
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#59595B").s().p("AgDANQgFgCgDgEQgCgFABgFQABgFAFgDQAFgCAEABQAFABADAFQADAFgBAEQgCAGgEACQgEACgDAAIgDAAg");
	this.shape.setTransform(282,340.3,1.444,1.444);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#7DA489").s().p("AidgeQAxgNDuiIIAlCmQhOBMg5AkQhOAxh4Agg");
	this.shape_1.setTransform(298.6,357.6,1.444,1.444);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#EEEEEE").s().p("AiHgYIDnhVIAoCOIkABNg");
	this.shape_2.setTransform(296.3,337.4,1.444,1.444);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F6D0B4").s().p("AgQDBIgGgwIgvhiIg7hXIgsgqQgCgGABgGQACgNASAAQAfgBAcAqQAFAHASAPQgBg6ABgpQADhOAZgJQCIgvBBC4QAhBcgiBcIgBADQgCAGAIAzIAIAxQgpANg0ALIhXARQgDgNgDgjg");
	this.shape_3.setTransform(282.5,304,1.444,1.444);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AhCDvQgrgMgigZQgigYgZgjQgZgigLgoQgMgqADgrQADgsASgoQARgmAcgfQAdgfAlgTQAngUArgGQArgGAqAJQApAJAkAWQAlAWAaAhQA3BFABBXIAAAAQAAA0gVAvQgUAwgmAiQhBA9hXAGIgPAAQgiAAgigJgAgGjrQgsACgoAQQgnAQgfAdQgfAdgTAmQgTAmgFAsQgEArALAqQAMAoAYAjQAZAjAjAXQAkAYAqAKQArALApgHQAqgFAmgUQAmgUAcggQAcghAPgoQAPgoAAgrIAAAAQAAg/gfg2QgVgkghgbQghgcgngNQgngOgoAAIgFAAg");
	this.shape_4.setTransform(222.1,255.1,1.444,1.444);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#1DBAB9").s().p("AgdAzQgDgBgBgDQAAgDABgDIAzhZQACgCADAAQADgBACACIABAAQAGAEgEAFIg0BZQgCADgDAAIgEgBg");
	this.shape_5.setTransform(273.6,287.3,1.444,1.444);

	this.instance = new lib.Path_0();
	this.instance.parent = this;
	this.instance.setTransform(247.2,249.6,1.444,1.444,0,0,0,3.4,3.5);
	this.instance.alpha = 0.309;

	this.instance_1 = new lib.Group_20();
	this.instance_1.parent = this;
	this.instance_1.setTransform(219.1,241.2,1.444,1.444,0,0,0,20.2,12.3);
	this.instance_1.alpha = 0.219;

	this.instance_2 = new lib.Path();
	this.instance_2.parent = this;
	this.instance_2.setTransform(221.4,256.3,1.444,1.444,0,0,0,25.1,25);
	this.instance_2.alpha = 0.5;

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#1DBAB9").s().p("AiRDrQhig9gahvQgahvA9hhQA9hiBwgZQBvgaBhA8QBhA9AaBwQAaBvg9BhQg9BhhwAaQghAHgfAAQhLAAhEgqgAg0jnQhhAXg0BTQg0BUAWBfQAXBgBTA0QBUA0BfgWQBggWA0hUQA0hTgWhfQgWhhhUg0Qg6gkhBAAQgbAAgcAGg");
	this.shape_6.setTransform(222.6,254.8,1.444,1.444);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#085466").s().p("ABGBtIjTiBIA4hdIDTCEQAOAJACATQABATgLATIgBABQgLASgSAHQgIADgHAAQgJAAgIgFg");
	this.shape_7.setTransform(290.7,297.7,1.444,1.444);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#CCCCCC").s().p("AhxgPIAwhLICzB0IgoBAg");
	this.shape_8.setTransform(266,283.5,1.444,1.444);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#8DD2CA").s().p("AgHgKIAJAAIAFAUIgMABg");
	this.shape_9.setTransform(221.7,257.6,1.444,1.444);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#231F20").s().p("AgEAQIgIgXIAIgCIgHgRIASgOIgBAeQABAMAGAmQgNgSgEgGg");
	this.shape_10.setTransform(219.6,248.8,1.444,1.444);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#414042").s().p("AAkgKIgGgHIhGgCIgNA0IgCAAIAKg7IAdgHIAAAHIAwAFIANgGIALA8IgLABg");
	this.shape_11.setTransform(223.4,264.6,1.444,1.444);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FDA96F").s().p("AgMAKIgDgNIARgGIAOAAIAAAIIgSALg");
	this.shape_12.setTransform(224.3,256.8,1.444,1.444);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FDA96F").s().p("AgMABIAFgKIAKAEIAKAMIgTADg");
	this.shape_13.setTransform(215.8,254.8,1.444,1.444);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#DB635E").s().p("AgIgEIAIgNIgDgJIAFgHIAHAHIgEAIIADAQIgCAJIgHAbg");
	this.shape_14.setTransform(221.7,249.7,1.444,1.444);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#414042").s().p("AABAkIgNgRIgUgCIgMgOIgDgiIAPAfIANAMIApgBIALgbIAPgUIgLAXIgEAjIAGAJIgbAGg");
	this.shape_15.setTransform(222.5,253.3,1.444,1.444);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#231F20").s().p("AgHgDQAKgSACgHIABgNIARALIgRASIAKAGIgmAwg");
	this.shape_16.setTransform(224.8,248.5,1.444,1.444);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgSgCIACgaIABgGIAKAMIATgUIAFAEIAAAKQgCAHgMATIgOAtQgIgigBgLg");
	this.shape_17.setTransform(223,248,1.444,1.444);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#58595B").s().p("AgFBIIgJAWIghgCIAKg7IgHAAIgGAAQgFABgCgBIgGgFQgEgEAAgDIgBgHIABgHIAGgIQACgGAEgaQAEgWAFgHQAEgFAQgJIAPgHIANATIAXgeIAQAOIAOAIQAKAEADAEQABADAAAIIgBAKIgCAjIgMAnIALA9Ig+ACg");
	this.shape_18.setTransform(222.1,256.1,1.444,1.444);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#231F20").s().p("Ag0BKIABiEIAggQIBFASIADBvIglAOIgEgRIgGhSIgQAAIgCBpIgogBg");
	this.shape_19.setTransform(223.7,276.2,1.444,1.444);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FDA96F").s().p("AgDAAQACgHACABQAEABgBAGQgBAGgDAAQgEgBABgGg");
	this.shape_20.setTransform(225.9,238.4,1.444,1.444);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FDA96F").s().p("AgDABQgBgGAEgBQADgBABAHQABAGgEABQgDAAgBgGg");
	this.shape_21.setTransform(219.3,238.4,1.444,1.444);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#403024").s().p("AATACQgCgBgIABIgJAAQgLAAgGADQgDABgCAIIAAAIQgDgLAAgLQAAgVAVAAQAQAAAGAEQAHAEABAKQACANgGAMQABgRgEgDg");
	this.shape_22.setTransform(222.7,234.9,1.444,1.444);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FDA96F").s().p("AgFAaQgEgCgFgFQgFgFgBgEQgCgFABgQIABgPIAqAAQABAcgDAJQgBADgEAFQgEAFgEACIgGABIgGgBg");
	this.shape_23.setTransform(222.6,238.6,1.444,1.444);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FD8A5A").s().p("AgJAAQgGgJAEAEQAIAFAJgCQAFgBADgDQgBAMgKABIgBAAQgGAAgFgHg");
	this.shape_24.setTransform(222.7,242.7,1.444,1.444);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FDA96F").s().p("AgPgBIAAgOIAegCIABAYIgXALg");
	this.shape_25.setTransform(222.9,243.2,1.444,1.444);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#E3EFB9").s().p("AjkIXQhogshPhRQhQhQgshpQgthsAAh2QAAh3AuhsQAshoBRhQQBRhQBpgsQBtgsB3AAQB2AABrAuQBoAsBPBRQBQBRArBoQAtBtAAB1QAAB3guBrQgsBphQBQQhRBPhpAsQhsAth2AAQh3AAhsgug");
	this.shape_26.setTransform(251,282.5,1.729,1.729);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#EFEFEF").s().p("AmqP0QjFhUiZiYQiXiXhUjGQhWjMAAjfQAAjfBWjMQBUjFCXiYQCZiYDFhTQDMhXDeAAQDgAADLBXQDGBTCYCYQCYCYBSDFQBXDMAADfQAADfhXDMQhSDGiYCXQiYCYjGBUQjLBXjggBQjeABjMhXg");
	this.shape_27.setTransform(251.2,282.9);

	this.ch1_0 = new lib.chpag2();
	this.ch1_0.parent = this;
	this.ch1_0.setTransform(475.4,131.1);

	this.c2_op0 = new cjs.Text("Atraer individuos en suficiente número y con los debidos atributos y estimularlos para que soliciten empleo en la organización.", "16px 'Arial'");
	this.c2_op0.name = "c2_op0";
	this.c2_op0.lineHeight = 18;
	this.c2_op0.lineWidth = 383;
	this.c2_op0.parent = this;
	this.c2_op0.setTransform(521.4,139.8);

	this.ch1_4 = new lib.chpag2();
	this.ch1_4.parent = this;
	this.ch1_4.setTransform(494,373.9,1,1,0,0,0,18.6,18.6);

	this.ch1_2 = new lib.chpag2();
	this.ch1_2.parent = this;
	this.ch1_2.setTransform(494,271.3,1,1,0,0,0,18.6,18.6);

	this.ch1_3 = new lib.chpag2();
	this.ch1_3.parent = this;
	this.ch1_3.setTransform(494,318.1,1,1,0,0,0,18.6,18.6);

	this.ch1_1 = new lib.chpag2();
	this.ch1_1.parent = this;
	this.ch1_1.setTransform(494,216.5,1,1,0,0,0,18.6,18.6);

	this.c2_op4 = new cjs.Text("Identificar, retener y desarrollar a personas con alto potencial (“Top Talent”) en la organización.", "16px 'Arial'");
	this.c2_op4.name = "c2_op4";
	this.c2_op4.lineHeight = 18;
	this.c2_op4.lineWidth = 361;
	this.c2_op4.parent = this;
	this.c2_op4.setTransform(521.4,365.1);

	this.c2_op2 = new cjs.Text("Identificar a los mejores candidatos internos para los puestos con los que cuenta la organización.", "16px 'Arial'");
	this.c2_op2.name = "c2_op2";
	this.c2_op2.lineHeight = 18;
	this.c2_op2.lineWidth = 366;
	this.c2_op2.parent = this;
	this.c2_op2.setTransform(521.4,259.1);

	this.c2_op3 = new cjs.Text("Clarificar los objetivos estratégicos de la empresa en el largo plazo.", "16px 'Arial'");
	this.c2_op3.name = "c2_op3";
	this.c2_op3.lineHeight = 18;
	this.c2_op3.lineWidth = 356;
	this.c2_op3.parent = this;
	this.c2_op3.setTransform(521.4,309.2);

	this.c2_op1 = new cjs.Text("Contar con un inventario de talento dentro de la organización.", "16px 'Arial'");
	this.c2_op1.name = "c2_op1";
	this.c2_op1.lineHeight = 18;
	this.c2_op1.lineWidth = 366;
	this.c2_op1.parent = this;
	this.c2_op1.setTransform(521.4,207.8);

	this.p2 = new cjs.Text("Identifica 3 beneficios que obtenemos al gestionar el talento de la organización.", "20px 'Arial'");
	this.p2.name = "p2";
	this.p2.lineHeight = 24;
	this.p2.lineWidth = 311;
	this.p2.parent = this;
	this.p2.setTransform(114.6,13);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.p2},{t:this.c2_op1},{t:this.c2_op3},{t:this.c2_op2},{t:this.c2_op4},{t:this.ch1_1},{t:this.ch1_3},{t:this.ch1_2},{t:this.ch1_4},{t:this.c2_op0},{t:this.ch1_0},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.instance_2},{t:this.instance_1},{t:this.instance},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// fondo y encabezado
	this.instance_3 = new lib.iconoactividadesyretos("synched",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(473.7,95.1,0.551,0.551,0,0,0,55.7,55.7);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("rgba(230,149,122,0.498)").s().p("EgiSAJ5QjsAAAAjsIAAsZQAAjsDsAAMBElAAAQDsAAAADsIAAMZQAADsjsAAg");
	this.shape_28.setTransform(252.4,49.7);

	this.instance_4 = new lib.fondo("synched",0);
	this.instance_4.parent = this;
	this.instance_4.setTransform(469.6,267.3,1,1,0,0,0,485.2,268.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_4},{t:this.shape_28},{t:this.instance_3}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.evalpag2, new cjs.Rectangle(2.4,-36.5,958.3,510.2), null);


(lib.Certificado_Symbol = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.btn_imprimir.on("click", function () {
			parent.imprimirIframe();
		});
		var f = new Date();
		this.nombre.text = parent.getStudentName();
		this.curso.text="Talent Management Review";
		this.cal.text= parent.SCORE;
		this.fecha.text=f.getDate() + "/" + (f.getMonth() +1) + "/" + f.getFullYear();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Componentes
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#373535").s().p("AqfKmIAA1LIU/AAIAAVLg");
	this.shape.setTransform(763,306.2,0.13,0.131);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#373535").s().p("Aq4KmIAA1LIVxAAIAAVLg");
	this.shape_1.setTransform(871.6,197.4,0.13,0.131);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#373535").s().p("AqiKgIAA1AIVFAAIAAVAg");
	this.shape_2.setTransform(763,197.5,0.13,0.131);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#373535").s().p("AjPDaIAAmzIGfAAIAAGzg");
	this.shape_3.setTransform(853.3,288.1,0.13,0.131);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#373535").s().p("ADWDXIm0AAIAAm2IG0AAIAAG2IAJAAIgJAIg");
	this.shape_4.setTransform(817.6,233.9,0.13,0.131);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#373535").s().p("AjeDXIAIAAIAAAIgAjWDXgAjWjeIG1AAIAAG0Im1ABg");
	this.shape_5.setTransform(804.6,215.8,0.13,0.131);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#373535").s().p("AjeKqIAA1LIG1AAIAAVLgADXqhIAAgIIAIAIgADXqhg");
	this.shape_6.setTransform(817.6,215.4,0.13,0.131);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#373535").s().p("AjZDQIAAmfIGzAAIAAGfg");
	this.shape_7.setTransform(890,324.3,0.13,0.131);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#373535").s().p("AjeDfIAAm0IG1AAIAAG0gADXjVIAAgJIAIAJgADXjVg");
	this.shape_8.setTransform(853.5,324.1,0.13,0.131);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#373535").s().p("AjWDUIAAmnIGtAAIAAGng");
	this.shape_9.setTransform(792.8,312.2,0.13,0.131);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#373535").s().p("ADXDXIAIAAIgIAIgAjeDXIAAm1IG0AAIABG1g");
	this.shape_10.setTransform(744.5,239.9,0.13,0.131);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#373535").s().p("ADWDiIm0AAIAAnEIG0AAIAAHEIAJAAIgJAIgADWjiIAAgHIAJAHgADWjig");
	this.shape_11.setTransform(769.1,251.8,0.13,0.131);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#373535").s().p("AjhDfIAAm0IgIAAIAIgJIAAAJIHDAAIAAG0gADijVIAAgJIAIAJg");
	this.shape_12.setTransform(798.8,293.9,0.13,0.131);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#373535").s().p("AjeDiIAJAAIAAAIgAjVDiIAAnEIgJAAIAJgHIAAAHIG0AAIAAHEg");
	this.shape_13.setTransform(786.7,257.9,0.13,0.131);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#373535").s().p("AjpDjIAIAAIAAAIgADiDjInDAAIAAnEIgIAAIAIgIIAAAIIHDAAIAAHEIAIAAIgIAHgADijhIAAgJIAIAJgADijhg");
	this.shape_14.setTransform(780.9,251.8,0.13,0.131);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#373535").s().p("AjqDiIAIAAIAAAIgAjiDiIAAnDIHEAAIAAHDgAjiDigADijhIAAgIIAIAIg");
	this.shape_15.setTransform(877.9,282,0.13,0.131);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#373535").s().p("AjhDeIAAmzIgIAAIAIgIIAAAIIHDAAIAAGzgADijVIAAgIIAIAIg");
	this.shape_16.setTransform(823.5,281.8,0.13,0.131);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#373535").s().p("AjeDjIABm9IgIAAIAIgIIAAAIIG7AKIAAGzgADejQIAAgIIAIAIg");
	this.shape_17.setTransform(769,269.7,0.13,0.131);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#373535").s().p("AjuDWIAHAAIAAAIgAjnjdIHPAAIAAGmInPANgADoDJIAIAAIgIAJg");
	this.shape_18.setTransform(763.1,264.1,0.13,0.131);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#373535").s().p("ADjDWIAHAAIgHAJgAjpDWIAIAAIAAAIgAjhDWIAAm0IHEAAIAAG0gAjhDWg");
	this.shape_19.setTransform(883.9,276.1,0.13,0.131);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#373535").s().p("ADiDWInDAAIAAm0IHDAAIAAG0IAIAAIgIAJgAjpDWIAIAAIAAAJg");
	this.shape_20.setTransform(877.9,227.8,0.13,0.131);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#373535").s().p("AjXDWIAAmrIGvAAIAAGrg");
	this.shape_21.setTransform(792.8,179.4,0.13,0.131);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#373535").s().p("AjTDXIAAmtIGnAAIAAGtg");
	this.shape_22.setTransform(744.3,227.6,0.13,0.131);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#373535").s().p("AjqDiIAIAAIAAAIgAjiDiIAAnEIHEAAIAAHEgAjiDigADijiIAAgIIAIAIg");
	this.shape_23.setTransform(804.8,191.5,0.13,0.131);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#373535").s().p("ADXDXIm1AAIAAm2IG1AAIAAG2IAIAAIgIAJg");
	this.shape_24.setTransform(793,191.6,0.13,0.131);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#373535").s().p("AjZDSIAAmjIGzAAIAAGjg");
	this.shape_25.setTransform(841.3,185.4,0.13,0.131);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#373535").s().p("AjyDfIAAm1IgIAAIAIgIIAAAIIHtAAIAAG1g");
	this.shape_26.setTransform(871.4,324.1,0.13,0.131);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#373535").s().p("AkMDiIAIAAIAAAIgAkEDiIACnDIIHAIIAAgIIAIAIIgIAAIAAG7gAkEDigAkKjhIAIgIIAAAIg");
	this.shape_27.setTransform(750.8,245.8,0.13,0.131);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#373535").s().p("AjeHEIAAt+IG0AAIAAN+gADWm6IAAgJIAJAJgADWm6g");
	this.shape_28.setTransform(744.5,254.7,0.13,0.131);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#373535").s().p("AjeG8IAIAAIAAAIgAjWG8IAAt/IG1AAIAAN/gAjWG8g");
	this.shape_29.setTransform(841.2,212.8,0.13,0.131);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#373535").s().p("ADiHIIAIAAIgIAJgAjhHIIAAuQIgIAAIAIgIIAAAIIHDAAIAAOQg");
	this.shape_30.setTransform(829.4,212.6,0.13,0.131);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#373535").s().p("ADXHIIAIAAIgIAIgAjeHIIAAuQIG1AAIAAOQgADXnIIAAgHIAIAHgADXnIg");
	this.shape_31.setTransform(793,212.6,0.13,0.131);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#373535").s().p("AjeHJIAIAAIAAAIgAjWHJIAAuQIgHAAIAHgJIAAAJIG1AAIAAOQgAjWHJg");
	this.shape_32.setTransform(889.7,285,0.13,0.131);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#373535").s().p("ADdHOIm6AAIAAuaIgIAAIAIgJIAAAJIG6AKIAAOQIAIAAIgIAIgADdnCIAAgIIAJAIIgJAAg");
	this.shape_33.setTransform(792.9,284.9,0.13,0.131);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#373535").s().p("AnhDfIAAm1IO7AAIAAG1gAHajWIAAgIIAIAIgAHajWg");
	this.shape_34.setTransform(874.7,263.7,0.13,0.131);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#373535").s().p("AHEHIIuPAAIAAmzIGrAAIAfncIgHAAIAHgJIAAAJIHFAAIAAOPIAHAAIgHAJg");
	this.shape_35.setTransform(784.1,272.8,0.13,0.131);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#373535").s().p("AnUHIIAIAAIAAuPIHEAAIAAgIIAIAIIgIAAIAAHLIHMAAIgBgHIAJAHIgIAAIAJG5IAIAAIgIAJIAAgJIuZALIAAAIgAnMnHIgIAAIAIgIIAAAIg");
	this.shape_36.setTransform(778,260.9,0.13,0.131);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#373535").s().p("AnDHJIAJAAIAAAHgAm6HJIAAuPIgIAAIAIgJIAAAJIHDgBIAAgIIAIAIIgIAAIAAG8IG7AYIAAG8gAm6HJg");
	this.shape_37.setTransform(801.6,200.5,0.13,0.131);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#373535").s().p("AqrDfIAAm1IVOAAIAAG1gAKjjWIAAgIIAJAIgAKjjWg");
	this.shape_38.setTransform(799,324.1,0.13,0.131);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#373535").s().p("AAVKkIAAnDInTAAIAAnEIgIAAIAIgIIAAAIIG6AAIAYnAIG0AAIAAVHgAnHDhIAJAAIAAAHg");
	this.shape_39.setTransform(886.8,233.7,0.13,0.131);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#373535").s().p("AAZKgIAAnCInUAAIAAm3IG8gdIAAmpIHEAAIAAU/gAnEDeIAJAAIAAAIgAm7Deg");
	this.shape_40.setTransform(886.7,257.9,0.13,0.131);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#373535").s().p("AnKKqIAJAAIAAAJgAnBKqIAA1cIGyAAIAAOOIHTAAIAAHPgAHEDcIAAgJIAIAJgAHEDcg");
	this.shape_41.setTransform(760.1,233.9,0.13,0.131);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#373535").s().p("AEDHFIgYm0IuxAAIAAnMIWFAAIAAOAgAK/m7IAAgJIAIAJgAK/m7g");
	this.shape_42.setTransform(750.8,272.8,0.13,0.131);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#373535").s().p("AkQG7IAIAAIAAAIgAkIG7IAAm4InBgcIAAmpIWLAAIAAGyIAIAAIgIAIIAAgIIm9AAIgaHLg");
	this.shape_43.setTransform(811.3,182.6,0.13,0.131);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#373535").s().p("AngKuIAA1TIHsAAIAAHMIHMAAIAAgHIAJAHIgJAAIAAG5Im8AbIgWGzgAAMqlIAAgIIAIAIgAAMqlg");
	this.shape_44.setTransform(874.7,239.6,0.13,0.131);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#373535").s().p("ALMKmIvLgBIAAuXInMAAIAAm7IObAAIAAOCIH8AAIAAHRIAIAAIgIAIgAkHKlIAIAAIAAAJgArTjyIAIAAIAAAIg");
	this.shape_45.setTransform(805.2,282.1,0.13,0.131);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#373535").s().p("AEKR7Im6AAIgZnCInsgBIgLnOIIGAAIAA1kIgIAAIAIgIIAAAIIHUAAIAAHQIGvAAIAAOEIm/AdIAAOEIAIAAIgIAIgAq+K4IAJAAIAAAIgArIDqIAIgIIAAAIg");
	this.shape_46.setTransform(817,263.9,0.13,0.131);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#373535").s().p("AHTOJIAIAAIAAAJgAAHOKInEAAIAAuaInMAAIAAnMIOPAAIAAm1IOMAAIAAcaIm3AAIAAm1InUAAIAAG2IAIAAIgIAIgAAOgdIG1AAIAAm3Im1AAgAnFOKIAIAAIAAAHgAm9OKgAHbOJgAuRgQIAIAAIAAAJgAuJgQg");
	this.shape_47.setTransform(777.8,236.9,0.13,0.131);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#373535").s().p("AgDRyInEgBIAAnVInCAAIAAmxIHCggIAAuCIgIAAIAIgIIAAAIIG4AAIAcnCIGzAAIAAVEIHKAgIAAGxIuNAAIAAHWIAHAAIgHAIgAnPRxIAIAAIAAAIg");
	this.shape_48.setTransform(826.4,191.6,0.13,0.131);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#373535").s().p("AERVgIAAnDIoNAAIAAm3InCgeIAAt8IPHAAIAAujIG1AAIAAVeImtAAIAAHBIGuAYIAAOAgAkFOdIAJAAIAAAIgAj8OdgAEB1XIAIgIIAAAIg");
	this.shape_49.setTransform(811.1,309,0.13,0.131);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#373535").s().p("ADFcuIuAAAIAA8iIGrgWIAAuAIm6gaIAAuJIgJAAIAJgIIAAAIIHDABIAAHLIHRAAIAAVoIICAAIAAHCIAIAAIgIAIIAAgIIu8AAIAAHFIG1AaIAAOGIAIAAIgIAIgAkH8sIAAgIIAIAIg");
	this.shape_50.setTransform(805.2,242.8,0.13,0.131);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#373535").s().p("A5bY4MAAAgxvMAy3AAAMAAAAxvgAyJRmMAkdAAAMAAAgjVMgkdAAAg");
	this.shape_51.setTransform(762.5,306.2,0.13,0.131);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#373535").s().p("A5WY6MAAAgxzMAytAAAMAAAAxzgAyRRwMAkTAAAMAAAgjaMgkTAAAg");
	this.shape_52.setTransform(871.6,197.4,0.13,0.131);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#373535").s().p("A5WY6MAAAgxzMAytAAAMAAAAxzgAyLRqMAkeAAAMAAAgjYMgkeAAAg");
	this.shape_53.setTransform(762.6,197.6,0.13,0.131);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#373535").s().p("EgVpBAtIgam2It2AAIAAucINzAAIAAnGImqgaIAAuDIGigTIAAuVIt+AAIAAm8IHEgZIAA8fIm7AAIgbnHIm5gYIAAm6IgJAAIAJgJIAAAJIOXAAIAA1mIgIAAIAIgJIAAAJIHEAAIAAgIIAIAIIgIAAIAAG4IHGAdIAVGpIOBAAIAbmmIGyAAIAAN6ImuAaIAAG6IGmAAIAAHFImnAdIAAGxIGpAAIAAHKIuAAAIAAmpInEAAIgaGyImsAAIAAOPIN9AAIAAmnIORAAIAeGuIGxAAIAAOmIIPAAIAAgIIAIAIIgIAAIAAHSInsAAIAAHMIHlAAIAWGxIHLAAIAAuCIG+AAIAAVSIHAAaIAAGzIuCAAIAAmqIvdAAIAAOBIuOgBIAAm4IG4gcIAAmyImtAAIgcnLImzAAIAAN4InaAgIAAN/gAuYcmIVGAAIAA1CI1GAAgEgWHgkAIm5AYIAAG8IOKAAIAam/IGwgYIAAmwIt9AAgEAOCA5oIAIAAIgIAIgEgAUA5nIAIAAIAAAIgEAkhAVyIAAgIIAJAIgEgkUAHQIAIAAIAAAJgEgkMAHQg");
	this.shape_54.setTransform(856.5,272.8,0.13,0.131);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#FFFFFF").s().p("Eh4hB3MMAAAjuXMDxDAAAMAAADuXg");
	this.shape_55.setTransform(816.7,252.2,0.13,0.131);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#000000").s().p("AgHAIIAAgPIAOAAIAAAPg");
	this.shape_56.setTransform(612.3,354.7);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#000000").s().p("AASAoIAAgvQAAgIgBgEQgBgEgEgCQgFgCgFAAQgHAAgGAFQgHAFAAAPIAAAqIgMAAIAAhNIALAAIAAALQAJgNAPAAQAHAAAGADQAGACADAEQACAEACAGIABANIAAAvg");
	this.shape_57.setTransform(606,351.4);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#000000").s().p("AgZAsQgLgKAAgUQAAgUANgLQAJgJAOABQAQgBAKALQALALAAARQAAAPgFAJQgFAIgIAFQgJAFgKAAQgQAAgJgLgAgPgHQgHAHAAAOQAAAPAHAIQAGAHAJAAQAKAAAGgHQAHgIAAgQQAAgNgHgHQgGgHgKAAQgJAAgGAHgAgGghIAJgVIARAAIgQAVg");
	this.shape_58.setTransform(597.6,350.1);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#000000").s().p("AgFA2IAAhNIALAAIAABNgAgFglIAAgQIALAAIAAAQg");
	this.shape_59.setTransform(591.8,350);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#000000").s().p("AgXAeQgKgKAAgUQAAgLAEgKQAEgJAJgFQAJgFAJAAQAMAAAIAHQAIAGADAMIgNACQgCgIgFgEQgEgEgHAAQgJAAgGAHQgGAHAAAPQAAAPAGAIQAGAHAIAAQAIAAAFgFQAGgFABgKIANACQgCANgJAIQgJAIgNAAQgOAAgKgLg");
	this.shape_60.setTransform(586.6,351.5);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#000000").s().p("AgcAiQgHgGAAgKQAAgFADgFQACgFAFgDQAEgCAFgBIAMgCQAPgCAHgDIAAgDQAAgIgDgDQgFgFgKAAQgJAAgEADQgFAEgCAIIgNgCQACgIAEgFQAEgFAIgDQAHgDAKAAQAJAAAHADQAGACADADQADAEABAFIABANIAAAQQAAATABAEQAAAFADAFIgOAAQgCgEgBgGQgHAGgHADQgFADgIAAQgNAAgHgHgAgCAFIgMACQgDACgCADQgCACAAAEQAAAFAEAEQAEADAIAAQAHAAAFgDQAGgDADgGQACgFAAgIIAAgFQgHADgNACg");
	this.shape_61.setTransform(578.4,351.5);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#000000").s().p("AgBAzQgEgDgCgDQgBgEAAgMIAAgrIgKAAIAAgLIAKAAIAAgTIAMgIIAAAbIANAAIAAALIgNAAIAAAsIAAAHIADADIAEAAIAGAAIACAMIgKABQgHAAgDgCg");
	this.shape_62.setTransform(572.3,350.2);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#000000").s().p("AgGA2IAAhNIANAAIAABNgAgGglIAAgQIANAAIAAAQg");
	this.shape_63.setTransform(568.4,350);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#000000").s().p("AgXAeQgKgKAAgUQAAgLAEgKQAEgJAJgFQAJgFAJAAQAMAAAIAHQAIAGADAMIgNACQgCgIgFgEQgEgEgHAAQgJAAgGAHQgGAHAAAPQAAAPAGAIQAGAHAIAAQAIAAAFgFQAGgFABgKIANACQgCANgJAIQgJAIgNAAQgOAAgKgLg");
	this.shape_64.setTransform(563.2,351.5);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#000000").s().p("AgcAiQgHgGAAgKQAAgFADgFQACgFAFgDQAEgCAFgBIAMgCQAPgCAHgDIAAgDQAAgIgDgDQgFgFgKAAQgJAAgEADQgFAEgCAIIgNgCQACgIAEgFQAEgFAIgDQAHgDAKAAQAJAAAHADQAGACADADQADAEABAFIABANIAAAQQAAATABAEQAAAFADAFIgOAAQgCgEgBgGQgHAGgHADQgFADgIAAQgNAAgHgHgAgCAFIgMACQgDACgCADQgCACAAAEQAAAFAEAEQAEADAIAAQAHAAAFgDQAGgDADgGQACgFAAgIIAAgFQgHADgNACg");
	this.shape_65.setTransform(555,351.5);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#000000").s().p("AghA3IAAhrIAMAAIAAAKQAEgGAGgDQAFgDAHAAQAKAAAHAFQAIAFAEAKQAEAJAAALQAAAMgFAJQgEAJgIAFQgIAGgJAAQgGAAgFgDQgFgDgEgEIAAAmgAgOgkQgHAIAAAPQAAAOAGAHQAGAIAJAAQAIAAAGgIQAGgHAAgPQAAgPgGgHQgGgHgIAAQgIAAgGAHg");
	this.shape_66.setTransform(546.9,352.9);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#000000").s().p("AgcAiQgHgGAAgKQAAgFADgFQACgFAFgDQAEgCAFgBIAMgCQAPgCAHgDIAAgDQAAgIgDgDQgFgFgKAAQgJAAgEADQgFAEgCAIIgNgCQACgIAEgFQAEgFAIgDQAHgDAKAAQAJAAAHADQAGACADADQADAEABAFIABANIAAAQQAAATABAEQAAAFADAFIgOAAQgCgEgBgGQgHAGgHADQgFADgIAAQgNAAgHgHgAgCAFIgMACQgDACgCADQgCACAAAEQAAAFAEAEQAEADAIAAQAHAAAFgDQAGgDADgGQACgFAAgIIAAgFQgHADgNACg");
	this.shape_67.setTransform(538.3,351.5);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#000000").s().p("AgXAeQgKgKAAgUQAAgLAEgKQAEgJAJgFQAJgFAJAAQAMAAAIAHQAIAGADAMIgNACQgCgIgFgEQgEgEgHAAQgJAAgGAHQgGAHAAAPQAAAPAGAIQAGAHAIAAQAIAAAFgFQAGgFABgKIANACQgCANgJAIQgJAIgNAAQgOAAgKgLg");
	this.shape_68.setTransform(530.7,351.5);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#000000").s().p("AgZAeQgKgLAAgSQAAgTAKgLQAKgLAQAAQAPAAAKALQAKAKAAATIAAADIg5AAQABANAGAHQAHAHAIAAQAIAAAFgEQAFgEADgIIAOABQgEAMgIAHQgJAHgOAAQgQAAgKgLgAgOgXQgGAGAAAKIAqAAQgBgJgEgFQgGgIgKAAQgIAAgHAGg");
	this.shape_69.setTransform(518.3,351.5);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#000000").s().p("AgQAxQgIgFgEgJQgFgJAAgMQAAgMAEgIQAEgKAIgFQAIgFAJAAQAGAAAGADQAFADAEAFIAAgnIANAAIAABrIgMAAIAAgKQgIAMgOAAQgIAAgIgGgAgNgIQgGAHAAAPQAAAPAGAHQAHAIAHAAQAJAAAGgHQAGgHAAgPQAAgPgGgHQgGgIgJAAQgIAAgGAHg");
	this.shape_70.setTransform(509.7,350.1);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#000000").s().p("AgGA2IAAhrIANAAIAABrg");
	this.shape_71.setTransform(500,350);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#000000").s().p("AgcAiQgHgGAAgKQAAgFADgFQACgFAFgDQAEgCAFgBIAMgCQAPgCAHgDIAAgDQAAgIgDgDQgFgFgKAAQgJAAgEADQgFAEgCAIIgNgCQACgIAEgFQAEgFAIgDQAHgDAKAAQAJAAAHADQAGACADADQADAEABAFIABANIAAAQQAAATABAEQAAAFADAFIgOAAQgCgEgBgGQgHAGgHADQgFADgIAAQgNAAgHgHgAgCAFIgMACQgDACgCADQgCACAAAEQAAAFAEAEQAEADAIAAQAHAAAFgDQAGgDADgGQACgFAAgIIAAgFQgHADgNACg");
	this.shape_72.setTransform(494.1,351.5);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#000000").s().p("AASAoIAAgvQAAgIgBgEQgBgEgEgCQgFgCgFAAQgHAAgGAFQgHAFAAAPIAAAqIgMAAIAAhNIALAAIAAALQAJgNAPAAQAHAAAGADQAGACADAEQACAEACAGIABANIAAAvg");
	this.shape_73.setTransform(485.8,351.4);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#000000").s().p("AgZAeQgLgKAAgUQAAgVANgKQAJgJAOAAQAQAAAKALQALAKAAATQAAAOgFAIQgFAJgIAFQgJAFgKAAQgQAAgJgLgAgPgVQgHAHAAAOQAAAPAHAHQAGAIAJAAQAKAAAGgIQAHgHAAgPQAAgOgHgHQgGgIgKAAQgJAAgGAIg");
	this.shape_74.setTransform(477.5,351.5);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#000000").s().p("AgVAiQgIgGgCgMIANgDQABAIAFAEQAFAFAIAAQAJAAAFgEQAEgEAAgFQAAgEgEgDIgNgEQgOgEgGgCQgFgCgDgFQgDgFAAgFQAAgGACgEQADgEAEgDQADgDAFgBQAGgCAGAAQAIAAAHADQAHACADAFQADAEACAIIgNACQgBgGgEgEQgFgDgHAAQgIAAgEADQgEADAAAEQAAABAAAAQAAABAAABQAAAAABABQAAAAAAABIAFADIALAEQAOADAGADQAFABADAFQADAEAAAHQAAAGgDAGQgEAGgHADQgIAEgJAAQgOAAgIgHg");
	this.shape_75.setTransform(469.5,351.5);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#000000").s().p("AgUAoIAAhNIAMAAIAAAMQAEgJAEgCQADgDAFAAQAGAAAHAEIgEANQgFgDgFAAQgEAAgDACQgDADgCAFQgCAHAAAIIAAAog");
	this.shape_76.setTransform(463.9,351.4);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#000000").s().p("AgZAeQgKgLAAgSQAAgTAKgLQAKgLAQAAQAPAAAKALQAKAKAAATIAAADIg5AAQABANAGAHQAHAHAIAAQAIAAAFgEQAFgEADgIIAOABQgEAMgIAHQgJAHgOAAQgQAAgKgLgAgOgXQgGAGAAAKIAqAAQgBgJgEgFQgGgIgKAAQgIAAgHAGg");
	this.shape_77.setTransform(456.6,351.5);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#000000").s().p("AghA3IAAhrIAMAAIAAAKQAEgGAGgDQAFgDAHAAQAKAAAHAFQAIAFAEAKQAEAJAAALQAAAMgFAJQgEAJgIAFQgIAGgJAAQgGAAgFgDQgFgDgEgEIAAAmgAgOgkQgHAIAAAPQAAAOAGAHQAGAIAJAAQAIAAAGgIQAGgHAAgPQAAgPgGgHQgGgHgIAAQgIAAgGAHg");
	this.shape_78.setTransform(448.5,352.9);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#000000").s().p("AgGA2IAAhrIANAAIAABrg");
	this.shape_79.setTransform(438.2,350);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#000000").s().p("AgZAeQgKgLAAgSQAAgTAKgLQAKgLAQAAQAPAAAKALQAKAKAAATIAAADIg5AAQABANAGAHQAHAHAIAAQAIAAAFgEQAFgEADgIIAOABQgEAMgIAHQgJAHgOAAQgQAAgKgLgAgOgXQgGAGAAAKIAqAAQgBgJgEgFQgGgIgKAAQgIAAgHAGg");
	this.shape_80.setTransform(432.4,351.5);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#000000").s().p("AgUAoIAAhNIAMAAIAAAMQAEgJAEgCQADgDAFAAQAGAAAHAEIgEANQgFgDgFAAQgEAAgDACQgDADgCAFQgCAHAAAIIAAAog");
	this.shape_81.setTransform(422.2,351.4);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#000000").s().p("AgZAeQgLgKAAgUQAAgVANgKQAKgJANAAQAQAAAKALQALAKAAATQAAAOgFAIQgFAJgIAFQgJAFgKAAQgQAAgJgLgAgPgVQgHAHAAAOQAAAPAHAHQAGAIAJAAQAKAAAGgIQAHgHAAgPQAAgOgHgHQgGgIgKAAQgJAAgGAIg");
	this.shape_82.setTransform(414.9,351.5);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#000000").s().p("AghA3IAAhrIAMAAIAAAKQAEgGAGgDQAFgDAHAAQAKAAAHAFQAIAFAEAKQAEAJAAALQAAAMgFAJQgEAJgIAFQgIAGgJAAQgGAAgFgDQgFgDgEgEIAAAmgAgOgkQgHAIAAAPQAAAOAGAHQAGAIAJAAQAIAAAGgIQAGgHAAgPQAAgPgGgHQgGgHgIAAQgIAAgGAHg");
	this.shape_83.setTransform(406.8,352.9);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#000000").s().p("AgZAeQgLgKABgUQgBgVAMgKQALgJANAAQAQAAAKALQALAKAAATQgBAOgEAIQgEAJgJAFQgJAFgKAAQgPAAgKgLgAgQgVQgGAHAAAOQAAAPAGAHQAHAIAJAAQAKAAAHgIQAGgHAAgPQAAgOgGgHQgIgIgJAAQgJAAgHAIg");
	this.shape_84.setTransform(394.1,351.5);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#000000").s().p("AgQAxQgIgFgEgJQgFgJAAgMQAAgMAEgIQAEgKAIgFQAIgFAJAAQAGAAAGADQAFADAEAFIAAgnIANAAIAABrIgMAAIAAgKQgIAMgOAAQgIAAgIgGgAgNgIQgGAHAAAPQAAAPAGAHQAHAIAHAAQAJAAAGgHQAGgHAAgPQAAgPgGgHQgGgIgJAAQgIAAgGAHg");
	this.shape_85.setTransform(385.4,350.1);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#000000").s().p("AgcAiQgHgGAAgKQAAgFADgFQACgFAFgDQAEgCAFgBIAMgCQAPgCAHgDIAAgDQAAgIgDgDQgFgFgKAAQgJAAgEADQgFAEgCAIIgNgCQACgIAEgFQAEgFAIgDQAHgDAKAAQAJAAAHADQAGACADADQADAEABAFIABANIAAAQQAAATABAEQAAAFADAFIgOAAQgCgEgBgGQgHAGgHADQgFADgIAAQgNAAgHgHgAgCAFIgMACQgDACgCADQgCACAAAEQAAAFAEAEQAEADAIAAQAHAAAFgDQAGgDADgGQACgFAAgIIAAgFQgHADgNACg");
	this.shape_86.setTransform(377.3,351.5);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#000000").s().p("AgBAzQgEgDgCgDQgBgEAAgMIAAgrIgKAAIAAgLIAKAAIAAgTIAMgIIAAAbIANAAIAAALIgNAAIAAAsIAAAHIADADIAEAAIAGAAIACAMIgKABQgHAAgDgCg");
	this.shape_87.setTransform(371.2,350.2);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#000000").s().p("AgGA2IAAhNIANAAIAABNgAgGglIAAgQIANAAIAAAQg");
	this.shape_88.setTransform(367.4,350);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#000000").s().p("AgXAeQgKgKAAgUQAAgLAEgKQAEgJAJgFQAJgFAJAAQAMAAAIAHQAIAGADAMIgNACQgCgIgFgEQgEgEgHAAQgJAAgGAHQgGAHAAAPQAAAPAGAIQAGAHAIAAQAIAAAFgFQAGgFABgKIANACQgCANgJAIQgJAIgNAAQgOAAgKgLg");
	this.shape_89.setTransform(362.2,351.5);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#000000").s().p("AgFA2IAAhNIALAAIAABNgAgFglIAAgQIALAAIAAAQg");
	this.shape_90.setTransform(356.5,350);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#000000").s().p("AgGA2IAAhrIANAAIAABrg");
	this.shape_91.setTransform(353.1,350);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#000000").s().p("AgaAeQgJgKgBgUQAAgVANgKQAJgJAOAAQAQAAAKALQALAKgBATQABAOgFAIQgEAJgJAFQgJAFgKAAQgPAAgLgLgAgPgVQgHAHAAAOQAAAPAHAHQAGAIAJAAQAKAAAGgIQAHgHAAgPQAAgOgHgHQgGgIgKAAQgJAAgGAIg");
	this.shape_92.setTransform(347.3,351.5);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#000000").s().p("AgVAiQgIgGgCgMIANgDQABAIAFAEQAFAFAIAAQAJAAAFgEQAEgEAAgFQAAgEgEgDIgNgEQgOgEgGgCQgFgCgDgFQgDgFAAgFQAAgGACgEQADgEAEgDQADgDAFgBQAGgCAGAAQAIAAAHADQAHACADAFQADAEACAIIgNACQgBgGgEgEQgFgDgHAAQgIAAgEADQgEADAAAEQAAABAAAAQAAABAAABQAAAAABABQAAAAAAABIAFADIALAEQAOADAGADQAFABADAFQADAEAAAHQAAAGgDAGQgEAGgHADQgIAEgJAAQgOAAgIgHg");
	this.shape_93.setTransform(339.3,351.5);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#000000").s().p("AgUAoIAAhNIAMAAIAAAMQAEgJAEgCQADgDAFAAQAGAAAHAEIgEANQgFgDgFAAQgEAAgDACQgDADgCAFQgCAHAAAIIAAAog");
	this.shape_94.setTransform(329.6,351.4);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#000000").s().p("AgZAeQgKgLAAgSQAAgTAKgLQAKgLAQAAQAPAAAKALQAKAKAAATIAAADIg5AAQABANAGAHQAHAHAIAAQAIAAAFgEQAFgEADgIIAOABQgEAMgIAHQgJAHgOAAQgQAAgKgLgAgOgXQgGAGAAAKIAqAAQgBgJgEgFQgGgIgKAAQgIAAgHAGg");
	this.shape_95.setTransform(322.3,351.5);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#000000").s().p("AgVAiQgIgGgCgMIANgDQABAIAFAEQAFAFAIAAQAJAAAFgEQAEgEAAgFQAAgEgEgDIgNgEQgOgEgGgCQgFgCgDgFQgDgFAAgFQAAgGACgEQADgEAEgDQADgDAFgBQAGgCAGAAQAIAAAHADQAHACADAFQADAEACAIIgNACQgBgGgEgEQgFgDgHAAQgIAAgEADQgEADAAAEQAAABAAAAQAAABAAABQAAAAABABQAAAAAAABIAFADIALAEQAOADAGADQAFABADAFQADAEAAAHQAAAGgDAGQgEAGgHADQgIAEgJAAQgOAAgIgHg");
	this.shape_96.setTransform(314.3,351.5);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#000000").s().p("AgZAeQgKgLAAgSQAAgTAKgLQAKgLAQAAQAPAAAKALQAKAKAAATIAAADIg5AAQABANAGAHQAHAHAIAAQAIAAAFgEQAFgEADgIIAOABQgEAMgIAHQgJAHgOAAQgQAAgKgLgAgOgXQgGAGAAAKIAqAAQgBgJgEgFQgGgIgKAAQgIAAgHAGg");
	this.shape_97.setTransform(302.3,351.5);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#000000").s().p("AgQAxQgIgFgEgJQgFgJAAgMQAAgMAEgIQAEgKAIgFQAIgFAJAAQAGAAAGADQAFADAEAFIAAgnIANAAIAABrIgMAAIAAgKQgIAMgOAAQgIAAgIgGgAgNgIQgGAHAAAPQAAAPAGAHQAHAIAHAAQAJAAAGgHQAGgHAAgPQAAgPgGgHQgGgIgJAAQgIAAgGAHg");
	this.shape_98.setTransform(293.7,350.1);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#000000").s().p("AgZAeQgKgLAAgSQAAgTAKgLQAKgLAQAAQAPAAAKALQAKAKAAATIAAADIg5AAQABANAGAHQAHAHAIAAQAIAAAFgEQAFgEADgIIAOABQgEAMgIAHQgJAHgOAAQgQAAgKgLgAgOgXQgGAGAAAKIAqAAQgBgJgEgFQgGgIgKAAQgIAAgHAGg");
	this.shape_99.setTransform(285.6,351.5);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#000000").s().p("AgQAlQgHgCgCgEQgEgFgBgGIgBgMIAAgvIAOAAIAAArIABANQABAFAEADQAEADAGAAQAFAAAFgDQAFgCACgGQACgFABgKIAAgpIANAAIAABNIgMAAIAAgMQgJAOgPAAQgGAAgGgDg");
	this.shape_100.setTransform(277.2,351.6);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#000000").s().p("AghA3IAAhrIAMAAIAAAKQAEgGAGgDQAFgDAHAAQAKAAAHAFQAIAFAEAKQAEAJAAALQAAAMgFAJQgEAJgIAFQgIAGgJAAQgGAAgFgDQgFgDgEgEIAAAmgAgOgkQgHAIAAAPQAAAOAGAHQAGAIAJAAQAIAAAGgIQAGgHAAgPQAAgPgGgHQgGgHgIAAQgIAAgGAHg");
	this.shape_101.setTransform(269.1,352.9);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("#000000").s().p("AgZAeQgKgLAAgSQAAgTAKgLQAKgLAQAAQAPAAAKALQAKAKAAATIAAADIg5AAQABANAGAHQAHAHAIAAQAIAAAFgEQAFgEADgIIAOABQgEAMgIAHQgJAHgOAAQgQAAgKgLgAgOgXQgGAGAAAKIAqAAQgBgJgEgFQgGgIgKAAQgIAAgHAGg");
	this.shape_102.setTransform(256.4,351.5);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("#000000").s().p("AgBAzQgEgDgCgDQgBgEAAgMIAAgrIgKAAIAAgLIAKAAIAAgTIAMgIIAAAbIANAAIAAALIgNAAIAAAsIABAHIACADIAEAAIAGAAIACAMIgKABQgHAAgDgCg");
	this.shape_103.setTransform(250.3,350.2);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f("#000000").s().p("AATAoIAAgvQAAgIgCgEQgBgEgEgCQgFgCgFAAQgHAAgHAFQgFAFgBAPIAAAqIgNAAIAAhNIAMAAIAAALQAJgNAPAAQAHAAAGADQAGACADAEQACAEACAGIABANIAAAvg");
	this.shape_104.setTransform(243.9,351.4);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f("#000000").s().p("AgcAiQgHgGAAgKQAAgFADgFQACgFAFgDQAEgCAFgBIAMgCQAPgCAHgDIAAgDQAAgIgDgDQgFgFgKAAQgJAAgEADQgFAEgCAIIgNgCQACgIAEgFQAEgFAIgDQAHgDAKAAQAJAAAHADQAGACADADQADAEABAFIABANIAAAQQAAATABAEQAAAFADAFIgOAAQgCgEgBgGQgHAGgHADQgFADgIAAQgNAAgHgHgAgCAFIgMACQgDACgCADQgCACAAAEQAAAFAEAEQAEADAIAAQAHAAAFgDQAGgDADgGQACgFAAgIIAAgFQgHADgNACg");
	this.shape_105.setTransform(235.5,351.5);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f("#000000").s().p("AgVArIAAAKIgMAAIAAhrIANAAIAAAnQAJgLAMAAQAHAAAGADQAHADAEAFQAEAFACAIQADAGAAAJQAAAUgKALQgKALgOAAQgNAAgIgMgAgPgHQgGAHAAANQAAAOAEAGQAGALALAAQAHAAAHgIQAGgHAAgPQAAgOgGgIQgGgHgIAAQgIAAgHAIg");
	this.shape_106.setTransform(227.4,350.1);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f("#000000").s().p("AgaAeQgKgKAAgUQABgVALgKQALgJANAAQAQAAAKALQAKAKAAATQABAOgFAIQgFAJgIAFQgJAFgKAAQgQAAgKgLgAgQgVQgGAHAAAOQAAAPAGAHQAHAIAJAAQAKAAAHgIQAGgHAAgPQAAgOgGgHQgIgIgJAAQgJAAgHAIg");
	this.shape_107.setTransform(218.9,351.5);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f("#000000").s().p("AgUAoIAAhNIAMAAIAAAMQAEgJAEgCQADgDAFAAQAGAAAHAEIgEANQgFgDgFAAQgEAAgDACQgDADgCAFQgCAHAAAIIAAAog");
	this.shape_108.setTransform(212.8,351.4);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f("#000000").s().p("AghA3IAAhrIAMAAIAAAKQAEgGAGgDQAFgDAHAAQAKAAAHAFQAIAFAEAKQAEAJAAALQAAAMgFAJQgEAJgIAFQgIAGgJAAQgGAAgFgDQgFgDgEgEIAAAmgAgOgkQgHAIAAAPQAAAOAGAHQAGAIAJAAQAIAAAGgIQAGgHAAgPQAAgPgGgHQgGgHgIAAQgIAAgGAHg");
	this.shape_109.setTransform(205.7,352.9);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f("#000000").s().p("AAnAoIAAgwIgBgMQgBgDgEgCQgDgCgEAAQgJAAgFAFQgFAGAAAMIAAAsIgNAAIAAgyQAAgJgDgEQgDgEgHAAQgGAAgFADQgEACgDAGQgCAGAAAKIAAAoIgNAAIAAhNIAMAAIAAALQAEgGAGgDQAGgEAIAAQAIAAAGAEQAEADACAHQAKgOAPAAQALAAAGAHQAHAGAAANIAAA1g");
	this.shape_110.setTransform(195.1,351.4);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f("#000000").s().p("AgaAeQgKgKAAgUQABgVALgKQALgJANAAQAQAAAKALQAKAKAAATQABAOgFAIQgFAJgIAFQgJAFgKAAQgQAAgKgLgAgQgVQgGAHAAAOQAAAPAGAHQAHAIAJAAQAKAAAHgIQAGgHAAgPQAAgOgGgHQgIgIgJAAQgJAAgHAIg");
	this.shape_111.setTransform(184.7,351.5);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.f("#000000").s().p("AgXAeQgKgKAAgUQAAgLAEgKQAEgJAJgFQAJgFAJAAQAMAAAIAHQAIAGADAMIgNACQgCgIgFgEQgEgEgHAAQgJAAgGAHQgGAHAAAPQAAAPAGAIQAGAHAIAAQAIAAAFgFQAGgFABgKIANACQgCANgJAIQgJAIgNAAQgOAAgKgLg");
	this.shape_112.setTransform(177,351.5);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.f("#000000").s().p("AgZAeQgKgLAAgSQAAgTAKgLQAKgLAQAAQAPAAAKALQAKAKAAATIAAADIg5AAQABANAGAHQAHAHAIAAQAIAAAFgEQAFgEADgIIAOABQgEAMgIAHQgJAHgOAAQgQAAgKgLgAgOgXQgGAGAAAKIAqAAQgBgJgEgFQgGgIgKAAQgIAAgHAGg");
	this.shape_113.setTransform(164.6,351.5);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.f("#000000").s().p("AgBAzQgEgDgBgDQgCgEAAgMIAAgrIgKAAIAAgLIAKAAIAAgTIAMgIIAAAbIANAAIAAALIgNAAIAAAsIAAAHIADADIAFAAIAFAAIACAMIgKABQgHAAgDgCg");
	this.shape_114.setTransform(158.5,350.2);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.f("#000000").s().p("AgVAiQgIgGgCgMIANgDQABAIAFAEQAFAFAIAAQAJAAAFgEQAEgEAAgFQAAgEgEgDIgNgEQgOgEgGgCQgFgCgDgFQgDgFAAgFQAAgGACgEQADgEAEgDQADgDAFgBQAGgCAGAAQAIAAAHADQAHACADAFQADAEACAIIgNACQgBgGgEgEQgFgDgHAAQgIAAgEADQgEADAAAEQAAABAAAAQAAABAAABQAAAAABABQAAAAAAABIAFADIALAEQAOADAGADQAFABADAFQADAEAAAHQAAAGgDAGQgEAGgHADQgIAEgJAAQgOAAgIgHg");
	this.shape_115.setTransform(152.5,351.5);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.f("#000000").s().p("AgnA2IAAhrIBMAAIAAANIg+AAIAAAhIA7AAIAAAMIg7AAIAAAkIBBAAIAAANg");
	this.shape_116.setTransform(144.1,350);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.f("#000000").s().p("AgGAnIAAgPIANAAIAAAPgAgGgXIAAgPIANAAIAAAPg");
	this.shape_117.setTransform(182.6,332.7);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.f("#000000").s().p("AAiA2IgNghIgsAAIgLAhIgPAAIAphrIAOAAIAsBrgAgHgVIgLAfIAjAAIgLgdIgHgWQgCAKgEAKg");
	this.shape_118.setTransform(175.5,331.2);

	this.shape_119 = new cjs.Shape();
	this.shape_119.graphics.f("#000000").s().p("AgGA2IAAheIgjAAIAAgNIBTAAIAAANIgjAAIAABeg");
	this.shape_119.setTransform(166,331.2);

	this.shape_120 = new cjs.Shape();
	this.shape_120.graphics.f("#000000").s().p("AgaAwQgMgHgGgNQgGgMAAgPQAAgZAOgPQAOgQAWAAQAPAAAMAIQAMAHAGAMQAGANAAAPQAAARgGAMQgHANgMAHQgMAHgOAAQgOAAgMgIgAgZggQgLAKAAAYQAAATALALQAKALAPAAQAQAAAKgLQALgLAAgVQAAgMgFgKQgEgKgJgFQgIgFgLAAQgOAAgLAKg");
	this.shape_120.setTransform(155.6,331.2);

	this.shape_121 = new cjs.Shape();
	this.shape_121.graphics.f("#000000").s().p("AAcA2Ig4hUIAABUIgNAAIAAhrIAOAAIA4BUIAAhUIANAAIAABrg");
	this.shape_121.setTransform(144.2,331.2);

	this.shape_122 = new cjs.Shape();
	this.shape_122.graphics.f("#000000").s().p("AgHAHIAAgOIAOAAIAAAOg");
	this.shape_122.setTransform(594.7,307.1);

	this.shape_123 = new cjs.Shape();
	this.shape_123.graphics.f("#000000").s().p("AgZAeQgKgLAAgSQAAgTAKgLQAKgLAQAAQAPAAAKALQAKAKAAATIAAADIg5AAQABANAGAHQAHAHAIAAQAIAAAFgEQAFgEADgIIAOABQgEAMgIAHQgJAHgOAAQgQAAgKgLgAgOgXQgGAGAAAKIAqAAQgBgJgEgFQgGgIgKAAQgIAAgHAGg");
	this.shape_123.setTransform(588.4,303.9);

	this.shape_124 = new cjs.Shape();
	this.shape_124.graphics.f("#000000").s().p("AgBAzQgEgDgCgDQgBgEAAgMIAAgsIgKAAIAAgKIAKAAIAAgTIAMgIIAAAbIANAAIAAAKIgNAAIAAAtIAAAHIADADIAEAAIAGAAIACAMIgKABQgHAAgDgCg");
	this.shape_124.setTransform(582.3,302.6);

	this.shape_125 = new cjs.Shape();
	this.shape_125.graphics.f("#000000").s().p("AASAoIAAgvQAAgIgBgEQgBgEgEgCQgEgCgGAAQgHAAgHAFQgFAFgBAPIAAAqIgMAAIAAhNIALAAIAAALQAJgNAPAAQAHAAAGADQAGACADAEQACAEACAGIABANIAAAvg");
	this.shape_125.setTransform(575.9,303.8);

	this.shape_126 = new cjs.Shape();
	this.shape_126.graphics.f("#000000").s().p("AgZAeQgKgLAAgSQAAgTAKgLQAKgLAQAAQAPAAAKALQAKAKAAATIAAADIg5AAQABANAGAHQAHAHAIAAQAIAAAFgEQAFgEADgIIAOABQgEAMgIAHQgJAHgOAAQgQAAgKgLgAgOgXQgGAGAAAKIAqAAQgBgJgEgFQgGgIgKAAQgIAAgHAGg");
	this.shape_126.setTransform(567.5,303.9);

	this.shape_127 = new cjs.Shape();
	this.shape_127.graphics.f("#000000").s().p("AAnAoIAAgwIgBgMQgBgDgEgCQgDgCgEAAQgJAAgFAFQgFAGAAAMIAAAsIgNAAIAAgyQAAgJgDgEQgDgEgHAAQgGAAgFADQgEACgDAGQgCAGAAAKIAAAoIgNAAIAAhNIAMAAIAAALQAEgGAGgDQAGgEAIAAQAIAAAGAEQAEADACAHQAKgOAPAAQALAAAGAHQAHAGAAANIAAA1g");
	this.shape_127.setTransform(557.2,303.8);

	this.shape_128 = new cjs.Shape();
	this.shape_128.graphics.f("#000000").s().p("AgcAiQgHgGAAgKQAAgFADgFQACgFAFgDQAEgCAFgBIAMgCQAPgCAHgDIAAgDQAAgIgDgDQgFgFgKAAQgJAAgEADQgFAEgCAIIgNgCQACgIAEgFQAEgFAIgDQAHgDAKAAQAJAAAHADQAGACADADQADAEABAFIABANIAAAQQAAATABAEQAAAFADAFIgOAAQgCgEgBgGQgHAGgHADQgFADgIAAQgNAAgHgHgAgCAFIgMACQgDACgCADQgCACAAAEQAAAFAEAEQAEADAIAAQAHAAAFgDQAGgDADgGQACgFAAgIIAAgFQgHADgNACg");
	this.shape_128.setTransform(546.7,303.9);

	this.shape_129 = new cjs.Shape();
	this.shape_129.graphics.f("#000000").s().p("AgBAzQgEgDgBgDQgCgEAAgMIAAgsIgKAAIAAgKIAKAAIAAgTIAMgIIAAAbIANAAIAAAKIgNAAIAAAtIAAAHIADADIAFAAIAFAAIACAMIgKABQgHAAgDgCg");
	this.shape_129.setTransform(540.6,302.6);

	this.shape_130 = new cjs.Shape();
	this.shape_130.graphics.f("#000000").s().p("AgXAeQgKgKAAgUQAAgLAEgKQAEgJAJgFQAJgFAJAAQAMAAAIAHQAIAGADAMIgNACQgCgIgFgEQgEgEgHAAQgJAAgGAHQgGAHAAAPQAAAPAGAIQAGAHAIAAQAIAAAFgFQAGgFABgKIANACQgCANgJAIQgJAIgNAAQgOAAgKgLg");
	this.shape_130.setTransform(534.9,303.9);

	this.shape_131 = new cjs.Shape();
	this.shape_131.graphics.f("#000000").s().p("AgZAeQgKgLAAgSQAAgTAKgLQAKgLAQAAQAPAAAKALQAKAKAAATIAAADIg5AAQABANAGAHQAHAHAIAAQAIAAAFgEQAFgEADgIIAOABQgEAMgIAHQgJAHgOAAQgQAAgKgLgAgOgXQgGAGAAAKIAqAAQgBgJgEgFQgGgIgKAAQgIAAgHAGg");
	this.shape_131.setTransform(526.7,303.9);

	this.shape_132 = new cjs.Shape();
	this.shape_132.graphics.f("#000000").s().p("AgUAoIAAhNIAMAAIAAAMQAEgJAEgCQADgDAFAAQAGAAAHAEIgEANQgFgDgFAAQgEAAgDACQgDADgCAFQgCAHAAAIIAAAog");
	this.shape_132.setTransform(520.6,303.8);

	this.shape_133 = new cjs.Shape();
	this.shape_133.graphics.f("#000000").s().p("AgUAoIAAhNIAMAAIAAAMQAEgJAEgCQADgDAFAAQAGAAAHAEIgEANQgFgDgFAAQgEAAgDACQgDADgCAFQgCAHAAAIIAAAog");
	this.shape_133.setTransform(515.6,303.8);

	this.shape_134 = new cjs.Shape();
	this.shape_134.graphics.f("#000000").s().p("AgZAeQgLgKABgUQgBgVAMgKQALgJANAAQAQAAAKALQALAKAAATQgBAOgEAIQgEAJgJAFQgJAFgKAAQgPAAgKgLgAgPgVQgHAHAAAOQAAAPAHAHQAGAIAJAAQAKAAAHgIQAGgHAAgPQAAgOgGgHQgIgIgJAAQgJAAgGAIg");
	this.shape_134.setTransform(508.4,303.9);

	this.shape_135 = new cjs.Shape();
	this.shape_135.graphics.f("#000000").s().p("AgXAeQgKgKAAgUQAAgLAEgKQAEgJAJgFQAJgFAJAAQAMAAAIAHQAIAGADAMIgNACQgCgIgFgEQgEgEgHAAQgJAAgGAHQgGAHAAAPQAAAPAGAIQAGAHAIAAQAIAAAFgFQAGgFABgKIANACQgCANgJAIQgJAIgNAAQgOAAgKgLg");
	this.shape_135.setTransform(500.7,303.9);

	this.shape_136 = new cjs.Shape();
	this.shape_136.graphics.f("#000000").s().p("AgZAeQgKgKAAgUQAAgVAMgKQAKgJANAAQAQAAAKALQALAKAAATQAAAOgFAIQgFAJgIAFQgJAFgKAAQgQAAgJgLgAgPgVQgHAHAAAOQAAAPAHAHQAGAIAJAAQAKAAAGgIQAHgHAAgPQAAgOgHgHQgGgIgKAAQgJAAgGAIg");
	this.shape_136.setTransform(488.4,303.9);

	this.shape_137 = new cjs.Shape();
	this.shape_137.graphics.f("#000000").s().p("AgVAiQgIgGgCgMIANgDQABAIAFAEQAFAFAIAAQAJAAAFgEQAEgEAAgFQAAgEgEgDIgNgEQgOgEgGgCQgFgCgDgFQgDgFAAgFQAAgGACgEQADgEAEgDQADgDAFgBQAGgCAGAAQAIAAAHADQAHACADAFQADAEACAIIgNACQgBgGgEgEQgFgDgHAAQgIAAgEADQgEADAAAEQAAABAAAAQAAABAAABQAAAAABABQAAAAAAABIAFADIALAEQAOADAGADQAFABADAFQADAEAAAHQAAAGgDAGQgEAGgHADQgIAEgJAAQgOAAgIgHg");
	this.shape_137.setTransform(480.4,303.9);

	this.shape_138 = new cjs.Shape();
	this.shape_138.graphics.f("#000000").s().p("AgUAoIAAhNIAMAAIAAAMQAEgJAEgCQADgDAFAAQAGAAAHAEIgEANQgFgDgFAAQgEAAgDACQgDADgCAFQgCAHAAAIIAAAog");
	this.shape_138.setTransform(474.8,303.8);

	this.shape_139 = new cjs.Shape();
	this.shape_139.graphics.f("#000000").s().p("AgRAlQgFgCgEgEQgDgFgBgFIAAgNIAAgvIANAAIAAArIAAANQACAGAEACQAEADAGAAQAFAAAFgDQAFgDACgFQACgFAAgKIAAgpIAOAAIAABNIgMAAIAAgMQgJAOgPAAQgGAAgHgDg");
	this.shape_139.setTransform(467.5,304);

	this.shape_140 = new cjs.Shape();
	this.shape_140.graphics.f("#000000").s().p("AgXAeQgKgKAAgUQAAgLAEgKQAEgJAJgFQAJgFAJAAQAMAAAIAHQAIAGADAMIgNACQgCgIgFgEQgEgEgHAAQgJAAgGAHQgGAHAAAPQAAAPAGAIQAGAHAIAAQAIAAAFgFQAGgFABgKIANACQgCANgJAIQgJAIgNAAQgOAAgKgLg");
	this.shape_140.setTransform(459.8,303.9);

	this.shape_141 = new cjs.Shape();
	this.shape_141.graphics.f("#000000").s().p("AgGA2IAAhrIANAAIAABrg");
	this.shape_141.setTransform(450,302.4);

	this.shape_142 = new cjs.Shape();
	this.shape_142.graphics.f("#000000").s().p("AgZAeQgKgLAAgSQAAgTAKgLQAKgLAQAAQAPAAAKALQAKAKAAATIAAADIg5AAQABANAGAHQAHAHAIAAQAIAAAFgEQAFgEADgIIAOABQgEAMgIAHQgJAHgOAAQgQAAgKgLgAgOgXQgGAGAAAKIAqAAQgBgJgEgFQgGgIgKAAQgIAAgHAGg");
	this.shape_142.setTransform(444.1,303.9);

	this.shape_143 = new cjs.Shape();
	this.shape_143.graphics.f("#000000").s().p("AgZAeQgKgKAAgUQAAgVAMgKQAKgJANAAQAQAAAKALQALAKAAATQAAAOgFAIQgFAJgIAFQgJAFgKAAQgQAAgJgLgAgPgVQgHAHAAAOQAAAPAHAHQAGAIAJAAQAKAAAGgIQAHgHAAgPQAAgOgHgHQgGgIgKAAQgJAAgGAIg");
	this.shape_143.setTransform(431.7,303.9);

	this.shape_144 = new cjs.Shape();
	this.shape_144.graphics.f("#000000").s().p("AgQAxQgIgFgEgJQgFgJAAgMQAAgMAEgIQAEgKAIgFQAIgFAJAAQAGAAAGADQAFADAEAFIAAgnIANAAIAABrIgMAAIAAgKQgIAMgOAAQgIAAgIgGgAgNgIQgGAHAAAPQAAAPAGAHQAHAIAHAAQAJAAAGgHQAGgHAAgPQAAgPgGgHQgGgIgJAAQgIAAgGAHg");
	this.shape_144.setTransform(423,302.5);

	this.shape_145 = new cjs.Shape();
	this.shape_145.graphics.f("#000000").s().p("AgcAiQgHgGAAgKQAAgFADgFQACgFAFgDQAEgCAFgBIAMgCQAPgCAHgDIAAgDQAAgIgDgDQgFgFgKAAQgJAAgEADQgFAEgCAIIgNgCQACgIAEgFQAEgFAIgDQAHgDAKAAQAJAAAHADQAGACADADQADAEABAFIABANIAAAQQAAATABAEQAAAFADAFIgOAAQgCgEgBgGQgHAGgHADQgFADgIAAQgNAAgHgHgAgCAFIgMACQgDACgCADQgCACAAAEQAAAFAEAEQAEADAIAAQAHAAAFgDQAGgDADgGQACgFAAgIIAAgFQgHADgNACg");
	this.shape_145.setTransform(414.9,303.9);

	this.shape_146 = new cjs.Shape();
	this.shape_146.graphics.f("#000000").s().p("AgBAzQgEgDgBgDQgCgEAAgMIAAgsIgKAAIAAgKIAKAAIAAgTIAMgIIAAAbIANAAIAAAKIgNAAIAAAtIAAAHIADADIAEAAIAGAAIACAMIgKABQgHAAgDgCg");
	this.shape_146.setTransform(408.8,302.6);

	this.shape_147 = new cjs.Shape();
	this.shape_147.graphics.f("#000000").s().p("AgZAeQgKgLAAgSQAAgTAKgLQAKgLAQAAQAPAAAKALQAKAKAAATIAAADIg5AAQABANAGAHQAHAHAIAAQAIAAAFgEQAFgEADgIIAOABQgEAMgIAHQgJAHgOAAQgQAAgKgLgAgOgXQgGAGAAAKIAqAAQgBgJgEgFQgGgIgKAAQgIAAgHAGg");
	this.shape_147.setTransform(402.4,303.9);

	this.shape_148 = new cjs.Shape();
	this.shape_148.graphics.f("#000000").s().p("AgGA2IAAhrIANAAIAABrg");
	this.shape_148.setTransform(396.6,302.4);

	this.shape_149 = new cjs.Shape();
	this.shape_149.graphics.f("#000000").s().p("AghA3IAAhrIAMAAIAAAKQAEgGAGgDQAFgDAHAAQAKAAAHAFQAIAFAEAKQAEAJAAALQAAAMgFAJQgEAJgIAFQgIAGgJAAQgGAAgFgDQgFgDgEgEIAAAmgAgOgkQgHAIAAAPQAAAOAGAHQAGAIAJAAQAIAAAGgIQAGgHAAgPQAAgPgGgHQgGgHgIAAQgIAAgGAHg");
	this.shape_149.setTransform(391,305.3);

	this.shape_150 = new cjs.Shape();
	this.shape_150.graphics.f("#000000").s().p("AAnAoIAAgwIgBgMQgBgDgEgCQgDgCgEAAQgJAAgFAFQgFAGAAAMIAAAsIgNAAIAAgyQAAgJgDgEQgDgEgHAAQgGAAgFADQgEACgDAGQgCAGAAAKIAAAoIgNAAIAAhNIAMAAIAAALQAEgGAGgDQAGgEAIAAQAIAAAGAEQAEADACAHQAKgOAPAAQALAAAGAHQAHAGAAANIAAA1g");
	this.shape_150.setTransform(380.4,303.8);

	this.shape_151 = new cjs.Shape();
	this.shape_151.graphics.f("#000000").s().p("AgZAeQgLgKAAgUQAAgVANgKQAKgJANAAQAQAAAKALQALAKAAATQAAAOgFAIQgFAJgIAFQgJAFgKAAQgQAAgJgLgAgPgVQgHAHAAAOQAAAPAHAHQAGAIAJAAQAKAAAGgIQAHgHAAgPQAAgOgHgHQgGgIgKAAQgJAAgGAIg");
	this.shape_151.setTransform(369.9,303.9);

	this.shape_152 = new cjs.Shape();
	this.shape_152.graphics.f("#000000").s().p("AgXAeQgKgKAAgUQAAgLAEgKQAEgJAJgFQAJgFAJAAQAMAAAIAHQAIAGADAMIgNACQgCgIgFgEQgEgEgHAAQgJAAgGAHQgGAHAAAPQAAAPAGAIQAGAHAIAAQAIAAAFgFQAGgFABgKIANACQgCANgJAIQgJAIgNAAQgOAAgKgLg");
	this.shape_152.setTransform(362.2,303.9);

	this.shape_153 = new cjs.Shape();
	this.shape_153.graphics.f("#000000").s().p("AgVAiQgIgGgCgMIANgDQABAIAFAEQAFAFAIAAQAJAAAFgEQAEgEAAgFQAAgEgEgDIgNgEQgOgEgGgCQgFgCgDgFQgDgFAAgFQAAgGACgEQADgEAEgDQADgDAFgBQAGgCAGAAQAIAAAHADQAHACADAFQADAEACAIIgNACQgBgGgEgEQgFgDgHAAQgIAAgEADQgEADAAAEQAAABAAAAQAAABAAABQAAAAABABQAAAAAAABIAFADIALAEQAOADAGADQAFABADAFQADAEAAAHQAAAGgDAGQgEAGgHADQgIAEgJAAQgOAAgIgHg");
	this.shape_153.setTransform(350.3,303.9);

	this.shape_154 = new cjs.Shape();
	this.shape_154.graphics.f("#000000").s().p("AgcAiQgHgGAAgKQAAgFADgFQACgFAFgDQAEgCAFgBIAMgCQAPgCAHgDIAAgDQAAgIgDgDQgFgFgKAAQgJAAgEADQgFAEgCAIIgNgCQACgIAEgFQAEgFAIgDQAHgDAKAAQAJAAAHADQAGACADADQADAEABAFIABANIAAAQQAAATABAEQAAAFADAFIgOAAQgCgEgBgGQgHAGgHADQgFADgIAAQgNAAgHgHgAgCAFIgMACQgDACgCADQgCACAAAEQAAAFAEAEQAEADAIAAQAHAAAFgDQAGgDADgGQACgFAAgIIAAgFQgHADgNACg");
	this.shape_154.setTransform(342.4,303.9);

	this.shape_155 = new cjs.Shape();
	this.shape_155.graphics.f("#000000").s().p("AASA2IAAgyQAAgIgDgFQgFgEgIAAQgFAAgFADQgFADgCAFQgCAEgBAJIAAArIgMAAIAAhrIAMAAIAAAnQAKgLANAAQAIAAAHAEQAGADADAGQADAGAAAKIAAAyg");
	this.shape_155.setTransform(334.1,302.4);

	this.shape_156 = new cjs.Shape();
	this.shape_156.graphics.f("#000000").s().p("AgHAMQAEgBACgDQABgFABgFIgHAAIAAgPIAOAAIAAAPQAAAIgDAEQgDAFgGADg");
	this.shape_156.setTransform(323.7,308.1);

	this.shape_157 = new cjs.Shape();
	this.shape_157.graphics.f("#000000").s().p("AASAoIAAgvQABgIgCgEQgCgEgEgCQgEgCgFAAQgHAAgGAFQgHAFAAAPIAAAqIgMAAIAAhNIALAAIAAALQAJgNAPAAQAHAAAGADQAGACADAEQADAEABAGIABANIAAAvg");
	this.shape_157.setTransform(317.4,303.8);

	this.shape_158 = new cjs.Shape();
	this.shape_158.graphics.f("#000000").s().p("AgaAtQgJgLgBgUQAAgVANgKQAJgJAOABQAQAAAKAKQALAKgBASQABAPgFAJQgEAIgJAFQgJAFgKAAQgPAAgLgKgAgPgHQgHAHAAAOQAAAPAHAIQAGAHAJAAQAKAAAGgHQAHgIAAgQQAAgNgHgHQgGgHgKAAQgJAAgGAHgAgGghIAJgVIARAAIgQAVg");
	this.shape_158.setTransform(309.1,302.5);

	this.shape_159 = new cjs.Shape();
	this.shape_159.graphics.f("#000000").s().p("AgFA2IAAhNIALAAIAABNgAgFglIAAgQIALAAIAAAQg");
	this.shape_159.setTransform(303.2,302.4);

	this.shape_160 = new cjs.Shape();
	this.shape_160.graphics.f("#000000").s().p("AgXAeQgKgKAAgUQAAgLAEgKQAEgJAJgFQAJgFAJAAQAMAAAIAHQAIAGADAMIgNACQgCgIgFgEQgEgEgHAAQgJAAgGAHQgGAHAAAPQAAAPAGAIQAGAHAIAAQAIAAAFgFQAGgFABgKIANACQgCANgJAIQgJAIgNAAQgOAAgKgLg");
	this.shape_160.setTransform(298,303.9);

	this.shape_161 = new cjs.Shape();
	this.shape_161.graphics.f("#000000").s().p("AgcAiQgHgGAAgKQAAgFADgFQACgFAFgDQAEgCAFgBIAMgCQAPgCAHgDIAAgDQAAgIgDgDQgFgFgKAAQgJAAgEADQgFAEgCAIIgNgCQACgIAEgFQAEgFAIgDQAHgDAKAAQAJAAAHADQAGACADADQADAEABAFIABANIAAAQQAAATABAEQAAAFADAFIgOAAQgCgEgBgGQgHAGgHADQgFADgIAAQgNAAgHgHgAgCAFIgMACQgDACgCADQgCACAAAEQAAAFAEAEQAEADAIAAQAHAAAFgDQAGgDADgGQACgFAAgIIAAgFQgHADgNACg");
	this.shape_161.setTransform(289.8,303.9);

	this.shape_162 = new cjs.Shape();
	this.shape_162.graphics.f("#000000").s().p("AghA3IAAhrIAMAAIAAAKQAEgGAGgDQAFgDAHAAQAKAAAHAFQAIAFAEAKQAEAJAAALQAAAMgFAJQgEAJgIAFQgIAGgJAAQgGAAgFgDQgFgDgEgEIAAAmgAgOgkQgHAIAAAPQAAAOAGAHQAGAIAJAAQAIAAAGgIQAGgHAAgPQAAgPgGgHQgGgHgIAAQgIAAgGAHg");
	this.shape_162.setTransform(281.7,305.3);

	this.shape_163 = new cjs.Shape();
	this.shape_163.graphics.f("#000000").s().p("AgFA2IAAhNIALAAIAABNgAgFglIAAgQIALAAIAAAQg");
	this.shape_163.setTransform(275.7,302.4);

	this.shape_164 = new cjs.Shape();
	this.shape_164.graphics.f("#000000").s().p("AgXAeQgKgKAAgUQAAgLAEgKQAEgJAJgFQAJgFAJAAQAMAAAIAHQAIAGADAMIgNACQgCgIgFgEQgEgEgHAAQgJAAgGAHQgGAHAAAPQAAAPAGAIQAGAHAIAAQAIAAAFgFQAGgFABgKIANACQgCANgJAIQgJAIgNAAQgOAAgKgLg");
	this.shape_164.setTransform(270.5,303.9);

	this.shape_165 = new cjs.Shape();
	this.shape_165.graphics.f("#000000").s().p("AgGA2IAAhNIAMAAIAABNgAgGglIAAgQIAMAAIAAAQg");
	this.shape_165.setTransform(264.8,302.4);

	this.shape_166 = new cjs.Shape();
	this.shape_166.graphics.f("#000000").s().p("AgBAzQgEgDgCgDQgBgEAAgMIAAgsIgKAAIAAgKIAKAAIAAgTIAMgIIAAAbIANAAIAAAKIgNAAIAAAtIABAHIACADIAEAAIAGAAIACAMIgKABQgHAAgDgCg");
	this.shape_166.setTransform(261.2,302.6);

	this.shape_167 = new cjs.Shape();
	this.shape_167.graphics.f("#000000").s().p("AgUAoIAAhNIAMAAIAAAMQAEgJAEgCQADgDAFAAQAGAAAHAEIgEANQgFgDgFAAQgEAAgDACQgDADgCAFQgCAHAAAIIAAAog");
	this.shape_167.setTransform(257.1,303.8);

	this.shape_168 = new cjs.Shape();
	this.shape_168.graphics.f("#000000").s().p("AgcAiQgHgGAAgKQAAgFADgFQACgFAFgDQAEgCAFgBIAMgCQAPgCAHgDIAAgDQAAgIgDgDQgFgFgKAAQgJAAgEADQgFAEgCAIIgNgCQACgIAEgFQAEgFAIgDQAHgDAKAAQAJAAAHADQAGACADADQADAEABAFIABANIAAAQQAAATABAEQAAAFADAFIgOAAQgCgEgBgGQgHAGgHADQgFADgIAAQgNAAgHgHgAgCAFIgMACQgDACgCADQgCACAAAEQAAAFAEAEQAEADAIAAQAHAAAFgDQAGgDADgGQACgFAAgIIAAgFQgHADgNACg");
	this.shape_168.setTransform(249.8,303.9);

	this.shape_169 = new cjs.Shape();
	this.shape_169.graphics.f("#000000").s().p("AghA3IAAhrIAMAAIAAAKQAEgGAGgDQAFgDAHAAQAKAAAHAFQAIAFAEAKQAEAJAAALQAAAMgFAJQgEAJgIAFQgIAGgJAAQgGAAgFgDQgFgDgEgEIAAAmgAgOgkQgHAIAAAPQAAAOAGAHQAGAIAJAAQAIAAAGgIQAGgHAAgPQAAgPgGgHQgGgHgIAAQgIAAgGAHg");
	this.shape_169.setTransform(241.7,305.3);

	this.shape_170 = new cjs.Shape();
	this.shape_170.graphics.f("#000000").s().p("AgQAlQgHgCgCgEQgDgFgCgFIgBgNIAAgvIAOAAIAAArIABANQABAGAEACQAEADAGAAQAFAAAFgDQAFgDADgFQACgFAAgKIAAgpIAMAAIAABNIgLAAIAAgMQgJAOgPAAQgHAAgFgDg");
	this.shape_170.setTransform(228.9,304);

	this.shape_171 = new cjs.Shape();
	this.shape_171.graphics.f("#000000").s().p("AgBAzQgEgDgCgDQgBgEAAgMIAAgsIgKAAIAAgKIAKAAIAAgTIAMgIIAAAbIANAAIAAAKIgNAAIAAAtIABAHIACADIAEAAIAGAAIACAMIgKABQgHAAgDgCg");
	this.shape_171.setTransform(222.8,302.6);

	this.shape_172 = new cjs.Shape();
	this.shape_172.graphics.f("#000000").s().p("AgUAoIAAhNIAMAAIAAAMQAEgJAEgCQADgDAFAAQAGAAAHAEIgEANQgFgDgFAAQgEAAgDACQgDADgCAFQgCAHAAAIIAAAog");
	this.shape_172.setTransform(214.6,303.8);

	this.shape_173 = new cjs.Shape();
	this.shape_173.graphics.f("#000000").s().p("AgZAeQgLgKABgUQgBgVAMgKQALgJANAAQAQAAAKALQALAKAAATQgBAOgEAIQgEAJgJAFQgJAFgKAAQgPAAgKgLgAgQgVQgGAHAAAOQAAAPAGAHQAHAIAJAAQAKAAAHgIQAGgHAAgPQAAgOgGgHQgIgIgJAAQgJAAgHAIg");
	this.shape_173.setTransform(207.3,303.9);

	this.shape_174 = new cjs.Shape();
	this.shape_174.graphics.f("#000000").s().p("AghA3IAAhrIAMAAIAAAKQAEgGAGgDQAFgDAHAAQAKAAAHAFQAIAFAEAKQAEAJAAALQAAAMgFAJQgEAJgIAFQgIAGgJAAQgGAAgFgDQgFgDgEgEIAAAmgAgOgkQgHAIAAAPQAAAOAGAHQAGAIAJAAQAIAAAGgIQAGgHAAgPQAAgPgGgHQgGgHgIAAQgIAAgGAHg");
	this.shape_174.setTransform(199.2,305.3);

	this.shape_175 = new cjs.Shape();
	this.shape_175.graphics.f("#000000").s().p("AgVAiQgIgGgCgMIANgDQABAIAFAEQAFAFAIAAQAJAAAFgEQAEgEAAgFQAAgEgEgDIgNgEQgOgEgGgCQgFgCgDgFQgDgFAAgFQAAgGACgEQADgEAEgDQADgDAFgBQAGgCAGAAQAIAAAHADQAHACADAFQADAEACAIIgNACQgBgGgEgEQgFgDgHAAQgIAAgEADQgEADAAAEQAAABAAAAQAAABAAABQAAAAABABQAAAAAAABIAFADIALAEQAOADAGADQAFABADAFQADAEAAAHQAAAGgDAGQgEAGgHADQgIAEgJAAQgOAAgIgHg");
	this.shape_175.setTransform(186.8,303.9);

	this.shape_176 = new cjs.Shape();
	this.shape_176.graphics.f("#000000").s().p("AgcAiQgHgGAAgKQAAgFADgFQACgFAFgDQAEgCAFgBIAMgCQAPgCAHgDIAAgDQAAgIgDgDQgFgFgKAAQgJAAgEADQgFAEgCAIIgNgCQACgIAEgFQAEgFAIgDQAHgDAKAAQAJAAAHADQAGACADADQADAEABAFIABANIAAAQQAAATABAEQAAAFADAFIgOAAQgCgEgBgGQgHAGgHADQgFADgIAAQgNAAgHgHgAgCAFIgMACQgDACgCADQgCACAAAEQAAAFAEAEQAEADAIAAQAHAAAFgDQAGgDADgGQACgFAAgIIAAgFQgHADgNACg");
	this.shape_176.setTransform(178.9,303.9);

	this.shape_177 = new cjs.Shape();
	this.shape_177.graphics.f("#000000").s().p("AgGA2IAAhNIANAAIAABNgAgGglIAAgQIANAAIAAAQg");
	this.shape_177.setTransform(173.1,302.4);

	this.shape_178 = new cjs.Shape();
	this.shape_178.graphics.f("#000000").s().p("AgXAeQgKgKAAgUQAAgLAEgKQAEgJAJgFQAJgFAJAAQAMAAAIAHQAIAGADAMIgNACQgCgIgFgEQgEgEgHAAQgJAAgGAHQgGAHAAAPQAAAPAGAIQAGAHAIAAQAIAAAFgFQAGgFABgKIANACQgCANgJAIQgJAIgNAAQgOAAgKgLg");
	this.shape_178.setTransform(167.9,303.9);

	this.shape_179 = new cjs.Shape();
	this.shape_179.graphics.f("#000000").s().p("AgcAiQgHgGAAgKQAAgFADgFQACgFAFgDQAEgCAFgBIAMgCQAPgCAHgDIAAgDQAAgIgDgDQgFgFgKAAQgJAAgEADQgFAEgCAIIgNgCQACgIAEgFQAEgFAIgDQAHgDAKAAQAJAAAHADQAGACADADQADAEABAFIABANIAAAQQAAATABAEQAAAFADAFIgOAAQgCgEgBgGQgHAGgHADQgFADgIAAQgNAAgHgHgAgCAFIgMACQgDACgCADQgCACAAAEQAAAFAEAEQAEADAIAAQAHAAAFgDQAGgDADgGQACgFAAgIIAAgFQgHADgNACg");
	this.shape_179.setTransform(159.7,303.9);

	this.shape_180 = new cjs.Shape();
	this.shape_180.graphics.f("#000000").s().p("AgUAoIAAhNIAMAAIAAAMQAEgJAEgCQADgDAFAAQAGAAAHAEIgEANQgFgDgFAAQgEAAgDACQgDADgCAFQgCAHAAAIIAAAog");
	this.shape_180.setTransform(153.7,303.8);

	this.shape_181 = new cjs.Shape();
	this.shape_181.graphics.f("#000000").s().p("AgXAwQgNgGgGgNQgHgNAAgQQAAgPAHgNQAGgNANgHQAMgGAPAAQAMAAAJADQAJAEAGAGQAFAIADAKIgNAEQgCgJgEgEQgDgFgHgCQgHgEgIAAQgJAAgHAEQgHADgEAEQgFAFgCAGQgEAKAAALQAAAOAFAKQAFAJAJAFQAKAEAJABQAKgBAIgDQAJgDAFgEIAAgVIggAAIAAgLIAuAAIAAAmQgLAJgLAEQgLAFgMgBQgPABgNgIg");
	this.shape_181.setTransform(144.7,302.5);

	this.shape_182 = new cjs.Shape();
	this.shape_182.graphics.f("#000000").s().p("AgHAqIAAgRIAPAAIAAARgAgHgZIAAgPIAPAAIAAAPg");
	this.shape_182.setTransform(234.5,265.3);

	this.shape_183 = new cjs.Shape();
	this.shape_183.graphics.f("#000000").s().p("AgeAkQgHgGAAgLQAAgFACgGQADgEAFgEQAFgCAFgBIAMgCQARgDAHgCIAAgEQAAgJgDgDQgGgFgKABQgKgBgEAEQgFADgCAJIgOgCQACgIAFgGQADgFAJgDQAIgDAJgBQALAAAHADQAGACADAEQAEAEABAGIABANIAAARQAAAUABAGIADAKIgOAAIgEgKQgHAGgHADQgHACgIAAQgNABgIgIgAgCAFIgNADQgDABgCAEQgCADAAADQAAAGAEADQAFAFAHAAQAIgBAGgDQAHgEADgGQABgEAAgKIAAgFQgHADgOACg");
	this.shape_183.setTransform(227.8,265.3);

	this.shape_184 = new cjs.Shape();
	this.shape_184.graphics.f("#000000").s().p("AgVArIAAhSIAMAAIAAAMQAFgJAEgCQADgDAFgBQAHAAAIAFIgGANQgEgDgGAAQgEAAgDADQgDADgCAEQgDAIAAAJIAAArg");
	this.shape_184.setTransform(221.3,265.2);

	this.shape_185 = new cjs.Shape();
	this.shape_185.graphics.f("#000000").s().p("AgbAgQgLgLAAgVQAAgWANgLQALgKAOAAQARAAALAMQALALAAAUQAAAPgFAJQgFAJgJAGQgJAEgLAAQgQAAgLgLgAgRgXQgGAIAAAPQAAAQAGAIQAHAIAKAAQAKAAAHgIQAHgIAAgQQAAgPgHgHQgHgJgKABQgKAAgHAHg");
	this.shape_185.setTransform(213.5,265.3);

	this.shape_186 = new cjs.Shape();
	this.shape_186.graphics.f("#000000").s().p("AAUA5IAAg0QAAgKgFgFQgEgEgJAAQgFAAgFADQgGADgCAGQgDAEAAAKIAAAtIgOAAIAAhxIAOAAIAAApQAKgMAOAAQAJAAAHAEQAHAEADAGQADAGAAAMIAAA0g");
	this.shape_186.setTransform(204.6,263.7);

	this.shape_187 = new cjs.Shape();
	this.shape_187.graphics.f("#000000").s().p("AgeA5IgBgNIAIABQAFAAADgCIAEgEIAFgLIABgDIgghSIAPAAIARAwIAGASIAFgSIASgwIAOAAIggBTQgEAOgDAFQgDAHgFADQgFADgHAAIgJgBg");
	this.shape_187.setTransform(191.8,267);

	this.shape_188 = new cjs.Shape();
	this.shape_188.graphics.f("#000000").s().p("AgeAkQgHgGAAgLQAAgFACgGQADgEAFgEQAEgCAGgBIANgCQAQgDAHgCIAAgEQAAgJgDgDQgGgFgKABQgKgBgEAEQgFADgCAJIgOgCQACgIAFgGQADgFAJgDQAIgDAJgBQALAAAHADQAGACADAEQAEAEABAGIABANIAAARQAAAUAAAGIAEAKIgOAAIgEgKQgHAGgHADQgHACgIAAQgNABgIgIgAgCAFIgNADQgDABgCAEQgCADAAADQAAAGAEADQAFAFAHAAQAHgBAHgDQAGgEADgGQACgEAAgKIAAgFQgHADgOACg");
	this.shape_188.setTransform(178.8,265.3);

	this.shape_189 = new cjs.Shape();
	this.shape_189.graphics.f("#000000").s().p("AAUA5IAAg0QAAgKgFgFQgEgEgJAAQgFAAgFADQgGADgCAGQgDAEAAAKIAAAtIgOAAIAAhxIAOAAIAAApQAKgMAOAAQAJAAAHAEQAHAEADAGQADAGAAAMIAAA0g");
	this.shape_189.setTransform(169.9,263.7);

	this.shape_190 = new cjs.Shape();
	this.shape_190.graphics.f("#000000").s().p("AgZAhQgKgMAAgVQAAgMAEgKQAFgLAJgFQAJgEAKgBQANABAIAGQAJAIADAMIgOACQgCgIgFgFQgFgEgHAAQgJAAgHAIQgHAIAAAPQAAARAGAHQAHAIAKAAQAHAAAGgGQAFgEACgLIAOACQgCAOgKAIQgJAJgNgBQgQABgLgLg");
	this.shape_190.setTransform(161.8,265.3);

	this.shape_191 = new cjs.Shape();
	this.shape_191.graphics.f("#000000").s().p("AgbAgQgKgLAAgVQAAgTAKgMQALgMAQAAQARAAALAMQAKALAAAUIAAAEIg9AAQABANAHAIQAHAHAJAAQAIAAAFgEQAGgEADgJIAPABQgEAOgJAGQgJAIgPgBQgRAAgLgLgAgPgZQgGAHgBALIAtAAQgBgLgEgEQgHgJgKAAQgJAAgHAGg");
	this.shape_191.setTransform(153,265.3);

	this.shape_192 = new cjs.Shape();
	this.shape_192.graphics.f("#000000").s().p("AgmA5IAAhxIBNAAIAAANIg9AAIAAAkIA0AAIAAAMIg0AAIAAA0g");
	this.shape_192.setTransform(144,263.7);

	this.shape_193 = new cjs.Shape();
	this.shape_193.graphics.f("#000000").s().p("AgHApIAAgPIAPAAIAAAPgAgHgZIAAgQIAPAAIAAAQg");
	this.shape_193.setTransform(222.9,225.3);

	this.shape_194 = new cjs.Shape();
	this.shape_194.graphics.f("#000000").s().p("AAUAqIAAgxQAAgIgCgFQgCgEgEgCQgEgDgGAAQgIAAgGAGQgHAFAAAQIAAAsIgOAAIAAhSIANAAIAAANQAJgOAQgBQAIAAAGADQAGADAEAEQADAFABAGIABAOIAAAxg");
	this.shape_194.setTransform(216.2,225.2);

	this.shape_195 = new cjs.Shape();
	this.shape_195.graphics.f("#000000").s().p("AgbAvQgLgLAAgVQAAgWANgLQALgJAOgBQARABALALQALALAAATQAAAQgFAJQgFAJgJAFQgJAFgLABQgQAAgLgMgAgRgIQgGAIAAAPQAAAQAGAIQAHAIAKAAQAKAAAHgIQAHgIAAgQQAAgPgHgIQgHgHgKgBQgKAAgHAIgAgHgkIAKgVIASAAIgRAVg");
	this.shape_195.setTransform(207.3,223.8);

	this.shape_196 = new cjs.Shape();
	this.shape_196.graphics.f("#000000").s().p("AgGA5IAAhSIANAAIAABSgAgGgoIAAgQIANAAIAAAQg");
	this.shape_196.setTransform(201.1,223.7);

	this.shape_197 = new cjs.Shape();
	this.shape_197.graphics.f("#000000").s().p("AgZAgQgKgLAAgUQAAgNAEgKQAFgLAJgEQAJgGAJAAQAOAAAJAIQAJAHABAMIgNACQgCgJgFgDQgFgFgHAAQgJAAgHAIQgHAHAAAQQAAARAHAHQAGAIAJAAQAJAAAFgFQAGgGABgKIAOACQgCAOgKAJQgJAHgOABQgPAAgLgMg");
	this.shape_197.setTransform(195.6,225.3);

	this.shape_198 = new cjs.Shape();
	this.shape_198.graphics.f("#000000").s().p("AgeAlQgHgHAAgLQAAgFACgFQADgGAFgCQAFgCAFgCIAMgDQARgCAHgCIAAgEQAAgIgDgEQgGgFgKAAQgKAAgEAEQgFADgCAJIgOgCQACgIAFgGQADgFAJgEQAIgDAJAAQALABAHACQAGADADADQAEAEABAGIABANIAAASQAAATABAFIADAKIgOAAIgEgKQgHAHgHACQgHAEgIAAQgNgBgIgGgAgCAFIgNADQgDABgCADQgCADAAAEQAAAGAEADQAFAEAHAAQAIAAAGgDQAHgEADgGQABgEAAgKIAAgFQgHADgOACg");
	this.shape_198.setTransform(186.8,225.3);

	this.shape_199 = new cjs.Shape();
	this.shape_199.graphics.f("#000000").s().p("AgZAgQgKgLAAgUQAAgNAEgKQAFgLAJgEQAJgGAKAAQANAAAIAIQAKAHABAMIgNACQgCgJgFgDQgFgFgHAAQgKAAgGAIQgHAHAAAQQAAARAHAHQAGAIAKAAQAHAAAGgFQAFgGACgKIAOACQgCAOgKAJQgJAHgNABQgRAAgKgMg");
	this.shape_199.setTransform(178.7,225.3);

	this.shape_200 = new cjs.Shape();
	this.shape_200.graphics.f("#000000").s().p("AgGA5IAAhSIANAAIAABSgAgGgoIAAgQIANAAIAAAQg");
	this.shape_200.setTransform(172.6,223.7);

	this.shape_201 = new cjs.Shape();
	this.shape_201.graphics.f("#000000").s().p("AgLA6IAAhHIgMAAIAAgLIAMAAIAAgJQAAgIACgEQACgFAFgEQAEgDAJAAIANABIgCAMIgIAAQgHAAgCACQgDADAAAIIAAAHIAQAAIAAALIgQAAIAABHg");
	this.shape_201.setTransform(169,223.6);

	this.shape_202 = new cjs.Shape();
	this.shape_202.graphics.f("#000000").s().p("AgGA5IAAhSIANAAIAABSgAgGgoIAAgQIANAAIAAAQg");
	this.shape_202.setTransform(164.6,223.7);

	this.shape_203 = new cjs.Shape();
	this.shape_203.graphics.f("#000000").s().p("AgGA5IAAhxIANAAIAABxg");
	this.shape_203.setTransform(161,223.7);

	this.shape_204 = new cjs.Shape();
	this.shape_204.graphics.f("#000000").s().p("AgeAlQgHgHAAgLQAAgFADgFQADgGAEgCQAFgCAFgCIANgDQAPgCAJgCIAAgEQAAgIgFgEQgFgFgKAAQgJAAgFAEQgFADgCAJIgOgCQACgIAEgGQAFgFAIgEQAIgDAKAAQAKABAHACQAGADAEADQADAEABAGIAAANIAAASQAAATABAFIAEAKIgPAAIgCgKQgIAHgIACQgFAEgJAAQgOgBgHgGgAgDAFIgLADQgFABgCADQgBADAAAEQAAAGAEADQAEAEAJAAQAGAAAHgDQAGgEADgGQADgEAAgKIAAgFQgIADgPACg");
	this.shape_204.setTransform(154.8,225.3);

	this.shape_205 = new cjs.Shape();
	this.shape_205.graphics.f("#000000").s().p("AgaA0QgLgIgHgOQgFgOAAgQQAAgSAGgNQAHgNANgHQANgHAOAAQAQAAANAJQALAIAFAQIgPAEQgEgNgHgGQgJgFgLAAQgMAAgJAGQgJAGgDALQgEALAAALQAAAOAFALQAEAKAIAGQAJAFAKAAQANAAAJgHQAJgHACgPIAQAEQgFATgMAJQgNAKgRAAQgSAAgMgHg");
	this.shape_205.setTransform(144.7,223.7);

	this.shape_206 = new cjs.Shape();
	this.shape_206.graphics.f("#000000").s().p("AgHApIAAgQIAPAAIAAAQgAgHgYIAAgQIAPAAIAAAQg");
	this.shape_206.setTransform(198.1,185.3);

	this.shape_207 = new cjs.Shape();
	this.shape_207.graphics.f("#000000").s().p("AgbAgQgKgLAAgVQAAgTAKgMQALgMAQABQARgBALAMQAKALAAAUIAAAEIg9AAQABAOAHAGQAHAIAJAAQAIAAAFgEQAGgFADgIIAPABQgEAOgJAGQgJAIgPgBQgRAAgLgLgAgPgYQgGAGgBALIAtAAQgBgLgEgEQgHgJgKAAQgJAAgHAHg");
	this.shape_207.setTransform(191.3,185.3);

	this.shape_208 = new cjs.Shape();
	this.shape_208.graphics.f("#000000").s().p("AgVAqIAAhRIAMAAIAAAMQAFgJAEgCQADgDAFAAQAHgBAIAFIgGANQgEgDgGAAQgEAAgDADQgDACgCAFQgDAIAAAJIAAAqg");
	this.shape_208.setTransform(184.9,185.2);

	this.shape_209 = new cjs.Shape();
	this.shape_209.graphics.f("#000000").s().p("AgWAuIAAAKIgNAAIAAhxIAOAAIAAApQAJgMANAAQAIAAAGAEQAHADAEAFQAFAGACAIQADAHAAAJQAAAVgLALQgKAMgPAAQgNAAgJgMgAgPgIQgHAIAAAOQAAAPAEAHQAGALAMAAQAIAAAHgIQAGgIABgQQgBgQgGgHQgHgIgIAAQgIAAgHAIg");
	this.shape_209.setTransform(177.3,183.8);

	this.shape_210 = new cjs.Shape();
	this.shape_210.graphics.f("#000000").s().p("AAqAqIAAgzQAAgIgBgEQgBgDgEgDQgEgCgFAAQgIAAgGAGQgGAGAAANIAAAuIgNAAIAAg0QAAgKgDgFQgEgEgIAAQgGAAgFADQgFADgCAGQgCAGAAALIAAAqIgOAAIAAhRIAMAAIAAALQAEgGAHgEQAGgDAJAAQAJAAAGADQAFAEACAHQAKgOAQAAQAMAAAHAGQAGAIAAAOIAAA3g");
	this.shape_210.setTransform(166,185.2);

	this.shape_211 = new cjs.Shape();
	this.shape_211.graphics.f("#000000").s().p("AgbAgQgLgLAAgVQAAgWANgLQALgKAOABQARgBALAMQALALAAAUQAAAPgFAJQgFAJgJAGQgJAEgLAAQgQAAgLgLgAgRgXQgGAIAAAPQAAAQAGAIQAHAIAKAAQAKAAAHgIQAHgIAAgQQAAgPgHgHQgHgJgKABQgKAAgHAHg");
	this.shape_211.setTransform(154.8,185.3);

	this.shape_212 = new cjs.Shape();
	this.shape_212.graphics.f("#000000").s().p("AAeA5Ig8hZIAABZIgOAAIAAhxIAPAAIA8BZIAAhZIAOAAIAABxg");
	this.shape_212.setTransform(144.6,183.7);

	this.shape_213 = new cjs.Shape();
	this.shape_213.graphics.f("#000000").s().p("AgHAqIAAgQIAPAAIAAAQgAgHgZIAAgQIAPAAIAAAQg");
	this.shape_213.setTransform(186.4,148.5);

	this.shape_214 = new cjs.Shape();
	this.shape_214.graphics.f("#000000").s().p("AgbAgQgLgLAAgVQAAgWANgLQALgKAOAAQARAAALAMQALALAAAUQAAAPgFAJQgFAJgJAFQgJAGgLAAQgQAAgLgMgAgRgXQgGAIAAAPQAAAQAGAIQAHAIAKAAQAKAAAHgIQAHgIAAgQQAAgPgHgIQgHgHgKgBQgKAAgHAIg");
	this.shape_214.setTransform(179.6,148.5);

	this.shape_215 = new cjs.Shape();
	this.shape_215.graphics.f("#000000").s().p("AgWAkQgJgGgDgNIAPgCQABAIAFAEQAFAFAJAAQAJAAAFgEQAFgEAAgFQAAgFgEgDQgDgCgMgCQgOgFgGgCQgGgDgDgFQgDgEAAgGQAAgGADgEQACgGAEgCQADgDAGgCQAGgCAHAAQAIAAAIADQAHADADAFQAEAFABAIIgOACQgBgGgEgEQgEgEgIAAQgKAAgDAEQgFADAAAEIACAFIAGAEIALADQAPAEAGADQAGABADAFQADAFAAAHQAAAHgDAGQgFAHgIADQgIADgJABQgPAAgIgIg");
	this.shape_215.setTransform(171.2,148.5);

	this.shape_216 = new cjs.Shape();
	this.shape_216.graphics.f("#000000").s().p("AgWArIAAhTIANAAIAAANQAFgIAEgEQADgDAFAAQAHABAHAEIgFANQgEgDgGAAQgFAAgCADQgDADgCAFQgCAHAAAJIAAArg");
	this.shape_216.setTransform(165.2,148.4);

	this.shape_217 = new cjs.Shape();
	this.shape_217.graphics.f("#000000").s().p("AgSAnQgGgCgDgEQgDgFgCgGIgBgNIAAgzIAPAAIAAAtIAAAPQACAGAEADQAEADAHAAQAFAAAGgDQAFgDACgGQADgFAAgLIAAgsIAOAAIAABTIgNAAIAAgNQgKAOgPABQgHAAgHgEg");
	this.shape_217.setTransform(157.3,148.6);

	this.shape_218 = new cjs.Shape();
	this.shape_218.graphics.f("#000000").s().p("AgaA0QgMgIgFgOQgHgOAAgQQAAgSAIgNQAGgNANgHQAMgHAOAAQARAAAMAJQAMAIAFAQIgPAEQgEgNgIgGQgHgFgMAAQgMAAgJAGQgJAGgEALQgDALAAALQAAAOAEALQAFAKAJAGQAJAFAJAAQANAAAIgHQAJgHAEgPIAOAEQgEATgNAJQgMAKgSAAQgRAAgMgHg");
	this.shape_218.setTransform(147.3,146.9);

	this.fecha = new cjs.Text("", "20px 'Arial'");
	this.fecha.name = "fecha";
	this.fecha.textAlign = "center";
	this.fecha.lineHeight = 24;
	this.fecha.lineWidth = 376;
	this.fecha.parent = this;
	this.fecha.setTransform(433.6,249.4);

	this.cal = new cjs.Text("", "20px 'Arial'");
	this.cal.name = "cal";
	this.cal.textAlign = "center";
	this.cal.lineHeight = 24;
	this.cal.lineWidth = 376;
	this.cal.parent = this;
	this.cal.setTransform(433.6,210);

	this.nombre = new cjs.Text("", "20px 'Arial'");
	this.nombre.name = "nombre";
	this.nombre.textAlign = "center";
	this.nombre.lineHeight = 24;
	this.nombre.lineWidth = 376;
	this.nombre.parent = this;
	this.nombre.setTransform(433.6,169.7);

	this.curso = new cjs.Text("", "20px 'Arial'");
	this.curso.name = "curso";
	this.curso.textAlign = "center";
	this.curso.lineHeight = 24;
	this.curso.lineWidth = 376;
	this.curso.parent = this;
	this.curso.setTransform(433.6,129.1);

	this.shape_219 = new cjs.Shape();
	this.shape_219.graphics.f("#000000").s().p("AgGA2IAAhrIANAAIAABrg");
	this.shape_219.setTransform(508.6,73.3);

	this.shape_220 = new cjs.Shape();
	this.shape_220.graphics.f("#000000").s().p("AgcAiQgHgGAAgKQAAgFADgFQACgFAFgDQAEgCAFgBIAMgCQAPgCAHgDIAAgDQAAgIgDgDQgFgFgKAAQgJAAgEADQgFAEgCAIIgNgCQACgIAEgFQAEgFAIgDQAHgDAKAAQAJAAAHADQAGACADADQADAEABAFIABANIAAAQQAAATABAEQAAAFADAFIgOAAQgCgEgBgGQgHAGgHADQgFADgIAAQgNAAgHgHgAgCAFIgMACQgDACgCADQgCACAAAEQAAAFAEAEQAEADAIAAQAHAAAFgDQAGgDADgGQACgFAAgIIAAgFQgHADgNACg");
	this.shape_220.setTransform(502.8,74.8);

	this.shape_221 = new cjs.Shape();
	this.shape_221.graphics.f("#000000").s().p("AgBAzQgEgDgCgDQgBgEAAgMIAAgrIgKAAIAAgLIAKAAIAAgTIAMgIIAAAbIANAAIAAALIgNAAIAAAsIAAAHIADADIAEAAIAGAAIACAMIgKABQgHAAgDgCg");
	this.shape_221.setTransform(496.7,73.5);

	this.shape_222 = new cjs.Shape();
	this.shape_222.graphics.f("#000000").s().p("AASAoIAAgvQAAgIgBgEQgBgEgEgCQgFgCgFAAQgHAAgGAFQgHAFAAAPIAAAqIgMAAIAAhNIALAAIAAALQAJgNAPAAQAHAAAGADQAGACADAEQACAEACAGIABANIAAAvg");
	this.shape_222.setTransform(490.3,74.7);

	this.shape_223 = new cjs.Shape();
	this.shape_223.graphics.f("#000000").s().p("AgZAeQgKgLAAgSQAAgTAKgLQAKgLAQAAQAPAAAKALQAKAKAAATIAAADIg5AAQABANAGAHQAHAHAIAAQAIAAAFgEQAFgEADgIIAOABQgEAMgIAHQgJAHgOAAQgQAAgKgLgAgOgXQgGAGAAAKIAqAAQgBgJgEgFQgGgIgKAAQgIAAgHAGg");
	this.shape_223.setTransform(481.9,74.8);

	this.shape_224 = new cjs.Shape();
	this.shape_224.graphics.f("#000000").s().p("AATAoIAAgvQgBgIgBgEQgCgEgEgCQgDgCgGAAQgHAAgHAFQgFAFAAAPIAAAqIgOAAIAAhNIANAAIAAALQAIgNAPAAQAHAAAGADQAGACADAEQADAEABAGIAAANIAAAvg");
	this.shape_224.setTransform(473.6,74.7);

	this.shape_225 = new cjs.Shape();
	this.shape_225.graphics.f("#000000").s().p("AgFA2IAAhNIALAAIAABNgAgFglIAAgQIALAAIAAAQg");
	this.shape_225.setTransform(467.8,73.3);

	this.shape_226 = new cjs.Shape();
	this.shape_226.graphics.f("#000000").s().p("AgBAzQgEgDgCgDQgBgEAAgMIAAgrIgKAAIAAgLIAKAAIAAgTIAMgIIAAAbIANAAIAAALIgNAAIAAAsIABAHIACADIAEAAIAGAAIACAMIgKABQgHAAgDgCg");
	this.shape_226.setTransform(464.1,73.5);

	this.shape_227 = new cjs.Shape();
	this.shape_227.graphics.f("#000000").s().p("AATAoIAAgvQAAgIgCgEQgCgEgDgCQgEgCgGAAQgHAAgHAFQgFAFAAAPIAAAqIgOAAIAAhNIAMAAIAAALQAJgNAPAAQAHAAAGADQAGACADAEQACAEACAGIAAANIAAAvg");
	this.shape_227.setTransform(457.8,74.7);

	this.shape_228 = new cjs.Shape();
	this.shape_228.graphics.f("#000000").s().p("AgZAeQgLgKABgUQgBgVAMgKQALgJANAAQAQAAAKALQALAKAAATQgBAOgEAIQgEAJgJAFQgJAFgKAAQgPAAgKgLgAgPgVQgHAHAAAOQAAAPAHAHQAGAIAJAAQAKAAAHgIQAGgHAAgPQAAgOgGgHQgIgIgJAAQgJAAgGAIg");
	this.shape_228.setTransform(449.4,74.8);

	this.shape_229 = new cjs.Shape();
	this.shape_229.graphics.f("#000000").s().p("AgZAwQgKgHgGgNQgFgOgBgOQABgRAGgMQAHgNALgGQAMgGANAAQAQgBAMAJQAKAHAEAPIgNAEQgEgMgHgFQgIgFgKgBQgMAAgIAHQgIAFgEALQgDAKAAAKQAAAMAEALQAEAKAIAFQAJAFAJAAQAMAAAIgHQAJgHACgNIAPADQgFASgLAJQgNAJgQAAQgQABgMgIg");
	this.shape_229.setTransform(439.9,73.3);

	this.shape_230 = new cjs.Shape();
	this.shape_230.graphics.f("#000000").s().p("AgcAiQgHgGAAgKQAAgFADgFQACgFAFgDQAEgCAFgBIAMgCQAPgCAHgDIAAgDQAAgIgDgDQgFgFgKAAQgJAAgEADQgFAEgCAIIgNgCQACgIAEgFQAEgFAIgDQAHgDAKAAQAJAAAHADQAGACADADQADAEABAFIABANIAAAQQAAATABAEQAAAFADAFIgOAAQgCgEgBgGQgHAGgHADQgFADgIAAQgNAAgHgHgAgCAFIgMACQgDACgCADQgCACAAAEQAAAFAEAEQAEADAIAAQAHAAAFgDQAGgDADgGQACgFAAgIIAAgFQgHADgNACg");
	this.shape_230.setTransform(426,74.8);

	this.shape_231 = new cjs.Shape();
	this.shape_231.graphics.f("#000000").s().p("AgXAeQgKgKAAgUQAAgLAEgKQAEgJAJgFQAJgFAJAAQAMAAAIAHQAIAGADAMIgNACQgCgIgFgEQgEgEgHAAQgJAAgGAHQgGAHAAAPQAAAPAGAIQAGAHAIAAQAIAAAFgFQAGgFABgKIANACQgCANgJAIQgJAIgNAAQgOAAgKgLg");
	this.shape_231.setTransform(418.4,74.8);

	this.shape_232 = new cjs.Shape();
	this.shape_232.graphics.f("#000000").s().p("AgUAoIAAhNIAMAAIAAAMQAEgJAEgCQADgDAFAAQAGAAAHAEIgEANQgFgDgFAAQgEAAgDACQgDADgCAFQgCAHAAAIIAAAog");
	this.shape_232.setTransform(412.5,74.7);

	this.shape_233 = new cjs.Shape();
	this.shape_233.graphics.f("#000000").s().p("AAiA2IgNghIgsAAIgLAhIgPAAIAphrIAOAAIAsBrgAgHgVIgLAfIAjAAIgLgdIgHgWQgCAKgEAKg");
	this.shape_233.setTransform(404.4,73.3);

	this.instance = new lib.titulo();
	this.instance.parent = this;
	this.instance.setTransform(288.3,45.8,1,1,0,0,0,14.4,8.7);

	this.btn_imprimir = new lib.imprimir();
	this.btn_imprimir.parent = this;
	this.btn_imprimir.setTransform(389.4,450,1,1,0,0,0,58.5,17.3);
	new cjs.ButtonHelper(this.btn_imprimir, 0, 1, 1);

	this.shape_234 = new cjs.Shape();
	this.shape_234.graphics.f("#000000").s().p("AgGAHIAAgOIANAAIAAAOg");
	this.shape_234.setTransform(592.1,394.9);

	this.shape_235 = new cjs.Shape();
	this.shape_235.graphics.f("#000000").s().p("AgjA2IAAhrIBHAAIAAANIg5AAIAAAhIAxAAIAAAMIgxAAIAAAxg");
	this.shape_235.setTransform(585.7,390.3);

	this.shape_236 = new cjs.Shape();
	this.shape_236.graphics.f("#000000").s().p("AgsA2IAAhrIAlAAQAMAAAGACQAKACAGAGQAJAHAEALQAEALAAAOQAAAMgCAJQgEAKgEAGQgFAGgEAEQgGADgIACQgHACgJAAgAgdApIAWAAQALAAAFgCQAGgCAEgDQAFgGADgIQACgJAAgLQABgRgGgJQgFgJgJgDQgFgCgMAAIgWAAg");
	this.shape_236.setTransform(575.6,390.3);

	this.shape_237 = new cjs.Shape();
	this.shape_237.graphics.f("#000000").s().p("AgoA2IAAhrIAoAAIAQABQAIACAFADQAFAEAEAHQADAGAAAIQAAAOgIAJQgKAJgWAAIgbAAIAAAsgAgagCIAbAAQAOAAAFgFQAHgFgBgJQAAgHgDgFQgEgEgFgCIgOgBIgaAAg");
	this.shape_237.setTransform(565.3,390.3);

	this.shape_238 = new cjs.Shape();
	this.shape_238.graphics.f("#000000").s().p("AgZAeQgLgKABgUQgBgVAMgKQAKgJAOAAQAQAAAKALQAKAKAAATQAAAOgEAIQgFAJgIAFQgJAFgKAAQgPAAgKgLgAgQgVQgGAHAAAOQAAAPAGAHQAHAIAJAAQAKAAAHgIQAGgHAAgPQAAgOgGgHQgIgIgJAAQgJAAgHAIg");
	this.shape_238.setTransform(551.7,391.8);

	this.shape_239 = new cjs.Shape();
	this.shape_239.graphics.f("#000000").s().p("AgBAzQgEgCgBgEQgCgEAAgMIAAgsIgKAAIAAgKIAKAAIAAgTIAMgIIAAAbIANAAIAAAKIgNAAIAAAtIAAAHIADADIAFAAIAFAAIACAMIgKABQgHAAgDgCg");
	this.shape_239.setTransform(545.5,390.5);

	this.shape_240 = new cjs.Shape();
	this.shape_240.graphics.f("#000000").s().p("AgcAiQgHgGAAgKQAAgFADgFQACgFAFgDQAEgCAFgBIAMgCQAPgCAHgDIAAgDQAAgIgDgDQgFgFgKAAQgJAAgEADQgFAEgCAIIgNgCQACgIAEgFQAEgFAIgDQAHgDAKAAQAJAAAHADQAGACADADQADAEABAFIABANIAAAQQAAATABAEQAAAFADAFIgOAAQgCgEgBgGQgHAGgHADQgFADgIAAQgNAAgHgHgAgCAFIgMACQgDACgCADQgCACAAAEQAAAFAEAEQAEADAIAAQAHAAAFgDQAGgDADgGQACgFAAgIIAAgFQgHADgNACg");
	this.shape_240.setTransform(539.1,391.8);

	this.shape_241 = new cjs.Shape();
	this.shape_241.graphics.f("#000000").s().p("AAnAoIAAgwIgBgMQgBgDgEgCQgDgCgEAAQgJAAgFAFQgFAGAAAMIAAAsIgNAAIAAgyQAAgJgDgEQgDgEgHAAQgGAAgFADQgEACgDAGQgCAGAAAKIAAAoIgNAAIAAhNIAMAAIAAALQAEgGAGgDQAGgEAIAAQAIAAAGAEQAEADACAHQAKgOAPAAQALAAAGAHQAHAGAAANIAAA1g");
	this.shape_241.setTransform(528.8,391.7);

	this.shape_242 = new cjs.Shape();
	this.shape_242.graphics.f("#000000").s().p("AgUAoIAAhNIAMAAIAAAMQAEgJAEgCQADgDAFAAQAGAAAHAEIgEANQgFgDgFAAQgEAAgDACQgDADgCAFQgCAHAAAIIAAAog");
	this.shape_242.setTransform(520.6,391.7);

	this.shape_243 = new cjs.Shape();
	this.shape_243.graphics.f("#000000").s().p("AgZAeQgLgKABgUQgBgVAMgKQAKgJAOAAQAQAAAKALQALAKAAATQgBAOgEAIQgEAJgJAFQgJAFgKAAQgPAAgKgLgAgQgVQgGAHAAAOQAAAPAGAHQAHAIAJAAQAKAAAHgIQAGgHAAgPQAAgOgGgHQgIgIgJAAQgJAAgHAIg");
	this.shape_243.setTransform(513.3,391.8);

	this.shape_244 = new cjs.Shape();
	this.shape_244.graphics.f("#000000").s().p("AgKA2IAAhCIgMAAIAAgLIAMAAIAAgHQAAgJABgDQACgFAFgEQAEgDAIABIANAAIgCAMIgIgBQgGAAgDADQgCACAAAIIAAAGIAPAAIAAALIgPAAIAABCg");
	this.shape_244.setTransform(507.4,390.2);

	this.shape_245 = new cjs.Shape();
	this.shape_245.graphics.f("#000000").s().p("AATAoIAAgvQgBgIgBgEQgCgEgEgCQgDgCgGAAQgHAAgHAFQgFAFAAAPIAAAqIgOAAIAAhNIANAAIAAALQAIgNAPAAQAHAAAGADQAGACADAEQADAEABAGIAAANIAAAvg");
	this.shape_245.setTransform(496.7,391.7);

	this.shape_246 = new cjs.Shape();
	this.shape_246.graphics.f("#000000").s().p("AgZAeQgKgLAAgSQAAgTAKgLQAKgLAQAAQAPAAAKALQAKAKAAATIAAADIg5AAQABANAGAHQAHAHAIAAQAIAAAFgEQAFgEADgIIAOABQgEAMgIAHQgJAHgOAAQgQAAgKgLgAgOgXQgGAGAAAKIAqAAQgBgJgEgFQgGgIgKAAQgIAAgHAGg");
	this.shape_246.setTransform(488.3,391.8);

	this.shape_247 = new cjs.Shape();
	this.shape_247.graphics.f("#000000").s().p("AgZAeQgKgLAAgSQAAgTAKgLQAKgLAQAAQAPAAAKALQAKAKAAATIAAADIg5AAQABANAGAHQAHAHAIAAQAIAAAFgEQAFgEADgIIAOABQgEAMgIAHQgJAHgOAAQgQAAgKgLgAgOgXQgGAGAAAKIAqAAQgBgJgEgFQgGgIgKAAQgIAAgHAGg");
	this.shape_247.setTransform(475.8,391.8);

	this.shape_248 = new cjs.Shape();
	this.shape_248.graphics.f("#000000").s().p("AgBAzQgEgCgCgEQgBgEAAgMIAAgsIgKAAIAAgKIAKAAIAAgTIAMgIIAAAbIANAAIAAAKIgNAAIAAAtIAAAHIADADIAEAAIAGAAIACAMIgKABQgHAAgDgCg");
	this.shape_248.setTransform(469.7,390.5);

	this.shape_249 = new cjs.Shape();
	this.shape_249.graphics.f("#000000").s().p("AASAoIAAgvQAAgIgBgEQgBgEgEgCQgFgCgFAAQgHAAgGAFQgHAFAAAPIAAAqIgMAAIAAhNIALAAIAAALQAJgNAPAAQAHAAAGADQAGACADAEQACAEACAGIABANIAAAvg");
	this.shape_249.setTransform(463.3,391.7);

	this.shape_250 = new cjs.Shape();
	this.shape_250.graphics.f("#000000").s().p("AgcAiQgHgGAAgKQAAgFADgFQACgFAFgDQAEgCAFgBIAMgCQAPgCAHgDIAAgDQAAgIgDgDQgFgFgKAAQgJAAgEADQgFAEgCAIIgNgCQACgIAEgFQAEgFAIgDQAHgDAKAAQAJAAAHADQAGACADADQADAEABAFIABANIAAAQQAAATABAEQAAAFADAFIgOAAQgCgEgBgGQgHAGgHADQgFADgIAAQgNAAgHgHgAgCAFIgMACQgDACgCADQgCACAAAEQAAAFAEAEQAEADAIAAQAHAAAFgDQAGgDADgGQACgFAAgIIAAgFQgHADgNACg");
	this.shape_250.setTransform(454.9,391.8);

	this.shape_251 = new cjs.Shape();
	this.shape_251.graphics.f("#000000").s().p("AgVArIAAAKIgMAAIAAhrIANAAIAAAnQAJgLAMAAQAHAAAGADQAHADAEAFQAEAFACAIQADAGAAAJQAAAUgKALQgKALgOAAQgNAAgIgMgAgPgHQgGAHAAANQAAAOAEAGQAGALALAAQAHAAAHgIQAGgHAAgPQAAgOgGgIQgGgHgIAAQgIAAgHAIg");
	this.shape_251.setTransform(446.8,390.4);

	this.shape_252 = new cjs.Shape();
	this.shape_252.graphics.f("#000000").s().p("AgZAeQgLgKABgUQgBgVAMgKQAKgJAOAAQAQAAAKALQAKAKAAATQAAAOgEAIQgEAJgJAFQgJAFgKAAQgPAAgKgLgAgQgVQgGAHAAAOQAAAPAGAHQAHAIAJAAQAKAAAHgIQAGgHAAgPQAAgOgGgHQgIgIgJAAQgJAAgHAIg");
	this.shape_252.setTransform(438.3,391.8);

	this.shape_253 = new cjs.Shape();
	this.shape_253.graphics.f("#000000").s().p("AgUAoIAAhNIAMAAIAAAMQAEgJAEgCQADgDAFAAQAGAAAHAEIgEANQgFgDgFAAQgEAAgDACQgDADgCAFQgCAHAAAIIAAAog");
	this.shape_253.setTransform(432.2,391.7);

	this.shape_254 = new cjs.Shape();
	this.shape_254.graphics.f("#000000").s().p("AghA3IAAhrIAMAAIAAAKQAEgGAGgDQAFgDAHAAQAKAAAHAFQAIAFAEAKQAEAJAAALQAAAMgFAJQgEAJgIAFQgIAGgJAAQgGAAgFgDQgFgDgEgEIAAAmgAgOgkQgHAIAAAPQAAAOAGAHQAGAIAJAAQAIAAAGgIQAGgHAAgPQAAgPgGgHQgGgHgIAAQgIAAgGAHg");
	this.shape_254.setTransform(425.1,393.2);

	this.shape_255 = new cjs.Shape();
	this.shape_255.graphics.f("#000000").s().p("AAnAoIAAgwIgBgMQgBgDgEgCQgDgCgEAAQgJAAgFAFQgFAGAAAMIAAAsIgNAAIAAgyQAAgJgDgEQgDgEgHAAQgGAAgFADQgEACgDAGQgCAGAAAKIAAAoIgNAAIAAhNIAMAAIAAALQAEgGAGgDQAGgEAIAAQAIAAAGAEQAEADACAHQAKgOAPAAQALAAAGAHQAHAGAAANIAAA1g");
	this.shape_255.setTransform(414.5,391.7);

	this.shape_256 = new cjs.Shape();
	this.shape_256.graphics.f("#000000").s().p("AgaAeQgKgKABgUQgBgVAMgKQAKgJAOAAQAQAAAKALQAKAKAAATQAAAOgEAIQgFAJgIAFQgJAFgKAAQgPAAgLgLgAgQgVQgGAHAAAOQAAAPAGAHQAHAIAJAAQAKAAAHgIQAGgHAAgPQAAgOgGgHQgIgIgJAAQgJAAgHAIg");
	this.shape_256.setTransform(404.1,391.8);

	this.shape_257 = new cjs.Shape();
	this.shape_257.graphics.f("#000000").s().p("AgXAeQgKgKAAgUQAAgLAEgKQAEgJAJgFQAJgFAJAAQAMAAAIAHQAIAGADAMIgNACQgCgIgFgEQgEgEgHAAQgJAAgGAHQgGAHAAAPQAAAPAGAIQAGAHAIAAQAIAAAFgFQAGgFABgKIANACQgCANgJAIQgJAIgNAAQgOAAgKgLg");
	this.shape_257.setTransform(396.4,391.8);

	this.shape_258 = new cjs.Shape();
	this.shape_258.graphics.f("#000000").s().p("AgRAlQgGgCgDgEQgCgFgBgFIgBgNIAAgvIANAAIAAArIAAANQACAGAEACQAEADAGABQAFgBAFgDQAFgDACgFQACgFAAgKIAAgpIAOAAIAABNIgMAAIAAgMQgJAOgPAAQgGAAgHgDg");
	this.shape_258.setTransform(384,391.9);

	this.shape_259 = new cjs.Shape();
	this.shape_259.graphics.f("#000000").s().p("AgBAzQgEgCgBgEQgCgEAAgMIAAgsIgKAAIAAgKIAKAAIAAgTIAMgIIAAAbIANAAIAAAKIgNAAIAAAtIABAHIACADIAFAAIAFAAIACAMIgKABQgHAAgDgCg");
	this.shape_259.setTransform(377.9,390.5);

	this.shape_260 = new cjs.Shape();
	this.shape_260.graphics.f("#000000").s().p("AgcAiQgHgGAAgKQAAgFADgFQACgFAFgDQAEgCAFgBIAMgCQAPgCAHgDIAAgDQAAgIgDgDQgFgFgKAAQgJAAgEADQgFAEgCAIIgNgCQACgIAEgFQAEgFAIgDQAHgDAKAAQAJAAAHADQAGACADADQADAEABAFIABANIAAAQQAAATABAEQAAAFADAFIgOAAQgCgEgBgGQgHAGgHADQgFADgIAAQgNAAgHgHgAgCAFIgMACQgDACgCADQgCACAAAEQAAAFAEAEQAEADAIAAQAHAAAFgDQAGgDADgGQACgFAAgIIAAgFQgHADgNACg");
	this.shape_260.setTransform(367.4,391.8);

	this.shape_261 = new cjs.Shape();
	this.shape_261.graphics.f("#000000").s().p("AgQAxQgIgFgEgJQgFgJAAgMQAAgMAEgIQAEgKAIgFQAIgFAJAAQAGAAAGADQAFADAEAFIAAgnIANAAIAABrIgMAAIAAgKQgIAMgOAAQgIAAgIgGgAgNgIQgGAHAAAPQAAAPAGAHQAHAIAHAAQAJAAAGgHQAGgHAAgPQAAgPgGgHQgGgIgJAAQgIAAgGAHg");
	this.shape_261.setTransform(358.8,390.4);

	this.shape_262 = new cjs.Shape();
	this.shape_262.graphics.f("#000000").s().p("AgUAoIAAhNIAMAAIAAAMQAEgJAEgCQADgDAFAAQAGAAAHAEIgEANQgFgDgFAAQgEAAgDACQgDADgCAFQgCAHAAAIIAAAog");
	this.shape_262.setTransform(353,391.7);

	this.shape_263 = new cjs.Shape();
	this.shape_263.graphics.f("#000000").s().p("AgcAiQgHgGAAgKQAAgFADgFQACgFAFgDQAEgCAFgBIAMgCQAPgCAHgDIAAgDQAAgIgDgDQgFgFgKAAQgJAAgEADQgFAEgCAIIgNgCQACgIAEgFQAEgFAIgDQAHgDAKAAQAJAAAHADQAGACADADQADAEABAFIABANIAAAQQAAATABAEQAAAFADAFIgOAAQgCgEgBgGQgHAGgHADQgFADgIAAQgNAAgHgHgAgCAFIgMACQgDACgCADQgCACAAAEQAAAFAEAEQAEADAIAAQAHAAAFgDQAGgDADgGQACgFAAgIIAAgFQgHADgNACg");
	this.shape_263.setTransform(345.7,391.8);

	this.shape_264 = new cjs.Shape();
	this.shape_264.graphics.f("#000000").s().p("AgRAlQgFgCgEgEQgDgFAAgFIgBgNIAAgvIANAAIAAArIAAANQACAGAEACQAEADAGABQAFgBAFgDQAFgDACgFQACgFAAgKIAAgpIAOAAIAABNIgMAAIAAgMQgJAOgPAAQgGAAgHgDg");
	this.shape_264.setTransform(337.3,391.9);

	this.shape_265 = new cjs.Shape();
	this.shape_265.graphics.f("#000000").s().p("AgXAxQgIgGAAgNIANADQABAGAEACQAEADAJABQAIgBAFgDQAFgDACgIQABgDAAgNQgJAKgMAAQgQAAgJgMQgIgLAAgQQAAgLAEgJQAEgJAHgGQAIgEAKAAQANgBAJALIAAgJIAMAAIAABCQAAATgEAHQgDAIgIAEQgIAEgLAAQgOABgJgHgAgOgkQgGAGAAAOQAAAQAGAGQAGAHAIAAQAKAAAGgHQAGgGAAgPQAAgOgGgHQgHgIgJAAQgIAAgGAIg");
	this.shape_265.setTransform(328.8,393.3);

	this.shape_266 = new cjs.Shape();
	this.shape_266.graphics.f("#000000").s().p("AgaAeQgKgKAAgUQABgVALgKQALgJANAAQAQAAAKALQAKAKAAATQABAOgFAIQgFAJgIAFQgJAFgKAAQgQAAgKgLgAgQgVQgGAHAAAOQAAAPAGAHQAHAIAJAAQAKAAAGgIQAHgHAAgPQAAgOgHgHQgHgIgJAAQgJAAgHAIg");
	this.shape_266.setTransform(316.5,391.8);

	this.shape_267 = new cjs.Shape();
	this.shape_267.graphics.f("#000000").s().p("AgZAeQgKgLAAgSQAAgTAKgLQAKgLAQAAQAPAAAKALQAKAKAAATIAAADIg5AAQABANAGAHQAHAHAIAAQAIAAAFgEQAFgEADgIIAOABQgEAMgIAHQgJAHgOAAQgQAAgKgLgAgOgXQgGAGAAAKIAqAAQgBgJgEgFQgGgIgKAAQgIAAgHAGg");
	this.shape_267.setTransform(304,391.8);

	this.shape_268 = new cjs.Shape();
	this.shape_268.graphics.f("#000000").s().p("AAnAoIAAgwIgBgMQgBgDgEgCQgDgCgEAAQgJAAgFAFQgFAGAAAMIAAAsIgNAAIAAgyQAAgJgDgEQgDgEgHAAQgGAAgFADQgEACgDAGQgCAGAAAKIAAAoIgNAAIAAhNIAMAAIAAALQAEgGAGgDQAGgEAIAAQAIAAAGAEQAEADACAHQAKgOAPAAQALAAAGAHQAHAGAAANIAAA1g");
	this.shape_268.setTransform(293.6,391.7);

	this.shape_269 = new cjs.Shape();
	this.shape_269.graphics.f("#000000").s().p("AgMA2IAAhNIAMAAIAABNgAgNggIAKgVIAQAAIgPAVg");
	this.shape_269.setTransform(286,390.3);

	this.shape_270 = new cjs.Shape();
	this.shape_270.graphics.f("#000000").s().p("AgUAoIAAhNIAMAAIAAAMQAEgJAEgCQADgDAFAAQAGAAAHAEIgEANQgFgDgFAAQgEAAgDACQgDADgCAFQgCAHAAAIIAAAog");
	this.shape_270.setTransform(281.3,391.7);

	this.shape_271 = new cjs.Shape();
	this.shape_271.graphics.f("#000000").s().p("AghA3IAAhrIAMAAIAAAKQAEgGAGgDQAFgDAHAAQAKAAAHAFQAIAFAEAKQAEAJAAALQAAAMgFAJQgEAJgIAFQgIAGgJAAQgGAAgFgDQgFgDgEgEIAAAmgAgOgkQgHAIAAAPQAAAOAGAHQAGAIAJAAQAIAAAGgIQAGgHAAgPQAAgPgGgHQgGgHgIAAQgIAAgGAHg");
	this.shape_271.setTransform(274.2,393.2);

	this.shape_272 = new cjs.Shape();
	this.shape_272.graphics.f("#000000").s().p("AAnAoIAAgwIgBgMQgBgDgEgCQgDgCgEAAQgJAAgFAFQgFAGAAAMIAAAsIgNAAIAAgyQAAgJgDgEQgDgEgHAAQgGAAgFADQgEACgDAGQgCAGAAAKIAAAoIgNAAIAAhNIAMAAIAAALQAEgGAGgDQAGgEAIAAQAIAAAGAEQAEADACAHQAKgOAPAAQALAAAGAHQAHAGAAANIAAA1g");
	this.shape_272.setTransform(263.6,391.7);

	this.shape_273 = new cjs.Shape();
	this.shape_273.graphics.f("#000000").s().p("AgGA2IAAhrIANAAIAABrg");
	this.shape_273.setTransform(255.3,390.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_273},{t:this.shape_272},{t:this.shape_271},{t:this.shape_270},{t:this.shape_269},{t:this.shape_268},{t:this.shape_267},{t:this.shape_266},{t:this.shape_265},{t:this.shape_264},{t:this.shape_263},{t:this.shape_262},{t:this.shape_261},{t:this.shape_260},{t:this.shape_259},{t:this.shape_258},{t:this.shape_257},{t:this.shape_256},{t:this.shape_255},{t:this.shape_254},{t:this.shape_253},{t:this.shape_252},{t:this.shape_251},{t:this.shape_250},{t:this.shape_249},{t:this.shape_248},{t:this.shape_247},{t:this.shape_246},{t:this.shape_245},{t:this.shape_244},{t:this.shape_243},{t:this.shape_242},{t:this.shape_241},{t:this.shape_240},{t:this.shape_239},{t:this.shape_238},{t:this.shape_237},{t:this.shape_236},{t:this.shape_235},{t:this.shape_234},{t:this.btn_imprimir},{t:this.instance},{t:this.shape_233},{t:this.shape_232},{t:this.shape_231},{t:this.shape_230},{t:this.shape_229},{t:this.shape_228},{t:this.shape_227},{t:this.shape_226},{t:this.shape_225},{t:this.shape_224},{t:this.shape_223},{t:this.shape_222},{t:this.shape_221},{t:this.shape_220},{t:this.shape_219},{t:this.curso},{t:this.nombre},{t:this.cal},{t:this.fecha},{t:this.shape_218},{t:this.shape_217},{t:this.shape_216},{t:this.shape_215},{t:this.shape_214},{t:this.shape_213},{t:this.shape_212},{t:this.shape_211},{t:this.shape_210},{t:this.shape_209},{t:this.shape_208},{t:this.shape_207},{t:this.shape_206},{t:this.shape_205},{t:this.shape_204},{t:this.shape_203},{t:this.shape_202},{t:this.shape_201},{t:this.shape_200},{t:this.shape_199},{t:this.shape_198},{t:this.shape_197},{t:this.shape_196},{t:this.shape_195},{t:this.shape_194},{t:this.shape_193},{t:this.shape_192},{t:this.shape_191},{t:this.shape_190},{t:this.shape_189},{t:this.shape_188},{t:this.shape_187},{t:this.shape_186},{t:this.shape_185},{t:this.shape_184},{t:this.shape_183},{t:this.shape_182},{t:this.shape_181},{t:this.shape_180},{t:this.shape_179},{t:this.shape_178},{t:this.shape_177},{t:this.shape_176},{t:this.shape_175},{t:this.shape_174},{t:this.shape_173},{t:this.shape_172},{t:this.shape_171},{t:this.shape_170},{t:this.shape_169},{t:this.shape_168},{t:this.shape_167},{t:this.shape_166},{t:this.shape_165},{t:this.shape_164},{t:this.shape_163},{t:this.shape_162},{t:this.shape_161},{t:this.shape_160},{t:this.shape_159},{t:this.shape_158},{t:this.shape_157},{t:this.shape_156},{t:this.shape_155},{t:this.shape_154},{t:this.shape_153},{t:this.shape_152},{t:this.shape_151},{t:this.shape_150},{t:this.shape_149},{t:this.shape_148},{t:this.shape_147},{t:this.shape_146},{t:this.shape_145},{t:this.shape_144},{t:this.shape_143},{t:this.shape_142},{t:this.shape_141},{t:this.shape_140},{t:this.shape_139},{t:this.shape_138},{t:this.shape_137},{t:this.shape_136},{t:this.shape_135},{t:this.shape_134},{t:this.shape_133},{t:this.shape_132},{t:this.shape_131},{t:this.shape_130},{t:this.shape_129},{t:this.shape_128},{t:this.shape_127},{t:this.shape_126},{t:this.shape_125},{t:this.shape_124},{t:this.shape_123},{t:this.shape_122},{t:this.shape_121},{t:this.shape_120},{t:this.shape_119},{t:this.shape_118},{t:this.shape_117},{t:this.shape_116},{t:this.shape_115},{t:this.shape_114},{t:this.shape_113},{t:this.shape_112},{t:this.shape_111},{t:this.shape_110},{t:this.shape_109},{t:this.shape_108},{t:this.shape_107},{t:this.shape_106},{t:this.shape_105},{t:this.shape_104},{t:this.shape_103},{t:this.shape_102},{t:this.shape_101},{t:this.shape_100},{t:this.shape_99},{t:this.shape_98},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_94},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Certificado_Symbol, new cjs.Rectangle(136.9,13.1,779.9,455.1), null);


(lib.btn_siguiente = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_19 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(19).call(this.frame_19).wait(1));

	// Layer 5
	this.instance = new lib.traingulo();
	this.instance.parent = this;
	this.instance.setTransform(788.2,24.1);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(6).to({_off:false},0).to({x:820.7},11,cjs.Ease.get(1)).wait(3));

	// Layer 4
	this.instance_1 = new lib.traingulo();
	this.instance_1.parent = this;
	this.instance_1.setTransform(790.9,30.8,1,1,0,0,0,4.4,8.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({x:830.9,y:32.3,alpha:0.148},11,cjs.Ease.get(1)).to({_off:true},1).wait(8));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-25.5,20.4,13.9,20.8);


(lib.bntSiguiente2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		//this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(40));

	// boton
	this.instance = new lib.traingulo();
	this.instance.parent = this;
	this.instance.setTransform(830.7,4.1);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({regX:-805.1,regY:8.6,x:25.6,y:12.7,alpha:0.947},0).wait(1).to({alpha:0.895},0).wait(1).to({alpha:0.842},0).wait(1).to({alpha:0.789},0).wait(1).to({alpha:0.737},0).wait(1).to({alpha:0.684},0).wait(1).to({alpha:0.632},0).wait(1).to({alpha:0.579},0).wait(1).to({alpha:0.526},0).wait(1).to({alpha:0.474},0).wait(1).to({alpha:0.421},0).wait(1).to({alpha:0.368},0).wait(1).to({alpha:0.316},0).wait(1).to({alpha:0.263},0).wait(1).to({alpha:0.211},0).wait(1).to({alpha:0.158},0).wait(1).to({alpha:0.105},0).wait(1).to({alpha:0.053},0).wait(1).to({alpha:0},0).wait(1).to({alpha:0.05},0).wait(1).to({alpha:0.1},0).wait(1).to({alpha:0.15},0).wait(1).to({alpha:0.2},0).wait(1).to({alpha:0.25},0).wait(1).to({alpha:0.3},0).wait(1).to({alpha:0.35},0).wait(1).to({alpha:0.4},0).wait(1).to({alpha:0.45},0).wait(1).to({alpha:0.5},0).wait(1).to({alpha:0.55},0).wait(1).to({alpha:0.6},0).wait(1).to({alpha:0.65},0).wait(1).to({alpha:0.7},0).wait(1).to({alpha:0.75},0).wait(1).to({alpha:0.8},0).wait(1).to({alpha:0.85},0).wait(1).to({alpha:0.9},0).wait(1).to({alpha:0.95},0).wait(1).to({alpha:1},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(18.7,2.4,13.8,20.8);


(lib._3a5anios = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.text = new cjs.Text("Necesita desarrollar la mayoría de las competencias requeridas del siguiente nivel.", "8px 'Arial'", "#333333");
	this.text.textAlign = "center";
	this.text.lineHeight = 8;
	this.text.lineWidth = 53;
	this.text.parent = this;
	this.text.setTransform(71.2,56.2,2.067,2.067);

	this.text_1 = new cjs.Text("3 a 5 años", "bold 8px 'Arial'", "#FFFFFF");
	this.text_1.lineHeight = 10;
	this.text_1.lineWidth = 51;
	this.text_1.parent = this;
	this.text_1.setTransform(33,13.5,2.067,2.067);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F7931E").s().p("ArDDUIAAiwQAAj3D3AAIOZAAQD3AAAAD3IAACwg");
	this.shape.setTransform(70.6,21.2);

	this.instance = new lib.cajaatraslistoahora("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(73.2,114.5,2.067,2.067,0,0,0,35.4,35);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance},{t:this.shape},{t:this.text_1},{t:this.text}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.3,0,142,201.5);


(lib.reemplazodeemergencia = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.text = new cjs.Text("El colaborador está listo para ocupar alguna posición determinada en caso de emergencia.", "8px 'Arial'", "#333333");
	this.text.textAlign = "center";
	this.text.lineHeight = 8;
	this.text.lineWidth = 53;
	this.text.parent = this;
	this.text.setTransform(70.7,51.9,2.067,2.067);

	this.text_1 = new cjs.Text("Reemplazo de emergencia", "bold 8px 'Arial'", "#FFFFFF");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 8;
	this.text_1.lineWidth = 56;
	this.text_1.parent = this;
	this.text_1.setTransform(74.6,8.2,2.067,2.067);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#3FA9F5").s().p("ArEDUIAAiwQAAj3D5AAIOXAAQD5AAAAD3IAACwg");
	this.shape.setTransform(71.2,25.9);

	this.instance = new lib.cajaatraslistoahora("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(72.6,119.2,2.067,2.067,0,0,0,35.1,35);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance},{t:this.shape},{t:this.text_1},{t:this.text}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,4,142,193.2);


(lib.evalpagina13 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		/*NOTA IMPROTANTE:
		EN CADA ACTIVIDAD CON MC IGUALES, SE TIENEN QUE DUPLICAR
		NO BASTA CON CAMBIARLES LA INSTANCIA, A NIVEL CÓDIGO NO HAY DIFERENCIA
		ADEMAS DE QUE TIENEN QUE TENER INSTANCIAS DIFERENTES A LAS ANTERIORES
		*/
		this.stop();
		var root = this;
		var resp = 2;
		var correcta = 1;
		root.p13.text=("¿Cómo definimos “Readiness” en el proceso de gestión de talento en Arca Continental?");
		root.c13_op0.text=("Se refiere a la cualidad de “estar alerta”, en todo momento, para identificar oportunidades de negocio.");
		root.c13_op1.text=("Es el tiempo en que un colaborador puede estar listo para asumir una posición distinta a la actual en la organización.");
		root.c13_op2.text=("Es el potencial de desarrollo que el colaborador muestra en sus actividades cotidianas.");
		iniciar();
		
		function iniciar() {
			root.parent.parent.btn_siguiente.visible = false;
			for (var i = 0; i <= resp; i++) {
				root['c13_' + i].cursor = "pointer";
				root['c13_' + i].n = i;
				root['c13_' + i].addEventListener("click", cambios);
				root['c13_' + i].gotoAndStop(1);
			}
		}
		
		function cambios(r) {
			//Cambia el estatus de la opcion seleccionada
			for (var i = 0; i <= resp; i++) {
				if (root['c13_' + i].n != r.currentTarget.n) {
					root['c13_' + i].gotoAndStop(0);
				} else {
					root['c13_' + i].gotoAndStop(1);
				}
			}
		
			//Valida la respuesta
			if (r.currentTarget.n == correcta) {
				root.parent.parent.resultados[root.parent.parent.cont] = 10;
				console.log("Respuesta Correcta " + root.parent.parent.resultados[root.parent.parent.cont]);
			} else {
				root.parent.parent.resultados[root.parent.parent.cont] = 0;
				console.log("Respuesta Incorrecta " + root.parent.parent.resultados[root.parent.parent.cont]);
			}
			root.parent.parent.activarSiguiente();
			root.parent.parent.registrar_pregunta(root.p13.text, root['c13_op'+r.currentTarget.n].text, root['c13_op'+correcta].text);
		
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.instance = new lib.listoahora("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(72.3,260.9,0.483,0.483,0,0,0,71.1,91.4);

	this.instance_1 = new lib.unodosanios("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(145.8,265.4,0.483,0.483,0,0,0,72.5,100.8);

	this.instance_2 = new lib._3a5anios("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(219.6,265.4,0.483,0.483,0,0,0,72.8,100.8);

	this.instance_3 = new lib.nohaysucesor("synched",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(294.4,265.4,0.483,0.483,0,0,0,72.7,100.8);

	this.instance_4 = new lib.reemplazodeemergencia("synched",0);
	this.instance_4.parent = this;
	this.instance_4.setTransform(368.6,262.1,0.483,0.483,0,0,0,72.5,98.6);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("rgba(102,218,255,0.6)").ss(1,1,1).p("AAAgjIAABI");
	this.shape.setTransform(419.4,315.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(255,255,255,0.498)").s().p("A8nLMQiUAAAAiTIAAxwQAAiUCUAAMA5QAAAQCTAAAACUIAAQnIAABJQAACTiTAAg");
	this.shape_1.setTransform(221.3,261.9);

	this.c13_2 = new lib.mc_radioButton13();
	this.c13_2.parent = this;
	this.c13_2.setTransform(529.9,341.2,1,1,0,0,0,18,18.1);

	this.c13_1 = new lib.mc_radioButton13();
	this.c13_1.parent = this;
	this.c13_1.setTransform(529.9,255.5,1,1,0,0,0,18,18.1);

	this.c13_op0 = new cjs.Text("Se refiere a la cualidad de “estar alerta”, en todo momento, para identificar oportunidades de negocio.", "16px 'Arial'", "#333333");
	this.c13_op0.name = "c13_op0";
	this.c13_op0.lineHeight = 18;
	this.c13_op0.lineWidth = 346;
	this.c13_op0.parent = this;
	this.c13_op0.setTransform(552.3,158.8);

	this.c13_op2 = new cjs.Text("Es el potencial de desarrollo que el colaborador muestra en sus actividades cotidianas.", "16px 'Arial'", "#333333");
	this.c13_op2.name = "c13_op2";
	this.c13_op2.lineHeight = 18;
	this.c13_op2.lineWidth = 355;
	this.c13_op2.parent = this;
	this.c13_op2.setTransform(552.3,332.1);

	this.c13_op1 = new cjs.Text("Es el tiempo en que un colaborador puede estar listo para asumir una posición distinta a la actual en la organización.", "16px 'Arial'", "#333333");
	this.c13_op1.name = "c13_op1";
	this.c13_op1.lineHeight = 18;
	this.c13_op1.lineWidth = 356;
	this.c13_op1.parent = this;
	this.c13_op1.setTransform(552.3,245.2);

	this.c13_0 = new lib.mc_radioButton13();
	this.c13_0.parent = this;
	this.c13_0.setTransform(529.9,169.7,1,1,0,0,0,18,18.1);

	this.p13 = new cjs.Text("¿Cómo definimos “Readiness” en el proceso de gestión de talento en Arca Continental?", "20px 'Arial'");
	this.p13.name = "p13";
	this.p13.lineHeight = 24;
	this.p13.lineWidth = 324;
	this.p13.parent = this;
	this.p13.setTransform(117,16.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.p13},{t:this.c13_0},{t:this.c13_op1},{t:this.c13_op2},{t:this.c13_op0},{t:this.c13_1},{t:this.c13_2},{t:this.shape_1},{t:this.shape},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	// fondo y encabezado
	this.instance_5 = new lib.iconoactividadesyretos("synched",0);
	this.instance_5.parent = this;
	this.instance_5.setTransform(475.7,95.1,0.551,0.551,0,0,0,55.7,55.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(230,149,122,0.498)").s().p("EgiSAJ5QjsAAAAjsIAAsZQAAjsDsAAMBElAAAQDsAAAADsIAAMZQAADsjsAAg");
	this.shape_2.setTransform(254.4,49.7);

	this.instance_6 = new lib.fondo("synched",0);
	this.instance_6.parent = this;
	this.instance_6.setTransform(469.6,267.3,1,1,0,0,0,485.2,268.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_6},{t:this.shape_2},{t:this.instance_5}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.evalpagina13, new cjs.Rectangle(2.4,-36.5,958.3,510.2), null);


(lib.mc_eval = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		this.txt_numPreg.text = this.parent.cont+1;
		console.log("numero de pregunta");
		console.log(this.parent.cont);
	}
	this.frame_1 = function() {
		this.stop();
		this.txt_numPreg.text = this.parent.cont+1;
		console.log("numero de pregunta");
		console.log(this.parent.cont);
	}
	this.frame_2 = function() {
		this.stop();
		this.txt_numPreg.text = this.parent.cont+1;
		console.log("numero de pregunta");
		console.log(this.parent.cont);
	}
	this.frame_3 = function() {
		this.stop();
		this.txt_numPreg.text = this.parent.cont+1;
		console.log("numero de pregunta");
		console.log(this.parent.cont);
	}
	this.frame_4 = function() {
		this.stop();
		this.txt_numPreg.text = this.parent.cont+1;
		console.log("numero de pregunta");
		console.log(this.parent.cont);
	}
	this.frame_5 = function() {
		this.stop();
		this.txt_numPreg.text = this.parent.cont+1;
		console.log("numero de pregunta");
		console.log(this.parent.cont);
	}
	this.frame_6 = function() {
		this.stop();
		this.txt_numPreg.text = this.parent.cont+1;
		console.log("numero de pregunta");
		console.log(this.parent.cont);
	}
	this.frame_7 = function() {
		this.stop();
		this.txt_numPreg.text = this.parent.cont+1;
		console.log("numero de pregunta");
		console.log(this.parent.cont);
	}
	this.frame_8 = function() {
		this.stop();
		this.txt_numPreg.text = this.parent.cont+1;
		console.log("numero de pregunta");
		console.log(this.parent.cont);
	}
	this.frame_9 = function() {
		this.stop();
		this.txt_numPreg.text = this.parent.cont+1;
		console.log("numero de pregunta");
		console.log(this.parent.cont);
	}
	this.frame_10 = function() {
		this.stop();
		this.txt_numPreg.text = this.parent.cont+1;
		console.log("numero de pregunta");
		console.log(this.parent.cont);
	}
	this.frame_11 = function() {
		this.stop();
		this.txt_numPreg.text = this.parent.cont+1;
		console.log("numero de pregunta");
		console.log(this.parent.cont);
	}
	this.frame_12 = function() {
		this.stop();
		this.txt_numPreg.text = this.parent.cont+1;
		console.log("numero de pregunta");
		console.log(this.parent.cont);
	}
	this.frame_13 = function() {
		this.stop();
		this.txt_numPreg.text = this.parent.cont+1;
		console.log("numero de pregunta");
		console.log(this.parent.cont);
	}
	this.frame_14 = function() {
		this.stop();
		this.txt_numPreg.text = this.parent.cont+1;
		console.log("numero de pregunta");
		console.log(this.parent.cont);
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1).call(this.frame_4).wait(1).call(this.frame_5).wait(1).call(this.frame_6).wait(1).call(this.frame_7).wait(1).call(this.frame_8).wait(1).call(this.frame_9).wait(1).call(this.frame_10).wait(1).call(this.frame_11).wait(1).call(this.frame_12).wait(1).call(this.frame_13).wait(1).call(this.frame_14).wait(1));

	// Layer 2
	this.txt_numPreg = new cjs.Text("0", "49px 'Arial'");
	this.txt_numPreg.name = "txt_numPreg";
	this.txt_numPreg.lineHeight = 55;
	this.txt_numPreg.lineWidth = 50;
	this.txt_numPreg.parent = this;
	this.txt_numPreg.setTransform(29.4,31.6);

	this.text = new cjs.Text("/7", "49px 'Arial'");
	this.text.lineHeight = 55;
	this.text.lineWidth = 50;
	this.text.parent = this;
	this.text.setTransform(56.4,31.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text},{t:this.txt_numPreg}]}).wait(15));

	// Capa 4
	this.instance = new lib.mc_p1();
	this.instance.parent = this;
	this.instance.setTransform(467.7,219.2,1,1,0,0,0,470.6,215.2);

	this.instance_1 = new lib.evalpag2();
	this.instance_1.parent = this;
	this.instance_1.setTransform(480,221.5,1,1,0,0,0,482.9,217.5);

	this.instance_2 = new lib.evapag3();
	this.instance_2.parent = this;
	this.instance_2.setTransform(480,221.5,1,1,0,0,0,482.1,217.5);

	this.instance_3 = new lib.mc_p4();
	this.instance_3.parent = this;
	this.instance_3.setTransform(480,221.5,1,1,0,0,0,482.9,217.5);

	this.instance_4 = new lib.mc_p5();
	this.instance_4.parent = this;
	this.instance_4.setTransform(480,221.5,1,1,0,0,0,482.9,217.5);

	this.instance_5 = new lib.evalpag6();
	this.instance_5.parent = this;
	this.instance_5.setTransform(480,221.5,1,1,0,0,0,482.9,217.5);

	this.instance_6 = new lib.evalpag7();
	this.instance_6.parent = this;
	this.instance_6.setTransform(480,221.5,1,1,0,0,0,482.9,217.5);

	this.instance_7 = new lib.evalpag8();
	this.instance_7.parent = this;
	this.instance_7.setTransform(480,221.5,1,1,0,0,0,482.9,217.5);

	this.instance_8 = new lib.evalpag9();
	this.instance_8.parent = this;
	this.instance_8.setTransform(480,221.5,1,1,0,0,0,482.9,217.5);

	this.instance_9 = new lib.evalpagina10();
	this.instance_9.parent = this;
	this.instance_9.setTransform(480,221.5,1,1,0,0,0,482.9,217.5);

	this.instance_10 = new lib.evalpagina11();
	this.instance_10.parent = this;
	this.instance_10.setTransform(480,221.5,1,1,0,0,0,482.9,217.5);

	this.instance_11 = new lib.evalpagina12();
	this.instance_11.parent = this;
	this.instance_11.setTransform(480,221.5,1,1,0,0,0,482.9,217.5);

	this.instance_12 = new lib.evalpagina13();
	this.instance_12.parent = this;
	this.instance_12.setTransform(480,221.5,1,1,0,0,0,482.9,217.5);

	this.instance_13 = new lib.evalpag14();
	this.instance_13.parent = this;
	this.instance_13.setTransform(480,221.5,1,1,0,0,0,482.9,217.5);

	this.instance_14 = new lib.evalpagina15();
	this.instance_14.parent = this;
	this.instance_14.setTransform(480,221.5,1,1,0,0,0,482.9,217.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_9}]},1).to({state:[{t:this.instance_10}]},1).to({state:[{t:this.instance_11}]},1).to({state:[{t:this.instance_12}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_14}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.5,-32.5,958.3,510.2);


// stage content:
(lib.template_evaluacion = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{inicio:0});

	// timeline functions:
	this.frame_0 = function() {
		var root = this;
		console.log("inicia");
		console.log("Inicio de oportunidades:", parent.oportunidades, parent.intentoAct);
		try {
			parent.getCanvas(this);
			parent.bloquear_barra();
		} catch (e) {
			console.log("No hay comunicación con el start.js", e);
		}
		var root = this;
		//variables necesarias para el guardado de respuestas 
		this.calificacion = 0;
		this.res = 0;
		this.minima = parent.califMinima;
		this.resultados = ["0", "0", "0", "0", "0", "0", "0"]; //en este arreglo se guardaran las calificaciones de cada pregunta 
		this.stop();
		this.Array = ["", "", "", "", "", "", ""]; // se guarda en orden de las preguntas
		this.preguntas = ["", "", "", "", "", "", ""]; //se guardara la pregunata 
		this.respuestas = ["", "", "", "", "", "", ""]; // se guarda la respuesta seleccionada
		this.correctas = ["", "", "", "", "", "", ""]; //se guardara la(s) respuesta(s) correctas 
		this.cont = 0;
		this.x;
		this.val = true;
		console.log("desde animate las preguntas son:"+root.mc_eval.timeline.duration);
		console.log(this.Array.length);
		//arreglo para el random
		for (var i = 0; i < this.Array.length; i++) {
			this.x = parseInt(Math.random() * root.mc_eval.timeline.duration +1 );
			for (var j = 0; j < this.Array.length; j++) {
				if (this.x == this.Array[j]) {
					this.val = false;
				}
			}
			if (this.val) {
				this.Array[i] = this.x;
			} else {
				this.val = true;
				i--;
			}
		}
		
		console.log("Seleccion " + root.Array);
		
		stage.enableMouseOver();
		
		//Actividades que llevar drag and drop etc.
		createjs.Touch.enable(stage);
		
		root.btn_iniciar.cursor = "pointer";
		root.btn_iniciar.addEventListener("click", fn1);
		
		function fn1() {
			console.log("iniciar ", root.timeline.position + 1);
			root.gotoAndStop(root.timeline.position + 1);
			root.mc_eval.gotoAndPlay(root.Array[root.cont] - 1);
		}
		var root = this;
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
		var root = this;
		console.log("Banco de letras" + root.Array[root.cont]);
		//habilitar las funciones de over mouse
		stage.enableMouseOver();
		
		//Actividades que llevar drag and drop etc.
		createjs.Touch.enable(stage);
		
		this.siguienteFrame = function (btn) {
			root.cont++;
			if (root.cont <= 6) {
				console.log("posision: ", root.mc_eval.timeline.position);
				root.mc_eval.gotoAndPlay(root.Array[root.cont] - 1);
				console.log("contador del ir " + root.cont);
				console.log("contador del ir" + root.Array[root.cont]);
			} else {
				fn();
			}
			/*if (root.mc_eval.timeline.position == root.mc_eval.timeline.duration - 1) {
				fn();
			} else {
				console.log("posision: ", root.mc_eval.timeline.position);
				root.mc_eval.gotoAndStop(root.Array[root.cont]);
				console.log(root.Array[root.cont]);
			}*/
			console.log(root.resultados);
		
		}
		
		this.activarSiguiente = function () {
			root.btn_siguiente.cursor = "pointer";
			root.btn_siguiente.visible = true;
			root.btn_siguiente.addEventListener("click", this.siguienteFrame);
		}
		
		this.imprimirCal = function () {
			for (var i = 0; i < this.resultados.length; i++) {
				this.calificacion += this.resultados[i];
				this.res += this.resultados[i];
			}
			switch (this.calificacion) {
				case 50:
					this.calificacion = 80;
					break;
				case 60:
					this.calificacion = 90;
					break;
				case 70:
					this.calificacion = 100;
					break;
			}
			if (this.calificacion <= 40) {
				this.calificacion = 70;
		
			}
			
			console.log(this.calificacion);
			
		}
		
		function fn() {
			root.gotoAndStop(root.timeline.position + 1);
		}
		
		this.registrar_pregunta = function (p, r, c) {
			console.log("contador   " + root.cont);
			this.preguntas[root.cont] = p;
			this.respuestas[root.cont] = r;
			this.correctas[root.cont] = c;
			console.log(root.preguntas, root.respuestas, root.correctas);
		}
		
		function reiniciar() {
			console.log("reiniciar");
			gotoAndStop(2);
		}
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
		var root = this;
		
		root.imprimirCal();
		
		if (this.calificacion < this.minima) {
			console.log("calificacion no aprobatoria");
			root.retro_eval.terminar.visible = false;
			root.retro_eval.reintentar.addEventListener("click", reintentar);
			root.retro_eval.reintentar.cursor = "pointer";
			try {
				if (this.calificacion > parent.SCORE) {
					parent.SCORE = this.calificacion;
				}
				if (parent.intentoAct >= parent.oportunidades) {
					console.log("Fail", parent.intentoAct, this.calificacion, this.minima);
					parent.new_nswf_DoFSCommand("CMISetFailed", "");
					parent.new_nswf_DoFSCommand("CMISetScore", parent.SCORE);
					parent.ComunicacionLMS("completado");
				}
				parent.guardarDatos();
			} catch (err) {
				console.log("No hay comunicación con el start.js u otros componentes");
			}
		} else {
			console.log("calificacion aprobatoria");
			root.retro_eval.reintentar.addEventListener("click", reintentar);
			root.retro_eval.reintentar.cursor = "pointer";
			root.retro_eval.reintentar.visible = true;
			root.retro_eval.terminar.addEventListener("click", function () {
				root.play();
			});
			root.retro_eval.terminar.cursor = "pointer";
			try {
				if (this.calificacion > parent.SCORE) {
					parent.SCORE = this.calificacion;
				}
				parent.guardarDatos();
				parent.new_nswf_DoFSCommand("CMISetScore", parent.SCORE);
				parent.ComunicacionLMS("completado");
				parent.new_nswf_DoFSCommand("CMISetPassed", "");
			} catch (err) {
				console.log("No hay comunicación con API", err);
			}
		}
		console.log("MaxIntentos:" + parent.oportunidades);
		function reintentar() {
			try {
					parent.intentoAct++;
					location.reload();
				
			} catch (err) {
				console.log("no hay comunicacion con start.js:" + err);
			}
		}
	}
	this.frame_3 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1));

	// instrucciones
	this.instance = new lib.flechamueve("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(904.4,76.4,1,1,0,0,0,23.4,23.4);

	this.text = new cjs.Text("Selecciona las opciones que consideres correctas.", "17px 'Arial'", "#606060");
	this.text.lineHeight = 19;
	this.text.lineWidth = 429;
	this.text.parent = this;
	this.text.setTransform(507,65.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text},{t:this.instance}]},1).to({state:[]},1).wait(2));

	// Capa 1
	this.instance_1 = new lib.mc_portada();
	this.instance_1.parent = this;
	this.instance_1.setTransform(492.5,220.2,1,1,0,0,0,296.4,178.5);

	this.btn_iniciar = new lib.bntSiguiente2();
	this.btn_iniciar.parent = this;
	this.btn_iniciar.setTransform(862.8,400.1,1,1,0,0,0,14.5,13.5);

	this.instance_2 = new lib.mcBanderilla();
	this.instance_2.parent = this;
	this.instance_2.setTransform(780.5,443.5,1,1,0,0,0,102.3,16.1);

	this.btn_siguiente = new lib.btn_siguiente();
	this.btn_siguiente.parent = this;
	this.btn_siguiente.setTransform(956.6,450.5,1,1,0,0,0,71.9,13.5);

	this.mc_eval = new lib.mc_eval();
	this.mc_eval.parent = this;
	this.mc_eval.setTransform(485.6,268.4,1,1,0,0,0,487.5,239.9);

	this.retro_eval = new lib.mc_retro_eval();
	this.retro_eval.parent = this;
	this.retro_eval.setTransform(433,338.9,1,1,0,0,0,197.8,58.8);

	this.instance_3 = new lib.Certificado_Symbol();
	this.instance_3.parent = this;
	this.instance_3.setTransform(447.9,253.6,1,1,0,0,0,489,250);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E3EFB9").s().p("AiwliIFhFiIlhFjg");
	this.shape.setTransform(426.3,233.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#E3EFB9").s().p("Egp5AYxQhoAAhJhJQhJhJAAhoMAAAgptQAAhoBJhJQBJhJBoAAMBXtAAAMAAAAxhg");
	this.shape_1.setTransform(347,258.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#EEEFEF").s().p("Eg/BAYxQhnAAhKhJQhIhJgBhoMAAAgptQABhoBIhJQBKhJBnAAMB+CAAAQBoAABJBJQBKBJgBBoMAAAAptQAAA1gTAtQgSArgkAkQhJBJhoAAg");
	this.shape_2.setTransform(482.1,258.1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("rgba(255,102,0,0.008)").ss(1,1,1).p("AAABAIAAh/");
	this.shape_3.setTransform(-896.4,464.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.btn_iniciar},{t:this.instance_1}]}).to({state:[{t:this.mc_eval},{t:this.btn_siguiente}]},1).to({state:[{t:this.retro_eval}]},1).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.instance_3}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(525.5,277.4,856.7,447);
// library properties:
lib.properties = {
	width: 950,
	height: 500,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [],
	preloads: []
};




})(lib = lib||{}, images = images||{}, createjs = createjs||{}, ss = ss||{}, AdobeAn = AdobeAn||{});
var lib, images, createjs, ss, AdobeAn;