(function (lib, img, cjs, ss, an) {

var p; // shortcut to reference prototypes
lib.ssMetadata = [];


// symbols:



(lib.mod02_c_istock_831277780 = function() {
	this.initialize(img.mod02_c_istock_831277780);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,505,330);// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.txt_modulo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D73D45").s().p("AhABzQgfgQgQgdQgQgeAAgqQAAgiAQgeQAQgfAegQQAdgQAkAAQA5AAAjAlQAkAlAAA3QAAA4gkAlQgkAlg4AAQghAAgfgPgAgqg3QgSATAAAkQAAAlASAUQASATAYABQAagBASgTQARgUAAglQAAgkgRgTQgSgVgaABQgYgBgSAVg");
	this.shape.setTransform(158,33);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#D73D45").s().p("AggCsIAAlXIBBAAIAAFXg");
	this.shape_1.setTransform(136.7,28.3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#D73D45").s().p("AhKB0QgUgLgJgUQgJgTAAgkIAAicIBCAAIAAByQAAA0ADAMQAEALAKAHQAJAHAPAAQAQAAANgJQAOgJAEgOQAFgOAAg0IAAhpIBCAAIAAD4Ig9AAIAAgmQgOAUgWAMQgVALgYAAQgaAAgTgLg");
	this.shape_2.setTransform(115.2,33.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#D73D45").s().p("AhaCMQgegjAAg9QAAg/AdggQAegiAuAAQApAAAeAjIAAh8IBCAAIAAFXIg+AAIAAglQgOAWgWALQgUAKgUgBQgrAAgfgigAglgPQgQARAAAlQAAAoALASQAQAZAcAAQAWABAQgUQAQgTAAgmQAAgrgPgSQgQgTgYAAQgXAAgPATg");
	this.shape_3.setTransform(85.4,28.6);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#D73D45").s().p("AhACiQgfgPgQgeQgQgeAAgrQAAghAQgeQAQgeAegQQAdgQAkgBQA5ABAjAkQAkAlAAA3QAAA4gkAlQgkAmg4gBQghAAgfgPgAgqgIQgSASAAAmQAAAkASAVQASATAYAAQAaAAASgTQARgUAAgmQAAglgRgSQgSgUgaAAQgYAAgSAUgAgghrIAghFIBJAAIhBBFg");
	this.shape_4.setTransform(56.8,28.3);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#D73D45").s().p("ABlCsIAAkOIhEEOIhCAAIhDkOIAAEOIhBAAIAAlXIBoAAIA9DqIA+jqIBoAAIAAFXg");
	this.shape_5.setTransform(22,28.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.txt_modulo, new cjs.Rectangle(0,0,174.8,57.6), null);


(lib.titulo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.text = new cjs.Text("Panorama general", "bold 25px 'Arial'", "#333333");
	this.text.textAlign = "center";
	this.text.lineHeight = 28;
	this.text.lineWidth = 186;
	this.text.parent = this;
	this.text.setTransform(94.1,13.4);

	this.timeline.addTween(cjs.Tween.get(this.text).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.8,11.4,189.9,146.7);


(lib.Tema = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa_1
	this.text = new cjs.Text("Pasos para identificar el talento", "36px 'Arial'", "#606060");
	this.text.lineHeight = 47;
	this.text.lineWidth = 329;
	this.text.parent = this;
	this.text.setTransform(2,2);

	this.timeline.addTween(cjs.Tween.get(this.text).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,333,91.7);


(lib.tapabca2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AwoG+IAAt8MAhRAAAIAAN8g");
	this.shape.setTransform(106.5,44.7);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,213,89.3);


(lib.tapabca = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AwoG+IAAt8MAhRAAAIAAN8g");
	this.shape.setTransform(106.5,44.7);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,213,89.3);


(lib.puestos1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhpAAIBfguIAAAaIB0AAIAAApIh0AAIAAAagAhSAAIA+AfIAAgUIB0AAIAAgVIh0AAIAAgTg");
	this.shape.setTransform(150.2,81.4,0.911,0.911);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#D15A61").s().p("AhgAAIBOgmIAAAXIB0AAIAAAfIh0AAIAAAXg");
	this.shape_1.setTransform(150.5,81.4,0.911,0.911);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AALAWIh0AAIAAgqIB0AAIAAgaIBfAuIhfAvgAhfAMIB0AAIAAATIA/gfIg/gdIAAATIh0AAg");
	this.shape_2.setTransform(36.9,115.1,0.911,0.911);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#D15A61").s().p("AATAQIh0AAIAAgfIB0AAIAAgXIBPAmIhPAng");
	this.shape_3.setTransform(36.6,115.1,0.911,0.911);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#91D6EE").s().p("Ag3AyIA3hjIA4Bjg");
	this.shape_4.setTransform(54.8,115,0.911,0.911);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#91D6EE").s().p("AlZgCIADgnIKvAsIgCAng");
	this.shape_5.setTransform(55,108.4,0.911,0.911);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#DC686B").p("Ahig5QgJgBgHAFQgHAFAAAHIgEBGQAAAIAGAFQAGAGAKAAIDKAKQAKABAHgFQAGgFABgHIADhHQABgHgHgFQgGgGgJAAgABjBBIjLgKQgMgBgJgHQgJgIAAgKIAEhHQABgJAJgHQAJgHANABIDLAKQANABAJAHQAJAIgBAKIgEBGQAAAKgKAHQgJAHgNgBg");
	this.shape_6.setTransform(37.9,89.3,0.911,0.911);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#F27B82").s().p("ABjBBIjLgKQgMgBgJgHQgJgIAAgKIAEhHQABgJAJgHQAJgHANABIDLAKQANABAJAHQAJAIgBAKIgEBGQAAAKgKAHQgIAGgLAAIgDAAgAhyg1QgHAFAAAHIgEBGQAAAIAGAFQAGAGAKAAIDKAKQAKABAHgFQAGgFABgHIADhHQABgHgHgFQgGgGgJAAIjLgKIgCAAQgIAAgGAEg");
	this.shape_7.setTransform(37.9,89.3,0.911,0.911);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#DC686B").p("ABeA9IjCgJQgNgBgIgKQgJgJABgNIACgyQABgNAKgIQAJgJANAAIDCAKQANABAJAJQAJAKgBANIgDAyQAAANgKAIQgKAJgNgBg");
	this.shape_8.setTransform(37.9,89.3,0.911,0.911);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#F27B82").s().p("ABeA9IjCgJQgNgBgIgKQgJgJABgNIACgyQABgNAKgIQAJgJANAAIDCAKQANABAJAJQAJAKgBANIgDAyQAAANgKAIQgJAJgLAAIgDgBg");
	this.shape_9.setTransform(37.9,89.3,0.911,0.911);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#DC686B").p("Ahig5QgKgBgGAFQgHAFAAAHIgEBHQgBAHAHAFQAGAGAKAAIDKAKQAKABAHgFQAGgFABgHIADhHQABgHgHgFQgGgGgJAAgABjBBIjLgKQgMgBgJgHQgJgIAAgKIAEhGQABgKAJgHQAKgGAMAAIDLAKQANABAJAHQAJAIgBAKIgEBGQAAAKgKAHQgJAHgNgBg");
	this.shape_10.setTransform(37.5,99.5,0.911,0.911);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#F27B82").s().p("ABjBBIjLgKQgMgBgJgHQgJgIAAgKIAEhGQABgKAJgHQAKgGAMAAIDLAKQANABAJAHQAJAIgBAKIgEBGQAAAKgKAHQgIAGgLAAIgDAAgAhyg1QgHAFAAAHIgEBHQgBAHAHAFQAGAGAKAAIDKAKQAKABAHgFQAGgFABgHIADhHQABgHgHgFQgGgGgJAAIjLgKIgCAAQgIAAgGAEg");
	this.shape_11.setTransform(37.5,99.5,0.911,0.911);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#DC686B").p("ABeA9IjCgJQgNgBgIgJQgJgKABgNIACgyQABgNAKgIQAJgJANABIDCAJQANABAJAKQAJAJgBANIgCAyQgBANgKAIQgKAJgNgBg");
	this.shape_12.setTransform(37.5,99.5,0.911,0.911);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#F27B82").s().p("ABeA9IjBgJQgOgBgIgJQgJgKABgNIADgyQABgNAJgIQAJgJANABIDCAJQANABAJAKQAJAJgBANIgDAyQAAANgKAIQgJAIgLAAIgDAAg");
	this.shape_13.setTransform(37.5,99.5,0.911,0.911);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#DC686B").p("ABhBEIjLgRQgMAAgJgIQgIgIAAgKIAGhHQABgKAJgGQAKgGANABIDKAQQANABAJAIQAIAIgBAKIgGBGQAAAKgKAHQgJAGgNgBgAhhg9QgJAAgHAEQgHAFgBAHIgFBHQgBAHAGAFQAGAGAKABIDKAQQAJABAHgFQAHgEABgHIAGhHQAAgHgGgGQgGgFgJgBg");
	this.shape_14.setTransform(76,81.1,0.911,0.911);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#F27B82").s().p("ABhBEIjLgRQgMAAgJgIQgIgIAAgKIAGhHQABgKAJgGQAKgGANABIDKAQQANABAJAIQAIAIgBAKIgGBGQAAAKgKAHQgIAFgKAAIgEAAgAhxg5QgHAFgBAHIgFBHQgBAHAGAFQAGAGAKABIDKAQQAJABAHgFQAHgEABgHIAGhHQAAgHgGgGQgGgFgJgBIjLgRIgBAAQgJAAgGAEg");
	this.shape_15.setTransform(76,81.1,0.911,0.911);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#DC686B").p("ABdBAIjCgQQgMAAgJgKQgJgKABgNIAEgyQABgNAKgIQAKgIANAAIDCAQQANABAIAKQAIAKAAANIgFAyQAAANgKAIQgKAIgNgBg");
	this.shape_16.setTransform(76,81.1,0.911,0.911);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#F27B82").s().p("ABdBAIjCgQQgMAAgJgKQgIgKABgNIADgyQABgNALgIQAJgIANAAIDCAQQANABAIAKQAIAKAAANIgFAyQgBANgKAIQgIAIgMAAIgCgBg");
	this.shape_17.setTransform(76,81.1,0.911,0.911);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#DC686B").p("ABhBEIjKgQQgNgBgJgIQgIgIAAgKIAGhGQABgKAKgHQAJgGANABIDLAQQAMABAJAIQAJAIgBAKIgHBHQAAAKgKAGQgKAGgMgBgAhhg8QgJgBgHAFQgHAEAAAHIgGBHQgBAHAHAFQAFAGAKABIDLAQQAJABAHgFQAHgEAAgHIAGhHQABgHgHgFQgGgGgJgBg");
	this.shape_18.setTransform(75.2,91.7,0.911,0.911);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#F27B82").s().p("ABhBEIjLgQQgMgBgJgIQgIgIABgKIAFhGQABgKAKgHQAJgGANABIDLAQQANABAIAIQAIAIAAAKIgHBHQAAAKgKAGQgIAFgLAAIgDAAgAhxg4QgGAEgCAHIgFBHQgBAHAGAFQAHAGAJABIDLAQQAIABAIgFQAGgEABgHIAGhHQAAgHgGgFQgGgGgJgBIjLgQIgBgBQgJAAgGAFg");
	this.shape_19.setTransform(75.2,91.7,0.911,0.911);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().s("#DC686B").p("ABdBAIjCgPQgNgBgIgKQgIgKAAgNIAFgyQAAgNAKgIQAKgIANABIDCAPQAMABAJAKQAJAKgBANIgFAyQAAAMgKAJQgKAIgNgBg");
	this.shape_20.setTransform(75.2,91.6,0.911,0.911);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#F27B82").s().p("ABcBAIjBgPQgNgBgIgKQgJgKABgNIAFgyQAAgNAKgIQALgIAMABIDBAPQANABAJAKQAJAKgCANIgEAyQgBAMgJAJQgJAHgMAAIgDAAg");
	this.shape_21.setTransform(75.2,91.6,0.911,0.911);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f().s("#DC686B").p("ABhBEIjLgRQgNgBgIgHQgIgIAAgKIAGhHQABgKAKgGQAKgGAMABIDLAQQAMABAJAIQAJAIgBAKIgGBGQgBAKgKAHQgJAGgNgBgAhgg9QgKAAgHAEQgGAFgBAHIgGBHQgBAHAHAFQAGAGAJABIDKAQQAKABAHgFQAHgEAAgHIAGhHQABgHgHgGQgGgFgJgBg");
	this.shape_22.setTransform(74.4,102.2,0.911,0.911);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#F27B82").s().p("ABhBEIjLgRQgNgBgIgHQgIgIAAgKIAGhHQABgKAKgGQAKgGAMABIDLAQQAMABAJAIQAJAIgBAKIgGBGQgBAKgKAHQgIAFgLAAIgDAAgAhxg5QgGAFgBAHIgGBHQgBAHAHAFQAGAGAJABIDKAQQAKABAHgFQAHgEAAgHIAGhHQABgHgHgGQgGgFgJgBIjKgRIgCAAQgIAAgHAEg");
	this.shape_23.setTransform(74.4,102.2,0.911,0.911);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f().s("#DC686B").p("ABdBAIjCgQQgMAAgJgKQgIgKABgNIAEgyQABgNAKgIQAJgIANAAIDCAQQANABAIAKQAIAKgBANIgEAyQAAAMgKAJQgKAIgNgBg");
	this.shape_24.setTransform(74.4,102.2,0.911,0.911);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#F27B82").s().p("ABdBAIjCgQQgMAAgJgKQgIgKABgNIAEgyQABgNAKgIQAJgIANAAIDCAQQANABAIAKQAIAKgBANIgEAyQAAAMgKAJQgJAIgMAAIgCgBg");
	this.shape_25.setTransform(74.4,102.2,0.911,0.911);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f().s("#DC686B").p("AAhAxIhBAAQgPAAgKgKQgKgKAAgPIAAgbQAAgPAKgKQAKgKAPAAIBCAAQAOAAAKAKQALALgBAOIAAAcQAAAOgKAKQgKAKgPAAgAgggrQgMAAgJAJQgJAIAAANIAAAbQAAAMAJAJQAIAJANAAIBBAAQANAAAIgJQAJgIAAgMIAAgcQAAgMgIgJQgJgJgMAAg");
	this.shape_26.setTransform(121.8,81.6,0.911,0.911);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#F27B82").s().p("AggAxQgPAAgKgKQgKgKAAgPIAAgbQAAgPAKgKQAKgKAPAAIBCAAQAOAAAKAKQALALgBAOIAAAcQAAAOgKAKQgKAKgPAAgAg1giQgJAIAAANIAAAbQAAAMAJAJQAIAJANAAIBBAAQANAAAIgJQAJgIAAgMIAAgcQAAgMgIgJQgJgJgMAAIhCAAQgMAAgJAJg");
	this.shape_27.setTransform(121.8,81.6,0.911,0.911);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f().s("#DC686B").p("AATAvIgmgBQgTAAgNgNQgOgOAAgTQAAgSAOgOQAOgOATABIAlAAQATAAAOANQANAOAAASQAAATgNAOQgOAOgTAAg");
	this.shape_28.setTransform(121.8,81.6,0.911,0.911);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#F27B82").s().p("AgTAuQgSAAgOgNQgOgOAAgTQAAgSAOgOQAOgOATABIAlAAQATAAAOANQAOAOAAASQAAATgOAOQgOAOgTAAg");
	this.shape_29.setTransform(121.8,81.6,0.911,0.911);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f().s("#DC686B").p("AA7AxIh1AAQgIAAgGgGQgGgFAAgJIAAg5QAAgJAGgFQAGgGAIAAIB2AAQAIAAAGAGQAFAGAAAIIAAA6QAAAIgGAGQgFAFgJAAgAg6grQgGAAgEAFQgEAEAAAGIgBA5QAAAGAFAFQAEAEAGAAIB1AAQAGAAAFgEQAEgEAAgGIAAg6QAAgGgEgEQgEgEgGAAg");
	this.shape_30.setTransform(134.7,98.6,0.911,0.911);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#F27B82").s().p("Ag6AxQgIAAgGgGQgGgFAAgJIAAg5QAAgJAGgFQAGgGAIAAIB2AAQAIAAAGAGQAFAGAAAIIAAA6QAAAIgGAGQgFAFgJAAgAhEgmQgEAEAAAGIgBA5QAAAGAFAFQAEAEAGAAIB1AAQAGAAAFgEQAEgEAAgGIAAg6QAAgGgEgEQgEgEgGAAIh2gBQgGAAgEAFg");
	this.shape_31.setTransform(134.7,98.6,0.911,0.911);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f().s("#DC686B").p("AAtAvIhZgBQgNAAgKgJQgIgJAAgNIAAgdQAAgNAIgKQAKgIANAAIBZAAQAOAAAJAIQAIAKAAANIAAAeQAAAMgJAKQgJAJgNAAg");
	this.shape_32.setTransform(134.7,98.6,0.911,0.911);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#F27B82").s().p("AgtAuQgMAAgKgJQgJgJAAgNIAAgdQAAgNAJgKQAKgIANgBIBaAAQAMABAKAIQAJAKgBANIAAAdQAAANgJAKQgJAIgNABg");
	this.shape_33.setTransform(134.7,98.6,0.911,0.911);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f().s("#DC686B").p("AAxAxIhgAAQgIAAgGgGQgGgFAAgJIAAg6QAAgIAGgGQAGgGAIAAIBgABQAIAAAGAGQAGAGAAAIIgBA5QAAAJgGAFQgFAGgIAAgAgvgrQgGAAgEAEQgFAEAAAGIAAA6QAAAGAFAEQAEAEAGAAIBgABQAFAAAFgEQAEgFAAgGIAAg5QAAgGgEgEQgEgFgGAAg");
	this.shape_34.setTransform(121.8,98.5,0.911,0.911);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#F27B82").s().p("AgwAxQgHAAgGgGQgHgGAAgIIAAg5QABgJAGgGQAGgFAHAAIBgAAQAJAAAGAGQAFAGAAAIIAAA5QAAAIgGAHQgFAFgJABgAg6gmQgEADAAAHIAAA5QAAAGAEAEQAFAFAFAAIBgAAQAGAAAEgEQAFgEAAgHIAAg5QAAgGgEgEQgFgEgGgBIhgAAQgFAAgFAFg");
	this.shape_35.setTransform(121.8,98.5,0.911,0.911);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f().s("#DC686B").p("AAiAuIhDAAQgNAAgKgJQgJgJAAgNIAAgeQAAgMAJgKQAKgJANAAIBDAAQANAAAKAKQAJAJAAANIAAAdQAAANgJAKQgKAIgNAAg");
	this.shape_36.setTransform(121.8,98.5,0.911,0.911);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#F27B82").s().p("AghAuQgNAAgKgJQgIgJgBgNIAAgeQABgMAIgJQAKgKANABIBEAAQAMAAAKAJQAJAJgBANIAAAeQABANgJAIQgKAKgNgBg");
	this.shape_37.setTransform(121.8,98.5,0.911,0.911);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f().s("#DC686B").p("ABBAxIiBAAQgIAAgGgGQgGgGAAgIIABg6QAAgIAGgGQAFgGAIABICBAAQAIAAAGAGQAGAFAAAJIAAA5QAAAJgGAFQgGAGgIAAgAhAgrQgFAAgFAEQgEAEAAAGIAAA6QAAAGAEAEQAEAEAGAAICBABQAGAAAEgEQAEgFAAgGIAAg5QAAgGgEgEQgEgFgGAAg");
	this.shape_38.setTransform(108.3,98.5,0.911,0.911);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#F27B82").s().p("AhAAxQgIAAgGgGQgGgGAAgIIABg6QAAgIAGgGQAFgGAIABICBAAQAIAAAGAGQAGAFAAAJIAAA5QAAAJgGAFQgGAGgIAAgAhKgnQgEAEAAAGIAAA6QAAAGAEAEQAEAEAGAAICBABQAGAAAEgEQAEgFAAgGIAAg5QAAgGgEgEQgEgFgGAAIiBAAQgFAAgFAEg");
	this.shape_39.setTransform(108.3,98.5,0.911,0.911);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f().s("#DC686B").p("AAzAvIhlAAQgNAAgJgKQgJgJAAgNIAAgdQAAgNAJgJQAJgJANAAIBlAAQANAAAJAJQAJAKAAAMIAAAeQAAAMgJAKQgKAJgMAAg");
	this.shape_40.setTransform(108.3,98.5,0.911,0.911);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#F27B82").s().p("AgyAvQgMAAgKgKQgJgJAAgNIAAgdQAAgNAJgKQAJgIANgBIBlABQANAAAJAJQAJAKAAAMIAAAdQAAANgJAKQgKAIgNABg");
	this.shape_41.setTransform(108.3,98.5,0.911,0.911);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f().s("#DC686B").p("ADMBAIgBAAImcgdQgIgBgFgGQgGgGABgIIAEg6QABgIAGgGQAGgFAIABIGcAdQAIAAAFAGQAGAGgBAJIgEA5QgBAIgFAFQgGAGgIAAgAjLg5QgGAAgEAEQgEADgBAGIgEA6QAAAGAEAEQAEAFAFAAIGcAdQAGABAFgEQAEgFAAgFIAFg6QAAgFgEgFQgEgEgGgBImbgdg");
	this.shape_42.setTransform(132.3,64.2,0.911,0.911);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#F27B82").s().p("ADLBAImcgdQgIgBgFgGQgGgGABgIIAEg6QABgIAGgGQAGgFAIABIGcAdQAIAAAFAGQAGAGgBAJIgEA5QgBAIgFAFQgGAGgIAAgAjVg1QgEADgBAGIgEA6QAAAGAEAEQAEAFAFAAIGcAdQAGABAFgEQAEgFAAgFIAFg6QAAgFgEgFQgEgEgGgBImbgdIgBAAQgGAAgEAEg");
	this.shape_43.setTransform(132.3,64.2,0.911,0.911);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f().s("#DC686B").p("AC9A8ImAgcQgMAAgJgKQgIgKAAgMIADgeQABgNAJgIQAKgJANABIF/AbQANABAJAKQAIAKgBALIgCAfQgBANgKAIQgJAJgNgBg");
	this.shape_44.setTransform(132.3,64.2,0.911,0.911);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#F27B82").s().p("AC9A8ImAgcQgMAAgJgKQgIgKAAgMIADgeQABgNAJgIQAKgJANABIF/AbQANABAJAKQAIAKgBALIgCAfQgBANgKAIQgIAIgLAAIgDAAg");
	this.shape_45.setTransform(132.3,64.2,0.911,0.911);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f().s("#DC686B").p("ADPAyImdgBQgIAAgGgGQgGgGAAgIIAAg6QAAgIAGgGQAGgGAIAAIGdACQAIAAAGAGQAGAFAAAIIAAA6QAAAIgGAGQgGAGgIAAgAjOgrQgGAAgEAEQgEAEAAAGIAAA6QAAAGAEAEQAEAEAGAAIGdABQAGAAAEgEQAEgEAAgGIAAg6QAAgFgEgFQgEgEgGAAg");
	this.shape_46.setTransform(121.3,73.1,0.911,0.911);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#F27B82").s().p("AjOAxQgIAAgGgGQgGgGAAgIIAAg6QAAgIAGgGQAGgGAIAAIGdACQAIAAAGAGQAGAFAAAIIAAA6QAAAIgGAGQgGAGgIAAgAjYgnQgEAEAAAGIAAA6QAAAGAEAEQAEAEAGAAIGdABQAGAAAEgEQAEgEAAgGIAAg6QAAgFgEgFQgEgEgGAAImdgBQgGAAgEAEg");
	this.shape_47.setTransform(121.3,73.1,0.911,0.911);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f().s("#DC686B").p("ADBAvImBgBQgNAAgJgJQgJgJAAgOIAAgdQAAgMAKgKQAJgJAMAAIGBABQANAAAJAJQAJAJAAAOIAAAdQAAANgJAJQgJAJgNAAg");
	this.shape_48.setTransform(121.3,73.2,0.911,0.911);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#F27B82").s().p("Ai/AuQgOAAgJgJQgJgKAAgNIAAgdQABgMAIgKQAKgJANAAIGAABQANAAAJAJQAJAKAAANIAAAdQAAANgJAJQgJAJgNAAg");
	this.shape_49.setTransform(121.3,73.2,0.911,0.911);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f().s("#DC686B").p("ADPAyImdgCQgIAAgGgFQgGgGAAgIIAAg6QAAgIAGgGQAGgGAIAAIGdABQAIAAAGAGQAGAGAAAIIAAA6QAAAIgGAGQgGAGgIAAgAjOgrQgGAAgEAEQgEAEAAAGIAAA6QAAAGAEAEQAEAEAGAAIGdABQAGAAAEgEQAEgEAAgGIAAg6QAAgGgEgEQgEgEgGAAg");
	this.shape_50.setTransform(121.3,90.1,0.911,0.911);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#F27B82").s().p("AjOAwQgIAAgGgFQgGgGAAgIIAAg6QAAgIAGgGQAGgGAIAAIGdABQAIAAAGAGQAGAGAAAIIAAA6QAAAIgGAGQgGAGgIAAgAjYgnQgEAEAAAGIAAA6QAAAGAEAEQAEAEAGAAIGdABQAGAAAEgEQAEgEAAgGIAAg6QAAgGgEgEQgEgEgGAAImdgBQgGAAgEAEg");
	this.shape_51.setTransform(121.3,90.1,0.911,0.911);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f().s("#DC686B").p("ADBAvImBgBQgNAAgJgJQgJgJAAgOIAAgdQAAgNAKgJQAIgJANAAIGBABQANAAAJAJQAJAKAAANIAAAdQAAANgJAJQgJAJgNAAg");
	this.shape_52.setTransform(121.3,90.1,0.911,0.911);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#F27B82").s().p("AjAAuQgNAAgJgJQgJgJAAgOIABgdQgBgMAKgKQAIgJANAAIGBABQANAAAJAKQAJAJAAAMIAAAeQAAANgJAJQgJAJgNAAg");
	this.shape_53.setTransform(121.3,90.1,0.911,0.911);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f().s("#DC686B").p("ADPAyImdgBQgIAAgGgGQgGgGAAgIIAAg6QAAgIAGgGQAGgGAIAAIGdABQAIABAGAFQAGAGAAAIIAAA6QAAAIgGAGQgGAGgIAAgAjOgrQgGAAgEAEQgEAEAAAGIAAA6QAAAGAEAEQAEAEAGAAIGdABQAGAAAEgEQAEgEAAgGIAAg6QAAgGgEgEQgEgEgGAAg");
	this.shape_54.setTransform(121.2,107,0.911,0.911);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#F27B82").s().p("AjOAxQgIAAgGgGQgGgGAAgIIAAg6QAAgIAGgGQAGgGAIAAIGdABQAIABAGAFQAGAGAAAIIAAA6QAAAIgGAGQgGAGgIAAgAjYgnQgEAEAAAGIAAA6QAAAGAEAEQAEAEAGAAIGdABQAGAAAEgEQAEgEAAgGIAAg6QAAgGgEgEQgEgEgGAAImdgBQgGAAgEAEg");
	this.shape_55.setTransform(121.2,107,0.911,0.911);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f().s("#DC686B").p("ADBAvImBgBQgNAAgJgJQgJgJAAgNIAAgeQAAgMAJgKQAKgJAMAAIGBABQANAAAJAJQAJAJAAANIAAAeQAAANgJAJQgJAJgNAAg");
	this.shape_56.setTransform(121.2,107,0.911,0.911);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#F27B82").s().p("Ai/AtQgOAAgJgJQgJgIAAgNIAAgeQABgNAIgJQAKgJANAAIGAABQANAAAJAJQAJAJAAANIAAAdQAAANgJAKQgJAJgNAAg");
	this.shape_57.setTransform(121.2,107,0.911,0.911);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f().s("#DC686B").p("AA7AxIh1AAQgIAAgGgGQgGgGAAgIIAAg6QAAgIAGgGQAGgGAIABIB2AAQAIAAAGAGQAFAFAAAJIAAA5QAAAJgGAFQgFAGgJAAgAg6grQgGAAgEAEQgEAEAAAGIgBA6QAAAGAFAEQAEAEAGAAIB1ABQAGAAAFgEQAEgFAAgGIAAg5QAAgGgEgEQgEgFgGAAg");
	this.shape_58.setTransform(134.6,115.5,0.911,0.911);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#F27B82").s().p("Ag6AxQgIAAgGgGQgGgGAAgIIAAg6QAAgIAGgGQAGgGAIABIB2AAQAIAAAGAGQAFAFAAAJIAAA5QAAAJgGAFQgFAGgJAAgAhEgnQgEAEAAAGIgBA6QAAAGAFAEQAEAEAGAAIB1ABQAGAAAFgEQAEgFAAgGIAAg5QAAgGgEgEQgEgFgGAAIh2AAQgGAAgEAEg");
	this.shape_59.setTransform(134.6,115.5,0.911,0.911);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f().s("#DC686B").p("AAtAuIhaAAQgNAAgJgJQgJgJAAgNIAAgeQAAgNAJgJQAKgJANAAIBZABQANAAAKAJQAIAJAAANIAAAdQAAANgJAJQgJAJgNAAg");
	this.shape_60.setTransform(134.7,115.5,0.911,0.911);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#F27B82").s().p("AgsAvQgNAAgKgJQgIgKgBgNIAAgeQABgNAIgIQAKgJANAAIBZAAQAOAAAIAJQAJAKAAAMIAAAdQABANgKAKQgJAJgNAAg");
	this.shape_61.setTransform(134.7,115.5,0.911,0.911);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f().s("#DC686B").p("AAxAxIhhAAQgIAAgGgGQgGgGAAgIIAAg6QAAgIAGgGQAGgFAIAAIBhAAQAIAAAGAGQAGAGAAAIIgBA6QAAAIgGAFQgGAGgHAAgAgwgrQgFAAgFAEQgEAFAAAFIAAA6QAAAGAEAEQAFAEAFABIBhAAQAFAAAFgEQAEgFAAgGIAAg5QAAgGgEgEQgEgFgGAAg");
	this.shape_62.setTransform(121.7,115.5,0.911,0.911);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#F27B82").s().p("AgvAxQgJAAgGgGQgFgGAAgIIAAg6QAAgIAFgGQAGgFAJAAIBgAAQAIAAAFAGQAHAGAAAIIgBA6QAAAIgGAFQgGAGgHAAgAg5gnQgFAFAAAFIAAA6QAAAGAFAEQADAEAHABIBgAAQAFAAAFgEQADgFAAgGIABg5QAAgGgEgEQgEgFgGAAIhgAAQgHAAgDAEg");
	this.shape_63.setTransform(121.7,115.5,0.911,0.911);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f().s("#DC686B").p("AAiAuIhDAAQgOAAgIgJQgKgJAAgNIAAgdQAAgNAKgKQAIgJAOAAIBDABQAOAAAIAJQAJAJAAANIAAAdQAAANgJAKQgJAJgNgBg");
	this.shape_64.setTransform(121.7,115.4,0.911,0.911);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#F27B82").s().p("AAiAuIhEAAQgMAAgJgJQgKgJABgNIAAgdQgBgNAKgKQAJgJAMAAIBFABQANAAAIAJQAJAJAAANIAAAdQAAANgJAKQgIAJgNAAIgBgBg");
	this.shape_65.setTransform(121.7,115.4,0.911,0.911);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f().s("#DC686B").p("ABBAxIiBAAQgIAAgGgGQgGgGAAgIIABg6QAAgIAGgFQAFgGAIAAICBAAQAJAAAFAGQAGAGAAAIIAAA6QAAAIgGAGQgGAFgIAAgAhAgrQgFAAgFAEQgEAFAAAFIAAA6QAAAGAEAFQAEAEAGAAICBAAQAGAAAEgEQAEgEAAgGIAAg6QAAgGgEgEQgEgEgGAAg");
	this.shape_66.setTransform(108.3,115.4,0.911,0.911);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#F27B82").s().p("AhAAxQgIAAgGgGQgGgGAAgIIABg6QAAgIAGgFQAFgGAIAAICBAAQAJAAAFAGQAGAGAAAIIAAA6QAAAIgGAGQgGAFgIAAgAhKgnQgEAFAAAFIAAA6QAAAGAEAFQAEAEAGAAICBAAQAGAAAEgEQAEgEAAgGIAAg6QAAgGgEgEQgEgEgGAAIiBgBQgFAAgFAEg");
	this.shape_67.setTransform(108.3,115.4,0.911,0.911);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f().s("#DC686B").p("AAzAvIhlgBQgNAAgJgJQgJgJAAgNIAAgdQAAgNAJgKQAJgJANAAIBlABQANAAAJAJQAJAJAAANIAAAdQAAANgJAKQgJAJgNAAg");
	this.shape_68.setTransform(108.3,115.4,0.911,0.911);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#F27B82").s().p("AgyAuQgNAAgJgJQgJgJAAgNIAAgdQAAgNAJgKQAJgJAOAAIBkABQANAAAJAJQAJAJAAANIAAAdQAAANgKAKQgIAJgNAAg");
	this.shape_69.setTransform(108.3,115.4,0.911,0.911);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#DFE5DF").s().p("ArlCOIgnhDQgbgtgIgZQFch7FKgTQHbgdHeCwQgIAYgbArQghA0gHANg");
	this.shape_70.setTransform(90.6,122.8,0.911,0.911);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#DFE5DF").s().p("AncBuQjTiFhwjgIY/AAQhwDgjUCFQjZCKkDAAQkCAAjaiKg");
	this.shape_71.setTransform(90.5,149.2,0.911,0.911);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#DFE5DF").s().p("AiIHfQlLAUlbB8QgchYgVhYQgch4AAg/QAAi1BGilQBEigB7h7QB8h8CghEQClhGC1AAQC1AACmBGQCgBEB8B8QB7B7BECgQBGClAAC1QAABAgcB5QgVBfgbBUQneixnaAcg");
	this.shape_72.setTransform(90.5,66.5,0.911,0.911);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#EFEFEF").s().p("AmFOcQi1hMiKiKQiLiLhMi1QhPi6AAjMQAAjLBPi7QBMizCLiLQCKiLC1hMQC6hPDLAAQDMAAC7BPQC0BMCKCLQCLCLBMCzQBPC7AADLQAADMhPC6QhMC1iLCLQiKCKi0BMQi7BPjMAAQjLAAi6hPg");
	this.shape_73.setTransform(91.4,91.4,0.911,0.911);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,182.8,182.8);


(lib.numerodetema = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.text = new cjs.Text("Tema", "50px 'Arial'", "#FFFFFF");
	this.text.textAlign = "center";
	this.text.lineHeight = 75;
	this.text.parent = this;
	this.text.setTransform(69.1,21.2,0.593,0.593);

	this.text_1 = new cjs.Text("2.1", "50px 'Arial'", "#FFFFFF");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 75;
	this.text_1.parent = this;
	this.text_1.setTransform(67.9,51.7,1.094,1.094);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#793A26").s().p("Ag7HKQiJgUhphiIgRgQQhthmgbiMQgaiBAyh/QAyh/BshOQB0hTCVAAIAQAAQC8AACFCFQCGCGAAC8IAAAPQAACQhPByQhKBqh5A1QhZAmhdAAQghAAgigFg");
	this.shape.setTransform(69.8,69.7,1.504,1.504);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.text_1},{t:this.text}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,139.6,139.3);


(lib.mc_numMod01 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AiEDGQAFgoAVgkQAWgjA/g7QAygvAMgRQAPgXAAgXQAAgZgNgOQgOgNgYAAQgWAAgOAOQgOAOgCAhIhMgHQAIg/AjgbQAkgbA0AAQA6AAAhAgQAiAfAAAvQAAAagKAZQgJAXgWAaQgNARgkAhQgkAhgIALQgKAKgFALICVAAIAABGg");
	this.shape.setTransform(25.5,32.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#D73D45").s().p("AghEHQhPgMg8g4IgKgJQg+g7gQhQQgPhKAchJQAdhIA+gtQBDgwBVAAIAJAAQBsAABNBNQBMBMAABsIAAAIQAABTgtBBQgqA9hGAfQgzAWg1AAQgSAAgUgDg");
	this.shape_1.setTransform(26.6,32.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.mc_numMod01, new cjs.Rectangle(0,0,53.3,65.5), null);


(lib.mascaratapar = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EgvWACqIAAlTMBetAAAIAAFTg");
	this.shape.setTransform(303.1,17);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,606.2,34);


(lib.m2t1mc1txt2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.text = new cjs.Text("Las 3 primeras etapas son fundamentales y la base de todo el proceso: ", "18px 'Arial'", "#333333");
	this.text.lineHeight = 20;
	this.text.lineWidth = 369;
	this.text.parent = this;
	this.text.setTransform(2,2);

	this.timeline.addTween(cjs.Tween.get(this.text).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,372.6,44.2);


(lib.m2t1mc1txt1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.text = new cjs.Text("Para llevar a cabo el proceso de Talent Management Review de forma eficiente, se requiere conocer y dominar las 6 etapas clave.", "18px 'Arial'", "#333333");
	this.text.lineHeight = 20;
	this.text.lineWidth = 370;
	this.text.parent = this;
	this.text.setTransform(2,2);

	this.timeline.addTween(cjs.Tween.get(this.text).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,374.1,84.4);


(lib.info01 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.text = new cjs.Text("Éstas nos proporcionan información para que las decisiones que tomemos sean óptimas y fortalezcan las metas corporativas.", "17px 'Arial'", "#333333");
	this.text.textAlign = "center";
	this.text.lineHeight = 18;
	this.text.lineWidth = 294;
	this.text.parent = this;
	this.text.setTransform(-220.9,-18.6);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E3EFB9").s().p("ASdJgI1uAAIilAAIh8AAIkoAAIgVAAIAAy/IAVAAIEoAAIB8AAIClAAIVuAAIIgAAQBkAAAABkIAAAqIAACWIAAIwIAAADIAACpIAAAAIAABbQAABkhkAAgAv0JgIglAAIg9AAIiMAAIgsAAImuAAQhkAAAAhkIAAhbIAAAAIAAipIAAgDIAAowIAAiWIAAgqQAAhkBkAAIGuAAIAsAAICMAAIA9AAIAlAAIDFAAIAAS/g");
	this.shape.setTransform(-221.7,2.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.text}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.info01, new cjs.Rectangle(-404.2,-58.6,365,121.6), null);


(lib.imgmod1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EgBBAiNQm9AAmXisQmJimkvkvQkvkvimmJQismWAAm+QAAm8CsmXQCmmJEvkvQEvkvGJimQGXisG9AAICCAAQG+AAGXCsQGJCmEuEvQEwEvCmGJQCsGXAAG8QAAG+isGWQimGJkwEvQkuEvmJCmQmXCsm+AAg");
	mask.setTransform(387,218.9);

	// Capa_3
	this.instance = new lib.mod02_c_istock_831277780();
	this.instance.parent = this;
	this.instance.setTransform(-33,-29,1.455,1.455);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.imgmod1, new cjs.Rectangle(161.5,0,451,437.8), null);


(lib.Group_17 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#6379B7").ss(0.5).p("AgCgyIAFBl");
	this.shape.setTransform(0.6,5.1);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_17, new cjs.Rectangle(-0.7,-1,2.7,12.1), null);


(lib.Group_16 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#6379B7").ss(0.5).p("AgCgwIAFBh");
	this.shape.setTransform(0.6,5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_16, new cjs.Rectangle(-0.7,-0.9,2.6,11.8), null);


(lib.Group_15 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#6379B7").ss(0.5).p("AgCgvQADAuACAs");
	this.shape.setTransform(0.6,4.8);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_15, new cjs.Rectangle(-0.7,-1,2.6,11.2), null);


(lib.Group_14 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#6379B7").ss(0.5).p("AgCgxQADAwACAu");
	this.shape.setTransform(0.6,5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_14, new cjs.Rectangle(-0.7,-0.9,2.6,11.5), null);


(lib.Group_13 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#6379B7").ss(0.5).p("AgCguIAFBd");
	this.shape.setTransform(0.5,4.7);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_13, new cjs.Rectangle(-0.7,-1,2.6,11.3), null);


(lib.Group_12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#6379B7").ss(0.5).p("AgCgsIAFBZ");
	this.shape.setTransform(0.6,4.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_12, new cjs.Rectangle(-0.7,-1,2.6,11), null);


(lib.Group_11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#6379B7").ss(0.5).p("AADgvQgDAwgCA0");
	this.shape.setTransform(0.5,4.8);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_11, new cjs.Rectangle(-0.7,-1,2.6,12.1), null);


(lib.Group_10 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#6379B7").ss(0.5).p("AADgwQgDAwgCAx");
	this.shape.setTransform(0.5,4.9);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_10, new cjs.Rectangle(-0.7,-0.9,2.6,11.8), null);


(lib.Group_9 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#6379B7").ss(0.5).p("AADgvQgDAugCAs");
	this.shape.setTransform(0.5,4.8);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_9, new cjs.Rectangle(-0.7,-1,2.6,11.2), null);


(lib.Group_8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#6379B7").ss(0.5).p("AADguIgFBd");
	this.shape.setTransform(0.6,4.8);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_8, new cjs.Rectangle(-0.7,-0.9,2.6,11.5), null);


(lib.Group_7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#6379B7").ss(0.5).p("AADgtQgDAtgCAv");
	this.shape.setTransform(0.5,4.6);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_7, new cjs.Rectangle(-0.7,-1,2.6,11.3), null);


(lib.Group_6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#6379B7").ss(0.5).p("AADgqQgDAegCA7");
	this.shape.setTransform(0.5,4.3);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_6, new cjs.Rectangle(-0.7,-1,2.6,11), null);


(lib.Group_5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#6379B7").ss(0.5).p("AAMglIgXBL");
	this.shape.setTransform(1.4,3.9);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_5, new cjs.Rectangle(-0.7,-0.9,4.4,9.6), null);


(lib.Group_4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#6379B7").ss(0.5).p("AgIAcIARg3");
	this.shape.setTransform(1.1,2.9);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_4, new cjs.Rectangle(-0.8,-0.9,3.8,7.7), null);


(lib.Group_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#6379B7").ss(0.5).p("AgSglQAZARAKA+");
	this.shape.setTransform(2,4);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_3, new cjs.Rectangle(-0.8,-0.8,5.6,10), null);


(lib.Group_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#6379B7").ss(0.5).p("AATglQgZARgKA+");
	this.shape.setTransform(1.9,4);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_2, new cjs.Rectangle(-0.7,-0.8,5.6,10), null);


(lib.Group_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#6379B7").ss(0.5).p("AgGgUIANAp");
	this.shape.setTransform(0.9,2.2);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_1, new cjs.Rectangle(-0.8,-0.9,3.5,6.2), null);


(lib.Group = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#6379B7").ss(0.5).p("AANAkIgZhH");
	this.shape.setTransform(1.5,3.6);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group, new cjs.Rectangle(-0.8,-0.9,4.6,9.1), null);


(lib.ClipGroup_10 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AgOAiIgjAEIArhjIA4AYIgrBjg");
	mask.setTransform(5,6.2);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#A7DAC8").ss(2).p("AgTAuIAnhb");
	this.shape.setTransform(3.3,5.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#A7DAC8").ss(2).p("AgSAvIAlhc");
	this.shape_1.setTransform(6.8,7);

	var maskedShapeInstanceList = [this.shape,this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_10, new cjs.Rectangle(0.3,0,9.5,12.5), null);


(lib.ClipGroup_9 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AgxglIA4gYIArBjIgjgEIgWAcg");
	mask.setTransform(5,6.2);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#A7DAC8").ss(2).p("AAUAuIgnhb");
	this.shape.setTransform(6.7,5.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#A7DAC8").ss(2).p("AATAvIglhc");
	this.shape_1.setTransform(3.1,7);

	var maskedShapeInstanceList = [this.shape,this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_9, new cjs.Rectangle(0.2,0,9.5,12.5), null);


(lib.ClipGroup_8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AgOAiIgjAEIArhjIA4AYIgrBjg");
	mask.setTransform(5,6.2);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#A7DAC8").ss(2).p("AgTAuIAnhb");
	this.shape.setTransform(3.3,5.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#A7DAC8").ss(2).p("AgSAvIAlhc");
	this.shape_1.setTransform(6.8,7);

	var maskedShapeInstanceList = [this.shape,this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_8, new cjs.Rectangle(0.3,0,9.5,12.5), null);


(lib.ClipGroup_7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AgxglIA4gYIArBjIgjgEIgWAcg");
	mask.setTransform(5,6.2);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#A7DAC8").ss(2).p("AAUAuIgnhb");
	this.shape.setTransform(6.7,5.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#A7DAC8").ss(2).p("AATAvIglhc");
	this.shape_1.setTransform(3.1,7);

	var maskedShapeInstanceList = [this.shape,this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_7, new cjs.Rectangle(0.2,0,9.5,12.5), null);


(lib.ClipGroup_6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AgOAiIgjAEIArhjIA4AYIgrBjg");
	mask.setTransform(5,6.2);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#A7DAC8").ss(2).p("AgTAuIAnhb");
	this.shape.setTransform(3.3,5.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#A7DAC8").ss(2).p("AgSAvIAlhc");
	this.shape_1.setTransform(6.8,7);

	var maskedShapeInstanceList = [this.shape,this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_6, new cjs.Rectangle(0.3,0,9.5,12.5), null);


(lib.ClipGroup_5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AgxglIA4gYIArBjIgjgEIgVAcg");
	mask.setTransform(5,6.2);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#A7DAC8").ss(2).p("AAUAuIgnhb");
	this.shape.setTransform(6.7,5.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#A7DAC8").ss(2).p("AATAvIglhc");
	this.shape_1.setTransform(3.1,7);

	var maskedShapeInstanceList = [this.shape,this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_5, new cjs.Rectangle(0.2,0,9.5,12.5), null);


(lib.estrategia1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F6D9B2").s().p("AgCAWIgEgDIgFAAIgDADIgGgFIADgDIAAgFIgBgBIgDgDIgEAAIgBgHIAFAAQAAAAABgBQAAAAAAAAQABgBAAAAQAAgBABgBIAAAAIAAgFIgDgDIAFgGIADADIAFAAIABgBQAAAAABAAQABgBAAAAQABgBAAAAQAAAAAAgBIAAgEIAHgBIAAAFIADADIABAAIAAAAQABAAABABQABAAAAAAQABAAAAAAQABgBAAAAIADgDIAGAFIgDADIAAAFIABABQAAABABAAQAAABAAAAQABABAAAAQAAAAABAAIAEAAIABAHIgFAAIgDADIAAACQgBABAAAAQAAABAAAAQAAABAAAAQAAABABAAIADADIgFAGIgEgDIgEAAIgEAEIAAAEIgHABgAgIgHQgDAEAAADQAAAFAEAEQAEADADAAQAFAAAEgEQADgEAAgEQAAgEgEgEQgEgDgEAAQgEAAgEAEg");
	this.shape.setTransform(128.3,55,0.911,0.911);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#F6D9B2").s().p("AAIAqQgCgCgGAAQgEgBgDACIgDABIgDAIIgOgHIAEgHQAAgDgDgFIgCgCQgDgDgDAAIgCgBIgJADIgFgOIAIgEQADgBAAgGIAAAAIABgBQAAgEgCgDIgBgCIgIgEIAGgOIAIAEIADgBQADAAADgDIABgBQAEgFAAgDIgDgIIAOgFIADAIIACACIAFABIACAAQAGAAADgCIAEgIIANAGIgDAIIAAADQABADADACIABABQAEAFADAAIAJgEIAFAOIgIADIgCADIgBAFIgBADQABAGACACIAIAEIgGANIgIgEQgEABgEADQgEADgBADIgBADIAEAIIgPAGgAgHgVQgJADgEAJQgEAJADAIQAEAJAIAEQAJAEAIgDQAJgEAEgJQAEgIgDgJQgDgJgJgDQgFgDgFAAIgHACg");
	this.shape_1.setTransform(123,59.7,0.911,0.911);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#0D4369").s().p("AgCAAQAAAAAAgBQAAAAABgBQAAAAABAAQAAAAAAAAQABAAABAAQAAAAABAAQAAABAAAAQAAABAAAAQAAABAAAAQAAABAAAAQgBABAAAAQgBAAgBAAQAAAAAAAAQgBAAAAgBQgBAAAAgBQAAAAAAgBg");
	this.shape_2.setTransform(90.4,135.9,0.911,0.911);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#0D4369").s().p("AgCAAQAAAAAAAAQAAgBAAAAQABgBAAAAQABAAAAAAQABAAAAAAQABAAAAABQABAAAAABQAAAAAAAAQAAABAAABQAAAAgBABQAAAAgBAAQAAAAgBAAQAAAAgBAAQAAAAgBAAQAAgBAAAAQAAgBAAgBg");
	this.shape_3.setTransform(90.4,133.6,0.911,0.911);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#0D4369").s().p("AgCAAQAAAAAAgBQAAAAAAAAQABgBAAAAQABAAAAAAQABAAAAAAQABAAAAABQABAAAAAAQAAABAAAAQAAABAAAAQAAABgBAAQAAABgBAAQAAAAgBAAQAAAAgBAAQAAAAgBgBQAAAAAAgBQAAAAAAgBg");
	this.shape_4.setTransform(90.4,131.4,0.911,0.911);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#156E92").s().p("AgYAkIAgheIARAIIgIAbIgQAFIAKAOIgjA/g");
	this.shape_5.setTransform(91.9,124.8,0.911,0.911);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#126484").s().p("AgzBvIAAiBIAnhcQAeAOALALQARAQADAeQAFA3gEBQIgfgBIgBhZIgGBpg");
	this.shape_6.setTransform(94.4,129.8,0.911,0.911);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#F0FAFC").s().p("AgQAAQARgEAJgKIAGAEIgQAZg");
	this.shape_7.setTransform(91.2,120.5,0.911,0.911);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#1175A1").s().p("AgLgEIALgOIgQgFIgHgbIASgIIAdBeIAAAXg");
	this.shape_8.setTransform(87.5,124.8,0.911,0.911);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#126484").s().p("AgMBvIgGhpIgBBZIgfABQgEhRAGg2QACgeARgQQALgLAegOIAnBcIABCBg");
	this.shape_9.setTransform(85.1,129.8,0.911,0.911);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#F0FAFC").s().p("AgPgKIAGgEQAJAKAQAEIgPAPg");
	this.shape_10.setTransform(88.2,120.5,0.911,0.911);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FC5633").s().p("AgIATIAEg2IAJAAIAEA2IgJARg");
	this.shape_11.setTransform(89.7,125,0.911,0.911);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FC391F").s().p("AgEAHIgEgNIARAAIgEANg");
	this.shape_12.setTransform(89.7,121.1,0.911,0.911);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#F1C199").s().p("AgXguQAMAAAKgCQAFgBAFAFQAFAEABAGIACAVIABAAQAGAAAAAIQAAAFgDAFQgEAHgDgBQgNAhgYAFg");
	this.shape_13.setTransform(91.9,115,0.911,0.911);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#F1C199").s().p("AAXAxQgYgGgMggQgEABgDgHQgDgFAAgFQAAgIAGAAIABAAIACgVQABgGAFgEQAFgFAEABQALACAMAAIAABfg");
	this.shape_14.setTransform(87.6,115,0.911,0.911);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#DFAC81").s().p("AgZALIAAgfIA0AAIAAAfQgOAKgNAAQgMAAgNgKg");
	this.shape_15.setTransform(89.7,118.5,0.911,0.911);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#B3D8DD").s().p("AgSA9IAAhvIAFgCQATgJANgBIAAB9QgUAAgRgCg");
	this.shape_16.setTransform(88,124.3,0.911,0.911);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#B3D8DD").s().p("AgSg+QANABATAJIAFACIAABvQgRACgUAAg");
	this.shape_17.setTransform(91.4,124.3,0.911,0.911);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#8A480F").s().p("AgWAnIAAhPQAjAJAIAUQADAKgCAOIgEAbg");
	this.shape_18.setTransform(91.9,111.2,0.911,0.911);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#8A480F").s().p("AgpAoIgEgpQAAgXAJgQQATgDAZAIQAdAJAHARQADAJgCAPIgEAbg");
	this.shape_19.setTransform(89.9,111.1,0.911,0.911);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#EB3637").s().p("AgaABIAEgIQAWAFAZgFIACAHQgNAIgOAAQgMAAgOgHg");
	this.shape_20.setTransform(89.7,119.5,0.911,0.911);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#0D4369").s().p("AggB8QgBhCgGhJQgFhAABgoIBXgEQABAJgGAUQgGASgGANQgBAEgEgCQgFAAAAADIgCBaQgBA8ABAgg");
	this.shape_21.setTransform(88.1,148.8,0.911,0.911);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#6D4826").s().p("AgYACIAAgDIAxAAIAAADg");
	this.shape_22.setTransform(87.2,162,0.911,0.911);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#49250D").s().p("AgWATQgCgEAAgGQAAgLAIgIQAHgIAJgBQAKABAIAIQAGAIABALQAAAGgCAEg");
	this.shape_23.setTransform(87.2,160.5,0.911,0.911);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#DFAC81").s().p("AgHAjQgBAAAAgBQgBAAAAAAQAAgBAAgBQAAAAAAgBQAGgIABgIQABgJgGgHQgBAJgCAEQAAABgBAAQAAAAAAAAQAAABgBAAQAAAAgBAAQAAAAgBgBQAAAAAAAAQAAAAgBgBQAAAAAAAAIAAgLQAAgOAFgIQABgEgCgFIAWgEQgBAIABADQADAEACAKQABAJgCAIQgHASgJAHQgDACgCAAIgBAAg");
	this.shape_24.setTransform(97.6,140.6,0.911,0.911);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#F1C199").s().p("AACAhQgJgHgHgTQgCgHACgJQABgKADgEQABgEgBgHIAWADQgCAGABAEQAFAIAAANIAAALQAAABgBAAQAAAAAAABQAAAAgBAAQAAAAAAAAQgBAAAAAAQAAAAgBAAQAAAAAAgBQgBAAAAAAQgCgEgBgJQgGAGABAJQABAIAGAJQAAAAAAABQAAABAAAAQAAABgBAAQAAAAgBABIgBAAQgCAAgDgCg");
	this.shape_25.setTransform(81.8,140.6,0.911,0.911);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#0D4369").s().p("AgOB8QABghgBg7IgChaQAAgDgFAAQgEACgBgEQgGgNgGgSQgGgUABgJIBXAEQABApgFA/QgGBKgBBBg");
	this.shape_26.setTransform(91.4,148.8,0.911,0.911);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#6D4826").s().p("AgYACIAAgDIAxAAIAAADg");
	this.shape_27.setTransform(92.3,162,0.911,0.911);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#49250D").s().p("AgWATQgCgEAAgGQAAgLAHgIQAIgIAJgBQAKABAIAIQAGAIABALQAAAGgCAEg");
	this.shape_28.setTransform(92.3,160.5,0.911,0.911);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#0D4369").s().p("AgBAAQAAAAAAAAQAAAAAAgBQABAAAAAAQAAAAAAAAQABAAAAAAQABAAAAAAQAAABAAAAQAAAAAAAAQAAAAAAABQAAAAAAABQAAAAgBAAQAAAAgBAAQAAAAAAAAQAAAAgBAAQAAgBAAAAQAAgBAAAAg");
	this.shape_29.setTransform(78.6,132.1,0.911,0.911);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#0D4369").s().p("AgCAAQABAAAAAAQAAgBAAAAQAAAAABAAQAAgBAAAAQABAAAAABQABAAAAAAQAAAAAAABQABAAAAAAQAAABgBAAQAAABAAAAQAAAAgBAAQAAABgBAAQAAAAAAgBQgBAAAAAAQAAAAAAgBQAAAAgBgBg");
	this.shape_30.setTransform(78.6,130.4,0.911,0.911);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#0D4369").s().p("AgCAAQABAAAAAAQAAgBAAAAQAAAAABAAQAAgBAAAAQABAAAAABQABAAAAAAQAAAAAAABQABAAAAAAQAAABgBAAQAAABAAAAQAAAAgBAAQAAABgBAAQAAAAAAgBQgBAAAAAAQAAAAAAgBQAAAAgBgBg");
	this.shape_31.setTransform(78.6,128.8,0.911,0.911);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#156E92").s().p("AgRAaIAXhFIAMAGIgFAUIgNAEIAIAKIgZAvg");
	this.shape_32.setTransform(79.7,123.9,0.911,0.911);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#125974").s().p("AglBSIAAhfIAchEQAWAKAJAIQAMAMACAWQAEAogDA8IgXAAIgBhDIgEBOg");
	this.shape_33.setTransform(81.6,127.5,0.911,0.911);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#F0FAFC").s().p("AgLAAQALgDAHgHIAFADIgMASg");
	this.shape_34.setTransform(79.2,120.7,0.911,0.911);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#1175A1").s().p("AgIgDIAIgKIgMgEIgFgUIANgGIAWBFIAAASg");
	this.shape_35.setTransform(76.4,123.9,0.911,0.911);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#125974").s().p("AgJBSIgEhOIgBBDIgXAAQgDg2AEguQACgWANgMQAIgIAWgKIAdBEIABBfg");
	this.shape_36.setTransform(74.6,127.5,0.911,0.911);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#F0FAFC").s().p("AgLgHIAEgDQAHAHAMADIgLALg");
	this.shape_37.setTransform(77,120.7,0.911,0.911);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#FC5633").s().p("AgGAOIADgnIAHAAIADAnIgHAMg");
	this.shape_38.setTransform(78.1,124,0.911,0.911);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#FC391F").s().p("AgDAGIgDgKIANAAIgDAKg");
	this.shape_39.setTransform(78.1,121.1,0.911,0.911);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#F1C199").s().p("AgRgiIARgBQADgBADADQAEADABAFIACAQIAAAAQAFAAAAAFQAAAEgCAEQgDAFgDgBQgIAYgTAFg");
	this.shape_40.setTransform(79.7,116.6,0.911,0.911);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#F1C199").s().p("AgJAIQgDABgDgFIgCgIQAAgFAFAAIAAAAIACgQQABgFAEgDQADgDADABIARABIAABGIAAABQgSgFgJgYg");
	this.shape_41.setTransform(76.5,116.6,0.911,0.911);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#DFAC81").s().p("AgTAIIAAgXIAnAAIAAAXQgKAIgKAAQgJAAgKgIg");
	this.shape_42.setTransform(78.1,119.2,0.911,0.911);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#B3D8DD").s().p("AgNAtIAAhSIADgBQANgHALgBIAABdIgbgCg");
	this.shape_43.setTransform(76.8,123.5,0.911,0.911);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#B3D8DD").s().p("AgNguQAKABAOAHIADABIAABSQgOACgNAAg");
	this.shape_44.setTransform(79.3,123.5,0.911,0.911);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#8A480F").s().p("AgQAdIAAg6QAaAGAGAPQACAHgCALIgCAUg");
	this.shape_45.setTransform(79.7,113.8,0.911,0.911);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#8A480F").s().p("AgfAeIgCgeQAAgSAHgLQAOgDASAGQAVAHAFAMQACAHgBALIgDAUg");
	this.shape_46.setTransform(78.2,113.7,0.911,0.911);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#EB3637").s().p("AgTABIADgGQARAEARgEIACAFQgKAGgKAAQgJAAgKgFg");
	this.shape_47.setTransform(78,119.9,0.911,0.911);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#0D4369").s().p("AgYBcQAAgwgFg3QgDguABgfIBAgDQAAAHgEAPQgEANgFAJQgBABAAABQAAAAgBAAQAAABgBAAQgBAAAAAAQgBgBgBAAQAAAAgBAAQAAABAAAAQAAAAAAABIgCBCIAABFg");
	this.shape_48.setTransform(76.9,141.7,0.911,0.911);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#6D4826").s().p("AgRACIAAgDIAjAAIAAADg");
	this.shape_49.setTransform(76.2,151.4,0.911,0.911);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#49250D").s().p("AgQAPQgBgEAAgFQAAgHAFgHQAGgGAGAAQAIAAAFAGQAFAHAAAHQAAAFgBAEg");
	this.shape_50.setTransform(76.2,150.3,0.911,0.911);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#DFAC81").s().p("AgFAaQAAgBgBAAQAAAAAAAAQAAgBAAAAQAAAAAAgBQAEgGABgGQABgGgEgFQgBAGgCADQAAAAgBABQAAAAAAAAQAAAAgBAAQAAABAAAAQgBgBAAAAQAAAAAAAAQAAAAAAgBQAAAAAAAAIgBgIQAAgKAEgGQABgEgCgDIAQgDQgBAFACAEQACACABAIQAAAGgBAGQgFANgGAGIgEABIgBAAg");
	this.shape_51.setTransform(83.9,135.5,0.911,0.911);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#F1C199").s().p("AABAYQgGgFgFgNQgBgGABgGQAAgIACgDQACgDgBgFIAQADQgCADABAEQAEAFAAAKIgBAIQAAABAAAAQAAAAAAAAQAAABAAAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQAAAAAAgBQgBAAAAAAQgCgDgBgHQgDAHAAAFQABAGAEAGQAAAAAAABQAAAAAAABQAAAAAAAAQgBABAAAAIgBAAIgEgCg");
	this.shape_52.setTransform(72.2,135.6,0.911,0.911);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#0D4369").s().p("AgKBcIAAhFIgChCQAAgBAAAAQAAAAgBgBQAAAAgBAAQAAAAgBABQgBAAgBAAQAAAAgBgBQAAAAAAAAQgBgBAAgBQgFgJgEgNQgEgPAAgHIBAADQACAfgEAuQgFA3AAAwg");
	this.shape_53.setTransform(79.3,141.7,0.911,0.911);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#6D4826").s().p("AgRACIAAgDIAjAAIAAADg");
	this.shape_54.setTransform(80,151.4,0.911,0.911);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#49250D").s().p("AgQAPIgBgJQAAgHAFgHQAFgGAHAAQAHAAAGAGQAFAHAAAHQAAAFgBAEg");
	this.shape_55.setTransform(80,150.3,0.911,0.911);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#0D4369").s().p("AgCAAQAAAAABAAQAAgBAAAAQAAAAABAAQAAAAAAAAQABAAAAAAQABAAAAAAQAAAAAAABQABAAAAAAQAAABgBAAQAAABAAAAQAAAAgBAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQAAAAAAgBQgBAAAAgBg");
	this.shape_56.setTransform(101.8,132,0.911,0.911);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#0D4369").s().p("AgCAAQAAAAABAAQAAAAAAgBQAAAAABAAQAAAAAAAAQABAAAAAAQABAAAAAAQAAABAAAAQABAAAAAAQAAABgBAAQAAABAAAAQAAAAgBAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQAAAAAAgBQgBAAAAgBg");
	this.shape_57.setTransform(101.8,130.3,0.911,0.911);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#0D4369").s().p("AgCAAQAAAAABAAQAAAAAAgBQAAAAABAAQAAAAAAAAQABAAAAAAQABAAAAAAQAAABAAAAQABAAAAAAQAAAAgBABQAAAAAAABQAAAAgBAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQAAgBAAAAQgBgBAAAAg");
	this.shape_58.setTransform(101.8,128.7,0.911,0.911);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#156E92").s().p("AgRAbIAWhGIANAGIgFAUIgNAEIAIAJIgZAwg");
	this.shape_59.setTransform(103,123.8,0.911,0.911);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#125974").s().p("AglBSIAAhfIAchEQAWAKAJAIQAMAMACAWQAEAogDA8IgXAAIAAhDIgFBOg");
	this.shape_60.setTransform(104.8,127.5,0.911,0.911);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#F0FAFC").s().p("AgLAAQAMgDAGgHIAFADIgMASg");
	this.shape_61.setTransform(102.4,120.6,0.911,0.911);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#1175A1").s().p("AgIgDIAIgKIgMgEIgFgUIANgGIAWBGIAAARg");
	this.shape_62.setTransform(99.7,123.8,0.911,0.911);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#125974").s().p("AgJBSIgEhOIgBBDIgXAAQgCg2ADguQACgWANgMQAIgIAWgKIAdBEIABBfg");
	this.shape_63.setTransform(97.9,127.5,0.911,0.911);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#F0FAFC").s().p("AgLgHIAEgDQAHAIAMACIgLALg");
	this.shape_64.setTransform(100.2,120.6,0.911,0.911);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#FC5633").s().p("AgFAOIACgnIAHAAIACAnIgGAMg");
	this.shape_65.setTransform(101.3,123.9,0.911,0.911);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#FC391F").s().p("AgDAFIgDgJIANAAIgDAJg");
	this.shape_66.setTransform(101.3,121,0.911,0.911);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#F1C199").s().p("AgRgiIARgBQADgBAEADQADADABAFIACAPIAAAAQAFAAAAAGQAAAEgCADQgDAGgDgBQgJAYgSAEg");
	this.shape_67.setTransform(102.9,116.5,0.911,0.911);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#F1C199").s().p("AARAkQgRgEgJgYQgDABgDgGQgCgDAAgEQAAgGAFAAIAAAAIACgPQABgFADgDQAEgDADABIARABIAABGg");
	this.shape_68.setTransform(99.7,116.5,0.911,0.911);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#DFAC81").s().p("AgTAIIAAgXIAnAAIAAAXQgKAIgKAAQgJAAgKgIg");
	this.shape_69.setTransform(101.3,119.1,0.911,0.911);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#B3D8DD").s().p("AgNAuIAAhTIADgBQANgHALgBIAABdQgOAAgNgBg");
	this.shape_70.setTransform(100.1,123.4,0.911,0.911);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#B3D8DD").s().p("AgNguQAKABAOAHIADABIAABTQgOABgNAAg");
	this.shape_71.setTransform(102.6,123.4,0.911,0.911);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#8A480F").s().p("AgQAdIAAg6QAaAHAGAOQACAHgCALIgCAUg");
	this.shape_72.setTransform(102.9,113.7,0.911,0.911);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#8A480F").s().p("AgeAeIgDgeQAAgSAHgLQAOgDASAGQAVAHAFAMQACAHgBALIgDAUg");
	this.shape_73.setTransform(101.4,113.6,0.911,0.911);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#EB3637").s().p("AgTAAIADgFQAQAEASgEIACAFQgKAGgKAAQgIAAgLgGg");
	this.shape_74.setTransform(101.3,119.8,0.911,0.911);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#0D4369").s().p("AgYBcQAAgxgEg2QgEgvABgeIBAgDQAAAHgEAPQgEANgFAKQAAAAgBABQAAAAAAAAQgBABAAAAQgBAAgBgBQgBAAAAAAQgBAAgBAAQAAABAAAAQAAABAAAAIgCBDIAABEg");
	this.shape_75.setTransform(100.1,141.6,0.911,0.911);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#6D4826").s().p("AgRACIAAgDIAjAAIAAADg");
	this.shape_76.setTransform(99.5,151.4,0.911,0.911);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#49250D").s().p("AgQAPQgBgEAAgEQAAgIAFgHQAGgFAGAAQAIAAAFAFQAFAHAAAIIgBAIg");
	this.shape_77.setTransform(99.5,150.2,0.911,0.911);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#DFAC81").s().p("AgFAaQgBgBAAAAQAAAAAAAAQAAgBAAAAQAAAAAAgBQAEgGAAgGQABgFgEgHIgCAKQAAAAAAABQgBAAAAAAQAAAAgBAAQAAABgBAAQAAgBAAAAQAAAAgBAAQAAAAAAgBQAAAAAAAAIAAgIQAAgKADgGQACgDgCgEIAQgDQgBAFABAEQAFAHgCAPQgEANgIAGIgDABIgBAAg");
	this.shape_78.setTransform(107.2,135.5,0.911,0.911);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#F1C199").s().p("AABAYQgGgFgFgOQgBgFABgHQAAgHACgDQACgEgBgEIAQACQgCAEABAEQAEAFAAAKIAAAIQAAABAAAAQAAAAgBAAQAAABAAAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQAAAAAAgBQgBAAAAAAQgCgDgBgHQgEAGABAGQABAGAEAGQAAAAAAABQAAAAAAAAQAAABAAAAQgBAAAAABIgBAAIgEgCg");
	this.shape_79.setTransform(95.5,135.5,0.911,0.911);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#0D4369").s().p("AgKBcIAAhEIgChDQAAAAAAgBQAAAAgBgBQAAAAgBAAQAAAAgBAAQgBABAAAAQgBAAgBgBQAAAAAAAAQgBgBAAAAQgFgKgEgNQgEgPAAgHIBBADQABAegEAvQgFA2AAAxg");
	this.shape_80.setTransform(102.6,141.6,0.911,0.911);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#6D4826").s().p("AgRACIAAgDIAjAAIAAADg");
	this.shape_81.setTransform(103.2,151.4,0.911,0.911);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#49250D").s().p("AgQAPQgBgEAAgEQAAgIAFgHQAFgFAHAAQAHAAAGAFQAFAHAAAIQAAAEgBAEg");
	this.shape_82.setTransform(103.2,150.2,0.911,0.911);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#6DB5C5").s().p("AgoAHIAehOIAkAuQAGAvAJAnIhGALQgHgjgEgeg");
	this.shape_83.setTransform(30.8,97.4,0.911,0.911);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#6DB5C5").s().p("AAIgiQAEAeAHAhIglAGg");
	this.shape_84.setTransform(26.3,101.2,0.911,0.911);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#6DB5C5").s().p("AgfgqIA/BOIgwAHQgKgmgFgvg");
	this.shape_85.setTransform(36.1,98.9,0.911,0.911);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#6DB5C5").s().p("AgtADQAjgaAfggIAtA3QgXAWgZAUIhTAOg");
	this.shape_86.setTransform(127.1,133.9,0.911,0.911);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#6DB5C5").s().p("AALgVIAaAfIhJAMQAZgUAWgXg");
	this.shape_87.setTransform(132.1,135.8,0.911,0.911);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#6DB5C5").s().p("AADgvIAfAlQggAggjAbg");
	this.shape_88.setTransform(126,129.8,0.911,0.911);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#6DB5C5").s().p("AAUAzQgngfgsgYIAvg2QAbAQAXAQIAeBVg");
	this.shape_89.setTransform(121.4,41,0.911,0.911);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#6DB5C5").s().p("AgZAAIAcgfIAXA/QgXgPgcgRg");
	this.shape_90.setTransform(122.2,35.6,0.911,0.911);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#6DB5C5").s().p("Ag4AGIAdghQArAZApAeg");
	this.shape_91.setTransform(118.1,43.1,0.911,0.911);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#6DB5C5").s().p("AgzAhQhKhqgeh+IBHgLQAaBsA+BdQA+BaBaBAIgfBCQhphJhHhpg");
	this.shape_92.setTransform(42.3,122.1,0.911,0.911);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#6DB5C5").s().p("AlkAeQBbg8BpgcQBtgeBwAIQCeAJCKBPIguA2Qh2g/iIgJQhjgGhfAYQhcAYhQAzg");
	this.shape_93.setTransform(87.3,35,0.911,0.911);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#6DB5C5").s().p("Ah7C4QBFhVAvhsQAuhxAOh4IBIgDQgOCLg3CBQg2B9hSBig");
	this.shape_94.setTransform(140,112,0.911,0.911);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#D25558").s().p("AhhBhQgBAAAAAAQgBAAAAAAQAAAAgBgBQAAAAAAgBIAAipQAAgKAIgHQAHgFANAAIBaAAQAZAAAfA8QAbA2AAAbIAAAyQAAABAAAAQAAABgBAAQAAAAAAAAQgBAAAAAAgAA6AmQgBgdgQgfQgRgigPAAIhEAAIAABeIB1AAIAAAAg");
	this.shape_95.setTransform(150.8,63.9,0.911,0.911);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#D25558").s().p("AhqAnQgBAAAAAAQgBAAAAAAQgBAAAAAAQAAgBgBAAQAAAAAAgBQgBAAAAgBQAAAAAAgBQAAAAAAgBIAAgIQAAgRgIgOQgIgPgOgJQgDgCABgEQABgDAEAAIEVAAQAFAAAAAEQAAADgDACQgOAJgHAPQgIAOAAARIAAAIQAAABAAAAQAAABAAAAQAAABAAAAQgBABAAAAQAAAAgBABQAAAAAAAAQgBAAAAAAQgBAAgBAAg");
	this.shape_96.setTransform(134.8,77.5,0.911,0.911);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#D25558").s().p("AAAAlIgBgBIgBgCIABgIQAAgSgIgPQgJgOgOgKQgBAAAAgBQAAAAAAAAQgBgBAAAAQAAgBABAAQAAAAAAgBQAAAAAAgBQAAAAABAAQAAAAABAAIBAAAQAAAAAAAAQABAAAAABQAAAAAAAAQABABAAAAIAABFQAAAAgBABQAAAAAAAAQAAABgBAAQAAAAAAAAg");
	this.shape_97.setTransform(156.8,77.5,0.911,0.911);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#D25558").s().p("AgnAUQAAAAgBAAQAAgBAAAAQgBAAAAgBQAAAAAAgBIAAghQAAgBAAAAQAAgBABAAQAAAAAAgBQABAAAAAAIBPAAQAAAAABAAQAAAAAAABQABAAAAAAQAAABAAAAQAAABAAAAQAAAAAAABQAAAAAAABQgBAAAAAAQgTAMgIAUQAAABAAAAQAAAAAAAAQAAABgBAAQAAAAgBAAg");
	this.shape_98.setTransform(112.2,75.9,0.911,0.911);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#A5A4A4").s().p("AglAnQgPgQAAgXQAAgWAPgQQAQgRAVAAQAWAAAPARQAQAQAAAWQAAAXgQAQQgPARgWAAQgVAAgQgRgAgRgSQgIAIAAAKQAAALAIAIQAHAIAKAAQALAAAHgIQAHgIAAgLQAAgKgHgIQgHgIgLAAQgKAAgHAIg");
	this.shape_99.setTransform(118.8,80.1,0.911,0.911);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#A5A4A4").s().p("AgkAnQgQgQAAgXQAAgWAQgQQAPgRAVAAQAWAAAPARQAQAQAAAWQAAAXgQAQQgPARgWAAQgVAAgPgRgAgRgSQgHAIgBAKQABALAHAIQAIAIAJAAQALAAAHgIQAHgIAAgLQAAgKgHgIQgHgIgLAAQgJAAgIAIg");
	this.shape_100.setTransform(150.8,80,0.911,0.911);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#F5AB9C").s().p("AiqB2QAAAAgBAAQAAAAgBAAQAAgBAAAAQAAgBAAAAIAAjnQAAAAAAgBQAAAAAAgBQABAAAAAAQABAAAAAAIFVAAQABAAAAAAQABAAAAAAQAAABAAAAQAAABAAAAIAADnQAAAAAAABQAAAAAAABQAAAAgBAAQAAAAgBAAg");
	this.shape_101.setTransform(124.5,62,0.911,0.911);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f().s("#E9F4E9").p("AAcBJQgYACg2gQQgqgMgyATIg6hdQA2gfAegKIALgCQAJgCARAAIAqADQAQACAJACIAPADQAQAFAIAEQALAEAFAEIAAAAQAPAKACAMQABAHgCAFIALgHQAGgFAKgEQAKgGAPgHQAigNATgDIABAAQAOgCAKAEQANAEABANQACAWhJArQhHArghACg");
	this.shape_102.setTransform(44.7,73.9,0.911,0.911);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("#D25558").s().p("AArgmIgZAAIAACDIgQgJIAAhkIgYAAIAABfIgRgFIAAg9IgZAAIAAA6IgQgDIAAgWIgZAAIAAAWIgkAFIgBAAQgGgVAAgXQgBg+AtgsQArgrA9AAQA+AAArArQAsAsAAA+QABAcgLAbQgQACgVAHIgRAHIAAigIgaAAIAACsIgQAJg");
	this.shape_103.setTransform(47.1,60.1,0.911,0.911);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f("#B6E9B7").s().p("AgGAJQgEgDAAgFQgBgDADgEQADgEAFAAQADgBAEADQAEADAAAFQABADgDAEQgDAEgFAAIgBAAQgDAAgDgCg");
	this.shape_104.setTransform(27.1,80.3,0.911,0.911);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f("#D25558").s().p("Ag+g/IBAgUIA6BdIADAYIhvAyg");
	this.shape_105.setTransform(25.3,79.5,0.911,0.911);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f("#F5AB9C").s().p("AgzA7QgqgMgyATIg6hdQA7ghAZgIIALgCQAJgCARAAIBDAHIAPAEIAYAIQAJADAHAFQAPAKACAMQABAHgCAGIhpgBQBeAaALgZIALgIIAQgJIAZgNQAggMAVgEIABAAQAOgCAKAEQANAEABANQACAWhJArQhHArghACIgGAAQgXAAgxgOg");
	this.shape_106.setTransform(44.8,74,0.911,0.911);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f("#DFE5DF").s().p("AlaM0QifhEh7h7Qh7h7hEifQhGimAAi1QAAi0BGilQBEigB7h8QB7h6CfhEQCmhGC0AAQC1AAClBGQCgBEB7B6QB7B8BECgQBGClAAC0QAAC1hGCmQhECfh7B7Qh7B7igBEQilBGi1AAQi0AAimhGg");
	this.shape_107.setTransform(91.5,91.3,0.911,0.911);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f("#EFEFEF").s().p("AmGOcQi0hMiKiLQiLiLhMizQhPi7AAjMQAAjLBPi7QBMizCLiLQCKiLC0hMQC7hPDLAAQDMAAC7BPQCzBMCLCLQCLCLBMCzQBPC7AADLQAADMhPC7QhMCziLCLQiLCLizBMQi7BPjMAAQjLAAi7hPg");
	this.shape_108.setTransform(91.4,91.4,0.911,0.911);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_108},{t:this.shape_107},{t:this.shape_106},{t:this.shape_105},{t:this.shape_104},{t:this.shape_103},{t:this.shape_102},{t:this.shape_101},{t:this.shape_100},{t:this.shape_99},{t:this.shape_98},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_94},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,182.8,182.8);


(lib.CirculoRojo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D73D45").s().p("AoZIYQjejdAAk7QAAk6DejfQDfjeE6AAQE7AADdDeQDgDfAAE6QAAE7jgDdQjdDgk7AAQk6AAjfjgg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-75.9,-76,152,152);


(lib.circulo_blanco = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AmrGsQixixAAj7QAAj6CxixQCxixD6AAQD7AACxCxQCxCxAAD6QAAD7ixCxQixCxj7AAQj6AAixixg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-60.5,-60.5,121,121);


(lib.barrabcdespliega = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Eu28AH9UmJ9gDTAAAgEqUAAAgEqGJ9gDTUGJ+gDTIs+AAAUIs/AAAGJ+ADTUGJ9ADTAAAAEqUAAAAEqmJ9ADTUmJ+ADUos/AAAUos+AAAmJ+gDUg");
	this.shape.setTransform(6978.4,72,1,1,0,180,0);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1629,0,17214.9,144.2);


(lib.AS_LG_153 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(2,0,0,4).p("ABKhhQAcAeAAAoQAAAVgMAVQgJATgQARQgJAIgDAIQgEAHAAAPIAAATQAAAJgGAGQgGAHgJAAIg3AAQgJAAgGgHQgHgGAAgJIAAgTQAAgPgDgHQgDgIgIgIQgRgRgKgTQgLgVAAgVQAAgpAcgdQAcgdApgCIAKAAQAoACAcAdg");
	this.shape.setTransform(16.3,37.3,1.111,1.111);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AitAjQgRAAgNgKQgNgLAAgOQAAgOANgJQANgLARAAIFbAAQARAAANALQAMAJAAAOQAAAOgMALQgNAKgRAAg");
	this.shape_1.setTransform(15.8,59.2,0.277,0.356);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AitAjQgRAAgNgKQgNgLAAgOQAAgOANgJQANgLARAAIFbAAQARAAANALQAMAJAAAOQAAAOgMALQgNAKgRAAg");
	this.shape_2.setTransform(15.8,55.7,0.277,0.356);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("rgba(0,0,0,0.067)").s().p("AjRBWIA7gGQA7gFAAgBQgBgBABhvQAUgtAAgCIANgSQAOgQAAgBQgBgCAUg9IgXhKQAEgDDoDkIAWAVQgHAfgMAeQgaA9gwAwQgvAvg+AaQg4AYg/ACg");
	this.shape_3.setTransform(29.3,50.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).to({state:[]},1).wait(6));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(3.5,21.9,46.8,54.3);


(lib.tema_entrada_titulo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_99 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(99).call(this.frame_99).wait(1));

	// destape TITULO
	this.instance = new lib.mascaratapar("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(-0.6,-226.5,1,1,0,0,0,303.1,17);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(87).to({_off:false},0).to({alpha:0},12,cjs.Ease.get(1)).wait(1));

	// TITULO
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgaAaQgLgKAAgQQAAgOALgLQAMgLAOAAQAPAAALALQALALAAAOQAAAQgLAKQgLALgPAAQgOAAgMgLg");
	this.shape.setTransform(-293.7,-229);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#D73D45").s().p("AgtAuQgTgTAAgbQAAgaATgTQATgTAaAAQAbAAATATQATATAAAaQAAAbgTATQgTATgbAAQgaAAgTgTg");
	this.shape_1.setTransform(-293.8,-229.1);

	this.text = new cjs.Text("Panorama general", "20px 'Arial'", "#333333");
	this.text.lineHeight = 22;
	this.text.parent = this;
	this.text.setTransform(-282,-240.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text},{t:this.shape_1},{t:this.shape}]},87).wait(13));

	// txt tit
	this.instance_1 = new lib.titulo("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(153.2,54.8,1,1,0,0,0,94.9,73.4);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(15).to({_off:false},0).wait(51).to({y:32.8},0).to({regX:95,regY:73.6,scaleX:0.04,scaleY:0.04},15,cjs.Ease.get(1)).to({_off:true},1).wait(18));

	// circulo bco
	this.instance_2 = new lib.circulo_blanco("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(150.7,20.1,0.24,0.24,0,0,0,1.3,0.4);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(5).to({_off:false},0).to({regX:0,regY:0,scaleX:2,scaleY:2,x:149.3,alpha:1},10,cjs.Ease.get(1)).wait(62).to({startPosition:0},0).to({scaleX:11.1,scaleY:11.1,x:180.3,y:0},10,cjs.Ease.get(1)).to({_off:true},1).wait(12));

	// circulo rojo
	this.instance_3 = new lib.CirculoRojo("synched",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(150.4,0,0.033,0.033);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({scaleX:2,scaleY:2,y:20},9,cjs.Ease.get(1)).wait(63).to({startPosition:0},0).to({regX:0.1,regY:-0.2,scaleX:9.88,scaleY:9.88,x:201,y:-22.2},11,cjs.Ease.get(1)).to({_off:true},5).wait(12));

	// Layer 6
	this.instance_4 = new lib.numerodetema("synched",0);
	this.instance_4.parent = this;
	this.instance_4.setTransform(98.1,-13.6,1,1,0,0,0,69.8,69.7);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(15).to({_off:false},0).to({x:-40.1,y:-113.6},9,cjs.Ease.get(1)).wait(41).to({startPosition:0},0).to({x:98.1,y:-13.6},12,cjs.Ease.get(1)).to({_off:true},1).wait(22));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(147.9,-2.5,5,5);


(lib.perfoles1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#87AE65").s().p("AACAkIAAgzQgGAHgLAEIAAgNQAFgBAHgGQAFgEADgHIALAAIAABHg");
	this.shape.setTransform(136.7,97.8,0.911,0.911);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#F9AF48").s().p("AgcAdQgMgMAAgRQAAgQAMgMQAMgMAQAAQARAAAMAMQAMAMAAAQQAAARgMAMQgMAMgRAAQgQAAgMgMg");
	this.shape_1.setTransform(137.4,97.8,0.911,0.911);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#EED264").s().p("AALBDQgIgDgDAAQgCAAgIADQgIADgDgBQgEgBgEgHQgFgIgDgBIgLgEQgHgCgCgDQgDgEABgHQAAgKgBgCIgGgKQgFgGAAgEQAAgDAFgGIAGgKQABgCAAgKQgBgHADgDQACgEAHgCQAJgCACgCQADgBAFgIQAEgGAEgCQADgBAIADQAIADACAAQADAAAIgDQAIgDADABQAEACAEAGQAFAIADABQACACAJACQAHACACAEQADADgBAHIABAMIAGAKQAFAGAAADQAAAEgFAGIgGAKIgBAMQABAHgDAEQgCADgHACIgLAEQgDABgFAIQgEAHgEABIgCAAIgJgCg");
	this.shape_2.setTransform(137.4,97.8,0.911,0.911);

	this.instance = new lib.ClipGroup_10();
	this.instance.parent = this;
	this.instance.setTransform(134,104.7,0.911,0.911,0,0,0,5.5,6.7);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#6CC1A4").s().p("AgNAiIgkAEIArhjIA4AYIgrBjg");
	this.shape_3.setTransform(133.7,105.2,0.911,0.911);

	this.instance_1 = new lib.ClipGroup_9();
	this.instance_1.parent = this;
	this.instance_1.setTransform(141.6,104.7,0.911,0.911,0,0,0,5.4,6.7);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#6CC1A4").s().p("AgxglIA4gYIArBjIgkgEIgUAcg");
	this.shape_4.setTransform(141.3,105.2,0.911,0.911);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#87AE65").s().p("AACAkIAAgzQgGAHgLAEIAAgNQAFgBAHgGQAFgEADgHIALAAIAABHg");
	this.shape_5.setTransform(90.3,97.8,0.911,0.911);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#F9AF48").s().p("AgcAdQgMgMAAgRQAAgQAMgMQAMgMAQAAQARAAAMAMQAMAMAAAQQAAARgMAMQgMAMgRAAQgQAAgMgMg");
	this.shape_6.setTransform(90.9,97.8,0.911,0.911);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#EED264").s().p("AALBDQgIgDgDAAQgCAAgIADQgIADgDgBQgEgBgEgHQgFgIgDgBIgLgEQgHgCgCgDQgDgEABgHQAAgKgBgCIgGgKQgFgGAAgEQAAgDAFgGIAGgKQABgCAAgKQgBgHADgDQACgEAHgCQAJgCACgCQADgBAFgIQAEgGAEgCQADgBAIADQAIADACAAQADAAAIgDQAIgDADABQAEACAEAGQAFAIADABQACACAJACQAHACACAEQADADgBAHIABAMIAGAKQAFAGAAADQAAAEgFAGIgGAKIgBAMQABAHgDAEQgCADgHACIgLAEQgDABgFAIQgEAHgEABIgCAAIgJgCg");
	this.shape_7.setTransform(90.9,97.8,0.911,0.911);

	this.instance_2 = new lib.ClipGroup_8();
	this.instance_2.parent = this;
	this.instance_2.setTransform(87.7,104.7,0.911,0.911,0,0,0,5.4,6.7);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#6CC1A4").s().p("AgOAiIgjAEIArhjIA4AYIgrBjg");
	this.shape_8.setTransform(87.2,105.2,0.911,0.911);

	this.instance_3 = new lib.ClipGroup_7();
	this.instance_3.parent = this;
	this.instance_3.setTransform(95.4,104.7,0.911,0.911,0,0,0,5.4,6.7);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#6CC1A4").s().p("AgxglIA4gYIArBjIgjgEIgWAcg");
	this.shape_9.setTransform(94.8,105.2,0.911,0.911);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#87AE65").s().p("AACAkIAAgzQgGAHgLAEIAAgNQAFgBAHgGQAFgEADgHIALAAIAABHg");
	this.shape_10.setTransform(44.7,97.8,0.911,0.911);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#F9AF48").s().p("AgcAdQgMgMAAgRQAAgQAMgMQAMgMAQAAQARAAAMAMQAMAMAAAQQAAARgMAMQgMAMgRAAQgQAAgMgMg");
	this.shape_11.setTransform(45.4,97.8,0.911,0.911);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#EED264").s().p("AALBDQgIgDgDAAQgCAAgIADQgIADgDgBQgEgBgEgHQgFgIgDgBIgLgEQgHgCgCgDQgDgEABgHQAAgKgBgCIgGgKQgFgGAAgEQAAgDAFgGIAGgKQABgCAAgKQgBgHADgDQACgEAHgCQAJgCACgCQADgBAFgIQAEgGAEgCQADgBAIADQAIADACAAQADAAAIgDQAIgDADABQAEACAEAGQAFAIADABQACACAJACQAHACACAEQADADgBAHIABAMIAGAKQAFAGAAADQAAAEgFAGIgGAKIgBAMQABAHgDAEQgCADgHACIgLAEQgDABgFAIQgEAHgEABIgCAAIgJgCg");
	this.shape_12.setTransform(45.4,97.8,0.911,0.911);

	this.instance_4 = new lib.ClipGroup_6();
	this.instance_4.parent = this;
	this.instance_4.setTransform(42,104.7,0.911,0.911,0,0,0,5.4,6.7);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#6CC1A4").s().p("AgOAiIgjAEIArhjIA4AYIgrBjg");
	this.shape_13.setTransform(41.6,105.2,0.911,0.911);

	this.instance_5 = new lib.ClipGroup_5();
	this.instance_5.parent = this;
	this.instance_5.setTransform(49.7,104.7,0.911,0.911,0,0,0,5.4,6.7);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#6CC1A4").s().p("AgxglIA4gYIArBjIgjgEIgVAcg");
	this.shape_14.setTransform(49.3,105.2,0.911,0.911);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#3F3231").s().p("Ah9BcIgJgCQgBAAgDgHQgFgQgHgrQgFgiAdgXQgDguAogTIgGAKQgHAMgCAJQAAAAAAAAQAAAAAAABQAAAAAAAAQAAAAAAAAIACAAQAPgRAagMQApgUA7gBQgWADgPAJQgBAAAAABQAAAAAAAAQAAAAAAABQAAAAAAABQAAAAAAAAQAAABABAAQAAAAABAAQAAAAAAAAQAZgDAZADQAmADAYAQQgHgCgKABIgBABQAAAAAAAAQAAAAAAABQAAAAABAAQAAAAAAAAQASAHAOAOQAVAUAAAdIgNgPIgBAAIAAABQAHAWgFAWQgBgGgIgHQgBAjgKAuQgKgBgGALIgFAMQABgQgBgUQgCgmgKgPQgagohIACIhDAJQgNAfgRASQgBAGgCAkIgCAiQgBgTgKgGg");
	this.shape_15.setTransform(137.8,65.1,0.911,0.911);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#3F3231").s().p("AAgAVQgGgBgEgEQgHgFAAgHIAAgCQgHgFgFABIgBAAQgEgBgIAFIAAACQAAAHgGAFQgFAEgGABIg1AAIgBAAQgJgEgEgFQgDgFABgEIAAgDIgQABIgCgJIATgDQAEgIAMgBIAAAAIAxAAQAOAAAFAKQAHgDAGAAQAIAAAGADQAHgKANAAIAwAAIABAAQALABAFAIIAOACIgBAGIgMADIAAADQAAAMgPAGIgBAAgAAXgKIAAAQIABAEQACADAFADIA5AAQAGgBAAgJIAAgPQgDgFgEAAIg5AAQgHABAAADgAhYgKIAAAQIABAEQACADAEADIA5AAQAGgBAAgJIAAgPQgBgFgGAAIg5AAQgGABAAADg");
	this.shape_16.setTransform(136.8,73.3,0.911,0.911);

	this.instance_6 = new lib.Group();
	this.instance_6.parent = this;
	this.instance_6.setTransform(155.1,97.1,0.911,0.911,0,0,0,1.8,4);
	this.instance_6.alpha = 0.391;

	this.instance_7 = new lib.Group_1();
	this.instance_7.parent = this;
	this.instance_7.setTransform(153.1,98.3,0.911,0.911,0,0,0,1.1,2.6);
	this.instance_7.alpha = 0.391;

	this.instance_8 = new lib.Group_2();
	this.instance_8.parent = this;
	this.instance_8.setTransform(152.9,96.8,0.911,0.911,0,0,0,2.2,4.8);
	this.instance_8.alpha = 0.391;

	this.instance_9 = new lib.Group_3();
	this.instance_9.parent = this;
	this.instance_9.setTransform(123.2,96.8,0.911,0.911,0,0,0,2.1,4.8);
	this.instance_9.alpha = 0.391;

	this.instance_10 = new lib.Group_4();
	this.instance_10.parent = this;
	this.instance_10.setTransform(122.3,97.8,0.911,0.911,0,0,0,1.2,3.2);
	this.instance_10.alpha = 0.391;

	this.instance_11 = new lib.Group_5();
	this.instance_11.parent = this;
	this.instance_11.setTransform(121.1,96.9,0.911,0.911,0,0,0,2,4.4);
	this.instance_11.alpha = 0.391;

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#A9B3BC").s().p("AgnAJIBAglIAOAcQgBALgUAKIgUAIg");
	this.shape_17.setTransform(141.1,92.2,0.911,0.911);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#A9B3BC").s().p("AgNAVQgZgOgBgKIAOgdIBBAuIgeATQgLgFgMgHg");
	this.shape_18.setTransform(133.8,91.7,0.911,0.911);

	this.instance_12 = new lib.Group_6();
	this.instance_12.parent = this;
	this.instance_12.setTransform(139.6,96.3,0.911,0.911,0,0,0,0.9,4.9);
	this.instance_12.alpha = 0.391;

	this.instance_13 = new lib.Group_7();
	this.instance_13.parent = this;
	this.instance_13.setTransform(142.3,96.3,0.911,0.911,0,0,0,1,5.4);
	this.instance_13.alpha = 0.391;

	this.instance_14 = new lib.Group_8();
	this.instance_14.parent = this;
	this.instance_14.setTransform(144.3,95.9,0.911,0.911,0,0,0,1,5);
	this.instance_14.alpha = 0.391;

	this.instance_15 = new lib.Group_9();
	this.instance_15.parent = this;
	this.instance_15.setTransform(150.9,96.3,0.911,0.911,0,0,0,0.9,5);
	this.instance_15.alpha = 0.391;

	this.instance_16 = new lib.Group_10();
	this.instance_16.parent = this;
	this.instance_16.setTransform(148.9,95.9,0.911,0.911,0,0,0,1,5.5);
	this.instance_16.alpha = 0.391;

	this.instance_17 = new lib.Group_11();
	this.instance_17.parent = this;
	this.instance_17.setTransform(146.4,95.8,0.911,0.911,0,0,0,1,5.5);
	this.instance_17.alpha = 0.391;

	this.instance_18 = new lib.Group_12();
	this.instance_18.parent = this;
	this.instance_18.setTransform(136.7,96.3,0.911,0.911,0,0,0,1.1,4.9);
	this.instance_18.alpha = 0.391;

	this.instance_19 = new lib.Group_13();
	this.instance_19.parent = this;
	this.instance_19.setTransform(134,96.3,0.911,0.911,0,0,0,1,5.4);
	this.instance_19.alpha = 0.391;

	this.instance_20 = new lib.Group_14();
	this.instance_20.parent = this;
	this.instance_20.setTransform(131.9,95.9,0.911,0.911,0,0,0,0.9,5);
	this.instance_20.alpha = 0.391;

	this.instance_21 = new lib.Group_15();
	this.instance_21.parent = this;
	this.instance_21.setTransform(125.4,96.3,0.911,0.911,0,0,0,0.7,5);
	this.instance_21.alpha = 0.391;

	this.instance_22 = new lib.Group_16();
	this.instance_22.parent = this;
	this.instance_22.setTransform(127.3,95.9,0.911,0.911,0,0,0,0.9,5.5);
	this.instance_22.alpha = 0.391;

	this.instance_23 = new lib.Group_17();
	this.instance_23.parent = this;
	this.instance_23.setTransform(129.8,95.8,0.911,0.911,0,0,0,0.9,5.5);
	this.instance_23.alpha = 0.391;

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#BBCACB").s().p("Ah0A+QAdhXAMgHQATgNApgHQATgEARgBQAkgMAhAUQAQAKAJAMIACBZg");
	this.shape_19.setTransform(128.3,96.6,0.911,0.911);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#CCD0D0").s().p("Ah4A+IAEhZIAZgWQAhgUAkAMIAlAFQApAHATANQAQAJAeBVg");
	this.shape_20.setTransform(147.2,96.6,0.911,0.911);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#E8AF93").s().p("AAQAAIgLgCIgDAAIgHABIgWAEQAEgDAJgDIAPgCIAFAAIAMACQAIAEACAFQgEgFgIgBg");
	this.shape_21.setTransform(131.9,72.2,0.911,0.911);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#E1BB93").s().p("AgUCbQgOgFgRgNQgjgYgUgiIgBgEIgBgWIgBAAQgDAAgDgCIgDgDIAAAAQgCgFgDgQIgEgbQgCgJAAgIQAAgHACgCQADgBAEAEQADACAAADIACgBQgEgSAAgVQAAgvAZgNIAbgUQAfgTAfAAIADAAIAAAAIABAAIABAAIAAAAIABAAIAAAAQAfgBAhAUQARAKAKAKIABAAQAYANAAAvQAAAVgEASIgBAEIADgDIAGgFQAEgDADABQAFADgEAUIgFAcQgDATgCACIAAABQgDAFgGAAIgBAAIgDAaQAAABAAAAQAAABAAAAQgBABAAAAQAAABAAAAQgKAPgQAQQgaAagcAPIgCAAQgGACgKABIgHAAQgKAAgKgDg");
	this.shape_22.setTransform(137.1,73.1,0.911,0.911);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#D6AE89").s().p("AgKA7QhVgDAVgVQATgTAJghIAFgfIApgJQAogGABAPQABAZAlBRQgdACgcAAIgggBg");
	this.shape_23.setTransform(137.4,87.5,0.911,0.911);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#C9C9C9").s().p("AgmBMIAWiXIAeApQAeAtgFAbIgHAmg");
	this.shape_24.setTransform(105.4,94.5,0.911,0.911);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#C9C9C9").s().p("AgdBGQgEgXgEgLQgMgoAgglQARgSARgKIAIAiQAHAlADAXIAGAtg");
	this.shape_25.setTransform(76.6,95.1,0.911,0.911);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#BBCACB").s().p("AgOAUQgXgOgCgKIAOgaIBBAoIggAVQgKgEgMgHg");
	this.shape_26.setTransform(87.3,87.1,0.911,0.911);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#BBCACB").s().p("AglAIIA9giIAOAaQgCAKgUAJIgSAIg");
	this.shape_27.setTransform(94.1,87.5,0.911,0.911);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#9D9393").s().p("AAdAaQgGgBgEgEQgHgHAAgJIAAgDQgGgFgFABIgBAAQgGgCgFAHIAAACQAAAJgGAHQgFAEgFABIgzAAIgBgBQgPgHAAgOIAAgFIgOACIgDgMIASgDQAFgJAKgCIAvAAQANAAAGAMQAGgEAGABQAHgBAGAEQAGgMAMAAIAvAAQAMACADAJIASADIgCAMIgOgCIAAAFQAAAOgOAHIgCABgAAagIIAAANQAAAGAFACIAsAAQAHgEAAgFIAAgNQAAgBgGgBIgtAAQgDgBgCAEgAhQgJIAAAOIABACQABADAEADIAsAAQAGgCAAgGIAAgNQgBgDgGAAIgsAAQgFABAAABg");
	this.shape_28.setTransform(90.2,68.7,0.911,0.911);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#71706F").s().p("ABqBBIgGgwQgCgIgGgJQgMgQgWABQgJAAgOAGQgpATgdgWIgBAAQgRgGgNABQgcADgFAdIgGAxQAAABAAAAQgBABAAAAQAAAAgBABQAAAAgBAAQAAAAgBAAQAAgBgBAAQAAAAAAgBQAAAAgBgBQgLhhAdgDQABAAAAAAQABAAAAAAQAAgBAAAAQAAgBAAAAIAHgIQAKgHAVgCQASgBAPgFQAOgGAKAAQBEgBAVAdIABACQAIAEAFAKQAJASgCAfIgCAnQAAABAAAAQgBABAAAAQAAAAgBABQAAAAgBAAQAAAAgBAAQAAgBgBAAQAAAAAAgBQAAAAgBgBg");
	this.shape_29.setTransform(90,60.6,0.911,0.911);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#EDAB86").s().p("AhEADIAjgEIARgBIAQAAQASAAARABIAiAEg");
	this.shape_30.setTransform(90.4,61.9,0.911,0.911);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#EDAB86").s().p("AhEADQARgDARgBIASAAIAQgBQARAAARABQASABARADg");
	this.shape_31.setTransform(90.3,63.4,0.911,0.911);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#F9BD9C").s().p("AgTCTQgNgFgRgMQghgXgTghIgBgDIAAgVIgBAAQgEAAgDgDIgCgCIAAAAIgFgUIgEgZQgCgJAAgHQAAgHADgCQACgBAEAEQABABAAAAQABAAAAABQABAAAAABQAAABAAAAIACAAIgCgMQgCgNAAgNQAAgtAYgLIAAAAIAZgTQAegSAdAAIAGAAQAdgBAfATQAQAJAKAKIABAAQAXALAAAtQAAAUgEASIgBAEIADgDQAIgIAEABQAEACgDAUIgEAbQgDASgCACIgBAAQgDAFgFAAIgBAAIgDAZIgBAEQgfAsgsAXIgCABQgLADgKAAQgKAAgKgDg");
	this.shape_32.setTransform(90.3,69.5,0.911,0.911);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#EDAB86").s().p("AgJA4QhSgDAVgUQASgSAIgfIAFgeIAngIQAmgFABANQABAYAjBNQgcACgaAAIgegBg");
	this.shape_33.setTransform(90.6,83.1,0.911,0.911);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#D6D8D8").s().p("Ai1BUIgBgYIAAg7QADgfAVgRQAVgQAigJQASgEANgBQA3gFA5gBQBAAAAQAGQAYAJAUAzQATAuAAApIgBAOg");
	this.shape_34.setTransform(91.5,93.9,0.911,0.911);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#7F795E").s().p("AgiAIIA4ggIANAYQgBAKgTAJIgRAGg");
	this.shape_35.setTransform(48.6,87.2,0.911,0.911);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#7F795E").s().p("AgMASQgVgNgCgIIANgZIA6AoIgbARIgVgLg");
	this.shape_36.setTransform(42.2,86.8,0.911,0.911);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#DAA675").s().p("ABmAiQgDgUgjAAQgtAEgVgBQgagBgYgSIgSgTQgLAogGAEQgEADgFAbIgFAaIgLgRQgMgRABgDQACgEACgLQACgPgDgLQgCgKAAgNQABgQAGgGIAAAAQgCgEAjgOQAngRAkgDQAmgDAvAbQAtAaABAVQABAWgEAaQgDAcgGABQgEABgGAJIgDAHQAIgSgFgfg");
	this.shape_37.setTransform(45,62,0.911,0.911);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#C4B98C").s().p("AhvBRQAnh+ANgJQAbgSA6gDQAggLAdARQAPAJAIALIACCCg");
	this.shape_38.setTransform(36.7,93.4,0.911,0.911);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#C4B98C").s().p("AhzBRIAFiCIAXgUQAdgRAgALIAgAEQAkAGARALQAJAGAQAlQAQAmAQA2g");
	this.shape_39.setTransform(54.6,93.4,0.911,0.911);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#F9BD9C").s().p("AgRCJQgMgFgQgLQgfgWgRgeIgBgDIgBgUIgBAAQgDAAgFgEIAAgBQgCgDgDgPIgDgXIgCgPQAAgHACgBQACgBAFADQAAABAAAAQABABAAAAQAAABAAAAQABABAAAAIACAAQgEgQAAgTQAAgqAWgKIABgBIAXgRQAcgRAbAAIAFAAQAcgBAdARQAPAJAJAJIAAABQAWAKAAAqQAAAMgCAMIgCALIAAAEIACgDQAIgIADACQAEACgDASIAAACIgEAXQgCAOgCAEIgBABQgDAEgFAAIgBAAIgCAYIgBADQgcApgrAWIgBABQgLADgKAAQgJAAgIgDg");
	this.shape_40.setTransform(45,70.4,0.911,0.911);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#EDAB86").s().p("AgIA0QhMgCATgTQAQgQAIgeIAFgcIAkgHQAkgFABAMQABAXAgBHQgaACgYAAIgcgBg");
	this.shape_41.setTransform(45.4,83.1,0.911,0.911);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#87AE65").s().p("AggA2QgIgFgJgQQgGgKgGgPQgDgIAEgEQAEgFAIgBQAFAAADAEIAHAKIAEAHIAVgYQAYgcAegMQAKgEAGABIABABIgEAEQgcAWgTAbQgOATgNAeIgCAEQgDAGgFAAQgDAAgEgDg");
	this.shape_42.setTransform(137.9,119,0.911,0.911);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#87AE65").s().p("AggA2QgIgFgJgQQgGgKgGgPQgDgIAEgEQAEgFAIgBQAFAAADAEIAHAKIAEAHIAVgYQAYgcAegMQAKgEAGABIABABIgEAEQgcAWgTAbQgOATgNAeIgCAEQgDAGgFAAQgDAAgEgDg");
	this.shape_43.setTransform(91.4,119,0.911,0.911);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#87AE65").s().p("AggA2QgIgFgJgQQgGgKgGgPQgDgIAEgEQAEgFAIgBQAEAAAEAEIAHAKIAEAHIAVgYQAYgcAegMQAKgEAGABIABABIgEAEQgcAWgTAbQgOATgNAeIgCAEQgDAGgFAAQgDAAgEgDg");
	this.shape_44.setTransform(46.8,119,0.911,0.911);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#DFE5DF").s().p("AlZM0QighEh8h7Qh6h7hEifQhGimAAi1QAAi0BGilQBEigB6h8QB8h6CghEQClhGC0AAQC1AACmBGQCfBEB7B6QB7B8BECgQBGClAAC0QAAC1hGCmQhECfh7B7Qh7B7ifBEQimBGi1AAQi0AAilhGg");
	this.shape_45.setTransform(91.8,90.3,0.911,0.911);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#EFEFEF").s().p("AmGOcQizhMiLiKQiLiMhMi0QhPi6AAjMQAAjLBPi6QBMi1CLiKQCLiLCzhMQC7hPDLAAQDMAAC6BPQC0BMCMCLQCKCKBMC1QBPC6AADLQAADMhPC6QhMC0iKCMQiMCKi0BMQi6BPjMAAQjLAAi7hPg");
	this.shape_46.setTransform(91.4,91.4,0.911,0.911);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.instance_23},{t:this.instance_22},{t:this.instance_21},{t:this.instance_20},{t:this.instance_19},{t:this.instance_18},{t:this.instance_17},{t:this.instance_16},{t:this.instance_15},{t:this.instance_14},{t:this.instance_13},{t:this.instance_12},{t:this.shape_18},{t:this.shape_17},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.instance_5},{t:this.shape_13},{t:this.instance_4},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.instance_3},{t:this.shape_8},{t:this.instance_2},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.instance_1},{t:this.shape_3},{t:this.instance},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,182.8,182.8);


(lib.mc_imagenmodulo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_24 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(24).call(this.frame_24).wait(1));

	// Capa_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("Ah7B7QgzgzAAhIQAAhIAzgzQAzgzBIAAQBJAAAzAzQAzAzAABIQAABIgzAzQgzA0hJAAQhIAAgzg0g");
	var mask_graphics_1 = new cjs.Graphics().p("AkNENQhwhvAAieQAAidBwhwQBwhwCdAAQCeAABvBwQBxBwAACdQAACehxBvQhvBxieAAQidAAhwhxg");
	var mask_graphics_2 = new cjs.Graphics().p("AmYGXQioioAAjvQAAjuCoiqQCqioDuAAQDvAACpCoQCpCqAADuQAADvipCoQipCqjvAAQjuAAiqiqg");
	var mask_graphics_3 = new cjs.Graphics().p("AoaIaQjfjeAAk8QAAk6DfjhQDfjdE7gBQE7ABDeDdQDhDhgBE6QABE8jhDeQjeDfk7ABQk7gBjfjfg");
	var mask_graphics_4 = new cjs.Graphics().p("AqVKTQkRkQAAmDQAAmCERkTQETkQGCgBQGDABEREQQESETAAGCQAAGDkSEQQkREUmDAAQmCAAkTkUg");
	var mask_graphics_5 = new cjs.Graphics().p("AsIMGQk/k/AAnHQAAnFE/lDQFDk/HFAAQHGAAFAE/QFCFDAAHFQAAHHlCE/QlAFDnGgBQnFABlDlDg");
	var mask_graphics_6 = new cjs.Graphics().p("AtzNwQlrlrAAoFQAAoDFrlwQFvlrIEAAQIEAAFsFrQFvFwAAIDQAAIFlvFrQlsFvoEAAQoEAAlvlvg");
	var mask_graphics_7 = new cjs.Graphics().p("AvWPTQmUmUAAo/QAAo9GUmYQGYmVI+AAQI/AAGUGVQGYGYAAI9QAAI/mYGUQmUGYo/AAQo+AAmYmYg");
	var mask_graphics_8 = new cjs.Graphics().p("AwxQuQm5m6AAp0QAApzG5m+QG+m5JzAAQJ0AAG5G5QG+G+AAJzQAAJ0m+G6Qm5G9p0AAQpzAAm+m9g");
	var mask_graphics_9 = new cjs.Graphics().p("AyESAQncnbAAqlQAAqjHcnhQHhncKjAAQKkAAHcHcQHhHhAAKjQAAKlnhHbQncHhqkAAQqjAAnhnhg");
	var mask_graphics_10 = new cjs.Graphics().p("AzPTLQn7n6AArRQAArPH7oAQH/n6LQAAQLQAAH7H6QIAIAAALPQAALRoAH6Qn7H/rQABQrQgBn/n/g");
	var mask_graphics_11 = new cjs.Graphics().p("A0SUOQoXoWABr4QgBr2IXodQIboVL3AAQL3AAIXIVQIcIdAAL2QAAL4ocIWQoXIcr3gBQr3ABobocg");
	var mask_graphics_12 = new cjs.Graphics().p("A1NVJQowouABsbQgBsZIwo0QIzowMaABQMagBIvIwQI1I0AAMZQAAMbo1IuQovI1saAAQsaAAozo1g");
	var mask_graphics_13 = new cjs.Graphics().p("A2BV8QpEpEAAs4QAAs4JEpJQJKpEM3AAQM4AAJEJEQJKJJAAM4QAAM4pKJEQpEJKs4AAQs3AApKpKg");
	var mask_graphics_14 = new cjs.Graphics().p("A2tWoQpVpWAAtSQAAtQJVpdQJcpVNRAAQNSAAJVJVQJdJdAANQQAANSpdJWQpVJctSAAQtRAApcpcg");
	var mask_graphics_15 = new cjs.Graphics().p("A3QXLQplpkAAtnQAAtmJlpqQJqplNmAAQNnAAJkJlQJrJqAANmQAANnprJkQpkJrtnAAQtmAApqprg");
	var mask_graphics_16 = new cjs.Graphics().p("A3sXnQpwpwAAt3QAAt2Jwp2QJ2pwN2AAQN3AAJwJwQJ2J2AAN2QAAN3p2JwQpwJ2t3AAQt2AAp2p2g");
	var mask_graphics_17 = new cjs.Graphics().p("A4AX6Qp4p4AAuCQAAuCJ4p+QJ+p4OCAAQOCAAJ4J4QJ/J+AAOCQAAOCp/J4Qp4J+uCABQuCgBp+p+g");
	var mask_graphics_18 = new cjs.Graphics().p("A4LYHQp9p9AAuKQAAuIJ9qEQKCp8OJAAQOJAAJ9J8QKDKEAAOIQAAOKqDJ9Qp9KDuJgBQuJABqCqDg");
	var mask_graphics_19 = new cjs.Graphics().p("A4PYKQp/p+AAuMQAAuKJ/qFQKEp/OLAAQOMAAJ+J/QKFKFAAOKQAAOMqFJ+Qp+KFuMAAQuLAAqEqFg");
	var mask_graphics_20 = new cjs.Graphics().p("A33XyQp0p0AAt+QAAt8J0p6QJ6p1N9AAQN9AAJ0J1QJ7J6AAN8QAAN+p7J0Qp0J6t9AAQt9AAp6p6g");
	var mask_graphics_21 = new cjs.Graphics().p("A3eXZQpqpqAAtvQAAttJqpxQJwpqNuAAQNuAAJqJqQJxJxAANtQAANvpxJqQpqJwtuAAQtuAApwpwg");
	var mask_graphics_22 = new cjs.Graphics().p("A3FXAQpfpgAAtgQAAtfJfpmQJmpfNfAAQNgAAJgJfQJlJmAANfQAANgplJgQpgJltgAAQtfAApmplg");
	var mask_graphics_23 = new cjs.Graphics().p("A2sWnQpVpWAAtRQAAtQJVpcQJcpVNQAAQNRAAJWJVQJbJcAANQQAANRpbJWQpWJbtRAAQtQAApcpbg");
	var mask_graphics_24 = new cjs.Graphics().p("A2TWOQpLpLAAtDQAAtBJLpSQJRpLNCAAQNCAAJMJLQJRJSAANBQAANDpRJLQpMJRtCAAQtCAApRpRg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:219.5,y:213.6}).wait(1).to({graphics:mask_graphics_1,x:220.2,y:214.1}).wait(1).to({graphics:mask_graphics_2,x:220.9,y:214.6}).wait(1).to({graphics:mask_graphics_3,x:221.5,y:215.1}).wait(1).to({graphics:mask_graphics_4,x:222.1,y:215.5}).wait(1).to({graphics:mask_graphics_5,x:222.7,y:215.9}).wait(1).to({graphics:mask_graphics_6,x:223.2,y:216.3}).wait(1).to({graphics:mask_graphics_7,x:223.7,y:216.7}).wait(1).to({graphics:mask_graphics_8,x:224.1,y:217}).wait(1).to({graphics:mask_graphics_9,x:224.6,y:217.3}).wait(1).to({graphics:mask_graphics_10,x:224.9,y:217.6}).wait(1).to({graphics:mask_graphics_11,x:225.3,y:217.8}).wait(1).to({graphics:mask_graphics_12,x:225.6,y:218}).wait(1).to({graphics:mask_graphics_13,x:225.8,y:218.2}).wait(1).to({graphics:mask_graphics_14,x:226,y:218.4}).wait(1).to({graphics:mask_graphics_15,x:226.2,y:218.5}).wait(1).to({graphics:mask_graphics_16,x:226.3,y:218.6}).wait(1).to({graphics:mask_graphics_17,x:226.4,y:218.7}).wait(1).to({graphics:mask_graphics_18,x:226.5,y:218.7}).wait(1).to({graphics:mask_graphics_19,x:226.5,y:218.7}).wait(1).to({graphics:mask_graphics_20,x:226.7,y:218.2}).wait(1).to({graphics:mask_graphics_21,x:226.8,y:217.7}).wait(1).to({graphics:mask_graphics_22,x:227,y:217.2}).wait(1).to({graphics:mask_graphics_23,x:227.1,y:216.7}).wait(1).to({graphics:mask_graphics_24,x:227.3,y:216.2}).wait(1));

	// Capa_1
	this.instance = new lib.imgmod1();
	this.instance.parent = this;
	this.instance.setTransform(225.5,217.5,1,1,0,0,0,386.9,219.2);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(25));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(202,196.1,35,35);


(lib.AS_LG_MOV_10 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,255,0.298)").s().p("AieF5QhKgfg4g5Qg4g5gghJQgghMAAhTQAAhSAghNQAghJA4g4QA4g5BKgfQBMggBSAAQBUAABLAgQBKAfA5A5QA4A4AfBJQAgBNAABSQAABTggBMQgfBJg4A5Qg5A5hKAfQhLAghUAAQhSAAhMggg");
	this.shape.setTransform(28.9,33.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(255,255,255,0.239)").s().p("AieF5QhKgfg4g5Qg4g5gghJQgghMAAhTQAAhSAghNQAghJA4g4QA4g5BKgfQBMggBSAAQBUAABLAgQBKAfA5A5QA4A4AfBJQAgBNAABSQAABTggBMQgfBJg4A5Qg5A5hKAfQhLAghUAAQhSAAhMggg");
	this.shape_1.setTransform(28.9,33.2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(255,255,255,0.18)").s().p("AieF5QhKgfg4g5Qg4g5gghJQgghMAAhTQAAhSAghNQAghJA4g4QA4g5BKgfQBMggBSAAQBUAABLAgQBKAfA5A5QA4A4AfBJQAgBNAABSQAABTggBMQgfBJg4A5Qg5A5hKAfQhLAghUAAQhSAAhMggg");
	this.shape_2.setTransform(28.9,33.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("rgba(255,255,255,0.118)").s().p("AieF5QhKgfg4g5Qg4g5gghJQgghMAAhTQAAhSAghNQAghJA4g4QA4g5BKgfQBMggBSAAQBUAABLAgQBKAfA5A5QA4A4AfBJQAgBNAABSQAABTggBMQgfBJg4A5Qg5A5hKAfQhLAghUAAQhSAAhMggg");
	this.shape_3.setTransform(28.9,33.2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("rgba(255,255,255,0.059)").s().p("AieF5QhKgfg4g5Qg4g5gghJQgghMAAhTQAAhSAghNQAghJA4g4QA4g5BKgfQBMggBSAAQBUAABLAgQBKAfA5A5QA4A4AfBJQAgBNAABSQAABTggBMQgfBJg4A5Qg5A5hKAfQhLAghUAAQhSAAhMggg");
	this.shape_4.setTransform(28.9,33.2);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("rgba(255,255,255,0)").s().p("AieF5QhKgfg4g5Qg4g5gghJQgghMAAhTQAAhSAghNQAghJA4g4QA4g5BKgfQBMggBSAAQBUAABLAgQBKAfA5A5QA4A4AfBJQAgBNAABSQAABTggBMQgfBJg4A5Qg5A5hKAfQhLAghUAAQhSAAhMggg");
	this.shape_5.setTransform(28.9,33.2);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("rgba(255,255,255,0.039)").s().p("AieF5QhKgfg4g5Qg4g5gghJQgghMAAhTQAAhSAghNQAghJA4g4QA4g5BKgfQBMggBSAAQBUAABLAgQBKAfA5A5QA4A4AfBJQAgBNAABSQAABTggBMQgfBJg4A5Qg5A5hKAfQhLAghUAAQhSAAhMggg");
	this.shape_6.setTransform(28.9,33.2);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("rgba(255,255,255,0.075)").s().p("AieF5QhKgfg4g5Qg4g5gghJQgghMAAhTQAAhSAghNQAghJA4g4QA4g5BKgfQBMggBSAAQBUAABLAgQBKAfA5A5QA4A4AfBJQAgBNAABSQAABTggBMQgfBJg4A5Qg5A5hKAfQhLAghUAAQhSAAhMggg");
	this.shape_7.setTransform(28.9,33.2);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("rgba(255,255,255,0.114)").s().p("AieF5QhKgfg4g5Qg4g5gghJQgghMAAhTQAAhSAghNQAghJA4g4QA4g5BKgfQBMggBSAAQBUAABLAgQBKAfA5A5QA4A4AfBJQAgBNAABSQAABTggBMQgfBJg4A5Qg5A5hKAfQhLAghUAAQhSAAhMggg");
	this.shape_8.setTransform(28.9,33.2);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("rgba(255,255,255,0.149)").s().p("AieF5QhKgfg4g5Qg4g5gghJQgghMAAhTQAAhSAghNQAghJA4g4QA4g5BKgfQBMggBSAAQBUAABLAgQBKAfA5A5QA4A4AfBJQAgBNAABSQAABTggBMQgfBJg4A5Qg5A5hKAfQhLAghUAAQhSAAhMggg");
	this.shape_9.setTransform(28.9,33.2);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("rgba(255,255,255,0.188)").s().p("AieF5QhKgfg4g5Qg4g5gghJQgghMAAhTQAAhSAghNQAghJA4g4QA4g5BKgfQBMggBSAAQBUAABLAgQBKAfA5A5QA4A4AfBJQAgBNAABSQAABTggBMQgfBJg4A5Qg5A5hKAfQhLAghUAAQhSAAhMggg");
	this.shape_10.setTransform(28.9,33.2);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("rgba(255,255,255,0.224)").s().p("AieF5QhKgfg4g5Qg4g5gghJQgghMAAhTQAAhSAghNQAghJA4g4QA4g5BKgfQBMggBSAAQBUAABLAgQBKAfA5A5QA4A4AfBJQAgBNAABSQAABTggBMQgfBJg4A5Qg5A5hKAfQhLAghUAAQhSAAhMggg");
	this.shape_11.setTransform(28.9,33.2);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("rgba(255,255,255,0.263)").s().p("AieF5QhKgfg4g5Qg4g5gghJQgghMAAhTQAAhSAghNQAghJA4g4QA4g5BKgfQBMggBSAAQBUAABLAgQBKAfA5A5QA4A4AfBJQAgBNAABSQAABTggBMQgfBJg4A5Qg5A5hKAfQhLAghUAAQhSAAhMggg");
	this.shape_12.setTransform(28.9,33.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape}]},1).wait(12));

	// Layer 1
	this.instance = new lib.AS_LG_153("single",0);
	this.instance.parent = this;
	this.instance.setTransform(35.9,14.9,1,1,0,0,0,23.9,23.9);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#DC6842").s().p("AiEE7Qg9gagwgvQgvgvgag+Qgbg/AAhGQAAhFAbg/QAag+AvgvQAwgvA9gaQBAgbBEAAQBGAAA/AbQA+AaAvAvQAwAvAaA+QAaA/AABFQAABGgaA/QgaA+gwAvQgvAvg+AaQg/AbhGAAQhEAAhAgbg");
	this.shape_13.setTransform(28.8,32.8);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#EFEFEF").s().p("AmdPUQi/hRiTiTQiTiThRi/QhUjFAAjZQAAjXBUjGQBRi/CTiTQCTiTC/hRQDGhUDXABQDYgBDGBUQC/BRCTCTQCTCTBRC/QBTDGABDXQgBDZhTDFQhRC/iTCTQiTCTi/BRQjGBUjYgBQjXABjGhUg");
	this.shape_14.setTransform(28.9,33.1,0.385,0.385);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_14},{t:this.shape_13},{t:this.instance}]}).wait(25));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-12,-7.7,81.8,81.8);


(lib.titulomodulo2TMR = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_86 = function() {
		this.stop();
		parent.siguiente_naranja();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(86).call(this.frame_86).wait(1));

	// Capa_3
	this.instance = new lib.mc_numMod01();
	this.instance.parent = this;
	this.instance.setTransform(219.5,213.6,1,1,0,0,0,26.6,32.8);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(4).to({_off:false},0).to({scaleX:8.6,scaleY:8.6,x:227.3,y:220.1},20).to({scaleX:7.71,scaleY:7.71,y:220},10).to({scaleX:7.63,scaleY:7.63,rotation:360,x:648.6,y:219.9},15).to({regY:32.7,scaleX:1,scaleY:1,x:542.6,y:152},14,cjs.Ease.get(1)).to({x:692.6},11,cjs.Ease.get(1)).wait(13));

	// Capa_5
	this.instance_1 = new lib.tapabca("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(647.8,152.3,1,1,0,0,0,106.5,44.6);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(63).to({_off:false},0).to({regX:106.6,scaleX:0.44,x:767.8},11,cjs.Ease.get(1)).to({_off:true},1).wait(12));

	// Capa_2
	this.instance_2 = new lib.txt_modulo();
	this.instance_2.parent = this;
	this.instance_2.setTransform(567.9,155.3,1,1,0,0,0,87.3,28.8);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(63).to({_off:false},0).wait(24));

	// Capa_7
	this.instance_3 = new lib.Tema("synched",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(1026.7,242.6,1,1,0,0,0,132.1,45.9);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(71).to({_off:false},0).to({x:614.7},15,cjs.Ease.get(1)).wait(1));

	// Capa_1
	this.instance_4 = new lib.mc_imagenmodulo("synched",0,false);
	this.instance_4.parent = this;
	this.instance_4.setTransform(225.5,217.4,1,1,0,0,0,225.5,217.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(87));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(8,0.2,437.1,435.9);


(lib.mc_infoRecuerda02 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_28 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(28).call(this.frame_28).wait(1));

	// icono
	this.instance = new lib.AS_LG_MOV_10();
	this.instance.parent = this;
	this.instance.setTransform(-154.4,11.9,1,1,0,0,0,30,29.9);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:-243.7,y:-67.7},26,cjs.Ease.get(1)).to({x:-244.1,y:-68.1},2).wait(1));

	// Layer 3
	this.instance_1 = new lib.barrabcdespliega("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(-454.1,-54.6,0.027,2.591,0,0,0,389.1,39.9);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({_off:false},0).to({alpha:0},26,cjs.Ease.get(1)).to({_off:true},1).wait(1));

	// Layer 1
	this.instance_2 = new lib.info01();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-62,-42);
	this.instance_2.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({x:-25.3,y:0,alpha:1},28,cjs.Ease.get(1)).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-466.2,-100.6,365,156.7);


(lib.mc1T1M2TMR = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_340 = function() {
		this.stop();
		
		parent.comando("terminar");
		parent.siguiente_verde();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(340).call(this.frame_340).wait(1));

	// CIRCULO1
	this.instance = new lib.estrategia1("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(678.5,255.9,0.23,0.23,0,0,0,91.4,91.4);
	this.instance.alpha = 0.23;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(199).to({_off:false},0).to({scaleX:1,scaleY:1,y:73.9,alpha:1},21,cjs.Ease.get(1)).wait(121));

	// CIRCULO2
	this.instance_1 = new lib.puestos1("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(671.7,265.8,0.26,0.26,0,0,0,91.4,91.4);
	this.instance_1.alpha = 0.102;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(236).to({_off:false},0).to({scaleX:1,scaleY:1,x:538,y:296.7,alpha:1},21,cjs.Ease.get(1)).wait(84));

	// CIRCULO3
	this.instance_2 = new lib.perfoles1("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(682.8,260.1,0.291,0.291,0,0,0,91.2,91.2);
	this.instance_2.alpha = 0.102;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(269).to({_off:false},0).to({regX:91.4,regY:91.4,scaleX:1,scaleY:1,x:801.1,y:296.7,alpha:1},19,cjs.Ease.get(1)).wait(53));

	// detapa txt circulo
	this.instance_3 = new lib.tapabca2("synched",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(673.4,210.5,0.91,0.814,0,0,0,107,45);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(220).to({_off:false},0).to({alpha:0},12,cjs.Ease.get(1)).wait(25).to({x:532.9,y:427.3,alpha:1},0).to({y:425.3,alpha:0},11,cjs.Ease.get(1)).wait(20).to({x:792.9,y:427.3,alpha:1},0).to({alpha:0},11,cjs.Ease.get(1)).wait(42));

	// Txt circulo
	this.text = new cjs.Text("Estrategia del Negocio", "bold 20px 'Arial'", "#333333");
	this.text.textAlign = "center";
	this.text.lineHeight = 22;
	this.text.lineWidth = 125;
	this.text.parent = this;
	this.text.setTransform(678.4,170.1);

	this.text_1 = new cjs.Text("Puestos Críticos", "bold 20px 'Arial'", "#333333");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 22;
	this.text_1.lineWidth = 125;
	this.text_1.parent = this;
	this.text_1.setTransform(537.9,394.4);

	this.text_2 = new cjs.Text("Perfiles de Éxito", "bold 20px 'Arial'", "#333333");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 22;
	this.text_2.lineWidth = 125;
	this.text_2.parent = this;
	this.text_2.setTransform(801.1,394.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text}]},220).to({state:[{t:this.text_1},{t:this.text}]},37).to({state:[{t:this.text_2},{t:this.text_1},{t:this.text}]},31).wait(53));

	// m2t1mc1 txt1
	this.instance_4 = new lib.m2t1mc1txt1("synched",0);
	this.instance_4.parent = this;
	this.instance_4.setTransform(135.6,88.4,1,1,0,0,0,187,42.2);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(132).to({_off:false},0).to({x:215.6,alpha:1},23,cjs.Ease.get(1)).wait(186));

	// m2t1mc1 txt2
	this.instance_5 = new lib.m2t1mc1txt2("synched",0);
	this.instance_5.parent = this;
	this.instance_5.setTransform(294.9,170.2,1,1,0,0,0,186.3,22.1);
	this.instance_5.alpha = 0;
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(164).to({_off:false},0).to({x:214.9,alpha:1},23,cjs.Ease.get(1)).wait(154));

	// TIP
	this.info = new lib.mc_infoRecuerda02();
	this.info.parent = this;
	this.info.setTransform(454.6,306);
	this.info._off = true;

	this.timeline.addTween(cjs.Tween.get(this.info).wait(304).to({_off:false},0).wait(37));

	// guia
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CCCCCC").s().p("Ah7CCQgyg1AAhNQAAhLAyg3QAzg2BIAAQBIAAA0A2QAzA3gBBLQABBNgzA1Qg0A2hIAAQhIAAgzg2g");
	this.shape.setTransform(-131.8,477.2);

	this.timeline.addTween(cjs.Tween.get(this.shape).to({_off:true},1).wait(340));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-149.2,458.8,34.9,36.9);


// stage content:
(lib.AC_TMR_M02_01 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		parent.comando("iniciar",this);
	}
	this.frame_1 = function() {
		this.stop();
		parent.comando("resetear");
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// TITULO
	this.instance = new lib.tema_entrada_titulo();
	this.instance.parent = this;
	this.instance.setTransform(303.6,249.9);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).wait(1));

	// PAGINAS
	this.instance_1 = new lib.titulomodulo2TMR();
	this.instance_1.parent = this;
	this.instance_1.setTransform(380,245.4,1,1,0,0,0,323.9,217.4);

	this.instance_2 = new lib.mc1T1M2TMR();
	this.instance_2.parent = this;
	this.instance_2.setTransform(17.4,40.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1}]}).to({state:[{t:this.instance_2}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(336.6,247.3,734.6,480);
// library properties:
lib.properties = {
	width: 950,
	height: 500,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/mod02_c_istock_831277780.jpg?1551146882055", id:"mod02_c_istock_831277780"}
	],
	preloads: []
};




})(lib = lib||{}, images = images||{}, createjs = createjs||{}, ss = ss||{}, AdobeAn = AdobeAn||{});
var lib, images, createjs, ss, AdobeAn;